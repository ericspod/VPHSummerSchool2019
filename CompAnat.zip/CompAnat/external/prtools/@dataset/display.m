%DISPLAY Display dataset information

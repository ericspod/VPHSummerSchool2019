%GETFEATDOM Get feature domain of a dataset
%
%	FEATDOM = GETFEATDOM(A,K)
%
% Returns the cell array with the feature domains of the dataset A.

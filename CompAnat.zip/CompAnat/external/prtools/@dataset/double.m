%DOUBLE Dataset to double conversion
%
%	D = double(A)
%
% Converts a dataset A to a double D, which is just the set of datavectors.

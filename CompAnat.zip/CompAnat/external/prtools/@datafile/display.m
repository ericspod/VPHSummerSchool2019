%DISPLAY Display datafile information

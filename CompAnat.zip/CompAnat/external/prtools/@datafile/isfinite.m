%ISFINITE Datafile overload

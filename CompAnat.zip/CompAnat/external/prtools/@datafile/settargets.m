%SETTARGETS Reset targets or soft labels of datafile
%
%     A = SETTARGETS(A,TARGETS)
%
% TARGETS should be a datafile with feature labels
% (FEATLAB) used for the desired LABLIST.

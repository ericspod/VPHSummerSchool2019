%CHECK12 Decide between monadic and dyadic datafile operations
%
% [CHECK,A,B] = CHECK12(A,B)

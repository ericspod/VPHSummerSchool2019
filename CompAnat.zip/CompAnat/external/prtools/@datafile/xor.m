%XOR Datafile overload

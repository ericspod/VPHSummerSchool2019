function [flag nii_info] = CallNiftiInfo(NIIfile)
% Function to wrap how the command info.exe from the IRTK library is
% called, making it robust to different platforms.
% 
% IRTK: http://www.doc.ic.ac.uk/~dr/software/


%setenv('mainPath', '/chosen_path') must be set in the main script indicating the
%main directory in which /external/info is located, where '/chosen_path' is
%e.g. /home/user/code/PabloCubicHermite
%If 'mainPath' is not found, the command will load info from current 
%location: pwd()+'/external/info'

if isunix()    
    directoryPath = getenv('mainPath');

    if ~isempty(directoryPath) %if path is found, add '/' to access subfolders
        directoryPath = [directoryPath '/'];
    end
            
    command = [directoryPath 'external/info "' NIIfile '"'];    
else
    command = ['info "' NIIfile '"'];
end
fprintf('   ... calling info with command: %s\n',command);
[flag nii_info] = system(command);

if flag~=0
     fprintf(' ERROR! Command "info" (from IRTK) did not succeed!\n')
     fprintf('     Is the executable available in the system? \n')
     fprintf('     Output obtained: %s\n',nii_info);
     fprintf(' This is needed to capture the rotation matrix from the header of the NII file \n');
end
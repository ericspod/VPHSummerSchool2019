function [] = PlotContours(C)
    for c = 1:numel(C)
      try,
            hold on
              plot3d( C(c).Points3D * C(c).RotationMatrix , 'color',rand(1,3) )
            hold off
      end
    end
    axis equal;
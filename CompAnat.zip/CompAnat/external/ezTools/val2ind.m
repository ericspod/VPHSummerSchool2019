function i = val2ind( g , x )

  [~,i] = min( abs( bsxfun( @minus , g(:) , x(:).' ) ) );
  i = reshape( i , size(x) );

end

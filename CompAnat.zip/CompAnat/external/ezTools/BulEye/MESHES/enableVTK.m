function enableVTK

  try
    evalc( 'vtkPolyDataReader()' );
    return;
  catch
    switch computer
      case 'PCWIN64'
        setenv( 'path' , [ getenv('path') , ';' , fullfile( fileparts(which('enableVTK')) , 'vtk' , 'w64' ) ] );
      
      case 'PCWIN32'
        setenv( 'path' , [ getenv('path') , ';' , fullfile( fileparts(which('enableVTK')) , 'vtk' , 'w32' ) ] );

%       case 'linux64'....  
        
      otherwise
        error('cannot enable VTK within a matlab runtime.')
    end
  end

  try
    evalc( 'vtkPolyDataReader()' );
  catch
    error('VTK couldn''t be enabled.');
  end
  
end

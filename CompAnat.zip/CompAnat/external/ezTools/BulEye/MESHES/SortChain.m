function C = SortChain( ids , tri )


  if isstruct( tri ), tri = tri.tri; end
  if isempty( ids ), ids = unique( tri(:) ); end

  tri( ~any( ismember( tri , ids(:) ) , 2 ) , : ) = [];

  E = [];
  for c = 1:size(tri,2)-1
    E = [ E ; tri(:,[c c+1]) ];
  end
  E = [ E ; tri(:,[end 1]) ];
  
  E( any( ~E , 2 ) , : ) = [];
  E( ~all( ismember( E , ids(:) ) , 2 ) , : ) = [];
  E = sort( E , 2 );
  E = unique( E , 'rows' );
  
  C = {};
  while ~isempty( ids )
    E( ~all( ismember( E , ids(:) ) , 2 ) , : ) = [];
    if isempty( E ), break; end
    
    valence = accumarray( E(:) , 1 );
    
                      LN = find( valence == 1 , 1 );
    if isempty( LN ), LN = find( valence , 1 ); end
    
    C{end+1} = LN; ids( ids == LN ) = [];
    while 1
      NN = setdiff( E( any( E == LN , 2 ) , : ) , C{end} );
      if isempty( NN ), break; end
      LN = min( NN );
      C{end} = [ C{end} , LN ]; ids( ids == LN ) = [];
    end
    
    LN = C{end}(1);
    while 1
      NN = setdiff( E( any( E == LN , 2 ) , : ) , C{end} );
      if isempty( NN ), break; end
      LN = min( NN );
      C{end} = [ LN , C{end} ]; ids( ids == LN ) = [];
    end
    
    
  end
  
  C = [ C , num2cell( ids(:).' ) ];
 
end

function [H] = BullsEye(CH,options)
% Function to generate the BullsEye of the thickness of a Cubic Hermite
% mesh. You need to define two options to make it work with an arbitrary LV
% mesh:
% - iPosterior: Index of the node in the Cubic Mesh that points in the 
%   posterior direction. This depends on the topology
% - Azimut2orientBullseye

enableVTK

% Default options:
Azimut2orientBullseye = -65; % angulation to correct the A-P-L-R orientation of the bullseye
discretization = 5;     % In each local Xi direction of the finite element
iPosterior = 124;       % 
MinThickness =  0;
MaxThickness = 1;
bDebug = 0;
nRows = 1;
iRow  = 1;
bNewFig = 1;
bColumn = 0;
bColorbar = 0;

if nargin>=2
    if isfield(options,'discretization'), discretization = options.discretization; end
    if isfield(options,'iPosterior'), iPosterior = options.iPosterior; end
    if isfield(options,'MinThickness'), MinThickness = options.MinThickness; end
    if isfield(options,'MaxThickness'), MaxThickness = options.MaxThickness; end
    if isfield(options,'bNewFig'), bNewFig = options.bNewFig; end
    if isfield(options,'nRows'), nRows = options.nRows; end
    if isfield(options,'iRow'), iRow = options.iRow; end
    if isfield(options,'bColumn'), bColumn = options.bColumn; end
    if isfield(options,'bColorbar'), bColorbar = options.bColorbar; end
    if isfield(options,'Azimut2orientBullseye'), Azimut2orientBullseye = options.Azimut2orientBullseye; end
    
end

% I = loadI3D('E:\Dropbox\WORK\Sohini\translation_on_SA\DTI001.gipl');
% load('DTI001.ch','-mat')
if ~isa(CH,'CubicMeshClass');
    % this should be the path to the mesh
    CH = CubicMeshClass(CH);
end


%% Orient correctly, in vertical and with the septum in the right direction
    [OrientMatrix] = GetLVmeshOrientation(CH,iPosterior);
    Mvertical = inv(OrientMatrix);
    CH = CH.rotateMesh(Mvertical);

%% 1. Tesselate the continous C.Hermite mesh:
CH = CH.FindExternalSurfaces;

[Elements,ENDO_id] = CH.FindEndoElements();
ENDO = [];
for e = Elements(:).'
%  disp(e)
  [ M.tri , M.xyz ] = CH.tesselateElementFace(e,ENDO_id,discretization);
  if isempty( ENDO ), ENDO = M; 
  else
    kk = AppendMeshes( ENDO , M );
    ENDO = kk;
  end
end


[Elements,EPI_id] = CH.FindEpiElements();
EPI = [];
for e = Elements(:).'
%  disp(e);
  [ M.tri , M.xyz ] = CH.tesselateElementFace(e,EPI_id,discretization);
  if isempty( EPI ), EPI = M;
  else
    kk = AppendMeshes( EPI , M );
    EPI = kk;
  end
end

if(bDebug)
     plotMESH( EPI  , 'FaceColor','b' ,'FaceAlpha',0.5);
    hplotMESH( ENDO , 'FaceColor','r' );
end
%% 2. Clean the meshes (merge nodes with different IDS but in the same location, remove collapsed elements such the ones in the APEX, etc )

ENDO = TidyMesh( ENDO , 1e-4 );
EPI  = TidyMesh( EPI  , 1e-4 );

bENDO = MeshBoundary( ENDO );
bEPI  = MeshBoundary( EPI  );

if(bDebug)
     plotMESH(  EPI  , 'FaceColor','b' ,'EdgeColor' , 'none' ,'FaceAlpha',0.4);
    hplotMESH( bEPI  , 'EdgeColor' , 'k' );

    hplotMESH(  ENDO , 'FaceColor','r' ,'EdgeColor' , 'none' );
    hplotMESH( bENDO , 'EdgeColor' , 'k' );
end

%% 3 computing the thickness (distance from Nodes of EPI to Surface ENDO)

[ id_closestTriangle , xyz_closestPpoint , EPI.xyzTHICKNESS ] = vtkClosestElement( ENDO , EPI.xyz );
%I'm used to calling the attributes of the nodes with the 'xyz' prefix and
%with the prefix 'tri' for the attributes of the triangles also called
%faces or elements.

if(bDebug)
    plotMESH( EPI , 'FaceColor','interp','CData',EPI.xyzTHICKNESS,'EdgeColor','none');
    colormap jet; colorbar
end

%% Building the bull-eye plots

%find the APEX
valence = accumarray( EPI.tri(:) , 1 );
[~,APEXid] = max(valence);

%Thanks to the topology of the mesh it is easy to find "equatorial" rings
rings = {APEXid};
while 1
  rings{end+1,1} = setdiff( EPI.tri( any( ismember( EPI.tri , cell2mat(rings) ) , 2 ) , : ) , cell2mat(rings) );
  if isempty( rings{end} ), rings( end , : ) = []; break; end
  rings{end} = SortChain( rings{end} , EPI.tri ); rings{end} = rings{end}{1}.';
end
rings{1} = rings{1} + zeros(size(rings{2}));

% Eventually, the rings have to be reordered...
for r = 2:numel(rings)
  thisRing = rings{r};
  [~,minID] = min( thisRing );
  thisRing = circshift( thisRing , [ 1-minID , 0 ]);
  if EPI.xyz( thisRing(2) ,3) > EPI.xyz( thisRing(1) ,3) 
    thisRing = circshift( flip( thisRing ,1) ,1);
  end
  %thisRing = flip( thisRing , 1 );   %si quieres que vaya CW o CCW
                                         %prueba a ver cual te viene mejor, pero en principio deberian ser consistentes!
  rings{r} = thisRing;
end
% 
% for r = 2:numel(rings)
%   bestE = Inf;
%   for s = 1:numel( rings{r} )
%     thisRing = rings{r}([s:end 1:s-1]);
%     thisE    = norm( EPI.xyz( rings{r-1} , : ) - EPI.xyz( thisRing , : ) , 'fro' );
%     if thisE < bestE, bestE = thisE; bestRing = thisRing; end
%   end
%   
%   %...and may be moved along the opposite direction.
%   rings{r} = rings{r}(end:-1:1);
%   for s = 1:numel( rings{r} )
%     thisRing = rings{r}([s:end 1:s-1]);
%     thisE    = norm( EPI.xyz( rings{r-1} , : ) - EPI.xyz( thisRing , : ) , 'fro' );
%     if thisE < bestE, bestE = thisE; bestRing = thisRing; end
%   end
%     
%   rings{r} = bestRing;
% end

if(bDebug)
    plotMESH( EPI );cellfun(@(r)hplot3d( EPI.xyz( r , : ) , 'linewidth',4,'color',rand(1,3)),rings)

    plotMESH( EPI );arrayfun(@(t)hplot3d( EPI.xyz( cellfun(@(r)r(t),rings) , : ) , 'linewidth',3,'color',rand(1,3)),1:numel(rings{1}))
end

%{
%if the rings were not be reordered, you can obtain something like...
rings_no_order = cellfun( @(r)circshift(r, randi(numel(r),1)) , rings , 'un',0 )
plotMESH( EPI );arrayfun(@(t)hplot3d( EPI.xyz( cellfun(@(r)r(t),rings_no_order) , : ) , 'linewidth',3,'color',rand(1,3)),1:numel(rings_no_order{1}))
%}

%starting from septum?
rings = cellfun( @(r)r( [ (1+2*(discretization-1)):end , 1:(1+2*(discretization-1)) ] ).' , rings , 'un' , false );

%closing each ring (making they cyclic)
rings = cellfun( @(r)[ r(:).' , r(1) ] , rings , 'un' , false );

%the rings define a system of polar coordinates
RS = linspace(0,1,numel(rings));                    %radius
TS = linspace(0,2*pi,numel(rings{1})); TS(end) = 0;  %angle theta

%from polar to cartesian
X = bsxfun(@times,RS.',cos(TS));  
Y = bsxfun(@times,RS.',sin(TS));

EPI.bull( cell2mat(rings) , 1 ) = X(:);
EPI.bull( cell2mat(rings) , 2 ) = Y(:);
EPI.bull( cell2mat(rings) , 3 ) = 0;     %z-coordinates equal 0

%%

%compare the map in the original anatomy and in the 'bulleye' plot
if(bNewFig)
    H = figure('color',[1 1 1],'OuterPosition',[500 300 800 700]);
else
    H = gca;
end
    
if ~bColumn
    subplot(nRows,2,1+(iRow-1)*2);
else
    subplot(2,nRows,iRow);
end
plotMESH( EPI , 'FaceColor','interp','CData',EPI.xyzTHICKNESS,'EdgeColor','none'); caxis([MinThickness MaxThickness]); colormap(jet);
hSPHERE = line(NaN,NaN,NaN,'Marker','o','Color','k','MarkerFaceColor','m','MarkerSize',10,'LineWidth',2);
hold on;
CH.plotExternalSurfaces('k')
view(-90,-65)
axis('off')

if ~bColumn
    subplot(nRows,2,2+(iRow-1)*2);
    location = 'North';
else
    subplot(2,nRows,nRows + iRow);
    location = 'East';
end
h = plotMESH( struct('xyz',EPI.bull,'tri',EPI.tri) , 'FaceColor','interp','CData',EPI.xyzTHICKNESS,'EdgeColor','none'); caxis([MinThickness MaxThickness]); colormap(jet);
setPOS = @(h,xyz)set(h,'XData',xyz(:,1),'YData',xyz(:,2),'ZData',xyz(:,3));
set( gcf , 'WindowButtonMotionFcn' , @(~,e)setPOS( hSPHERE , ...
  mean( EPI.xyz( EPI.tri( vtkClosestElement( struct('xyz',EPI.bull,'tri',EPI.tri) , mean(get( get(h,'Parent') ,'CurrentPoint') ,1) ) ,:) ,:) ,1) ) );

m = 1.3;
t = 1.15;
d = 0.06; % character delta in horizontal
axis([-m m -m m])

% The angle to callibrate the bulls-eye, and to flip it upside down!
Az = Azimut2orientBullseye;
view(Az,-90)
% Now add the labels of R, L, A, P:
sift = pi*(Az)/180;
RR = [cos(sift) -sin(sift);
      sin(sift) cos(sift)];
P1 = t*[-1-d 0]'; RP1 = RR*P1;
text(RP1(1), RP1(2),'R')
P2 = t*[1-d 0]'; RP2 = RR*P2;
text( RP2(1), RP2(2),'L')
P3 = t*[0-d -1]'; RP3 = RR*P3;
text( RP3(1), RP3(2),'A')
P4 = t*[0-d 1]'; RP4 = RR*P4;
text( RP4(1), RP4(2),'P')
axis('off')
if (bColorbar)
    if iRow ==1
        colorbar('Location',location)
    end
end
zoom(1.3);



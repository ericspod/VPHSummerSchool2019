#include "myMEX.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) { ALLOCATES();
  char    myERROR[128] = "";
  real   *O;
  real   **INPUTS = NULL;
  int    *sz  = NULL;
  int    *E   = NULL;
  int    n, c, C, r, R, j, i, e;
  double v;

  
  C = 0;
  for( n = 0 ; n < nrhs ; n++ ){
    if( myNumel( prhs[n] ) ){
      C++;
    }
  }
  if( !C ){
    plhs[0] = mxCreateDoubleMatrix( 0 , 0 , mxREAL );
    goto EXIT;
  }
  
  
  sz     = (int   *)  mxMalloc(  C    * sizeof(int   ) );
  E      = (int   *)  mxMalloc( (C+1) * sizeof(int   ) );
  INPUTS = (real **)  mxMalloc(  C    * sizeof(real *) );
  E[0] = 1; c = 0;
  for( n = 0 ; n < nrhs ; n++ ){
    sz[c] = myNumel( prhs[n] );
    if( !sz[c] ){ continue; }

    INPUTS[c] = myGetPr( prhs[n] );
    E[c+1] = E[c] * sz[c];
    c++;
  }
  R = E[c];

  plhs[0] = mxCreateDoubleMatrix( R , C , mxREAL );
  O       = mxGetPr( plhs[0] );
  for( c = 0 ; c < C ; c++ ){
    n = E[c];
    e = E[c+1] - n;
    for( i = 0 ; i < sz[c] ; i++ ){
      v = INPUTS[c][i];
      
      for( r = n*i ; r < R ; r += e ){
        for( j = 0 ; j < n ; j++ ){
          O[r++] = v;
        }
      }
    }
    O += R;
  }

    
  EXIT:
    if( INPUTS != NULL ){ mxFree( INPUTS ); }
    if( E      != NULL ){ mxFree( E      ); }
    if( sz     != NULL ){ mxFree( sz     ); }
    myFreeALLOCATES();
}

function item = DICOMxinfo( item , varargin )
% 
% DICOMxinfo( item , '^(?!Private_).*' )
% DICOMxinfo( item , '^x.*' )
% DICOMxinfo( item , 'xSpatialTransform' )
% DICOMxinfo( item , 'xSpatialTransform' , '' )
% DICOMxinfo( item , 'uid$' , '' )
% DICOMxinfo( item , 'Med' , '' )
% DICOMxinfo( item , '(?i)MEd' , '' )
% 

  if ischar( item )
    fn = item;
    item = NaN;
    if isnan( item )
      try, item = dicominfo( fn ); end
    end
    if isnumeric( item ) && isnan( item )
      IOpath = { fullfile( fileparts( mfilename('fullpath') ) , 'dicomIO' ) };
      swarn = warning('off','MATLAB:rmpath:DirNotFound');
      for io = 1:numel( IOpath )
        rmpath( IOpath{io} );
        try, item = dicominfo( fn ); break; end

        addpath( IOpath{io} );
        try, item = dicominfo( fn ); break; end
        rmpath( IOpath{io} );
      end
      warning( swarn );
    end
    if isnumeric( item ) && isnan( item ), return; end
  end
  
  %adding some extra useful information
  %%%%
  try,
  [p,f,e] = fileparts( item.Filename );
  item.xDirname = p;
  item.xFilename = [ f , e ];
  end
  
  %%%%
  if ~isfield( item , 'xPatientName' )
    try, item.xPatientName = item.PatientName.FamilyName;
    end
  end
  
  if ~isfield( item , 'xDatenum' )
    try,   item.xDatenum = DICOMdatenum( item );                  %#ok<TRYNC>
    end
  end
  
  %%%%
  if ~isfield( item , 'xSize' )
    try,   item.xSize = [ item.Rows ,  item.Columns ];
    catch, item.xSize = [ 0 , 0 ];
    end
    try,   item.xSize = [ item.xSize , item.SamplesPerPixel ];
    catch, item.xSize = [ item.xSize , 1 ];
    end
    try,   item.xSize = [ item.xSize , item.NumberOfFrames ];
    catch, item.xSize = [ item.xSize , 1 ];
    end
  end

  item.xNormal = [];
  try
    R = reshape( item.ImageOrientationPatient , 3 , 2 );
    N = cross( R(:,1), R(:,2) );
    for it = 1:5, N = N/sqrt( N(:).' *  N(:) ); end

    item.xNormal = N;
  end
  
  
  
  item.xRotationMatrix = [];
  try
    R = reshape( item.ImageOrientationPatient , 3 , 2 );
    R(:,3)= cross( R(:,1), R(:,2) );
    for cc = 1:3, for it = 1:5, R(:,cc) = R(:,cc)/sqrt( R(:,cc).' * R(:,cc) ); end; end

    item.xRotationMatrix = R;
  end
  
  
  if ~isfield( item , 'xSpatialTransform' )
    item.xSpatialTransform = [];
    try
      item.xSpatialTransform = [ item.xRotationMatrix , item.ImagePositionPatient(:) ; 0 0 0 1 ];
    end
  end  
  
  if ~isfield( item , 'xZLevel' )
    try
      Z = item.ImagePositionPatient;
      Z = R(1:3,1:3).'*Z(:);
      item.xZLevel = Z(3);
    end
  end 
  
  if ~isfield( item , 'xPhase' ) && any( ismember( varargin , 'xPhase' ) )
    item.xPhase = -1;
    try
      [d,fn,e] = fileparts( item.Filename ); fn = [fn,e];
      p = dir( d );
      p( [p.isdir] ) = [];
      p( strncmp( {p.name} , '.#.', 3 ) ) = [];
      for f=1:numel(p), p(f).name = fullfile( d , p(f).name ); end
      p = DICOMheader( p , 'MediaStorageSOPInstanceUID','SeriesInstanceUID','TriggerTime','SliceLocation');
      p( [ p.SliceLocation ] ~= item.SliceLocation ) = [];
      p( ~strcmp( { p.SeriesInstanceUID } , item.SeriesInstanceUID ) ) = [];
      [~,ord] = sort( [ p.TriggerTime ] );
      p = p(ord);
      item.xPhase = find( strcmp( { p.MediaStorageSOPInstanceUID } , item.MediaStorageSOPInstanceUID ) );
    end
  end 
  %%%%

  try
    [d,fn,e] = fileparts( item.Filename ); fn = [fn,e];
    p = dir( d );
    p( [p.isdir] ) = [];
    p( ~strncmp( {p.name} , '.#.', 3 ) ) = [];
    p( strcmp( {p.name} , fn ) ) = [];
    for f=1:numel(p), p(f).name = fullfile( d , p(f).name ); end
    p = DICOMheader( p , 'MediaStorageSOPInstanceUID' );
    p( ~strcmp( {p.MediaStorageSOPInstanceUID} , item.MediaStorageSOPInstanceUID ) ) = [];
    for f = 1:numel(p)
      xitem = dicominfo( p(f).name );
      
      for a = fieldnames( xitem ).', a = a{1};
        if isfield( item , a ) 
          if ~isidentical( item.(a) , xitem.(a) )
            %"ird" means "in replicated dicom"
            item.(['ird_', a]) = xitem.(a);
          end
        else
          item.(a) = xitem.(a);
        end
      end
    end
  end
  
  
  
  if numel( varargin ) == 1
    try
      item = item.(varargin{1});
      varargin(1) = [];
    end
  end  
    
  if ~isempty( varargin )
    fn = fieldnames( item );
    w = false;
    for v = 1:numel( varargin )
      if isempty( varargin{v} ), continue; end
      w = w | ~cellfun( 'isempty' , regexp( fn , varargin{v} , 'once' ) );
    end
    item = rmfield( item , fn(~w) );
  end
  
end

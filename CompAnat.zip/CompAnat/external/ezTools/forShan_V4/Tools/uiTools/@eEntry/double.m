function x = double(eE)

  x= eE.return_fcn( get( eE.slider,'Value' ) );

end

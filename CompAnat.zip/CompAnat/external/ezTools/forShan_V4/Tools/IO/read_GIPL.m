function [I,H] = read_GIPL( fname , varargin )

  if ~isfile( fname )
    error('imposible to open file');
  end

  onlyHDR = false;
  [varargin,onlyHDR] = parseargs(varargin,'onlyHDR' ,'$FORCE$',{true,onlyHDR});
  
  asStruct = false;
  [varargin,asStruct] = parseargs(varargin,'struct' ,'$FORCE$',{true,asStruct});
  
  if numel( varargin ) && varargin{1}
    asStruct = true;
  end
  
  if asStruct, onlyHDR = false; end
  

  H = struct();

  FID = fopen( fname , 'r' , 'ieee-be' );
  CLEANUP = onCleanup( @()fclose(FID) );

% trans_type{1}='binary'; trans_type{7}='char'; trans_type{8}='uchar'; 
% trans_type{15}='short'; trans_type{16}='ushort'; trans_type{31}='uint'; 
% trans_type{32}='int';  trans_type{64}='float';trans_type{65}='double'; 
% trans_type{144}='C_short';trans_type{160}='C_int';  trans_type{192}='C_float'; 
% trans_type{193}='C_double'; trans_type{200}='surface'; trans_type{201}='polygon';
% 
% trans_orien{0+1}='UNDEFINED'; trans_orien{1+1}='UNDEFINED_PROJECTION'; 
% trans_orien{2+1}='AP_PROJECTION';  trans_orien{3+1}='LATERAL_PROJECTION'; 
% trans_orien{4+1}='OBLIQUE_PROJECTION'; trans_orien{8+1}='UNDEFINED_TOMO'; 
% trans_orien{9+1}='AXIAL'; trans_orien{10+1}='CORONAL'; 
% trans_orien{11+1}='SAGITTAL'; trans_orien{12+1}='OBLIQUE_TOMO';

  H.FileName      = fname;

  fseek(FID,0,'eof');
  H.FileSize = ftell(FID);

  fseek(FID, 0,'bof');

  H.Dimensions         = fread(FID, 4,'uint16=>double').';
  if H.Dimensions(4)==1, maxdim=3;
  else,                  maxdim=4;
  end
  
  H.ImageType       = fread(FID, 1,'uint16');

  H.PixelDimensions = fread(FID, 4,'single=>double').';
  H.PixelDimensions = H.PixelDimensions(1:maxdim);

  H.Patient         = strtrim( fread(FID, 80, '*char').' );

  H.Matrix          = fread(FID, 20,'single=>double').';

  H.Orientation     = fread(FID, 1, '*uint8');
  
  H.Par2            = fread(FID, 1, '*uint8');
  
  H.VoxelMin        = fread(FID, 1, 'double');
  H.VoxelMax        = fread(FID, 1, 'double');

  H.Origin          = fread(FID, 4,'double').';
  H.Origin          = H.Origin( 1:maxdim );
  
  H.PixValOffset    = fread(FID, 1,'single');
  H.PixValCal       = fread(FID, 1,'single');
  H.InterSliceGap   = fread(FID, 1,'single');
  H.UserDef         = fread(FID, 1,'single');

  MagicNumber = fread(FID, 1,'*uint32');
  
  if onlyHDR
    if ~isequal( MagicNumber , 4026526128 )
      warning('file corrupt - or not big endian');
    end
    I = [];
    return;
  end

  if ~isequal( MagicNumber , 4026526128 )
    error('file corrupt - or not big endian');
  end
  
  switch H.ImageType
    case 1,  datasize = prod(H.Dimensions)*(1/8);   datatype = 'bit1';
    case 7,  datasize = prod(H.Dimensions)*(8/8);   datatype = '*int8';
    case 8,  datasize = prod(H.Dimensions)*(8/8);   datatype = '*uint8';
    case 15, datasize = prod(H.Dimensions)*(16/8);  datatype = '*int16';
    case 16, datasize = prod(H.Dimensions)*(16/8);  datatype = '*uint16';
    case 31, datasize = prod(H.Dimensions)*(32/8);  datatype = '*uint32';
    case 32, datasize = prod(H.Dimensions)*(32/8);  datatype = '*int32';
    case 64, datasize = prod(H.Dimensions)*(32/8);  datatype = '*single';
    case 65, datasize = prod(H.Dimensions)*(64/8);  datatype = '*double';
  end
  
  if      H.FileSize < datasize + ftell(FID)
    error('file look incomplete!');
  elseif  H.FileSize > datasize + ftell(FID)
    warning('file contains more data!');
  end
  
  I =   fread(FID, datasize , datatype );
  if H.ImageType == 1
    I = ~~I;
  end

  I = reshape( I , H.Dimensions );
  
  
  if asStruct

    I = struct('data',I,'header',H);
    
    I.X = ( 0:size(I.data,1)-1 ) * I.header.PixelDimensions(1) + I.header.Origin(1);
    I.Y = ( 0:size(I.data,2)-1 ) * I.header.PixelDimensions(2) + I.header.Origin(2);
    I.Z = ( 0:size(I.data,3)-1 ) * I.header.PixelDimensions(3) + I.header.Origin(3);
    I.SpatialTransform = reshape( double( I.header.Matrix(1:16) ) , [4,4] );

    O = I.SpatialTransform(1:3,1:3) * [ I.X(1) ; I.Y(1) ; I.Z(1) ] + I.SpatialTransform(1:3,4);
    I.SpatialTransform(1:3,4) = I.SpatialTransform(1:3,4) + O;
    I.X = I.X - I.X(1);
    I.Y = I.Y - I.Y(1);
    I.Z = I.Z - I.Z(1);
  end

end

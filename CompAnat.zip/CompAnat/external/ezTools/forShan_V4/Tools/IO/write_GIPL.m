function write_GIPL( I , fname , H )
% 
% 

  if nargin < 3, H = struct; end

  
  if numel(fname) > 8  && strcmp( lower(fname(end-7:end)) , '.gipl.gz' )
    [p,f,e] = fileparts( fname(1:end-3) );
  
    [zname,CLEANER] = tmpname( [ 'temp_gipl_????\' , f , e ] , 'mkdir' );
    
    write_GIPL( I , zname , H );
    
    gz_name = gzip( zname ); delete( zname );
    try
      movefile( gz_name{1} , fname );
    catch
      delete( gz_name{1} );
      error('no se puede escribir.');
    end
    return;
  end
  
  
  
  %%I3D
  if isa(I,'I3D')
%     I = I.coords2matrix;
    I = I.matrix2coords;

    PixelDimensions = [ mean(diff(I.X)) , mean(diff(I.Y)) , mean(diff(I.Z)) , mean(diff(I.T)) ];
    PixelDimensions = nonans( PixelDimensions , 1 );
    H = setH( H , PixelDimensions , true );
    
    Origin = zeros(1,4);
    if numel( I.X ), Origin(1) = I.X(1); end
    if numel( I.Y ), Origin(2) = I.Y(1); end
    if numel( I.Z ), Origin(3) = I.Z(1); end
    if numel( I.Z ), Origin(4) = I.T(1); end
    H = setH( H , Origin , true );
    
    VoxelMin = val2ind( I.ImageTransform(:,2) , 0 );
    VoxelMin = I.ImageTransform( VoxelMin , 1 );
    H = setH( H , VoxelMin , true );
    
    VoxelMax = val2ind( I.ImageTransform(:,2) , 1 );
    VoxelMax = I.ImageTransform( VoxelMax , 1 );
    H = setH( H , VoxelMax , true );
    
    Matrix = I.SpatialTransform;
    Matrix = Matrix(:);
    Matrix(end+1:20) = 0;
    H = setH( H , Matrix , true );
    
    I = I.data;
    
  elseif isstruct( I ) &&...
         isfield( I , 'data' ) &&...
         isfield( I , 'X' )  &&...
         isfield( I , 'Y' )  &&...
         isfield( I , 'Z' )
    
    O = I.SpatialTransform(1:3,1:3) * [ I.X(1) ; I.Y(1) ; I.Z(1) ] + I.SpatialTransform(1:3,4);
    I.SpatialTransform(1:3,4) = 0;
    Origin = I.SpatialTransform(1:3,1:3) \ O;
    Origin = [ Origin ; 0 ];
    H = setH( H , Origin , true );
    
    
    PixelDimensions = [ mean(diff(I.X)) , mean(diff(I.Y)) , mean(diff(I.Z)) , 0 ];
    PixelDimensions( isnan(PixelDimensions) ) = 1;
    H = setH( H , PixelDimensions , true );
    
    Matrix = I.SpatialTransform;
    Matrix = Matrix(:);
    Matrix(end+1:20) = 0;
    H = setH( H , Matrix , true );
    
    I = I.data;
    
  elseif isnumeric( I ) || isfloat( I ) || islogical( I )

  else
    
    error('unknown input type.');
    
  end
    
    
  switch class(I)
    case 'logical', ImageType = 1;
    case 'int8',    ImageType = 7;
    case 'uint8',   ImageType = 8;
    case 'int16',   ImageType = 15;
    case 'uint16',  ImageType = 16;
    case 'int32',   ImageType = 32;
    case 'uint32',  ImageType = 31;
    case 'single',  ImageType = 64;
    case 'double',  ImageType = 65;
    otherwise,      error('Unknown data type.');
  end
  H = setH( H , ImageType , true );
  
  Dimensions = [ size(I,1) , size(I,2) , size(I,3) ];
  Dimensions(4) = numel( I )/prod( Dimensions );
  H = setH( H , Dimensions , true );
  
  PixelDimensions = [ 1 , 1 , 1 , 1 ];        H = setH( H , PixelDimensions , false );
  Origin          = [ 0 , 0 , 0 , 0 ];        H = setH( H , Origin , false );
  Patient         = 'No Patient Information'; H = setH( H , Patient , false );
  Matrix          = zeros([1,20]);            H = setH( H , Matrix , false );
  Orientation     = 0;                        H = setH( H , Orientation , false );
  Par2            = 0;                        H = setH( H , Par2 , false );
  VoxelMin        = min(I(:));                H = setH( H , VoxelMin , false );
  VoxelMax        = max(I(:));                H = setH( H , VoxelMax , false );
  PixValOffset    = 0;                        H = setH( H , PixValOffset , false );
  PixValCal       = 0;                        H = setH( H , PixValCal , false );
  InterSliceGap   = 0;                        H = setH( H , InterSliceGap , false );
  UserDef         = 0;                        H = setH( H , UserDef , false );


  if numel( H.Dimensions ) ~= 4, error('error in Dimensions.'); end
  if numel( H.ImageType ) ~= 1, error('error in ImageType.'); end
  if numel( H.PixelDimensions )~= 4, error('error in PixelDimensions.'); end
  if numel( H.Patient ) > 80
    warning('Patient Info will be truncated to 80 characters.');
    H.Patient = H.Patient(1:80);
  elseif numel( H.Patient ) < 80
    H.Patient(end+1:80) = ' ';
  end
  H.Matrix = H.Matrix(:);
  if numel( H.Matrix ) > 20
    warning('Matrix Info will be truncated to 20 values.');
    H.Matrix = H.Matrix(1:20);
  elseif numel( H.Matrix ) < 20
    H.Matrix(end+1:20) = 0;
  end
  if numel( H.Orientation )   ~= 1, error('error in Orientation.'); end
  if numel( H.Par2 )          ~= 1, error('error in Par2.'); end
  if numel( H.VoxelMin )      ~= 1, error('error in VoxelMin.'); end
  if numel( H.VoxelMax )      ~= 1, error('error in VoxelMax.'); end
  if numel( H.Origin )        ~= 4, error('error in Origin.'); end
  if numel( H.PixValOffset )  ~= 1, error('error in PixValOffset.'); end
  if numel( H.PixValCal )     ~= 1, error('error in PixValCal.'); end
  if numel( H.InterSliceGap ) ~= 1, error('error in InterSliceGap.'); end
  if numel( H.UserDef )       ~= 1, error('error in UserDef.'); end

  
  FID = fopen( fname , 'w' , 'ieee-be' );
  if FID < 0, error('Imposible to open file.'); end
  CLEANUP = onCleanup( @()fclose(FID) );
  
  
  fwrite( FID , uint16( H.Dimensions )      , 'uint16' );
  fwrite( FID , uint16( H.ImageType )       , 'uint16' );
  fwrite( FID , single( H.PixelDimensions ) , 'single' );
  fwrite( FID ,   char( H.Patient )         , 'char'   );
  fwrite( FID , single( H.Matrix )          , 'single' );
  fwrite( FID ,  uint8( H.Orientation )     , 'uint8'  );
  fwrite( FID ,  uint8( H.Par2 )            , 'uint8'  );
  fwrite( FID , double( H.VoxelMin )        , 'double' );
  fwrite( FID , double( H.VoxelMax )        , 'double' );
  fwrite( FID , double( H.Origin )          , 'double' );
  fwrite( FID , single( H.PixValOffset )    , 'single' );
  fwrite( FID , single( H.PixValCal )       , 'single' );
  fwrite( FID , single( H.InterSliceGap )   , 'single' );
  fwrite( FID , single( H.UserDef )         , 'single' );
  
  fwrite( FID , uint32( 4026526128 )        , 'uint32' );
  
  if islogical( I )

if 0
X = rand(1,18) > 0.5

X( ceil(numel(X)/8)*8 ) = false;
n = bin2num( X );
FID = fopen('kk.kk','w'); fwrite( FID , n ,'uint8' ); fclose(FID);

% FID = fopen('kk.kk','w');
% fwrite( FID , X ,'ubit1' );
% fclose(FID);

FID = fopen('kk.kk','r');
XX = ~~fread( FID , Inf ,'*bit1' ).'
fclose(FID);

isidentical( X , XX )
end
    
    fwrite( FID , I(:) , 'bit1' );
  else,              fwrite( FID , I(:) , class(I) );
  end
  

  function H = setH( H , ATR , force )
    ATRname = inputname(2);
    if force && isfield( H , ATRname ) && ~isequal( H.(ATRname) , ATR )
      warning('Different provided attribute %s.', ATRname );
    end
    if force || ~isfield( H , ATRname )
      H.(ATRname) = ATR;
    end
  end

end


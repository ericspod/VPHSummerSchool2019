% addpath(genpath('Tools'))

%%

%read the GIPL
G = read_GIPL( 'DTI034.gipl' , true );  

%read the contours
C = load('DTI034.mat'); C = C.DICOM_epi_lv_rv;

%%

%clean out G, to use it as an empty container (grid) for the volumetric
%data.
G.data = zeros(size(G.data),'uint8');

%runs for all short-axis 
for r = 4:size(C,1)
% fillContourInImage( contour , volumetric_image )  returns a binary mask
% with the "voxels" within the contour
  G.data( fillContourInImage( C{r,4} , G ) ) = 3;  %right-endocardium
  G.data( fillContourInImage( C{r,2} , G ) ) = 1;  %left-epicardium
  G.data( fillContourInImage( C{r,3} , G ) ) = 2;  %left-endocardium
end

%eventually, runs for all the planes filling the holes (if any)
for r = 1:size( G.data , 3 )
  G.data(:,:,r) = imfill( G.data(:,:,r) , 'holes' );
end

%visualize the resulting volumetric image
image3( G );
hold on
plot3d( C(4:end,2) , 'r' );
plot3d( C(4:end,3) , 'g' );
plot3d( C(4:end,4) , 'b' );
hold off

%%

%save as a new GIPL
write_GIPL( G , 'new_gipl.gipl');

%check spatially the new file
image3( read_GIPL( 'new_gipl.gipl' , true ) );
hold on; plot3d( C(4:end,2:4) ); hold off




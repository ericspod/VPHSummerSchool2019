function M = fillContourInImage( C , I )

  M = false( numel( I.X ) , numel( I.Y ) , numel( I.Z ) );
  if isempty( C ), return; end

  [~,iZ] = getPlane( C );
  C  = transform( C , iZ );

  XY = transform( ndmat( I.X , I.Y , I.Z ) , iZ * I.SpatialTransform );
  gap = min( [ mean( diff( I.X ) ) , mean( diff( I.Y ) ) , mean( diff( I.Z ) ) ] )/2;
  m  = find( abs( XY(:,3) ) < gap );
  XY = XY( m , 1:2 );
  
  try
    w = inpoly( XY.' , C.' );
  catch
    w = inpolygon( XY(:,1) , XY(:,2) , C(:,1) , C(:,2) );
  end
  
  m = m(w);
  
  M(m) = true;
  
  
end

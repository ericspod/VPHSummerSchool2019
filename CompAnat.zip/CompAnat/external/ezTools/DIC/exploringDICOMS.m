%add to the path the tools from Ernesto
addpath c:\eCode\Tools\
addpath c:\eCode\Tools\uiTools\
addpath c:\eCode\Tools\uiTools\OrbitPanZoom
addpath c:\eCode\MEXs\
addpath c:\eCode\Image3D\

%add to the path the 'DICOMexplorer' "toolbox"
addpath c:\Dropbox\WORK\DIC\DICOMexplorer

%change current directory to the DATA folder
cd c:\Dropbox\WORK\DIC\

%explore all the DICOMs files within this folder (recursivelly)
%store results in the variable 'S'
S = sortDCMfiles( pwd );   %it takes some time!! be patient my friend...


%for example, exclusive information
S.Patient_02.Study_01.Serie_05.Orientation_01.Position_004.IMAGE_002.INFO
%or common information
S.INFO


%use DICOMDIRexplorer to dig into S
DICOMDIRexplorer(S)

%to load a DICOM stack (a single orientation)
I = loadDICOMvolume( S.Patient_02.Study_01.Serie_05 )
%or ask for the orientation to load
I = loadDICOMvolume( S )  %cancel it to follow the example script!!!


%now the whole stack is in I
size( I )  %96 columns, 72 rows, 18 slices, 2 times, 1 scalar in each voxel

%visualize I
figure; image3( I.t1 )   %shows the first time instant
figure; image3( I.t2 )   %shows the first time instant
                         % I.t2 is equivalent to I(:,:,:,2)
                         %always the fourth index for the time.


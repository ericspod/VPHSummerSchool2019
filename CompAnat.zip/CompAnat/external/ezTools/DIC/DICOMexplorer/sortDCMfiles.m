function sD = sortDCMfiles( dirname , varargin )

  [varargin,fast     ] = parseargs(varargin,'Fast'   ,'$FORCE$',1 );
  [varargin,i,DEPTH  ] = parseargs(varargin,'depth'  ,'$DEFS$',Inf );
  [varargin,i,INFOFCN] = parseargs(varargin,'infofcn','$DEFS$', @(fn)dicominfo(fn) );
  
  if nargin<1 
    dirname= uigetdir(pwd,'Select Dicom Folder');
  else
    dirname = fixname( dirname );
    isd = isdir( dirname );
    if isd
      dirname = [ dirname filesep ];
    else
      dirname= uigetdir(dirname,'Select Dicom Folder');
    end
  end
  if ~dirname, sD= []; return; end
  
  dirname = fixname( dirname );


  fprintf('Reading old DICOMDIR ... ');
  if isdir('#DICOMdirs') && isfile( [ pwd filesep '#DICOMdirs' filesep 'DICOMDIR.mat' ] )
    try,
      sD = load([ pwd filesep '#DICOMdirs' filesep 'DICOMDIR.mat' ]);
      sD = sD.DICOMDIR;

      PS = GetFieldName( sD , 'Patient_' );
      for p = 1:numel(PS),   P = PS{p};
        TS = GetFieldName( sD.(P) , 'Study_' );
        for t = 1:numel(TS), T = TS{t};
          RS = GetFieldName( sD.(P).(T) , 'Serie_' );
          for r = 1:numel(RS),  R = RS{r};
            OS = GetFieldName( sD.(P).(T).(R) , 'Orientation_' );
            for o = 1:numel(OS),  O = OS{o};
              orientation = sD.(P).(T).(R).(O).ImageOrientation;
              sD.(P).(T).(R).(O) = struct;
              sD.(P).(T).(R).(O).ImageOrientation = orientation;
            end
            sD.(P).(T).(R) = rmfield( sD.(P).(T).(R) , 'INFO' );
          end
          sD.(P).(T) = rmfield( sD.(P).(T) , 'INFO' );
        end
        sD.(P) = rmfield( sD.(P) , 'INFO' );
      end
      sD = rmfield( sD , 'INFO' );
    catch
      sD = struct;
    end
  else
    sD = struct;
  end
  fprintf('  Done\n');


  fprintf('Reading directory ... ');
  files= rdir(dirname,[],DEPTH);
  fprintf('  Done\n');

  if ~fast
    fprintf('Pre sorting files ...  000000 of 000000 items ');
    
    Instance = zeros( numel(files),1 );
    for ff = 1:numel(files)
      fprintf( repmat( '\b',1,23 ) );
      fprintf( '%6d of %6d items ', ff, numel(files) );
      try
        item = INFOFCN( fixname( files(ff).name ) );
        if ~isfield( item , 'PatientID' )
          Instance(ff) = Inf;
        elseif ~isfield( item , 'InstanceNumber' )
          Instance(ff) = 0;
        else
          Instance(ff) = item.InstanceNumber;
        end
      catch
        Instance(ff) = Inf;
      end
    end
    [Instance,order]= sort(Instance);
    files= files(order);
    files= files( Instance < Inf );
    fprintf('  Done\n');
  end
  
  files_warning = [];
  files_errors  = [];
  files_noimage = [];
  
  warning('off','all'); lastwarn('');
  
  fprintf('000000 of 000000 items ');
  for ff = 1:numel(files)
    fprintf( repmat( '\b',1,23 ) );
    fprintf( '%6d of %6d items ', ff, numel(files) );

    f = files(ff); fname = fixname( f.name );

    try
      item = INFOFCN( fname );
    catch
      continue;
    end

    try
      item.PatientID;
      item.StudyInstanceUID;
      item.SeriesInstanceUID;
      item.ImageOrientationPatient;
      item.ImagePositionPatient;
      item.Rows;
      item.Columns;
    catch
      files_noimage(end+1) = ff;
%       fprintf( '\nPlease Verify file:   %s\n', fname(length(dirname)+1:end) );
%       fprintf( '%6d of %6d items ', ff, numel(files) );
      continue;
    end
    
    try
      % PATIENT
      P = GetID( sD , 'Patient_' , 'PatientID', item.PatientID );
              sD.(P).PatientID  = item.PatientID;
      try,    sD.(P).FamilyName = item.PatientName.FamilyName;          end
%     try,    sD.(P).Sex        = item.PatientSex;                      end

      % STUDY
      T = GetID( sD.(P) , 'Study_' , 'StudyInstanceUID', item.StudyInstanceUID );
              sD.(P).(T).StudyInstanceUID = item.StudyInstanceUID;

      try,   StudyDescription = item.StudyDescription;
      catch, StudyDescription = '';                                     end
      if isempty( StudyDescription )
        StudyDescription = [ 'NoDescription_DIR_' fileparts( fname ) ];
      end
        
      if ~isfield( sD.(P).(T) , 'StudyDescription' )
        sD.(P).(T).StudyDescription = StudyDescription;
      else
        if ~isequal( sD.(P).(T).StudyDescription , StudyDescription )
          warning( 'diferent  StudyDescription  %s', StudyDescription );
        end
      end
      try,    sD.(P).(T).Date             = ToDay(item.StudyDate);      end

      % SERIE
      R = GetID( sD.(P).(T) , 'Serie_' , 'SeriesInstanceUID' , item.SeriesInstanceUID );
              sD.(P).(T).(R).SeriesInstanceUID = item.SeriesInstanceUID;

              
              
      try
        SerieDescription = item.SerieDescription;
      catch
        try
          SerieDescription = item.SeriesDescription;
        catch
          SerieDescription = '';
        end
      end

      if isempty( SerieDescription )
        SerieDescription = [ 'NoDescription_DIR_' fileparts( fname ) ];
      end
        
      if ~isfield( sD.(P).(T).(R) , 'SerieDescription' )
        sD.(P).(T).(R).SerieDescription = SerieDescription;
      else
        if ~isequal( sD.(P).(T).(R).SerieDescription , SerieDescription )
          warning( 'different  SerieDescription  %s', SerieDescription );
        end
      end              
      
%     try,    sD.(P).(T).(R).SeriesNumber      = item.SeriesNumber;    end
%     try,    sD.(P).(T).(R).Modality          = item.Modality;        end
%     try,    sD.(P).(T).(R).Institution       = item.InstitutionName; end

      % ORIENTATION
      O = GetID( sD.(P).(T).(R) , 'Orientation_' , 'ImageOrientation' , reshape( item.ImageOrientationPatient ,3,2)' );
      sD.(P).(T).(R).(O).ImageOrientation = reshape( item.ImageOrientationPatient ,3,2)';
      
      % ZS-POSITION
      Z = GetID( sD.(P).(T).(R).(O) , 'Position_' , 'ImagePosition' , item.ImagePositionPatient );
      sD.(P).(T).(R).(O).(Z).ImagePosition = item.ImagePositionPatient;

      try,    I = numel( GetFieldName( sD.(P).(T).(R).(O).(Z) , 'IMAGE_' ) ) + 1;
      catch,  I = 1;      end
      I = sprintf('IMAGE_%03d',I);
      
      sD.(P).(T).(R).(O).(Z).(I).FileName            = fixname( fname);%( numel(dirname)+2:end ) );

             sD.(P).(T).(R).(O).(Z).(I).Size                = [ item.Rows item.Columns ];
      try,   sD.(P).(T).(R).(O).(Z).(I).TriggerTime         = item.TriggerTime;                 end
      try,   sD.(P).(T).(R).(O).(Z).(I).InstanceNumber      = item.InstanceNumber;              end
      try,   sD.(P).(T).(R).(O).(Z).(I).ImageComments       = item.ImageComments;               end
      try,   sD.(P).(T).(R).(O).(Z).(I).PixelsSpacing       = item.PixelSpacing';               end
      try,   sD.(P).(T).(R).(O).(Z).(I).SliceThickness      = item.SliceThickness;              end
             sD.(P).(T).(R).(O).(Z).(I).Data                = [ ];
             sD.(P).(T).(R).(O).(Z).(I).INFO                = item;

    catch
      files_errors(end+1) = ff;
%       fprintf( '\nError in %s\n', fname(length(dirname)+1:end) );
%       fprintf( '%6d of %6d items ', ff, numel(files) );
      continue;
    end
    
    if ~isempty( lastwarn )
      files_warning(end+1) = ff;
%       fprintf( '\nWarning in %s\n', fname(length(dirname)+1:end) );
%       fprintf( '%6d of %6d items ', ff, numel(files) );
      lastwarn('');
    end

  end
  fprintf('\n');


  fprintf('Grouping and sorting ... ');
  if ~fast, sD= groupDICOMinfo(sD); end
  sD= orderDICOM( sD );
  fprintf('  Done\n');

%   fprintf('Creating #DICOMdirs ... ');
%   moveDCMfiles( sD , '#DICOMdirs' );
%   fprintf('  Done\n');

  if numel(files_errors)
    fprintf('\n\n');
    files_errors = arrayfun( @(x) x.name , files(files_errors) , 'UniformOutput', false );
    for fe= 1:numel(files_errors)
      fprintf('<a href="matlab:try, INFOFCN(''%s''); end">(DICOM info)</a> - Error in?? %s\n',...
          files_errors{fe} , files_errors{fe} );
    end
    fprintf('\n');
  end
  
  if numel(files_noimage)
    fprintf('\n\n');
    files_noimage = arrayfun( @(x) x.name , files(files_noimage) , 'UniformOutput', false );
    for fe= 1:numel(files_noimage)
      fprintf('<a href="matlab:try, figure;imagesc(safedicomread(''%s'')); catch, disp( size(safedicomread(''%s''))); end">(See it)</a> - Not Orientation IMAGE?? %s\n',...
          files_noimage{fe} , files_noimage{fe} , files_noimage{fe} );
    end
    fprintf('\n');
  end

  if numel(files_warning)
    fprintf('\n\n');
    files_warning = arrayfun( @(x) x.name , files(files_warning) , 'UniformOutput', false );
    for fe= 1:numel(files_warning)
      fprintf('<a href="matlab:try, INFOFCN(''%s''); end">(DICOM info)</a> - Warning   %s\n',...
          files_warning{fe} , files_warning{fe} );
    end
    fprintf('\n');
  end
    
  
  function day= ToDay( day )
    day= datestr(datenum([str2num(day(1:4)) str2num(day(5:6)) str2num(day(7:8))]), 'mmm.dd,yyyy');
  end

  function id = GetID( S , str , in , value )
    PS = GetFieldName( S , str );
    for p = 1:numel(PS)
      if isfield( S.(PS{p}) , in ) 
        if strcmp(str, 'Position_' ) && max( abs( S.(PS{p}).(in)(:) - value(:) ) ) < 1e-9
          id = PS{p}; return;
        elseif strcmp(str, 'Orientation_' ) && max( abs( S.(PS{p}).(in)(:) - value(:) ) ) < 1e-5
          id = PS{p}; return;
        elseif isequal( S.(PS{p}).(in) , value )
          id = PS{p}; return;
        end
      end
    end
    switch str
      case 'Patient_',     id = sprintf('Patient_%02d'     , numel(PS)+1 );
      case 'Study_',       id = sprintf('Study_%02d'       , numel(PS)+1 );
      case 'Serie_',       id = sprintf('Serie_%02d'       , numel(PS)+1 );
      case 'Orientation_', id = sprintf('Orientation_%02d' , numel(PS)+1 );
      case 'Position_',    id = sprintf('Position_%03d'    , numel(PS)+1 );
    end    
  end

  function names = GetFieldName( S , idx )
    names = fieldnames(S);
    
    if nargin > 1
      if isnumeric( idx )
        names = names( idx );
      elseif ischar( idx )
        names = names( strncmpi( names , idx , numel(idx) ) );
      elseif islogical(idx)
        names = names( idx );
      end
%       if numel( names ) == 1, names = names{1}; end
    end
  end


end

%   function s= tostring(s)
%     s= strrep(s,' ','_');
%     s= strrep(s,'`','_');
%     s= strrep(s,'~','_');
%     s= strrep(s,'!','_');
%     s= strrep(s,'@','_');
%     s= strrep(s,'#','_');
%     s= strrep(s,'$','_');
%     s= strrep(s,'%','_');
%     s= strrep(s,'^','_');
%     s= strrep(s,'&','_');
%     s= strrep(s,'*','_');
%     s= strrep(s,'(','_');
%     s= strrep(s,')','_');
%     s= strrep(s,'+','_');
%     s= strrep(s,'=','_');
%     s= strrep(s,'-','_');
%     s= strrep(s,'[','_');
%     s= strrep(s,']','_');
%     s= strrep(s,'{','_');
%     s= strrep(s,'}','_');
%     s= strrep(s,'\\','_');
%     s= strrep(s,'''','_');
%     s= strrep(s,'/','_');
%     s= strrep(s,'.','_');
%     s= strrep(s,',','_');
%     s= strrep(s,'>','_');
%     s= strrep(s,'<','_');
%     s= strrep(s,':','_');
%     s= strrep(s,'"','_');
%     s= strrep(s,';','_');
%   end

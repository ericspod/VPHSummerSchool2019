function sD = groupDICOMinfo( sD )

  PS= GetFieldName( sD , 'Patient_' );  infoP= {};
  for p= 1:numel(PS),  P= PS{p};
    
    TS= GetFieldName( sD.(P) , 'Study_' );  infoT= {};
    for t=1:numel(TS),   T= TS{t};

      RS= GetFieldName( sD.(P).(T) , 'Serie_' );  infoR= {};
      for r=1:numel(RS),   R= RS{r};

        OS= GetFieldName( sD.(P).(T).(R) , 'Orientation_' );  infoO= {};
        for o=1:numel(OS),   O= OS{o};
        
          ZS= GetFieldName( sD.(P).(T).(R).(O) , 'Position_' );  infoZ= {};
          for z=1:numel(ZS),    Z= ZS{z};
            
            IS= GetFieldName( sD.(P).(T).(R).(O).(Z) , 'IMAGE_' );   infoI= {};
            for i=1:numel(IS),   I= IS{i};
              infoI{end+1}= rmfield_safe( sD.(P).(T).(R).(O).(Z).(I).INFO , {} );
            end  % end I
            
            if isfield( sD.(P).(T).(R).(O).(Z) ,'INFO' )
              sD.(P).(T).(R).(O).(Z).INFO = joinfields( sD.(P).(T).(R).(O).(Z).INFO , rmfield_safe( equalfields( infoI{:} ) , {'FileSize' 'SliceThickness' 'FileName' 'Width' 'Height' 'PixelSpacing' 'FileModDate' 'InstanceNumber' 'Columns' 'Rows' 'Data'} ) );
            else
              sD.(P).(T).(R).(O).(Z).INFO = rmfield_safe( equalfields( infoI{:} ) , {'FileSize' 'SliceThickness' 'FileName' 'Width' 'Height' 'PixelSpacing' 'FileModDate' 'InstanceNumber' 'Columns' 'Rows' 'Data'} );
            end
%             sD.(P).(T).(R).(O).(Z)= last2first( sD.(P).(T).(R).(O).(Z) );
            infoZ{end+1}= sD.(P).(T).(R).(O).(Z).INFO;

            for i=1:numel(IS),   I= IS{i};
              [d1,d2]= notequalfields( sD.(P).(T).(R).(O).(Z).(I).INFO , sD.(P).(T).(R).(O).(Z).INFO );
              sD.(P).(T).(R).(O).(Z).(I).INFO = d1;
            end  % end I

          end    % end Z

          if isfield( sD.(P).(T).(R).(O) , 'INFO' )
            sD.(P).(T).(R).(O).INFO = joinfields( sD.(P).(T).(R).(O).INFO , rmfield_safe( equalfields( infoZ{:} ) , {'ImagePositionPatient' 'SliceLocation'} ) );
          else
            sD.(P).(T).(R).(O).INFO = rmfield_safe( equalfields( infoZ{:} ) , {'ImagePositionPatient' 'SliceLocation'} );
          end
%           sD.(P).(T).(R).(O)= last2first( sD.(P).(T).(R).(O) );
          infoO{end+1}= sD.(P).(T).(R).(O).INFO;

          for z=1:numel(ZS),   Z= ZS{z};
            [d1,d2]= notequalfields( sD.(P).(T).(R).(O).(Z).INFO , sD.(P).(T).(R).(O).INFO );
            sD.(P).(T).(R).(O).(Z).INFO = d1;
          end  % end Z
          
        end      % end O

        if isfield( sD.(P).(T).(R) , 'INFO' )
          sD.(P).(T).(R).INFO = joinfields( sD.(P).(T).(R).INFO , rmfield_safe( equalfields( infoO{:} ) , {'ImageOrientationPatient'} ) );
        else
          sD.(P).(T).(R).INFO = rmfield_safe( equalfields( infoO{:} ) , {'ImageOrientationPatient'} );
        end
%         sD.(P).(T).(R)= last2first( sD.(P).(T).(R) );
        infoR{end+1}= sD.(P).(T).(R).INFO;

        for o=1:numel(OS),   O= OS{o};
          [d1,d2]= notequalfields( sD.(P).(T).(R).(O).INFO , sD.(P).(T).(R).INFO );
          sD.(P).(T).(R).(O).INFO = d1;
        end  % end O
        
      end        % end R

      if isfield( sD.(P).(T) , 'INFO' )
        sD.(P).(T).INFO = joinfields( sD.(P).(T).INFO , rmfield_safe( equalfields( infoR{:} ) , { 'Serie' 'Sequence' 'ScanningSequence' } ) );
      else
        sD.(P).(T).INFO = rmfield_safe( equalfields( infoR{:} ) , { 'Serie' 'Sequence' 'ScanningSequence' } );
      end
%       sD.(P).(T)= last2first( sD.(P).(T) );
      infoT{end+1}= sD.(P).(T).INFO;

      for r=1:numel(RS),   R= RS{r};
        [d1,d2]= notequalfields( sD.(P).(T).(R).INFO , sD.(P).(T).INFO );
        sD.(P).(T).(R).INFO = d1;
      end  % end R
      
    end          % end T

    if isfield( sD.(P) , 'INFO' )
      sD.(P).INFO = joinfields( sD.(P).INFO , rmfield_safe( equalfields( infoT{:} ) , {'Study'} ) );
    else
      sD.(P).INFO = rmfield_safe( equalfields( infoT{:} ) , {'Study'} );
    end
%     sD.(P)= last2first( sD.(P) );
    infoP{end+1}= sD.(P).INFO;

    for t=1:numel(TS),   T= TS{t};
      [d1,d2]= notequalfields( sD.(P).(T).INFO , sD.(P).INFO );
      sD.(P).(T).INFO = d1;
    end  % end T

  end            % end P
  if isfield( sD , 'INFO' )
    sD.INFO= joinfields( sD.INFO , rmfield_safe( equalfields( infoP{:} ) , {'Patient'} ) );
  else
    sD.INFO= rmfield_safe( equalfields( infoP{:} ) , {'Patient'} );
  end
  
  for p=1:numel(PS),   P= PS{p};
    [d1,d2]= notequalfields( sD.(P).INFO , sD.INFO );
    sD.(P).INFO = d1;
  end  % end P

  function st=last2first(st)
    n= numel(fieldnames(st));
    st= orderfields( st , [n 1:n-1] );
  end    

  function names = GetFieldName( S , idx )
    names = fieldnames(S);
    
    if nargin > 1
      if isnumeric( idx )
        names = names( idx );
      elseif ischar( idx )
        names = names( strncmpi( names , idx , numel(idx) ) );
      elseif islogical(idx)
        names = names( idx );
      end
%       if numel( names ) == 1, names = names{1}; end
    end
  end


  function S = rmfield_safe( S , names )
    if ~isstruct(S) , return; end
    for n = 1:numel(names)
      S = rmfield( S , GetFieldName( S , names{n} ) );
    end
  end

end

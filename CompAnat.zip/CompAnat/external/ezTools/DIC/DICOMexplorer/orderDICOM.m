function D = orderDICOM(D,depth)

  if nargin<2, depth='Patient'; end

  fields = fieldnames(D);
  n = numel(fields);
  switch depth
    case 'Patient'
      p = [ find(strcmp(fields , 'INFO' ))    find(strncmp(fields , 'Patient_' , 8 ) )' ];
      p = [ p  setdiff(1:n,p) ];

      D = orderfields( D , p );
      for i= find(strncmp(fields , 'Patient_' , 8 ) )'
        D.(fields{i}) = orderDICOM( D.(fields{i}) , 'Study' );
      end
    case 'Study'
      p = [ find(strcmp(fields , 'INFO' ))    find(strncmp(fields , 'Study_' , 6 ) )' ];
      p = [p setdiff(1:n,p)];

      D = orderfields(D,p);
      for i = find(strncmp(fields , 'Study_' , 6 ) )'
        D.(fields{i}) = orderDICOM( D.(fields{i}) , 'Serie' );
      end
    case 'Serie'
      p = [  find(strcmp(fields , 'INFO' ))   find(strncmp(fields , 'Serie_' , 6 ) )'];
      p = [p setdiff(1:n,p)];

      D = orderfields(D,p);
      for i= find(strncmp(fields , 'Serie_' , 6 ) )'
        D.(fields{i}) = orderDICOM( D.(fields{i}) , 'Orientation' );
      end
    case 'Orientation'
      p = [ find(strcmp(fields , 'INFO' ))   find(strncmp(fields , 'Orientation_' , 12 ) )' ];
      p = [p setdiff(1:n,p)];

      D = orderfields(D,p);
      for i= find(strncmp(fields , 'Orientation_' , 12 ) )'
        D.(fields{i}) = orderDICOM( D.(fields{i}) , 'Position' );
      end
    case 'Position'
      p = [ find(strcmp(fields , 'INFO' ))   find(strncmp(fields , 'Position_' , 9 ) )' ];
      p = [p setdiff(1:n,p)];

      D = orderfields(D,p);
      for i= find(strncmp(fields , 'Position_' , 9 ) )'
        D.(fields{i}) = orderDICOM( D.(fields{i}) , 'IMAGE' );
      end
    case 'IMAGE'
      p = [ find(strcmp(fields , 'INFO' ))  find(strncmp(fields , 'IMAGE_' , 6 ) )' ];
      p = [p setdiff(1:n,p)];

      D = orderfields(D,p);
      for i= find(strncmp(fields , 'IMAGE_' , 6 ) )'
        D.(fields{i}) = orderDICOM( D.(fields{i}) , 'thisIMAGE' );
      end
    case 'thisIMAGE'
      p = find(strcmp(fields , 'INFO' ));
      p = [p setdiff(1:n,p)];

      D = orderfields(D,p);
  end

end
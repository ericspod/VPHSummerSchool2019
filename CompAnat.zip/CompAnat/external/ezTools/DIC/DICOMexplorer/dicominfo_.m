function info = dicominfo_( fname , DDIR )

  VERBOSE = false;

  info = dicominfo( fname );
  
  if nargin > 1
    % M:IMAGE,   A:PATIENT,   R:PRIVATE,   E:SERIES,   T:STUDY
    type = arrayfun(@(n)DDIR.DirectoryRecordSequence.(sprintf('Item_%d',n)).DirectoryRecordType(2),1:numel(fieldnames(DDIR.DirectoryRecordSequence)),'un',true);
    
    
    
    if 0
      series = find( type == 'E' );
      for sid = series
%         disp( DDIR.DirectoryRecordSequence.(sprintf('Item_%d',sid)).SeriesInstanceUID )
        disp( DDIR.DirectoryRecordSequence.(sprintf('Item_%d',sid)).SeriesDescription )
      end
    end
    
    SERIESname = repmat( {''} , [ 1 , numel(type) ] );
    series = find( type == 'E' );
    for sid = series
      SERIESname{sid} = DDIR.DirectoryRecordSequence.(sprintf('Item_%d',sid)).SeriesDescription;
    end
    
    fix = @(fn) strrep( fn , '//', filesep , '\\' , filesep , '/' , filesep , '\', filesep ); 
    ffname = fix( fname );
    Ms = find( type == 'M' );
    IMAGEid = Ms( arrayfun(@(n)~isempty(strfind( ffname , fix( DDIR.DirectoryRecordSequence.(sprintf('Item_%d',n)).ReferencedFileID ) )) , Ms ) );
    if numel( IMAGEid ) == 1
      IMAGE   = DDIR.DirectoryRecordSequence.(sprintf('Item_%d',IMAGEid));

      SERIEid = find( type(1:IMAGEid) == 'E' , 1 , 'last' );
      SERIE   = DDIR.DirectoryRecordSequence.(sprintf('Item_%d',SERIEid));
      SERIE.SerieTH_WithinDICOMDIR = sum( type(1:IMAGEid) == 'E' );
      
      SAMEseries = strcmp( SERIESname , SERIE.SeriesDescription );
      SAMEseries( SERIEid ) = false;
      SERIE.DistanceToSameSeries = min( abs( find( SAMEseries ) - SERIEid ) );
      
      STUDYid = find( type(1:IMAGEid) == 'T' , 1 , 'last' );
      STUDY   = DDIR.DirectoryRecordSequence.(sprintf('Item_%d',STUDYid));
      STUDY.StudyTH_WithinDICOMDIR = sum( type(1:IMAGEid) == 'T' );
    
      PATIENTid = find( type(1:IMAGEid) == 'A' , 1 , 'last' );
      PATIENT   = DDIR.DirectoryRecordSequence.(sprintf('Item_%d',PATIENTid));
      PATIENT.PatientTH_WithinDICOMDIR = sum( type(1:IMAGEid) == 'A' );
      
      
      FN = fieldnames( PATIENT );
      for f = FN(:).',
        if VERBOSE && isfield( info , f{1} )  && ~isequal( info.(f{1}) , PATIENT.(f{1}) )
          fprintf('From PATIENT, replacing ''%s'':  ', f{1} );
          try, fprintf('.%s. ---> .%s.', uneval( info.(f{1}) ) , uneval( PATIENT.(f{1}) ) ); end
          fprintf('\n');
        end
        info.(f{1}) = PATIENT.(f{1});
      end
      FN = fieldnames( STUDY );
      for f = FN(:).',
        if VERBOSE && isfield( info , f{1} )  && ~isequal( info.(f{1}) , STUDY.(f{1}) )
          fprintf('From STUDY,   replacing ''%s'':  ', f{1} );
          try, fprintf('.%s. ---> .%s.', uneval( info.(f{1}) ) , uneval( STUDY.(f{1}) ) ); end
          fprintf('\n');
        end
        info.(f{1}) = STUDY.(f{1});
      end
      FN = fieldnames( SERIE );
      for f = FN(:).',
        if VERBOSE && isfield( info , f{1} )  && ~isequal( info.(f{1}) , SERIE.(f{1}) )
          fprintf('From SERIE,   replacing ''%s'':  ', f{1} );
          try, fprintf('.%s. ---> .%s.', uneval( info.(f{1}) ) , uneval( SERIE.(f{1}) ) ); end
          fprintf('\n');
        end
        info.(f{1}) = SERIE.(f{1});
      end
      
    end
    
  end
  
  
  
  
  FN = fieldnames( info );
  if ~isfield( info , 'PatientID' )
%     [p,f,e] = fileparts( fn );
%     [p,f,e] = fileparts( f );
%     v = f;
    v = [];
    for ff = vec( find( strncmp( FN , 'Patient' , 7 ) ) ).'
      try, v = [ v , '_' , uneval( info.(FN{ff})) ]; end
    end
    info.PatientID = v;
  end
  if ~isfield( info , 'StudyInstanceUID' )
    v = [];
    for ff = vec( find( strncmp( FN , 'Study' , 5 ) ) ).'
      try, v = [ v , '_' , uneval( info.(FN{ff})) ]; end
    end
    info.StudyInstanceUID = v;
  end
  if ~isfield( info , 'SeriesInstanceUID' )
    v = [];
    for ff = vec( find( strncmp( FN , 'Serie' , 5 ) ) ).'
      try, v = [ v , '_' , uneval( info.(FN{ff})) ]; end
    end
    info.SeriesInstanceUID = v;
  end
  if ~isfield( info , 'SeriesInstanceUID' )
    try, info.SeriesInstanceUID = info.SeriesDescription; end
  end
  if ~isfield( info , 'SeriesInstanceUID' )
    try, info.SeriesInstanceUID = info.SerieDescription;  end
  end
  if ~isfield( info , 'ImageOrientationPatient' )
    v = eye(3,2);
    info.ImageOrientationPatient = v;
  end
  if ~isfield( info , 'ImagePositionPatient' )
    v = [0 0 0];
    info.ImagePositionPatient = v;
  end
  if ~isfield( info , 'ImageSZ' )
    v = size( dicomread( fname ) );
    info.ImageSZ = v;
  end

  try, info.SeriesInstanceUID = info.SeriesDescription; end
  try, info.SeriesInstanceUID = info.SerieDescription;  end
       info.SeriesInstanceUID = [ info.SeriesInstanceUID , uneval( info.ImageSZ ) ];
  try, info.SeriesInstanceUID = [ info.SeriesInstanceUID , uneval( info.DistanceToSameSeries ) ];  end
  
end

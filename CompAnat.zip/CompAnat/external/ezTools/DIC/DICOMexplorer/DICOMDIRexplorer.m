function DICOMDIRexplorer(D)

  if ~any( strcmp( import , 'javax.swing.*' ) )
    import('javax.swing.*');
  end

  h  = figure('NumberTitle', 'off',...
              'IntegerHandle','off',...
              'NextPlot','new',...
              'name','DICOMDIR Explorer',...
              'Toolbar', 'none',...
              'Menu','none');

  sp1 = splitpanel('horizontal','resizefcn',@placetree,'ratio',0.3);
  set(sp1.Hseparator,'background',[.4 .4 .4]);
  set(sp1.left   , 'BorderType','none');
  set(sp1.right  , 'BorderType','none');
  delete( findall(sp1.left,'Tag','MINMAX') );

  sp2 = splitpanel('vertical','Parent',sp1.right,'ratio',0.7);
  set(sp2.Vseparator,'background',[.4 .4 .4]);
  set(sp2.top    , 'BorderType','none');
  set(sp2.bottom , 'BorderType','none');

  sp3 = splitpanel('horizontal','Parent',sp2.top,'ratio',0.4);            
  set(sp3.Hseparator,'background',[.4 .4 .4]);
  set(sp3.left   , 'BorderType','none');
  set(sp3.right  , 'BorderType','none');
            
  texto = uicontrol('Parent',sp3.left,'Style','edit','units','normalized','Position',[0.02 0.02 .96 .96] ,...
                   'FontUnits','pixels','FontSize',12,'Fontname','Courier New','HorizontalAlignment','left','max',10);

  info = uicontrol('Parent', sp2.bottom, 'Style','edit','units','normalized','Position',[0.02 0.02 .96 .96] ,...
                   'FontUnits','pixels','FontSize',10,'Fontname','Courier New','HorizontalAlignment','left','max',10);

  jinfo = javaobjects(h); jinfo = jinfo{17};
                 
  ha = axes('Parent',sp3.right,'CLim',[0 1],'YDir','reverse','Position',[0 0 1 1],'DataAspectRatio',[1 1 1],'XTick',[],'YTick',[] );
  colormap( ha , 'gray' );
  hi = image('Parent',ha,'CData',zeros(4,4),'cdatamapping','scaled');

  ht = timer( 'ExecutionMode' , 'fixedSpacing' , 'Period' , 0.03 , 'BusyMode' , 'error' );
  set(hi,'DeleteFcn',@(h,e)stop_and_delete(ht));
  function stop_and_delete(ht)
    stop(ht);
    delete(ht);
  end

  hFPS = eEntry( 'Parent',sp3.right,'Position',[1 1 10 10],'small','range',[1 200],'iValue',25 );
  
  set(h,'UserData', D );

  root = uitreenode( 'v0' , '' , 'DICOMDIR' , [], 0);

  tree = uitree( 'v0' , 'Parent', h , 'ExpandFcn', @ExpandNodeFcn, 'Root', root );
  set(tree ,'units','pixels', 'NodeSelectedCallback'  , {@NodeSelectedFcn , hi} );
  tree.expand(root);

  function placetree(varargin)
    try
      set(tree,'Position', getposition( sp1.left ,'pixels')+[5 5 -10 -10] );
    end
  end
  
  function NodeSelectedFcn( tree , ev , hi )
    DD = get( get( tree.getUIContainer , 'Parent'),'UserData' );
    N = ev.getCurrentNode.getValue;
    if ~isempty( N )
      D= eval( [ 'DD' N ] );
    end

    lastpoint= findstr(N,'.');
    if isempty(lastpoint), lastpoint=1; end
    N= N( lastpoint(end):end );
    
    if strncmp( N , '.All' , 4 ) && iscell(D)
      textotext = dispcapture(D{1});
      for nn= 2:numel(D)
        textotext = [textotext dispcapture(D{nn})];
      end
    else
      textotext = dispcapture(D);
    end
    set(texto,'string',textotext);
      
    infotext= '';
    try
%       infotext = dispstruct(D.INFO); 
%       infotext = strrep( infotext , '\n' , char(10) );
%       if infotext(1)==10, infotext(1) = []; end

      father = ev.getCurrentNode;
      while ~isempty(father)
         name = father.getValue;
         infotext = [ infotext  'INFO in: ' name '\n' dispstruct( eval(['DD' name '.INFO']) ) '\n\n\n' ];
         father = father.getParent;
%          break;
      end
    
    end
    try
      infotext = strrep( infotext , '\n' , char(10) );
      if infotext(1)==10, infotext(1) = []; end
    end
    set(info,'string',infotext);
    drawnow;
    try, 
      set( jinfo , 'CaretPosition', 0 );
    end

    if strncmp( N , '.IMAGE_' , 7 )
      try, showimage(D); end
    elseif strncmp( N , '.Position_' , 9 )
      try, showimage(D.IMAGE_001); end
    elseif strncmp( N , '.Orientation_' , 12 )
      try, showimage(D.Position_001.IMAGE_001); end
    elseif strncmp( N , '.Serie_' , 7 )
      try, showimage(D.Orientation_01.Position_001.IMAGE_001); end
    end
    
  end

  function showimage(D)
    set(hi,'CData', [0 0;0 0] ); drawnow expose
    stop(ht); FRAME = 1;
    im= [];
    if isfield( D , 'thumbnail' ) && ~isempty( D.thumbnail )
      im = D.thumbnail;
    else
      if ~isempty( D.Data )
        im = D.Data;
      else
        try, im = safedicomread( D.FileName );
        catch, fprintf('imposible to read:  %s\n',fixname(D.FileName) );
        end
      end
      if ~isempty( im )
        im   = double(im);
        im   = im - min( im(:) );
        mmax = max(im(:));
        if mmax, im= im/mmax; end
      end
    end
    if isempty( im )
      set(hi,'CData', zeros(2) ); drawnow expose
      return;
    end

    set(ha,'XLim',[0 size(im,2)+1]);
    set(ha,'YLim',[0 size(im,1)+1]);
    set(hi,'CData', im(:,:,:,1) ); drawnow expose
    if ndims( im ) > 3
      set( hFPS.panel , 'Visible','on');
      
      T = size( im , 4 );
      if T < 10,     hFPS.v = T/0.5;
      elseif T < 30, hFPS.v = T/1.0;
      else,          hFPS.v = T/2.0;
      end
      set( ht , 'Period' , 1/hFPS.v );
      
      set( ht , 'TimerFcn' , @(h,e) updateFRAME(im) );
      start(ht);
    else
      set( hFPS.panel , 'Visible','off');
    end
  end
  function updateFRAME(im)
    t = clock;
    t = t(4:6)*[ 3600 ; 60 ; 1];
    f = rem( round( t * hFPS.v ) , size(im,4) ) + 1;
    set(hi,'CData', im(:,:,:,f) );
  end

  function isleaf = IsLeaf( D )
    isleaf= [];
    try
        isleaf = fieldnames(D);
    end
    if isempty( isleaf )
      isleaf= 1;
    else
      isleaf= 0;
    end
  end

  function nodes = ExpandNodeFcn( tree , N )
    D= get( get( tree.getUIContainer , 'Parent'),'UserData' );
    if ~isempty( N )
      D= eval( [ 'D' N ] );
    end

    done = 0;

    fnames= [];
    try fnames = fieldnames(D);  end
    nnn = 1;
    for nn=1:numel(fnames)
      nname= fnames{nn};
      if strncmp( nname , 'Patient_', 8 )
        nname = [ nname ' ( ' D.(nname).PatientID ' )' ...
                        ' [' num2str(sum(strncmp(fieldnames(D.(nname)),'Study_',6))) ' Studies]' ];
%         nname = [ '<html><b>' nname '<\b> ( ' D.(nname).FamilyName ' )' ...
%                         ' [' num2str(sum(strncmp(fieldnames(D.(nname)),'Study_',6))) ' Studies]<\html>' ];
      end
      if strncmp( nname , 'Study_', 6 )
        try
          nname = [ nname ' ( ' D.(nname).StudyDescription ' -- ' D.(nname).Date ' )' ...
                          ' [' num2str(sum(strncmp(fieldnames(D.(nname)),'Serie_',6))) ' Series]' ];
        catch
          nname = [ nname ' ( ' D.(nname).StudyDescription ' )' ...
                          ' [' num2str(sum(strncmp(fieldnames(D.(nname)),'Serie_',6))) ' Series]' ];
        end
      end
      if strncmp( nname , 'Serie_', 6 )
        nnname = [ nname ' ( ' D.(nname).SerieDescription ' )' ];

        nors=0;
        try
          nors = sum(strncmp(fieldnames(D.(nname)),'Orientation_',12)); 
        end
        if nors == 1
          nslices = sum(strncmp(fieldnames(D.(nname).Orientation_01),'Position_',9));
          nphases = sum(strncmp(fieldnames(D.(nname).Orientation_01.Position_001),'IMAGE_',6));
          nnname = [ nnname ' [1x' num2str(nslices) 'x' num2str(nphases) ']' ];
        else
          nnname = [ nnname ' [' num2str(nors) ' Ors]' ];
        end
        nname = nnname;
      end
      if strncmp( nname , 'Orientation_', 12 )
        nname = [ nname ' [' num2str(sum(strncmp(fieldnames(D.(nname)),'Position_',9))) ' Slices x ' ...
          num2str(sum(strncmp(fieldnames(D.(nname).Position_001),'IMAGE_',6))) ']' ];
      end
      if strncmp( nname , 'Position_', 9 )
        nname = [ nname ' [' num2str(sum(strncmp(fieldnames(D.(nname)),'IMAGE_',6))) ' Images]' ];
      end
      if strncmp( nname , 'IMAGE_', 6 )
        try,
        nname = [ nname ' [' num2str( D.(nname).INFO.ImageSZ ) ']' ];
        end
      end

      if   strncmp( nname , 'Patient_', 8 )      || ...
           strncmp( nname , 'Study_', 6 )        || ...
           strncmp( nname , 'Serie_', 6 )        || ...
           strncmp( nname , 'Orientation_', 12 ) || ...
           strncmp( nname , 'Position_', 9 )     || ...
           strncmp( nname , 'IMAGE_', 6 )
        nodes(nnn) = uitreenode( 'v0' , [N '.' fnames{nn}], nname , '' , IsLeaf( D.(fnames{nn}) ) );
        nnn = nnn+1;
        done = 1;
      end
    end
    if ~done,      nodes = [];    end  
  end

end


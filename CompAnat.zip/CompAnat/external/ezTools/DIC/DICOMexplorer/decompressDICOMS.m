function decompressDICOMS( origen , destino )

  if ~isdir( destino )
    mkdir(destino);
  end
  
  FS = dir( origen );
  
  wb = waitbar(0,'wait...');
  CLEANUP = onCleanup( @() ishandle(wb) && delete(wb) );
  
  for f=1:numel(FS)
    if ~ishandle(wb)
      break;
    end
    waitbar( f/numel(FS) , wb , sprintf('%4d  of  %4d',f,numel(FS)) );
    try
      file_compressed = dicominfo( fullfile( origen , FS(f).name ) );
      
      data = delta_decode( file_compressed.Private_07a1_100a );
      data = reshape( data , [ file_compressed.Rows , file_compressed.Columns ] );

      file_compressed = rmfield( file_compressed , 'TransferSyntaxUID' );
      dicomwrite( data , fullfile( destino , FS(f).name ) , file_compressed );
    end
  end

end

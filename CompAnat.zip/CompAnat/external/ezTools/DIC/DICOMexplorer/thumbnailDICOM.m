function S = thumbnailDICOM( S , sz )

  if nargin < 2, sz = 128; end
%   if isscalar(sz), sz = [1 1]*sz; end
%   sz = sz(:).';
  
  PS= GetFieldName( S , 'Patient_' );
  for p= 1:numel(PS),  P= PS{p};
    TS= GetFieldName( S.(P) , 'Study_' );
    for t=1:numel(TS),   T= TS{t};
      RS= GetFieldName( S.(P).(T) , 'Serie_' );
      for r=1:numel(RS),   R= RS{r};
        OS= GetFieldName( S.(P).(T).(R) , 'Orientation_' );
        for o=1:numel(OS),   O= OS{o};
          ZS= GetFieldName( S.(P).(T).(R).(O) , 'Position_' );
          for z=1:numel(ZS),   Z= ZS{z};
            IS= GetFieldName( S.(P).(T).(R).(O).(Z) , 'IMAGE_' );
            for i=1:numel(IS),   I= IS{i};
              im = S.(P).(T).(R).(O).(Z).(I).Data;
              if isempty( im )
                try, im = safedicomread( S.(P).(T).(R).(O).(Z).(I).FileName ); end
              end
              if isempty( im )
                S.(P).(T).(R).(O).(Z).(I).thumbnail = zeros(2);
                continue;
              end
              szim = [ size( im ) , 1 , 1 , 1 , 1 , 1 ];
              im = double(im);
              im = DCTresize( im , [ round(szim(1:2)/szim(1)*sz) , szim(3:end) ] );
              
              mmin = min(im(:));
              if mmin, im = im - mmin; end
              mmax = max(im(:));
              if mmax, im = im/mmax; end
              S.(P).(T).(R).(O).(Z).(I).thumbnail = im;
            end
          end
        end
      end
    end
  end
            
  function names = GetFieldName( S , idx )
    names = fieldnames(S);
    
    if nargin > 1
      if isnumeric( idx )
        names = names( idx );
      elseif ischar( idx )
        names = names( strncmpi( names , idx , numel(idx) ) );
      elseif islogical(idx)
        names = names( idx );
      end
%       if numel( names ) == 1, names = names{1}; end
    end
  end
end

function DICOMexplorer(D)

  if ~any( strcmp( import , 'javax.swing.*' ) )
    import javax.swing.*;
  end

  h  = figure('Units', 'pixels', 'Position',[5 80 300 890],...
              'NumberTitle', 'off',...
              'name','DICOMDIR Explorer',...
              'Toolbar', 'none',...
              'Menu','none');
  h2 = figure('Units', 'pixels', 'Position',[310 490 400 400],...
              'NumberTitle', 'off',...
              'Toolbar', 'none',...
              'Menu','none');
  ha = axes('Parent',h2,'CLim',[0 1],'YDir','reverse');
  colormap( ha , 'gray' );
  hi = image('Parent',ha,'CData',zeros(4,4));

  set(h,'UserData', D );

  root = uitreenode( '' , 'DICOMDIR' , [], 0);

  tree = uitree(h, 'ExpandFcn', @ExpandNodeFcn, 'Root', root );
  set(tree , 'Units', 'normalized'   ,...
             'position', [0 0 1 1] ,...
             'NodeSelectedCallback'  , {@NodeSelectedFcn , hi} );
  tree.expand(root);

  figurewindowstate( h ,'ontop');
  figurewindowstate( h2,'ontop');

  function NodeSelectedFcn( tree , ev , hi )
    D = get( get( tree.getUIContainer , 'Parent'),'UserData' );
    N = ev.getCurrentNode.getValue;
    if ~isempty( N )
      D= eval( [ 'D' N ] );
    end

    lastpoint= findstr(N,'.');
    N= N( lastpoint(end):end );
    
    clc;
    if strcmp( N(1:4) , '.All')
      if iscell( D )
        for nn= 1:numel(D)
          disp(D{nn});
        end
      else
        disp(D);
      end
    else
      disp(D);
      try
        fprintf('------------------------------------------------------------\n');
        dispstruct(D.INFO); 
      end
      if numel(N)>7 && strcmp( N(1:7), '.IMAGE_' )
        if ishandle( hi ) 
          im= [];
          if isempty( D.Data )
            try
              im= safedicomread( D.FileName );
            end
          else
            im= D.Data;
          end
          if ~isempty( im )
            im= double(im);
            im= im - min( im(:) );
            im= im/max(im(:));
            set(hi, 'CData', im ,'cdatamapping','scaled');
            ax= get(hi,'Parent');
            set(ax,'XLim', [0 D.Size(2)-1]);
            set(ax,'YLim', [0 D.Size(2)-1]);
          end
        end
      end
    end
  end

  function isleaf = IsLeaf( D )
    isleaf= [];
    try
        isleaf = fieldnames(D);
    end
    if isempty( isleaf )
      isleaf= 1;
    else
      isleaf= 0;
    end
  end

  function nodes = ExpandNodeFcn( tree , N )
    D= get( get( tree.getUIContainer , 'Parent'),'UserData' );
    if ~isempty( N )
      D= eval( [ 'D' N ] );
    end

    done = 0;

    fnames= [];
    try fnames = fieldnames(D);  end
    for nn=1:numel(fnames)
      nname= fnames{nn};
      if strncmp( nname , 'Patient_', 8 )
        nname = [ nname ' ( ' D.(nname).FamilyName ' )' ];
      end
      if strncmp( nname , 'Study_', 6 )
        try
          nname = [ nname ' ( ' D.(nname).StudyDescription ' -- ' D.(nname).Date ' )' ];
        catch
          nname = [ nname ' ( ' D.(nname).StudyDescription ' )' ];
        end
      end
      if strncmp( nname , 'Serie_', 6 )
        nname = [ nname ' ( ' D.(nname).SerieDescription ' )' ];
      end
      
      nodes(nn) = uitreenode( [N '.' fnames{nn}], nname , '' , IsLeaf( D.(fnames{nn}) ) );
      done = 1;
    end
    if ~done,      nodes = [];    end  
  end

end


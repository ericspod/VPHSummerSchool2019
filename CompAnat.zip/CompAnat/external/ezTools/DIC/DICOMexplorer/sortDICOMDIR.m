function sD= sortDICOMDIR( D )
  pth = fileparts( D.Filename );

  sD.FileModDate = D.FileModDate;
  sD.Format      = sprintf('%s(%d)', D.Format , D.FormatVersion );
  sD.FileSetID   = D.FileSetID;
  
  DirRecords= D.DirectoryRecordSequence;
  items= fieldnames( DirRecords );

  cP = 0;   P = enum;       % P   patient
  cT = 0;                   % T   study
  cS = 0;                   % S   series
  cO = 0;                   % O   orientation
  cC = 0;                   % C   position (coordinates)
  cI = 0;                   % I   image
  cF = 0;                   % F   phase
  
  fprintf('\n 00000 of 00000 items');
%   for i=1:300
  for i=1:numel( items )
    fprintf( repmat( '\b',1,21 ) );
    fprintf('%5d of %5d items',i,numel(items));
    item= DirRecords.( items{i} );
    switch item.DirectoryRecordType
      case 'PATIENT'
        [ cP , P ] = P(item.PatientName.FamilyName);
          cP = sprintf('Patient_%02d',cP);

        sD.AllPatients     = P.names;
        sD.(cP).FamilyName = item.PatientName.FamilyName;
        sD.(cP).PatientID  = item.PatientID;
        sD.(cP).BirthDate  = ToDay( item.PatientBirthDate );
        sD.(cP).Sex        = item.PatientSex;
  
      case 'STUDY'
        try T.(cP); catch T.(cP)= enum; end
        [ cT , T.(cP) ] = T.(cP)( item.StudyDescription );
          cT = sprintf('Study_%02d',cT);

        sD.(cP).AllStudies            = T.(cP).names;
        sD.(cP).(cT).StudyDescription = item.StudyDescription;
        sD.(cP).(cT).Date             = [ ToDay(item.StudyDate)  ' - ' time2str( str2num( item.StudyTime ) , '24','hms',-3) ];

      case 'SERIES'
        try S.(cP).(cT); catch S.(cP).(cT)=enum; end
        [ cS , S.(cP).(cT) ] = S.(cP).(cT)( item.SeriesDescription );
          cS = sprintf('Serie_%02d',cS);

        sD.(cP).(cT).AllSeries             = S.(cP).(cT).names;
        sD.(cP).(cT).(cS).SerieDescription = item.SeriesDescription;
        sD.(cP).(cT).(cS).Modality         = item.Modality;
        sD.(cP).(cT).(cS).Institution      = item.InstitutionName;
        
      case 'IMAGE'
        try O.(cP).(cT).(cS); catch O.(cP).(cT).(cS)= enum; end
        [ cO , O.(cP).(cT).(cS) ] = O.(cP).(cT).(cS)( item.ImageOrientationPatient' );
          cO = sprintf('Orientation_%02d',cO);

        sD.(cP).(cT).(cS).AllOrientations       = O.(cP).(cT).(cS).names;
        sD.(cP).(cT).(cS).(cO).ImageOrientation = reshape( item.ImageOrientationPatient ,3,2)';
        
        try C.(cP).(cT).(cS).(cO); catch C.(cP).(cT).(cS).(cO)= enum; end
        [ cC ,  C.(cP).(cT).(cS).(cO) ] = C.(cP).(cT).(cS).(cO)( item.ImagePositionPatient' );
        sD.(cP).(cT).(cS).(cO).AllPositions     = C.(cP).(cT).(cS).(cO).names;
        
        Iinfo = dicominfo( fixname( pth , item.ReferencedFileID ) );

        try F.(cP).(cT).(cS).(cO); catch F.(cP).(cT).(cS).(cO)= enum; end
        [ cF ,  F.(cP).(cT).(cS).(cO) ] = F.(cP).(cT).(cS).(cO)( ToPhase( Iinfo.ImageComments ) );
        sD.(cP).(cT).(cS).(cO).AllPhases      = F.(cP).(cT).(cS).(cO).names;
        
        cI = sprintf('IMAGE_Position_%03d_Phase_%03d', cC, cF);
        
        sD.(cP).(cT).(cS).(cO).(cI).Position            = item.ImagePositionPatient';
        sD.(cP).(cT).(cS).(cO).(cI).Phase               = ToPhase( Iinfo.ImageComments );
        sD.(cP).(cT).(cS).(cO).(cI).Data                = [ ];
        sD.(cP).(cT).(cS).(cO).(cI).FileName            = fixname( pth , item.ReferencedFileID );
        sD.(cP).(cT).(cS).(cO).(cI).Size                = [ Iinfo.Rows Iinfo.Columns ];
        sD.(cP).(cT).(cS).(cO).(cI).PixelsSpacing       = Iinfo.PixelSpacing';
        sD.(cP).(cT).(cS).(cO).(cI).ImageComments       = Iinfo.ImageComments;
        sD.(cP).(cT).(cS).(cO).(cI).SliceThickness      = Iinfo.SliceThickness;
        sD.(cP).(cT).(cS).(cO).(cI).ImageInstanceNumber = item.InstanceNumber;
        sD.(cP).(cT).(cS).(cO).(cI).INFO                = CleanInfo( Iinfo );
        
%         try
%           sD.(cP).(cT).(cS).(cO).(cC).(cI).Data   = safedicomread( [pth filesep item.ReferencedFileID] );
%         end
    end
    fprintf('\n');
  end
  
  function day= ToDay( day )
    day= datestr(datenum([str2num(day(1:4)) str2num(day(5:6)) str2num(day(7:8))]), 'mmm.dd,yyyy');
  end

  function ii= CleanInfo( i )
                             ii.FileModDate = i.FileModDate;
                                ii.BitDepth = i.BitDepth;
                               ii.ColorType = i.ColorType;
               ii.ImplementationVersionName = i.ImplementationVersionName;
                    ii.SpecificCharacterSet = i.SpecificCharacterSet;
                               ii.ImageType = i.ImageType;
                               ii.StudyDate = ToDay( i.StudyDate );
                              ii.SeriesDate = ToDay( i.SeriesDate );
                         ii.AcquisitionDate = ToDay( i.AcquisitionDate );
                             ii.ContentDate = ToDay( i.ContentDate );
                               ii.StudyTime = time2str(str2double( i.StudyTime ), '24','hms',-3);
                              ii.SeriesTime = time2str(str2double( i.SeriesTime ), '24','hms',-3);
                         ii.AcquisitionTime = time2str(str2double( i.AcquisitionTime ), '24','hms',-3);
                             ii.ContentTime = time2str(str2double( i.ContentTime ), '24','hms',-3);
                                ii.Modality = i.Modality;
                            ii.Manufacturer = i.Manufacturer;
                         ii.InstitutionName = i.InstitutionName;
                             ii.StationName = i.StationName;
                       ii.SeriesDescription = i.SeriesDescription;
                             ii.PatientName = i.PatientName;
                               ii.PatientID = i.PatientID;
                        ii.PatientBirthDate = ToDay( i.PatientBirthDate );
                              ii.PatientSex = i.PatientSex;
                         ii.PregnancyStatus = i.PregnancyStatus;
                      ii.ContrastBolusAgent = i.ContrastBolusAgent;
                        ii.BodyPartExamined = i.BodyPartExamined;
                          ii.SliceThickness = i.SliceThickness;
                            ii.ProtocolName = i.ProtocolName;
                     ii.ContrastBolusVolume = i.ContrastBolusVolume;
                        ii.ContrastFlowRate = i.ContrastFlowRate;
                    ii.ContrastFlowDuration = i.ContrastFlowDuration;
    ii.ContrastBolusIngredientConcentration = i.ContrastBolusIngredientConcentration;
                       ii.ConvolutionKernel = i.ConvolutionKernel;
                         ii.PatientPosition = i.PatientPosition;
               ii.Private_0019_10xx_Creator = i.Private_0019_10xx_Creator;
                       ii.Private_0019_10b0 = i.Private_0019_10b0;
                            ii.SeriesNumber = i.SeriesNumber;
                       ii.AcquisitionNumber = i.AcquisitionNumber;
                          ii.InstanceNumber = i.InstanceNumber;
                    ii.ImagePositionPatient = i.ImagePositionPatient';
                 ii.ImageOrientationPatient = i.ImageOrientationPatient';
                           ii.ImageComments = i.ImageComments;
               ii.Private_0021_10xx_Creator = i.Private_0021_10xx_Creator;
                         ii.SamplesPerPixel = i.SamplesPerPixel;
  end

  function F= ToPhase( c )
    i= findstr( c, '%');
    F= str2num( c( i-3:i-1 ) );
  end
  
end

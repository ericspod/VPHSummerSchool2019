function varargout = safedicomread( varargin )

  if ischar( varargin{1} )
    varargin{1} = fixname( varargin{1} );
  elseif isstruct( varargin{1} ) && isfield( varargin{1} , 'FileName' )
    varargin{1}.FileName = fixname( varargin{1}.FileName );
  end

  try
    
    [ varargout{1:nargout} ] = dicomread( varargin{:} );
    
  catch %may be it is a compressed dicom, try dicomdecompress
    
    varargout{1} = dicomdecompress( varargin{1} );
    
  end

end

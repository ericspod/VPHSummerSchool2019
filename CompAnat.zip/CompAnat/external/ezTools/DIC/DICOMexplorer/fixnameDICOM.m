function S = fixnameDICOM( S , change_filename_fcn )

  PS= GetFieldName( S , 'Patient_' );
  for p= 1:numel(PS),  P= PS{p};
    TS= GetFieldName( S.(P) , 'Study_' );
    for t=1:numel(TS),   T= TS{t};
      RS= GetFieldName( S.(P).(T) , 'Serie_' );
      for r=1:numel(RS),   R= RS{r};
        OS= GetFieldName( S.(P).(T).(R) , 'Orientation_' );
        for o=1:numel(OS),   O= OS{o};
          ZS= GetFieldName( S.(P).(T).(R).(O) , 'Position_' );
          for z=1:numel(ZS),   Z= ZS{z};
            IS= GetFieldName( S.(P).(T).(R).(O).(Z) , 'IMAGE_' );
            for i=1:numel(IS),   I= IS{i};
              fn = S.(P).(T).(R).(O).(Z).(I).FileName;
              fn = feval( change_filename_fcn , fn );
              S.(P).(T).(R).(O).(Z).(I).FileName = fn;
            end
          end
        end
      end
    end
  end
            
  function names = GetFieldName( S , idx )
    names = fieldnames(S);
    
    if nargin > 1
      if isnumeric( idx )
        names = names( idx );
      elseif ischar( idx )
        names = names( strncmpi( names , idx , numel(idx) ) );
      elseif islogical(idx)
        names = names( idx );
      end
    end
  end
end

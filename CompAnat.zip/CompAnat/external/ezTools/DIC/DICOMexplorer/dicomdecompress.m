function data_ = dicomdecompress( file_compressed , file_decompressed )

  if ischar( file_compressed )
    file_compressed = dicominfo( file_compressed );
  end
  if ~isstruct( file_compressed )
    error('a struct or a filename was expected');
  end

  if ~isfield( file_compressed , 'Private_07a1_100a' )
    error( 'no ''Private_07a1_100a'' data');
  end
  
  data = delta_decode( file_compressed.Private_07a1_100a );
  data = reshape( data , [ file_compressed.Rows , file_compressed.Columns ] );
  
  if nargout, data_ = data; end

  if nargin > 1
    if ~ischar( file_decompressed )
      error(' file_decompressed  is expected to be a valid filename' );
    end
    file_compressed = rmfield( file_compressed , 'TransferSyntaxUID' );
    dicomwrite( data , file_decompressed , file_compressed );
  end
end

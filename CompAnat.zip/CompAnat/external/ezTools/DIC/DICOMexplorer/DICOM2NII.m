function nii = DICOM2NII( S , varargin )

  [varargin,i,onlyphases]= parseargs( varargin ,'onlyphases','$DEFS',0 );


  if isstruct( S )
    
    S = validateDICOMDIR( S );
    [L,orien] = DICOMDIR2OrientationsList( S , 'mask', [] );
    if     numel(L)==0
      error('invalid input');
    elseif numel(L)==1
      orien= orien(1,:);
    else
      index= listdlg( 'ListString' , L ,...
        'SelectionMode','single','ListSize',[800 600],'Name','Select Volume' ,...
        'PromptString','Choose a Volume or a I3D data:', 'uh',18,'fus',2,'ffs',4  );
      orien= orien(index,:);
    end
    S = getfield( S , orien{:} );
    
    if onlyphases, S = removePHASES( S ); end
    
    S = getFileNames( S );
    S = unique( S );
  end
  

  if ~iscell( S ), error('invalid input'); end
    
  while 1
    tdir = fullfile( tempdir , [ 'DICOM2NII_' uuid(8) ] );
    if isdir( tdir ), continue; end
    mkdir( tdir );
    break;
  end

  for f = S(:).'
    [p,nf,e] = fileparts( f{1} );
    nf = [  nf   '_'  uuid(8)  ];
    while isfile( [ fullfile( tdir , nf ) e ] , 'fast' )
      nf = [ nf '_' ];
    end
    copyfile( f{1} , [ fullfile( tdir , nf ) e ] , 'f' );
  end

  if ispc
    [status,nii] = system( sprintf( '%s\\dcm2nii.exe  -o  %s   -r  n  -g  n   %s' , ...
            fileparts(which('DICOM2NII')) , tempdir , tdir ) );

    nii = regexp( nii ,'Saving (\<[^\n]*\>)\n' , 'tokens' );
    nii = cellfun( @(c) c{1} , nii , 'UniformOutput' , false );
    if numel(nii) == 1
      nii = nii{1};
    else
      warning('DICOMDIR:multipleDICOM2NII','multiples images in input');
    end
          
    system( sprintf( 'del /F /Q  %s\\*.*', tdir ) );
  end
  
  while 1
    try,
      rmdir( tdir );
      break;
    end
  end
  
  
  function S = removePHASES( S )
    for P = fieldnames( S )'
      if ~isstruct( S.(P{1}) ), continue; end
      for I = fieldnames( S.(P{1}) )'
        if strncmp( I{1} , 'IMAGE_' , 6 )  &&  ~ismember( str2double( I{1}(7:end) ) , onlyphases )
          S.(P{1}) = rmfield( S.(P{1}) , I{1} );
        end
      end
    end
  end
  

  function S = getFileNames( O )
    S = {};
    if ~isstruct( O ), return; end
    for f = fieldnames( O )'
      if strcmp( f{1} , 'FileName' ),
        S = O.FileName;
        return;
      end
      S = cat(1, S , getFileNames( O.(f{1}) ) );
    end
  end


end

function S = moveDCMfiles( S , todir )

  PS = GetFieldName( S , 'Patient_' );
  for p = 1:numel(PS),   P = PS{p};
    DIR_P = CleanDirName( [ todir ...
                            filesep S.(P).PatientID ] );
    
    TS = GetFieldName( S.(P) , 'Study_' );
    for t = 1:numel(TS), T = TS{t};
      DIR_T = CleanDirName( [ DIR_P ...
                            filesep T ' (' S.(P).(T).StudyDescription ' -- ' S.(P).(T).Date ')' ] );

      RS = GetFieldName( S.(P).(T) , 'Serie_' );
      for r = 1:numel(RS),  R = RS{r};
        DIR_R = CleanDirName( [ DIR_T ... 
                                filesep R ' (' S.(P).(T).(R).SerieDescription ')' ] );
        
        OS = GetFieldName( S.(P).(T).(R) , 'Orientation_' );
        for o = 1:numel(OS),  O = OS{o};
          DIR_O = CleanDirName( [ DIR_R ... 
                                  filesep O  sprintf('( %d x %d x %d x %d )' , ImageSize( S.(P).(T).(R).(O) )) ]);
          try, mkdir( DIR_O ); catch, error('error 1!!!'); end


          DICOMDIR              = rmfield( S              , PS([1:p-1 p+1:end]) );
          DICOMDIR.(P)          = rmfield( S.(P)          , TS([1:t-1 t+1:end]) );
          DICOMDIR.(P).(T)      = rmfield( S.(P).(T)      , RS([1:r-1 r+1:end]) );
          DICOMDIR.(P).(T).(R)  = rmfield( S.(P).(T).(R)  , OS([1:o-1 o+1:end]) );
          DICOMDIR = orderDICOM( groupDICOMinfo( DICOMDIR ) );
          DICOMDIR = ChangeFileNames( DICOMDIR , [ '..' filesep '..' filesep '..' filesep '..' filesep '..' ] );
          save( [DIR_O filesep 'DICOMDIR.mat'] , 'DICOMDIR' );
        end
        
        DICOMDIR.(P).(T)      = rmfield( S.(P).(T)      , RS([1:r-1 r+1:end]) );
        DICOMDIR = orderDICOM( groupDICOMinfo( DICOMDIR ) );
        DICOMDIR.(P).(T).(R) = ChangeFileNames( DICOMDIR.(P).(T).(R) , [ '..' filesep '..' filesep '..' filesep '..' ] );
        save( [DIR_R filesep 'DICOMDIR.mat'] , 'DICOMDIR' );
      end

      DICOMDIR.(P)          = rmfield( S.(P)          , TS([1:t-1 t+1:end]) );
      DICOMDIR = orderDICOM( groupDICOMinfo( DICOMDIR ) );
      DICOMDIR = ChangeFileNames( DICOMDIR , [ '..' filesep '..' filesep '..' ] );
      save( [DIR_T filesep 'DICOMDIR.mat'] , 'DICOMDIR' );
    end

    DICOMDIR              = rmfield( S              , PS([1:p-1 p+1:end]) );
    DICOMDIR = orderDICOM( groupDICOMinfo( DICOMDIR ) );
    DICOMDIR = ChangeFileNames( DICOMDIR , [ '..' filesep '..' ] );
    save( [DIR_P filesep 'DICOMDIR.mat'] , 'DICOMDIR' );
  end

  DICOMDIR = S;
  DICOMDIR = ChangeFileNames( DICOMDIR , [ '..' ] );
  save( [todir filesep 'DICOMDIR.mat'] , 'DICOMDIR' );
  
  
  
  function S = ChangeFileNames( S , sub )
    if ~isstruct( S ), return; end
    if isfield(S,'FileName')
%       [d,name,ext] = fileparts( S.FileName );
      S.FileName = [ sub filesep S.FileName  ];
      return;
    end
    F = fieldnames( S ); F(strcmp(F,'INFO')) = [];
    for f= 1:numel(F)
      S.(F{f}) = ChangeFileNames( S.(F{f}) , sub );
    end
  end
  
  
  
  function [d,s] = DirName( d )
    d = fixname( d );
    bar = find( d == filesep , 1 , 'last' );
    s = DIR( find( d == filesep , 1 , 'last' )+1:end);
    d = d(1:bar-1);
  end
  
  function x = CleanDirName( x )
    x = strrep( x , ':' , '_' );
    x = strrep( x , ['_' filesep] , [':' filesep] );
    x = strrep( x , '<' , '_' );
    x = strrep( x , '>' , '_' );
  end


  function names = GetFieldName( S , idx )
    names = fieldnames(S);
    
    if nargin > 1
      if isnumeric( idx )
        names = names( idx );
      elseif ischar( idx )
        names = names( strncmpi( names , idx , numel(idx) ) );
      elseif islogical(idx)
        names = names( idx );
      end
%       if numel( names ) == 1, names = names{1}; end
    end
  end

  function sz = ImageSize( orientation )
    sz = [ orientation.Position_001.IMAGE_001.Size                       , ...
           numel( GetFieldName( orientation , 'Position_' ))             , ...
           numel( GetFieldName( orientation.Position_001 , 'IMAGE_' ))   ];
  end


end

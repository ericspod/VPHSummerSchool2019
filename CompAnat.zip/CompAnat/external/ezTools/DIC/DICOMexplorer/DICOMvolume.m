function [ V , X,Y,Z,R, common_info , full_info ] = DICOMvolume( S , varargin )

  DRAW= 0;

  [varargin,i,onlyphases]= parseargs( varargin ,'onlyphases','$DEFS$',0 );

  phaseATT= 'InstanceNumber';  % TriggerTime

  try
    ORI = S.ImageOrientation;
  catch
    ORI = [1 0 0;0 1 0];
  end

%   POS = enum( S.AllPositions );
  POS = {};
  ZS= GetFieldName( S , 'Position_' );  infoZ= {};
  for z= 1:numel(ZS),    Z= ZS{z};
    POS{end+1} = S.(Z).ImagePosition';
  end

  ORI(3,:)= cross( ORI(1,:), ORI(2,:) );

  ORI(1,:)= ORI(1,:)/norm( ORI(1,:) );
  ORI(2,:)= ORI(2,:)/norm( ORI(2,:) );
  ORI(3,:)= ORI(3,:)/norm( ORI(3,:) );

  R = ORI';

  %Sort the positions
  xyz = cell2mat( POS' );
  xyz = transform( xyz , inv(R) , 'rows' );
  [aux,i]= sort( xyz(:,3) );
  POS = POS(i);

  xyz = xyz(i,:);
  Z= xyz(:,3)-xyz(1,3);
%   Z= xyz(:,3);
  Z= Z(:)';
  origin= transform( xyz(1,:), R , 'rows');
  R= [R origin']; R(4,4)= 1;

  if DRAW
    figure;
  %   set(gca,'XLim',[0 numel(POS.names)+1],'XLimMode','manual');
    xlabel('Position (or Z coordinate)');
    ylabel('Phase');
  end

  %Fillin the volume
  fprintf('\nz: 000/000  - phase: 000/000');
  Positions= fieldnames( S ); Positions= Positions(strncmp( 'Position_' , Positions , 9));
  for p=1:numel(Positions)
    this_pos= Positions{p};

    Inames = fieldnames( S.(this_pos) ); Inames= Inames(strncmp( 'IMAGE_' , Inames , 6));
    %read and sorting phases
    FAS= zeros(1,numel(Inames));
    for n= 1:numel(Inames)
      try
        FAS(n) = S.(this_pos).(Inames{n}).(phaseATT);
      catch
        dinfo  = dicominfo( fixname( S.(this_pos).(Inames{n}).FileName ) );
        FAS(n) = dinfo.(phaseATT);
      end
    end
    [FAS,order]= sort( FAS );
    
    %%%chequea que las FASES se correspondan con las
    %%%fases de la posicion anterior
    if p>1
      if numel( FAS ) ~= numel(oldFAS)
        [~,oorder] = unique( FAS , 'first' );
        order = order( oorder );
        FAS = FAS( order );
      end
      try
        FASdiff= diff(oldFAS) - diff(FAS);
      catch
        FASdiff= 1;
      end
      if any( abs(FASdiff) > 0.01)
        error('No phase correspondence.\n');
      end
    end
    oldFAS= FAS;

    %%% reordena las imagenes segun su fase
    Inames= Inames(order);

    if     onlyphases, loadphases= onlyphases;
    else,              loadphases= 1:numel(Inames);  end
    for i_cF= 1:numel(loadphases)
      cF= loadphases(i_cF);
      I= Inames{cF};
%       cP = POS( S.(this_pos).ImagePosition );
      cP = find( cellfun( @(x) isequal( x.' , S.(this_pos).ImagePosition ) , POS ) );
      

      fprintf( repmat( '\b',1,29 ) );
      fprintf('z: %3d/%3d   - phase: %3d/%3d', cP , numel( POS ) , cF , numel(FAS) );

      try
        im= S.(this_pos).(I).Data;
      catch
        im= [];
      end
      if isempty( im )
        im    = safedicomread( S.(this_pos).(I).FileName );
      end

      dinfo = dicominfo( fixname( S.(this_pos).(I).FileName ));
      if ~exist('common_info','var')
        common_info= dinfo;
      else
        common_info= equalfields( common_info, dinfo );
      end

      if DRAW
        try
          fase = double( S.(this_pos).(I).(phaseATT) );
        catch
          fase = double( dinfo.(phaseATT) );
        end
        line('XData',S.(this_pos).(I).Position(3),'YData', fase ,'Linestyle','none','marker','.','Color','red','MarkerSize',10);
        text( S.(this_pos).(I).Position(3) , fase , sprintf('(%d,%d)',cP,cF),'FontUnits','pixels','FontSize',7,'FontName','courier');
        drawnow;
      end
      
      if p==1 && i_cF==1
%         V(size(im,1),size(im,2),numel(POS.names),numel(loadphases)) = 0;
        V= zeros(size(im,1),size(im,2),numel(POS),numel(loadphases),class(im));
      end
      try
      V(:,:,cP,i_cF)= im;
      end
      full_info{cP,i_cF} = dinfo;

      [sy, sx]= size(im);
%       X= (1:sx) - 1; X= X*S.(this_pos).(I).PixelsSpacing(1);
%       Y= (1:sy) - 1; Y= Y*S.(this_pos).(I).PixelsSpacing(2);
      X= (1:sx) - 1; X= X*dinfo.PixelSpacing(1);
      Y= (1:sy) - 1; Y= Y*dinfo.PixelSpacing(2);
    end
  end
  fprintf( '\n' );

  
  
  function names = GetFieldName( S , idx )
    names = fieldnames(S);
    
    if nargin > 1
      if isnumeric( idx )
        names = names( idx );
      elseif ischar( idx )
        names = names( strncmpi( names , idx , numel(idx) ) );
      elseif islogical(idx)
        names = names( idx );
      end
%       if numel( names ) == 1, names = names{1}; end
    end
  end
  
end

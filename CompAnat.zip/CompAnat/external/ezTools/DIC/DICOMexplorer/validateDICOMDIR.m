function S = validateDICOMDIR( S )


  PS= GetFieldName( S , 'Patient_' );
  if isempty(PS)
    S=struct('Patient_00',S); 
    PS={'Patient_00'}; 
  end

  for p= 1:numel(PS),  P= PS{p};
    TS= GetFieldName( S.(P) , 'Study_' );
    if isempty(TS)
      S.(P) = struct('Study_00',S.(P));
      S.(P).PatientID = 'noPatientID';
      TS={'Study_00'};
    end

    for t=1:numel(TS),   T= TS{t};
      RS= GetFieldName( S.(P).(T) , 'Serie_' );
      if isempty(RS)
        S.(P).(T) = struct('Serie_00',S.(P).(T)); 
        S.(P).(T).StudyDescription = 'noStudyDescription'; 
        S.(P).(T).Date = 'noDate'; 
        RS = {'Serie_00'}; 
      end
      
      for r=1:numel(RS),   R= RS{r};
        OS= GetFieldName( S.(P).(T).(R) , 'Orientation_' );
        if isempty(OS)
          S.(P).(T).(R) = struct('Orientation_00',S.(P).(T).(R));
          S.(P).(T).(R).SerieDescription = 'noSerieDescription';
          OS={'Orientation_00'}; 
        end
        
      end
    end
  end

        
  function names = GetFieldName( S , idx )
    names = fieldnames(S);
    
    if nargin > 1
      if isnumeric( idx )
        names = names( idx );
      elseif ischar( idx )
        names = names( strncmpi( names , idx , numel(idx) ) );
      elseif islogical(idx)
        names = names( idx );
      end
%       if numel( names ) == 1, names = names{1}; end
    end
  end
        
end

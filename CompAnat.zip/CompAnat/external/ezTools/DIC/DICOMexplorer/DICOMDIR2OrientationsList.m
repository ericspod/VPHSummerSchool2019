function [L , orientations] = DICOMDIR2OrientationsList(S , varargin )
  L= {};
  orientations= {};

  [varargin,i,pattern]= parseargs(varargin,'mask' );

  
  
  
  S = validateDICOMDIR( S );
  
  
  
  
  
  PS= GetFieldName( S , 'Patient_' );  infoP= {};
  for p= 1:numel(PS),  P= PS{p};
    TS= GetFieldName( S.(P) , 'Study_' );  infoT= {};
    for t=1:numel(TS),   T= TS{t};
      RS= GetFieldName( S.(P).(T) , 'Serie_' );  infoR= {};
      for r=1:numel(RS),   R= RS{r};
        OS= GetFieldName( S.(P).(T).(R) , 'Orientation_' );  infoO= {};
        for o=1:numel(OS),   O= OS{o};
        
%           L{end+1}= ...
%             [ sprintf( ' (%3d x %3d x %3d x %2d) - ' , ...
%                                 S.(Ps{p}).(Ts{t}).(Ss{s}).(Os{o}).Position_001.IMAGE_Phase_001.Size , ...
%                                 numel( S.(Ps{p}).(Ts{t}).(Ss{s}).(Os{o}).AllPositions ), ...
%                                 numel( S.(Ps{p}).(Ts{t}).(Ss{s}).(Os{o}).AllPhases    ) ) ...
%               S.(Ps{p}).FamilyName  ...
%                 ' :: ' S.(Ps{p}).(Ts{t}).StudyDescription ...
%                   ' :: ' S.(Ps{p}).(Ts{t}).(Ss{s}).SerieDescription ...
%                     ' :: ' sprintf('Orientation_%02d',o) ];

          L{end+1}= sprintf( ' (%3d x %3d x %3d x %2d) - %s :: %s ( %s ) :: %s' , ...
                              ImageSize( S.(P).(T).(R).(O) )    , ...
                              S.(P).PatientID                  , ...
                              S.(P).(T).StudyDescription        , ... 
                              S.(P).(T).Date                    , ...
                              S.(P).(T).(R).SerieDescription    );

          if ( isempty(pattern) || strcmp( L{end} , pattern ) )  ||  ~isempty( regexp( L{end} , pattern ,'ONCE') )
            orientations{end+1,1}= P;
            orientations{end  ,2}= T;
            orientations{end  ,3}= R;
            orientations{end  ,4}= O;
          else
            L(end)= [];
          end

        end
      end
    end
  end

  if ~nargout
    for o= 1:numel(L)
      disp(L{o});
    end
  end

  
  function sz = ImageSize( orientation )
    sz = [ orientation.Position_001.IMAGE_001.Size                       , ...
           numel( GetFieldName( orientation , 'Position_' ))             , ...
           numel( GetFieldName( orientation.Position_001 , 'IMAGE_' ))   ];
  end

  function names = GetFieldName( S , idx )
    names = fieldnames(S);
    
    if nargin > 1
      if isnumeric( idx )
        names = names( idx );
      elseif ischar( idx )
        names = names( strncmpi( names , idx , numel(idx) ) );
      elseif islogical(idx)
        names = names( idx );
      end
%       if numel( names ) == 1, names = names{1}; end
    end
  end

end

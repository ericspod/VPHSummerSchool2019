function SortDCM( directorio )
  
  oldPWD= pwd;
  if nargin>0
    cd(directorio);
  end

  DICOMDIR= sortDCMfiles(pwd);
  
  save('DICOMDIR.mat','DICOMDIR');

  L= DICOMDIR2OrientationsList(DICOMDIR);
  for o=1:numel(L)
    fprintf( '%s\n' , L{o} );
  end

  cd(oldPWD);
end

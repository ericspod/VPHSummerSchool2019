function [] = CallcmGui(comfile,options)
% Function to make the call to cmGui, depending on the OS used.
% INPUT:
% - comfile: name of the .com file to run in cmGui.
% - options: other possibilities to call cmGui:
%        options.bExit: add a '-batch' in the call in order to exit once it
%        finishes.
% Need to have a global variable named WhichOperatingSystem defined 
% beforehand. If not, a windows machine is assumed.

%global WhichOperatingSystem;

bExit=0;
bAnd =0;
bWaitLonger = 0;

if nargin>=1
    if comfile(2)==':' %comfile(1)=='D' || comfile(1)=='C' || comfile(1)=='E' || comfile(1)=='H'
        % cmGui does not work with absolute windows paths!
        CurrentDir = pwd;
        TargetDir = comfile;
        fprintf('ERROR! cmGui does not work with absolute windows paths in a system call!\n');
        fprintf('    ... trying to get a relative path\n');
        fprintf('        - Original file: %s\n',comfile);
        fprintf('        - Current direc: %s\n',CurrentDir);
        relativePath = GetRelativePath(CurrentDir,TargetDir);
        %[path name] = GetPath(comfile);
        %comfile = [relativePath name];
        comfile = ['''' '\' relativePath ''''];
        fprintf('        - Updated path in the file: %s\n',comfile);
    end
else
    comfile = '';
    bAnd = 1;
end
Additionaloptions = '';
AdditionalFinaloptions = '';


% if isempty(WhichOperatingSystem)
%     WhichOperatingSystem = 'windows';
% end

% No specific control of which cmgui version is called:
 version = 'default';
%version = '2.8';   %added by G.Gonzalez 24/09/13

if nargin>1
    if isfield(options,'bExit'), bExit = options.bExit; end
    if isfield(options,'bAnd'),  bAnd  = options.bAnd;  end
    if isfield(options,'version'),  version  = options.version;  end
    if isfield(options,'bWaitLonger'), bWaitLonger = options.bWaitLonger;    end
end
%bExit=0;
switch version
    case {'2.7','27','default'}
        cmGuiExecutableName = 'cmgui-wx';
    case {'2.8','28'}
        cmGuiExecutableName = 'cmgui-wx_v28';
    case {'2.9','29'}
        cmGuiExecutableName = 'cmgui-wx_v29';
    otherwise
        fprintf('ERROR! cmgui version introduced not recognised: %s\n',version);
end
if bExit
    switch version
        case '2.8'
            % add the word "exit" to the comfile:
            fid = fopen(deblank2(comfile),'a+');
            if fid==-1
                fprintf('ERROR! Not possible to open file %s to insert the "exit"\n',comfile);
            else
                fprintf(fid,'exit\n');
                fclose(fid);
            end
        case '2.8optimised'
            % add the word "exit" to the comfile:
            fid = fopen(deblank2(comfile),'a+');
            if fid==-1
                fprintf('ERROR! Not possible to open file %s to insert the "exit"\n',comfile);
            else
                fprintf(fid,'exit\n');
                fclose(fid);
            end
        otherwise
            % This only works with cmgui 2.7. It does not work with cmgui 2.8!!
            Additionaloptions = [Additionaloptions ' -batch '];
    end
        
end
%if isunix() 
     %In some Perl versions of Linux, we need to close the rendered window,
     %otherwise subsequent calls to cmgui will make the script crash
     %Additionaloptions = [Additionaloptions ' -batch '];    
     %AdditionalFinaloptions = [AdditionalFinaloptions ' '];    
% else
    if bAnd
        AdditionalFinaloptions = [AdditionalFinaloptions ' & '];
    end
% end

unixcommand = ['' cmGuiExecutableName ' ' Additionaloptions comfile ' ' AdditionalFinaloptions];
windowscommand = [cmGuiExecutableName '.exe ' Additionaloptions comfile ' ' AdditionalFinaloptions];        
if isunix()
    command = unixcommand;
else
    command = windowscommand;
end
% switch WhichOperatingSystem
%    case 'windows'
%         command = windowscommand;
%    otherwise
%         % 'linux':
%        command = unixcommand;
% end
fprintf('   ... calling cmgui from %s\n',pwd);
fprintf('                     command: %s\n',command);

status = system(command);

if(bWaitLonger)
    fprintf('Waited 2 seconds to save image on disk... \n');
    pause(2);
end

%If cmgui is not found on Linux path, try launching it from current directory
if status == 127 
    unixcommand = ['./' cmGuiExecutableName ' ' Additionaloptions comfile ' ' AdditionalFinaloptions];
    status = system(unixcommand);
        
    if status == 127
        fprintf('   Error calling cmgui from %s, please check you have cmgui-wx in your system path or current directory\n',pwd);
    end
end

function [index,bFound]     = FindString(tline,string,bWarnings,bOnlyAtTheBeginningOfLine)
   nChar = length(tline);
   nCst  = length(string);
   nI=0;
   if nargin<3
       bWarnings=0;
   end
   if nargin<4
       bOnlyAtTheBeginningOfLine=0;
   end
   index=[];
   
   iEnd = nChar-nCst+1;
   if(bOnlyAtTheBeginningOfLine) && iEnd>1
       iEnd = 1;
   end
   for i=1:iEnd
       if strcmp(tline(i:i+nCst-1),string)
           nI=nI+1;
           index(nI)=i;
       end
   end
   if isempty(index)
       bFound=0;
       if (bWarnings)
        fprintf(1,' warning... String %s not found in %s!\n',string,tline);
       end
   else
       bFound=1;
   end
end
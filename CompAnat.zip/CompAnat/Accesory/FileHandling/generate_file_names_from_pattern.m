function imgs=generate_file_names_from_pattern(imgs_old)
%e.g. imgs=generate_file_names_from_pattern({'mesh_*.png',[1 20],'%02d'})

    count = 0;
    if(length(imgs_old)<3)
        imgs_old{3}='%d'; %default format
    end
    for i=imgs_old{2}(1):imgs_old{2}(2)
        count = count+1;
        imgs{count} = strrep(imgs_old{1}, '*', num2str(i,imgs_old{3}));
    end    
end
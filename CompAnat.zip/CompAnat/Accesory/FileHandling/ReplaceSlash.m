       function textout     = ReplaceSlash(textin)
            % Function to replace the windows \ for the linux / in the defintion of a
            % directory
            I = textin=='\';
            textout=textin;
            textout(I)='/';
       end
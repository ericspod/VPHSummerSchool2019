function [] = ChangeBasisIndexInIPfile(IPfilein,IPfileout,basisIn,basisOUT)
% This function also adds the definition of basis index 2 (the same as the
% one given)
   IPfilein = sprintf('%s',IPfilein)
   f1 = fopen(IPfilein,'r');
   if (f1==-1)
       fprintf(1,'Error while opening %s\n',IPfilein); return; 
   end
   f2 = fopen(IPfileout,'wb');
   if (f2==-1)
       fprintf(1,'Error while opening %s\n',IPfileout); return; 
   end
   fprintf(1,'  Reading %s, looking for basis %i\n and writting %s replacing basis by %i\n',IPfilein,basisIn,IPfileout,basisOUT);

   bDebug=0;
   
   tline=deblank2(fgetl(f1));
   [MESSAGE,ERRNUM] = ferror(f1);
   CharBasisIn = int2str(basisIn);
   nCharIn = length(CharBasisIn);
   CharBasisOut = int2str(basisOUT);
   nCharOut = length(CharBasisOut);
   bWriteThe8numbersforOtherBasis=0;
   bThisIsThePlaceToWriteIt=0;
   bCheckEndVersions=0;
   while (ERRNUM==0)
       LastChar = length(tline);
% Changing the number in brakets is not needed!       
%        if LastChar>16
%            if (strcmp(tline(1:16),'Element number ['))
%                %TODO: insert the element number in the braket as well
%                front = tline(1:16);
%                iElem = tline(25:end);
%                clear tline;
%                tline = [front iElem ']: ' iElem];
%            end
%        end       
       if LastChar>23
           if (strcmp(tline(1:23),'The basis function type'))
               if (tline(LastChar-nCharIn+1:LastChar) == CharBasisIn)
                   tline(LastChar-nCharIn+1:LastChar) = ' ';
                   tline(LastChar-nCharIn+1:LastChar-nCharIn+nCharOut) = CharBasisOut;
               end
           end
       end       
       if LastChar>40
           if (strcmp(tline(1:36),'Enter the 8 global numbers for basis'))
               % This only works for this specific location of the index
               % number, and for only one character basis!! TODO: make this
               % more versatile!
               numberBasis = deblank2(tline(37:38));
               if (numberBasis == CharBasisIn)
                   tline(37) = ' ';
                   tline(38) = CharBasisOut;
               end
               ElementDefinitionByEightNodeIndexes = tline(39:end);
               bWriteThe8numbersforOtherBasis = 1;
               if (bDebug), fprintf(1,'New element\n'); end
           end
       end
       
       if (bWriteThe8numbersforOtherBasis)
           if LastChar<2
               bThisIsThePlaceToWriteIt=1;
           end
           if (bThisIsThePlaceToWriteIt)
               for i=[2:6 13]
                   front= sprintf('Enter the 8 numbers for basis %i [prev]',i);
                   line = [front ElementDefinitionByEightNodeIndexes];
                   fprintf(f2,[' ' line '\n']);
                   clear line;
               end
               bWriteThe8numbersforOtherBasis=0;
               bThisIsThePlaceToWriteIt=0;
               bCheckEndVersions=0;
           end
           if LastChar>40
               if (strcmp(tline(1:33),'The version number for occurrence'))
                   bCheckEndVersions=1;
                    if (bDebug), fprintf(1,'... this element has versions\n');      end             
               else
                    if (bDebug), fprintf(1,'... and this was the last version!\n');      end  
                   if (bCheckEndVersions)
                       bThisIsThePlaceToWriteIt=1;
                       bCheckEndVersions=0;
                   end
               end
           end           
       end
       fprintf(f2,[' ' tline '\n']);
       
       tline=deblank2(fgetl(f1));
       [MESSAGE,ERRNUM] = ferror(f1);
   end
   if (bWriteThe8numbersforOtherBasis)
                      for i=[2:6 13]
                   front= sprintf('Enter the 8 numbers for basis %i [prev]',i);
                   line = [front ElementDefinitionByEightNodeIndexes];
                   fprintf(f2,[' ' line '\n']);
                   clear line;
                      end
   end
   
fclose(f1);
fclose(f2);

function b = deblank2(a)
   b = deblank(a);
   b = b(end:-1:1);
   b = deblank(b);
   b = b(end:-1:1);
       
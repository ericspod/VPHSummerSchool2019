function StudyParams = GetAtlasStudyParams(AtlasVersion,subversion)
% Function to encode the specific details of each atlas study


% Default options (for all JR results):
StudyParams.RootName = 'EVS';
options.LoD = 1;
options.bRVdirFromSA = 1;
options.BinaryName = 'BinaryMask.vtk';
options.SubDirectory = '/zmask/';
options.AssembleBinaryMasks = 0; % Used after MITK saved labels in different files
options.NamingConvention = 1; %Original naming convention 
options.surnameCases = NaN;
options.bTailorSlitTemplate = 0;


    switch AtlasVersion
        case 1 %First , without meshing improvements
            StudyParams.Directory = 'E:\data\JR\Atlas_v1.0\';
            StudyParams.ClinicalFile = 'EVSuncoding.xlsx';
            StudyParams.bMapClass = 0; 
        case 2 % Ago 2013, registration constrained by empty region at base
            StudyParams.Directory = 'E:\data\JR\Atlas_v2.0\';
        case {3,6}
            % A correction on the generation of cloud of points from binary
            % mask in order to get an accurate picture of fitting accuracy
            StudyParams.Directory = 'E:\data\JR\Atlas_v2.1\';       %E:\data %GGG 
            switch AtlasVersion
                case 3                
                    % Do nothing;
                case 6
                    % TODO: CODE THE COMPUTATION OF THE ATLAS WITH A SUBSET OF
                    % ALL THE CASES!!
                    StudyParams.AtlasSurname = 'Classes12';
                    StudyParams.AtlasFileName = ['Atlas' StudyParams.AtlasSurname '.mat']; %GGG
                    StudyParams.bOnlyGenerateAtlasStatistics = 1;
                    StudyParams.classes2include = [1 2];
                    StudyParams.bRestrictedClasses = 1;
            % No change in the generation of the meshes, but the atlas is only
            % computed from "preterms" and "term age matched".                 
            end
        case {4,5}
            % No change in the computation of the atlas from 3, but a change in
            % which classes are analysed:
            StudyParams.bStep1_CalculateAtlas = 0;        
            StudyParams.Directory = 'E:\data\JR\Atlas_v2.1\';
            StudyParams.ClinicalFile = 'preeclampsia_gestationalage_Pablo.xlsx';
            switch AtlasVersion
                case 4, StudyParams.StudyClass = 2;
                case 5, StudyParams.StudyClass = 3;
            end
        case 7
            StudyParams.Directory = 'E:\data\JR\AtlasRV_v1.0\';
            StudyParams.topology = 'BiV';
        case {8,9,10}
            % Female cohort
            switch subversion
                case 1 
                    StudyParams.Directory = 'E:\data\JRfemalecohort\Atlas v1.0\';
                case 2
                    StudyParams.Directory = 'E:\data\JRfemalecohort\Atlas v2.0\';
            end
            StudyParams.ClinicalFile = 'CohortDesign.xlsx';
            StudyParams.StudyClass = 4;
            StudyParams.RootName = 'OXPCS';
            StudyParams.HotDims   = [1 2 7 10];
            if AtlasVersion == 9
                % further analysis, comparing other kind of classes:
                StudyParams.StudyClass = 5;
                StudyParams.GroupedClasses{1} = 1;
                StudyParams.GroupedClasses{2} = [2 3];
            end
            if AtlasVersion == 10
                % further analysis, comparing other kind of classes:
                StudyParams.StudyClass = 6;
                StudyParams.GroupedClasses{1} = [1 2];
                StudyParams.GroupedClasses{2} = 3;
            end
        case 11
            % Generation of meshes after the improvements of the female
            % cohort (mainly about preventing base tilting), with the hope
            % of improving mesh quality for the meshing paper.
            StudyParams.Directory = 'E:\data\JR\Atlas_v3.0\';               
        case 12
            RootDir = 'E:\data\SSFP\AtlasSHF\'; %'F:\Atlas\AtlasSHF\';
            StudyParams.RootName = '';    
            options.LoD = 3;
            options.bRVdirFromSA = 0;
            options.BinaryName = 'SubDirectoryName';
            options.SubDirectory = '/';            
            
            options.RVpoolLabel = 2;
            options.MyoLabel = 1;
            StudyParams.nGroups   = 2;        
            switch subversion
                case 1 % manual segmentations
                    StudyParams.Directory = [RootDir 'ManualSegmentations\']; 
                    % naming of the binary files:
                    options.surname = 'b';
                    StudyParams.HotDims   = [2 5 12 23 30];    
                    options.Cases2include = [1:4 6:16 18:21];
                case 2
                    StudyParams.Directory = [RootDir 'UCLsegmentations\']; 
                    if(0)
                        options.bCorrectGrayscale2SegmentationOrientation = 1;
                    else
                        % Once binary segmentations have been reoriented:
                        options.bCorrectGrayscale2SegmentationOrientation = 0;
                        options.surname = 'R';
                    end
                    options.MyoLabel = [204 205];
                    options.RVpoolLabel = 600;
                    % Cases 10, 15 and 20 were wrong, and 5 had no
                    % anatomical definition:
                    options.Cases2include = [1:4 6:9 11:14 16:19 21];
                    StudyParams.HotDims   = [6 1 2 9];    
            end
        case 13
            StudyParams.RootName = 'ROI_';
                    
            switch subversion
                case 1
                    StudyParams.Directory = 'F:\Atlas\JamesWongAtlas\Version1\';
                    options.RVpoolLabel = 1;
                    options.MyoLabel = 3;
                case 2
                    StudyParams.Directory = 'F:\Atlas\JamesWongAtlas\Version2\';
                    options.RVpoolLabel = 2;
                    options.MyoLabel = 1;
                case 3
                    StudyParams.Directory = 'F:\Atlas\JamesWongAtlas\Version3\';
                    options.RVpoolLabel = 2;
                    options.MyoLabel = 1;
                    StudyParams.ClinicalFile = 'First 12 pts for Pablo.xlsx';
                    options.Cases2include = [40    41    43    44    45    46    47    48    51    52    53];
                case 4
                    StudyParams.Directory = 'F:\Atlas\JamesWongAtlas\Version4\';
                    options.RVpoolLabel = 2;
                    options.MyoLabel = 1;
                    StudyParams.ClinicalFile = 'full dataset HLHS for Pablo.xlsx';
                case 5
                    StudyParams.Directory = 'F:\Atlas\JamesWongAtlas\Version5\';
                    options.RVpoolLabel = 2;
                    options.MyoLabel = 1;
                    StudyParams.ClinicalFile = 'full dataset HLHS for Pablo.xlsx';                    
                    options.bTailorSlitTemplate = 1;
                    options.topology = 'LVL';
                case 6
                    % Restrict to data of stages I and II only
                    StudyParams.Directory = 'F:\Atlas\JamesWongAtlas\Version5\';
                    options.RVpoolLabel = 2;
                    options.MyoLabel = 1;
                    StudyParams.ClinicalFile = 'full dataset HLHS for Pablo stageI-II.xlsx';                    
                    options.bTailorSlitTemplate = 1;
                    options.topology = 'LVL';
                    options.Cases2include = [1 2 4:9 12:15 17:22 24 25 28:35 37 39:41 43:48 51:54 56:61 63 64 67:74 76 78 201 202 204 205 209:211 214:216 218:227 230:237 239:244];
            end
            options.LoD = 3;
            options.bRVdirFromSA = 0;
            options.BinaryName = 'SubDirectoryName';
            options.SubDirectory = '/';   
        case 14 
            RootDir = 'F:\Atlas\CRT_KCL\';
            
            StudyParams.RootName = '';    
            options.LoD = 3;
            options.bRVdirFromSA = 0;
            options.BinaryName = 'SubDirectoryName';
            options.SubDirectory = '/';            
            options.topology = 'BiV';
            
            options.RVpoolLabel = 2;
            options.MyoLabel = 1;
            StudyParams.nGroups   = 2;        
            switch subversion
                case 1 % manual segmentations
                    StudyParams.Directory = [RootDir 'ManualSegmentations\']; 
                    % naming of the binary files:
                    options.surname = 'b';
                    StudyParams.HotDims   = [2 5 12 23 30];    
                    options.Cases2include = [1:4 6:16 18:21];
                case 2
                    StudyParams.Directory = [RootDir 'UCLsegmentations\']; 
                    options.SubDirectory = '/segmentation/ucl/';            
                    options.MyoLabel = 18;
                    options.RVpoolLabel = 35; 
            end
            
        case 15
            switch subversion
                case 1
                    % 3D US HCM cases from the JR (R.Bates)
                    RootDir = 'C:\DataFromRoss\';
                    StudyParams.Directory = [RootDir 'Atlas_v1.0\'];
                    options.SubDirectory = '/';            
                    options.RVpoolLabel = 2;
                    options.MyoLabel = 1;
                    options.AssembleBinaryMasks = 1;
                    options.bRVdirFromSA = 0;
                    options.NamingConvention = 2;
                    options.LoD = 5;
                case 2
                    %   MRI SA Stack HCM from JR (R.Bates)
                    RootDir = 'C:/DataFromRoss/';
                    StudyParams.Directory = [RootDir 'MRDataFolder/'];
                    StudyParams.StudyClass = 7;
                    options.SubDirectory = '/';       
                    options.bRVdirFromSA = 0;
                    options.bRVpoolLabel = 1;
                    options.RVpoolLabel = 2;
                    options.MyoLabel = 1;
                    options.AssembleBinaryMasks = 0;
                    options.NamingConvention = 2;
                    options.LoD = 5;
                    options.BinaryName = 'SubDirectoryName';
                    options.surname = 'binary';
                    
            end
                    
        case 16
            %StudyParams.ColumnResponseInClinicalFile = 6; %6 = column corresponding to ESV
            StudyParams.ColumnResponseInClinicalFile = 2; %EDV 

            switch subversion
                case 1
                   % Complete CRT cohort
                   StudyParams.Directory = 'E:\data\SSFP\CRT_New(LatestEva)\Complete\MITKbased\EDV_10percent\LatestCohortNewEvaCases(51cases)\cHermiteFull\';
                   StudyParams.ClinicalFile = 'CaseIdentities10pc_AllCorrect_51cases.xlsx';%'CaseIdentities10pc_AllCorrect.xlsx'; 
            
                case 2 
                    %%To compare cohorts in different folders (Sheffield
                    %%Only) comparing different segmentations
                    
                    %%Manual segmentation (David Warriner's segmentation)      
                    %%'bsmooth' = after applying mean filter to binary mask 
                    Cohorts.surname = 'bsmooth';  
                    Cohorts.Directory = 'W:\Atlas\CRTCases\SheffieldSegmentations\ManualSegmentation\';
                    %%Gerardo's segmentation using MITK
                    Cohorts(2).surname = '';            
                    Cohorts(2).Directory = 'W:\Atlas\CRTCases\SheffieldSegmentations\GerardoSegmentation\';
                    %%Pablo's segmentation using MITK
                    Cohorts(3).surname = 'g';            
                    Cohorts(3).Directory = 'W:\Atlas\CRTCases\SheffieldSegmentations\PabloSegmentation\';
                    StudyParams.Cohorts = Cohorts;
                    StudyParams.Directory = 'W:\Atlas\CRTCases\SheffieldSegmentations\ManualSegmentation\'; %default for Sheffield cohort
                    StudyParams.ClinicalFile = 'CaseIdentities10pc_SHFCases.xlsx';            
                    %options.surname = ''; %bsmooth';
             
                case 3
                % %Reading of excel file with EDV/ESV measurements for
                % %statistical analysis (e.g. T-test only, for Cirulation paper)
                    StudyParams.ClinicalFile = 'StatisticsSummary_EDV-ESV_51cases.xlsx';%'StatisticsSummary_EDV-ESV.xlsx'; 
                    %StudyParams.ColumnResponseInClinicalFile = 3; %ESV
                    StudyParams.ColumnResponseInClinicalFile = 2; %EDV 
            end
            
            options.BinaryName = 'SubDirectoryName';
            options.SubDirectory = '/';            
            
            %Rest of parameters...
            StudyParams.RootName = '';    
            options.LoD = 3;
                        
            options.topology = 'LV';                        
            options.RVpoolLabel = 2;
            options.MyoLabel = 1;
            StudyParams.nGroups   = 2;  
            
%             %Other deprecated options: 
%             %A) JR 224cases cohort
%             StudyParams.Directory = 'E:\data\JR\Atlas_v2.1\cubicLagrangeFixed\';
%             StudyParams.ClinicalFile = 'caseidentities.xlsx';            
%             options.BinaryName = 'BinaryMask.vtk';
%             options.SubDirectory = '/zmask/';

%             %B) If using NAF (for machine learning testing - Works only on Linux)
%             if(isunix()) 
%                StudyParams.Directory = '/home/ggg13/Documents/data/data/SSFP/CRT_New(LatestEva)/Complete/MITKbased/EDV_10percent/cLagrange/cubicLagrangeFixed/';
%             end
                        
%             %C) Generate mesh data from SSFP images
%             StudyParams.Directory = 'E:\data\SSFP\MITK-based_AtlasData\ManualSegmentationOnly\SHF\';
%             options.surname = 'bsmooth';
%             StudyParams.ClinicalFile = 'CaseIdentities10pc_SHFCases.xlsx'; 

%             %D) Sheffield Cases Only
%             StudyParams.Directory = 'E:\data\SSFP\CRT\SHFOnly\';
%             StudyParams.ClinicalFile = 'CaseIdentitiesSHF.xlsx';            

        case 17
            % David Cox:
            StudyParams.Directory = 'F:\Atlas\DavidCox\';
            StudyParams.RootName = '';    
            options.LoD = 2;
            options.BinaryName = 'SubDirectoryName';
            options.SubDirectory = '/';            
            options.topology = 'LV';
            

            options.RVpoolLabel = 3;
            options.MyoLabel = 2;
            StudyParams.nGroups   = 5; 
            StudyParams.ClinicalFile = 'LV_Segmentation_cohorts.xlsx';
            options.bRVdirFromSA = 0;
                        
            options.AssembleBinaryMasks = 1;
            
        case 18
            % DN: New test case for creating an atlas
            % RootDir = 'F:\Atlas\HCMfromJR\DataFromRoss\';
            mdir = mfilename('fullpath');
            RootDir = fullfile(mdir, '../../../../VPH/Atlas_Input/data/JR/');
            %RootDir = '/home/dn14/Documents/VPH/Atlas_Input/data/JR/'; % DN(110413): use local directory
            StudyParams.Directory = [RootDir 'Atlas_v2.1/'];
            options.SubDirectory = '/';            
            options.RVpoolLabel = 2;
            options.MyoLabel = 1;
            options.AssembleBinaryMasks = 0;
        case 19
            RootDir = 'F:\Atlas\Etel\AtlasEcho/'; % DN(110413): use local directory
            StudyParams.Directory = RootDir;
            options.SubDirectory = '/';            
            options.RVpoolLabel = 100;
            options.MyoLabel = 250;          
            options.topology = 'LV';
            options.BinaryName = 'SubDirectoryName';
            options.bRVdirFromSA = 0;
        case 20
            RootDir = 'F:\Atlas\GenerationR\21July2014_Nof5_CardiacScans/';
            StudyParams.Directory = RootDir;
            options.SubDirectory = '/';            
            options.RVpoolLabel = 3;
            options.MyoLabel = 1;          
            options.topology = 'LV';
            options.BinaryName = 'binary.vtk';
            options.bRVdirFromSA = 0;
    end
    
    StudyParams.options = options;
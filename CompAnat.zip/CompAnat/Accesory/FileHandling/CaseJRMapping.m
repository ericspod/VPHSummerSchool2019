function [binary, heartType, labelmyocardium] = CaseJRMapping(resultDir,iHeart,JRAtlasVersion,subversion, subfolder, binaryname)
% Function to retrieve the naming of the JR cases for the generation of hte
% meshing graphical report

heartType = 'LV';
labelmyocardium = []; 

StudyParams = GetAtlasStudyParams(JRAtlasVersion,subversion);
options = StudyParams.options;
RootDataDir = fullfile(fileparts(resultDir(1:end-1)), 'AtlasData'); %fullfile(StudyParams.Directory, 'AtlasData/');
RootName    = StudyParams.RootName;
[ListCases] = GetCasesInDirectory(RootDataDir);
caseIndex = ListCases(iHeart);
if isfield(options,'surname')
    surname = options.surname;
else
    surname = '';
end

%user-defined sublist of cohorts with different surnames
if isfield(options, 'surnameCases')
    FileIndex = find(caseIndex == options.surnameCases);
    if(FileIndex > 0)
        surname = options.surnameID;
    end    
end

switch options.BinaryName
    case 'SubDirectoryName' % The SHF or James Wong cohort
        direct = dir(RootDataDir);
        iH = iHeart + 2;
        CaseDirectory = fullfile(RootDataDir, direct(iH).name, options.SubDirectory); %[RootDataDir direct(iH).name options.SubDirectory];
        binary = SearchSubDirectoryNameFile(direct(iH).name,CaseDirectory,surname);  
        binary = fullfile(CaseDirectory, binary); %[CaseDirectory binary];
    otherwise
        folderid = sprintf('%s%03i',RootName,caseIndex);
        binary = fullfile(RootDataDir, folderid, subfolder, binaryname);% sprintf('%s%s%03i/zmask/BinaryMask.vtk',RootDataDir,RootName,caseIndex);
end
function [] = CreateFolders(arg1,RootDir,character2defineName)

if isdir(arg1)
    listoffiles = dir(arg1);
    RootDestinyDir = RootDir;
    RootDir = arg1;
else
    listoffiles = arg1;
end
nFiles = numel(listoffiles);

    for iF = 1:nFiles
        namefile = listoffiles(iF).name;
        if numel(namefile)>5                % an arbritrary threshold to remove the '.' and '..;
            if ~isdir(fullfile(RootDir, namefile));  % in case the function is run twice by error
                I = strfind(namefile, character2defineName);
                if(numel(I)>0)
                    DirName = namefile(1:I(1)-1);
                    DestinyDir = fullfile(RootDestinyDir, DirName);
                    if ~isdir(DestinyDir);
                        mkdir(DestinyDir);
                    end
                    movefile(fullfile(RootDir, namefile),DestinyDir);
                else
                    fprintf('WARNING! Not possible to recognise the name of the subject from %s\n',namefile)
                end
            end
        end
    end
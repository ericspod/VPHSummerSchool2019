function [pos_start pos_end] = str_locate_range(string, start_label, end_label)
    pos = strfind(string, start_label);
    pos_start = pos(1) + length(start_label);
    pos = strfind(string, end_label);
    pos_end = pos(1) - 1;
end

%select measurements from Pre-term and term Cases

%Reads variables:
%LVMeasures2DByCase1, LVMeasures2DByCase3, LVMeasures2DByCase4
%This are crated variables from excel file: LVdimensions-EchoMesh.xlsx
%LVLenght, LVLumenDiameter, LVExternalDiameter (with indices!!)

% directory = 'U:\ResultsTraditionalModels\224cases\';
VariablesDir = ResultsDir;
load([VariablesDir 'LVMeasures2DByCase.mat']);


%pTranspose = p'; for eigenspace ( p = coefficient' * Ds'; 
%in CalculateAtlasGerardo.m)

%pTranspose: Col1 = index, col2 = length, col3 = epi, col4 = endo

% directory = 'E:\data\JR\Atlas_v2.1\AtlasOutput'; %hard-wired for now
% load([directory 'PCAShapeResiduals.mat']);
% pTranspose = p';

if ~exist('LVCaseNumber','var')
    load([OutputDirectory 'PCAShapeResiduals.mat']);
end
pTranspose = [LVCaseNumber' p'];



bUse11coordsP = 0; %select 3 "a-priori" eigvecs + 8 remaining using SVD
bUseResidualscoordsP = 0;

if(bUse11coordsP)
    %EigVectorsMean (a-priori eigvecs) must be read from:
    %load('E:\data\GG\TestsReconstruction\224cases\residualShapeCases\AllVariables_ResidualShapeCases.mat')
    nExtraPCs = 8;
    
    [UU,~,~] = svd(EigVectorsMean);
    coefficient11coords = [EigVectorsMean UU(:,4:(3+nExtraPCs))];
%    coefficient11coords = [EigVectorsMean UU(:,4:11)];
%     coefficient11coords = [EigVectorsMean UU(:,4:15)]; %+ 12 remaining
    p11 = coefficient11coords' * Ds'; %P-coords for 11 PCs
    pTranspose11coords = [LVCaseNumber' p11'];
    
    if(bUseResidualscoordsP)
        %3 a-priori + 12 residual PCs
        COVPCs = BPCs'*BPCs/nValidCases;
        [V,SSPCs] = eig(COVPCs);
        [mm,nn] = size(V);
%         lastEigenVects = V(:,3493:end); %12 PCs
%         lastEigenVects = V(:,3497:e+nd); %8 PCs
        lastEigenVects = V(:,(mm-nExtraPCs+1):end); %8 PCs
        lastEigenVects = fliplr(lastEigenVects);
        coefficient11coords = [EigVectorsMean lastEigenVects];
        p11 = coefficient11coords' * Ds'; %P-coords for 15 PCs
        pTranspose11coords = [LVCaseNumber' p11'];
    end
end

%Traditional (aka original) PCA coordinate values for 3 PCs
original3PCs = PCs(:,1:3);
pOriginalCoords = original3PCs' * Ds'; 
pOriginalPCsTranspose = [LVCaseNumber' pOriginalCoords'];
%Traditional (aka original) PCA coordinate values for ALL PCs
originalALLPCs = PCs;
pOriginalALLCoords = originalALLPCs' * Ds'; 
pOriginalALLPCsTranspose = [LVCaseNumber' pOriginalALLCoords'];

bOriginal3PCs = 0;
bAllMeasures2D = 0;
bOriginalALLPCs = 0;

%Case1 - quick hack for presentation
[k,~] = size(LVMeasures2DByCase1);

for i=1:k %97
    idx = LVMeasures2DByCase1(i);
    
    for j= 1:nValidCases %224
        %work on PCA coordinates (scores)        
        if(pTranspose(j,1) == idx) 
            LVLength3DByCase1(i) = pTranspose(j,2); 
            break;
        end       
    end
end

if(bOriginal3PCs)
    for i=1:k% 97
        idx = LVMeasures2DByCase1(i);

        for j= 1:nValidCases %224
            %work on original 3PCs PCA coordinates (scores)                
            if(pOriginalPCsTranspose(j,1) == idx) 
                LVLengthOriginalPCsByCase1(i) = pOriginalPCsTranspose(j,2); 
                break;
            end   
        end
    end
end

for i=1:k% 97
    idx = LVMeasures2DByCase1(i);
    for j= 1:nValidCases %224

        if(pTranspose(j,1) == idx) 
            LVLumen3DByCase1(i) = pTranspose(j,4); 
            break;
        end
        
    end
end

if(bOriginal3PCs)
    for i=1:k% 97
        idx = LVMeasures2DByCase1(i);
        for j= 1:nValidCases %224    
            if(pOriginalPCsTranspose(j,1) == idx) 
                LVLumenOriginalPCsByCase1(i) = pOriginalPCsTranspose(j,4); 
                break;
            end

        end
    end
end

for i=1:k% 97
    idx = LVMeasures2DByCase1(i);
    for j= 1:nValidCases %224   

        if(pTranspose(j,1) == idx) 
            LVExternal3DByCase1(i) = pTranspose(j,3); 
            break;
        end
               
    end     
end

if(bOriginal3PCs)
    for i=1:k% 97
        idx = LVMeasures2DByCase1(i);
        for j= 1:nValidCases %224  
            if(pOriginalPCsTranspose(j,1) == idx) 
                LVExternalOriginalPCsByCase1(i) = pOriginalPCsTranspose(j,3); 
                break;
            end
        end     
    end
end

length3DByCase1 = LVLength3DByCase1';
lumen3DByCase1 = LVLumen3DByCase1';
external3DByCase1 = LVExternal3DByCase1';
indices = LVMeasures2DByCase1(:,1);

LVMeasures3DByCase1 = [indices length3DByCase1 lumen3DByCase1 external3DByCase1];

if(bOriginal3PCs)
    length3DOriginalPCsByCase1 = LVLengthOriginalPCsByCase1';
    lumen3DOriginalPCsByCase1 = LVLumenOriginalPCsByCase1';
    external3DOriginalPCsByCase1 = LVExternalOriginalPCsByCase1';
    indices = LVMeasures2DByCase1(:,1);

    LVOriginalPCsByCase1 = [indices length3DOriginalPCsByCase1 lumen3DOriginalPCsByCase1 external3DOriginalPCsByCase1];
end

if(bAllMeasures2D) %all 2D measurements
    for i=1:k% 97
        idx = LVMeasures2DByCase1(i);
        for j= 1:nValidCases %224 
            if(LVAllMeasures2D(j,1) == idx) 
                LVAllMeasures2DByCase1(i,:) = LVAllMeasures2D(j,:); 
                break;
            end
        end     
    end
end

if(bUse11coordsP) %11 PCs (a-priori + 8eigvecs) 
    for i=1:k% 97
        idx = LVMeasures2DByCase1(i);
        for j= 1:nValidCases %224 
            if(pTranspose11coords(j,1) == idx) 
                p11coordsPByCase1(i,:) = pTranspose11coords(j,:); 
                break;
            end
        end     
    end
end

if(bOriginalALLPCs)
    for i=1:k% 97
        idx = LVMeasures2DByCase1(i);
        for j= 1:nValidCases %224 
            if(pOriginalALLPCsTranspose(j,1) == idx) 
                pALLOrigCoordsPByCase1(i,:) = pOriginalALLPCsTranspose(j,:); 
                break;
            end
        end     
    end
end

fprintf('case 1');

%Case3 - quick hack for presentation
[k,~] = size(LVMeasures2DByCase3);

for i=1:k %100
    idx = LVMeasures2DByCase3(i);
    
    for j= 1:nValidCases %224
%         if(LVLenght(j,1) == idx) 
%             LVLength3DByCase3(i) = LVLenght(j,2); 
%             break;
%         end
        if(pTranspose(j,1) == idx) 
            LVLength3DByCase3(i) = pTranspose(j,2); 
            break;
        end
        

    end
end

if(bOriginal3PCs)
    for i=1:k %100
        idx = LVMeasures2DByCase3(i);

        for j= 1:nValidCases %224    
            if(pOriginalPCsTranspose(j,1) == idx) 
                LVLengthOriginalPCsByCase3(i) = pOriginalPCsTranspose(j,2); 
                break;
            end            
        end
    end
end

for i=1:k %100
    idx = LVMeasures2DByCase3(i);
    for j= 1:nValidCases %224

        if(pTranspose(j,1) == idx) 
            LVLumen3DByCase3(i) = pTranspose(j,4); 
            break;
        end
        
    end
end

if(bOriginal3PCs)
    for i=1:k %100
        idx = LVMeasures2DByCase3(i);
        for j= 1:nValidCases %224
            if(pOriginalPCsTranspose(j,1) == idx) 
                LVLumenOriginalPCsByCase3(i) = pOriginalPCsTranspose(j,4); 
                break;
            end
        end
    end
end

            
for i=1:k %100
    idx = LVMeasures2DByCase3(i);
    for j= 1:nValidCases %224

        if(pTranspose(j,1) == idx) 
            LVExternal3DByCase3(i) = pTranspose(j,3); 
            break;
        end
        
    end     
end

if(bOriginal3PCs)
    for i=1:k %100
        idx = LVMeasures2DByCase3(i);
        for j= 1:nValidCases %224  
            if(pOriginalPCsTranspose(j,1) == idx) 
                LVExternalOriginalPCsByCase3(i) = pOriginalPCsTranspose(j,3); 
                break;
            end
        end     
    end
end

length3DByCase3 = LVLength3DByCase3';
lumen3DByCase3 = LVLumen3DByCase3';
external3DByCase3 = LVExternal3DByCase3';
indices = LVMeasures2DByCase3(:,1);

LVMeasures3DByCase3 = [indices length3DByCase3 lumen3DByCase3 external3DByCase3];

if(bOriginal3PCs)
    length3DOriginalPCsByCase3 = LVLengthOriginalPCsByCase3';
    lumen3DOriginalPCsByCase3 = LVLumenOriginalPCsByCase3';
    external3DOriginalPCsByCase3 = LVExternalOriginalPCsByCase3';
    indices = LVMeasures2DByCase3(:,1);

    LVOriginalPCsByCase3 = [indices length3DOriginalPCsByCase3 lumen3DOriginalPCsByCase3 external3DOriginalPCsByCase3];
end

if(bAllMeasures2D) %all 2D measurements
    for i=1:k %100
        idx = LVMeasures2DByCase3(i);
        for j= 1:nValidCases %224   
            if(LVAllMeasures2D(j,1) == idx) 
                LVAllMeasures2DByCase3(i,:) = LVAllMeasures2D(j,:); 
                break;
            end
        end     
    end
end

if(bUse11coordsP) %11 PCs (a-priori + 8eigvecs) 
    for i=1:k %100
        idx = LVMeasures2DByCase3(i);
        for j= 1:nValidCases %224   
            if(pTranspose11coords(j,1) == idx) 
                p11coordsPByCase3(i,:) = pTranspose11coords(j,:); 
                break;
            end
        end     
    end
end

if(bOriginalALLPCs)
    for i=1:k %100
        idx = LVMeasures2DByCase3(i);
        for j= 1:nValidCases %224   
            if(pOriginalALLPCsTranspose(j,1) == idx) 
                pALLOrigCoordsPByCase3(i,:) = pOriginalALLPCsTranspose(j,:); 
                break;
            end
        end     
    end
end

fprintf('case 3');

%Case4 - quick hack for presentation
[l,~] = size(LVMeasures2DByCase4);

for i=1:l %27
    idx = LVMeasures2DByCase4(i);
    
    for j= 1:nValidCases %224

        if(pTranspose(j,1) == idx) 
            LVLength3DByCase4(i) = pTranspose(j,2); 
            break;
        end
        
    end
end

if(bOriginal3PCs)
    for i=1:l %27
        idx = LVMeasures2DByCase4(i);
        for j= 1:nValidCases %224
            if(pOriginalPCsTranspose(j,1) == idx) 
                LVLengthOriginalPCsByCase4(i) = pOriginalPCsTranspose(j,2); 
                break;
            end
        end
    end
end

for i=1:l %27
    idx = LVMeasures2DByCase4(i);
    for j= 1:nValidCases %224

        if(pTranspose(j,1) == idx) 
            LVLumen3DByCase4(i) = pTranspose(j,4); 
            break;
        end
        
    end
end

if(bOriginal3PCs)
    for i=1:l %27
        idx = LVMeasures2DByCase4(i);
        for j= 1:nValidCases %224
            if(pOriginalPCsTranspose(j,1) == idx) 
                LVLumenOriginalPCsByCase4(i) = pOriginalPCsTranspose(j,4); 
                break;
            end
        end
    end
end

for i=1:l %27
    idx = LVMeasures2DByCase4(i);
    for j= 1:nValidCases %224

        if(pTranspose(j,1) == idx) 
            LVExternal3DByCase4(i) = pTranspose(j,3); 
            break;
        end

    end     
end

if(bOriginal3PCs)
    for i=1:l %27
        idx = LVMeasures2DByCase4(i);
        for j= 1:nValidCases %224
            if(pOriginalPCsTranspose(j,1) == idx) 
                LVExternalOriginalPCsByCase4(i) = pOriginalPCsTranspose(j,3); 
                break;
            end
        end     
    end
end

length3DByCase4 = LVLength3DByCase4';
lumen3DByCase4 = LVLumen3DByCase4';
external3DByCase4 = LVExternal3DByCase4';
indices = LVMeasures2DByCase4(:,1);

LVMeasures3DByCase4 = [indices length3DByCase4 lumen3DByCase4 external3DByCase4];

if(bOriginal3PCs)
    length3DOriginalPCsByCase4 = LVLengthOriginalPCsByCase4';
    lumen3DOriginalPCsByCase4 = LVLumenOriginalPCsByCase4';
    external3DOriginalPCsByCase4 = LVExternalOriginalPCsByCase4';
    indices = LVMeasures2DByCase4(:,1);

    LVOriginalPCsByCase4 = [indices length3DOriginalPCsByCase4 lumen3DOriginalPCsByCase4 external3DOriginalPCsByCase4];
end

if(bAllMeasures2D) %all 2D measurements
    for i=1:k %27
        idx = LVMeasures2DByCase4(i);
        for j= 1:nValidCases %224
            if(LVAllMeasures2D(j,1) == idx) 
                LVAllMeasures2DByCase4(i,:) = LVAllMeasures2D(j,:); 
                break;
            end
        end     
    end
end

if(bUse11coordsP) %11 PCs (a-priori + 8eigvecs) 
    for i=1:k %27
        idx = LVMeasures2DByCase4(i);
        for j= 1:nValidCases %224
            if(pTranspose11coords(j,1) == idx) 
                p11coordsPByCase4(i,:) = pTranspose11coords(j,:); 
                break;
            end
        end     
    end
end

if(bOriginalALLPCs)
    for i=1:k %27
        idx = LVMeasures2DByCase4(i);
        for j= 1:nValidCases %224
            if(pOriginalALLPCsTranspose(j,1) == idx) 
                pALLOrigCoordsPByCase4(i,:) = pOriginalALLPCsTranspose(j,:); 
                break;
            end
        end     
    end
end
fprintf('case 4 \n');


% %perform t-tests
% %LV length
% [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase1(:,2),LVMeasures3DByCase3(:,2)) %length_1vs3
% [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase1(:,2),LVMeasures3DByCase4(:,2)) %length_1vs4
% [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase3(:,2),LVMeasures3DByCase4(:,2)) %length_3vs4
% 
% %LV lumen diameter
% [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase1(:,3),LVMeasures3DByCase3(:,3)) %lumen_1vs3
% [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase1(:,3),LVMeasures3DByCase4(:,3)) %lumen_1vs4
% [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase3(:,3),LVMeasures3DByCase4(:,3)) %lumen_3vs4
% 
% %LV external diameter
% [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase1(:,4),LVMeasures3DByCase3(:,4)) %external_1vs3
% [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase1(:,4),LVMeasures3DByCase4(:,4)) %external_1vs4
% [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase3(:,4),LVMeasures3DByCase4(:,4)) %external_3vs4


%perform t-tests

bTTests = 0;
if(bTTests)
    diaryfile = [OutputDirectory 'Diary_t-tests_TraditionalvsTruncatedMetrics' '.txt'];
    diary(diaryfile)

    fprintf('"Traditional" metrics:\n\n');

    %LV length
    fprintf('LV length\n\n');

    fprintf('length_1vs3\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures2DByCase1(:,2),LVMeasures2DByCase3(:,2)) %length_1vs3
    fprintf('length_1vs4\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures2DByCase1(:,2),LVMeasures2DByCase4(:,2)) %length_1vs4
    fprintf('length_3vs4\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures2DByCase3(:,2),LVMeasures2DByCase4(:,2)) %length_3vs4

    %LV lumen diameter
    fprintf('LV lumen diameter\n\n');

    fprintf('lumen_1vs3\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures2DByCase1(:,3),LVMeasures2DByCase3(:,3)) %lumen_1vs3
    fprintf('lumen_1vs4\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures2DByCase1(:,3),LVMeasures2DByCase4(:,3)) %lumen_1vs4
    fprintf('lumen_3vs4\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures2DByCase3(:,3),LVMeasures2DByCase4(:,3)) %lumen_3vs4

    %LV external diameter
    fprintf('LV external diameter\n\n');

    fprintf('external_1vs3\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures2DByCase1(:,4),LVMeasures2DByCase3(:,4)) %external_1vs3
    fprintf('external_1vs4\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures2DByCase1(:,4),LVMeasures2DByCase4(:,4)) %external_1vs4
    fprintf('external_3vs4\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures2DByCase3(:,4),LVMeasures2DByCase4(:,4)) %external_3vs4


    fprintf('"Truncated" metrics:\n\n');
    %the follwing is in eigenspace
    %LV length
    fprintf('LV length\n\n');

    fprintf('length_1vs3\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase1(:,2),LVMeasures3DByCase3(:,2)) %length_1vs3
    fprintf('length_1vs4\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase1(:,2),LVMeasures3DByCase4(:,2)) %length_1vs4
    fprintf('length_3vs4\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase3(:,2),LVMeasures3DByCase4(:,2)) %length_3vs4

    %LV lumen diameter
    fprintf('LV lumen diameter\n\n');

    fprintf('lumen_1vs3\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase1(:,3),LVMeasures3DByCase3(:,3)) %lumen_1vs3
    fprintf('lumen_1vs4\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase1(:,3),LVMeasures3DByCase4(:,3)) %lumen_1vs4
    fprintf('lumen_3vs4\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase3(:,3),LVMeasures3DByCase4(:,3)) %lumen_3vs4

    %LV external diameter
    fprintf('LV external diameter\n\n');

    fprintf('external_1vs3\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase1(:,4),LVMeasures3DByCase3(:,4)) %external_1vs3
    fprintf('external_1vs4\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase1(:,4),LVMeasures3DByCase4(:,4)) %external_1vs4
    fprintf('external_3vs4\n');
    [hRes,pRes,ci,stats] = ttest2(LVMeasures3DByCase3(:,4),LVMeasures3DByCase4(:,4)) %external_3vs4

    diary off;
end

bGetCasesExecuted = 1;
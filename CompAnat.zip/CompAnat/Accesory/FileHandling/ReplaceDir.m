function [] = ReplaceDir(Root,Dorig,Ddest,StrOrig,StrDest)
% function to move the contents from Dorig to Ddest, changing the naming by
% replacing any StrOrig by StrDest

listfiles = dir(fullfile(Root,Dorig));

DdestDir = fullfile(Root,Ddest);
if ~exist(DdestDir,'dir'), mkdir(DdestDir); end;

for iF = 3:numel(listfiles)
    filename = listfiles(iF).name;
    File = fullfile(Root,Dorig,filename);
    if isdir(File)
        Dorig2 = fullfile(Dorig,filename);
        Ddest2 = fullfile(Ddest,filename);
        ReplaceDir(Root,Dorig2,Ddest2,StrOrig,StrDest)
    else
        NewFileName = regexprep(filename,StrOrig,StrDest);     
        NewFile = fullfile(DdestDir,NewFileName);
        fprintf('moving %s into %s\n',File,NewFile);
        movefile(File,NewFile);
    end
end
function [name,path,extension,decomposedpath] = RemovePathAndExtension(filename)
    path = [];
    extension = [];
    decomposedpath = [];
    name = [];
    if numel(filename)==0
        return;
    end
    OriginalFilename = filename;
    [index1,bFound1] = FindString(filename,'/',0);
    [index2,bFound2] = FindString(filename,'\',0);
    index = sort([index1 index2]);
    if bFound1||bFound2
        I = index(end);
        if I==numel(filename) % In case a directory is passed:
            if numel(index)==1
                filename = filename(1:end-1);
            else
                I = index(end-1);
                filename = filename(I+1:end);
            end
        else
            filename = filename(I+1:end);
        end
        % Build the decomposedpath
        I = index;
        for iI = 1:numel(I)
            bAdditionalPart = 1;
            switch iI
                case 1, 
                    if I(iI) == 1, 
                        i0 = 2; i1 = I(iI+1); bOffset = 1;
                    else
                        i0 = 1; i1 = I(iI); bOffset = 0;
                    end
                case numel(I)
                    if I(end) == numel(OriginalFilename)
                        bAdditionalPart = 0;
                    end
                    i0 = I(iI-1) + bOffset + 1;
                    i1 = I(iI) + bOffset;     
                otherwise
                    i0 = I(iI-1) + bOffset + 1;
                    i1 = I(iI) + bOffset;                     
            end
            if(bAdditionalPart)
                decomposedpath(iI).name = OriginalFilename(i0:i1);
            end
        end            
    end
    [index,bFound] = FindString(filename,'.',0);
    if bFound
        I = index(1);
        filename = filename(1:I-1);
    end
    name = filename;
    % Remore a possible last '/' or '\'
    [index,bFound] = FindString(name,'/',0);
    if(bFound)
        i0=1; i1=0;
        if index==1
            i0=2;
        end
        if index==numel(name);
            i1=-1;
        end
        name = name(i0:end+i1);
    end
    [index,bFound] = FindString(name,'\',0);
    if(bFound)
        i0=1; i1=0;
        if index==1
            i0=2;
        end
        if index==numel(name);
            i1=-1;
        end
        name = name(i0:end+i1);
    end
    index = FindString(OriginalFilename,name);
    if numel(index)==0
        fprintf('ERROR in RemovePathAndExtension\n')
    end
    path = OriginalFilename(1:index(end)-1);
    extension = OriginalFilename(index(end)+length(name):end);
    if isempty(path)
        path = './';
    end
end
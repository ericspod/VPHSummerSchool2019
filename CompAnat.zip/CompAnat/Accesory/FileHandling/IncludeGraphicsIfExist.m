function [bSuccess] = IncludeGraphicsIfExist(fid,filename,width,alternativeRootName,bWriteNotfoundInReport)
bSuccess= 0;
    if nargin<5
        bWriteNotfoundInReport = 1;
    end
    if(exist(filename,'file'))
        bSuccess = 1;
        file = filename;
    else
        if nargin ==4
            if ischar(alternativeRootName)
                [bSuccess,file] = SearchRootDirectory(alternativeRootName);
            else
                if iscell(alternativeRootName)
                    iA = 1;
                    while ~bSuccess && iA<=numel(alternativeRootName)                    
                        alter = alternativeRootName{iA};
                        [bSuccess,file] = SearchRootDirectory(alter);
                        iA = iA + 1;
                    end
                end
            end            
        end
    end
    if bSuccess
        file = ReplaceSlash(file);
        fprintf(fid,'  \\includegraphics[width=%1.2f\\textwidth]{%s}',width,file);
    else
        if(bWriteNotfoundInReport)
            fprintf(fid,'  Image not found ');
        end
        fprintf('WARNING! Image not found: %s\n',filename);
    end
    
function [bSuccess,file] = SearchRootDirectory(alternativeRootName)
    bSuccess = 0;
    file = '';
    stringlistofcandidatenames = ls([alternativeRootName '*']);
    if size(stringlistofcandidatenames,1)>1
        stringlistofcandidatenames = deblank2(stringlistofcandidatenames(end,:));
        fprintf('WARNING! several images matches the pattern %s, taking the last: %s\n',alternativeRootName,stringlistofcandidatenames);
    end
    RootPath = GetPath(alternativeRootName);
    if numel(stringlistofcandidatenames)>1
        bSuccess = 1;
        if strcmp(stringlistofcandidatenames(end),'\n')||strcmp(stringlistofcandidatenames(end),' ')
            iend = 1;
        else
            iend = 0;
        end
        file = fullfile(RootPath,stringlistofcandidatenames(1:end-iend));
    end
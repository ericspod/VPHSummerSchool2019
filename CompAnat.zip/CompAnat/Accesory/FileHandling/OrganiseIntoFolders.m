function [] = OrganiseIntoFolders(directory,rootname,options)
% Funciton to organise files into folders from a root directory
%

% Default options:
RootDir = rootname;
DestinyDir = directory;
bCleanEpochName = 0;
bRootfirstIDafter = 1;

if nargin>=3
    if isfield(options,'RootDir'), RootDir = options.RootDir; end
    if isfield(options,'DestinyDir'), DestinyDir = options.DestinyDir; end   
    if isfield(options,'bCleanEpochName'), bCleanEpochName = options.bCleanEpochName; end   
    if isfield(options,'bRootfirstIDafter'), bRootfirstIDafter = options.bRootfirstIDafter; end  
end

files = dir(directory);
nMoved = 0;
for iF = 3:numel(files) 
    % Check this is a file:
    if ~files(iF).isdir
        filename = files(iF).name;
        % Extract the root name:
        nChar = numel(rootname);
        nF = numel(filename);
        if nF>nChar
            bFound = 0;
            % Extract the case number:
            if(bRootfirstIDafter)
                bFound = strcmp(rootname,filename(1:nChar));
                caseID = RobustScan(filename(nChar+1:end));                
            else
                iFound = strfind(filename, rootname);
                if numel(iFound)>0, bFound = 1; end
                caseID = RobustScan(filename(1:end));                
            end
            if bFound
                nameDirOut = sprintf('%s/%s%03i/',DestinyDir,RootDir,caseID(1));
                % Create the directory if it does not exist:
                if ~exist(nameDirOut,'dir')
                    mkdir(nameDirOut);
                end
                if(bCleanEpochName)
                    [CleanName,bCorrect] = CleanFileName(filename, rootname);
                else
                    CleanName = filename;
                    bCorrect = 1;
                end
                % Move file
                if ~bCorrect
                    fprintf('ERROR! File name not correct: %s\n',filename);
                else
                    DestinyFile = fullfile(nameDirOut , CleanName);
                    if exist(DestinyFile,'file')
                        fprintf('ERROR! File %s already exists\n',DestinyFile);
                    else
                        nMoved = nMoved + 1;
                        movefile([directory '/' filename],DestinyFile);
                    end
                end
            end
        end
    end
end
fprintf('Total files moved: %i\n',nMoved);
 
function   [CleanName,bCorrect] = CleanFileName(filename, rootname)
% Sometimes the name includes spaces, or "chamber" instead of "ch"... In
% order to make a consistent naming, corrections are made. Example of a
% file is "epoch003fu 4chamber.txt"
nChar  = numel(rootname);
[caseID,i] = RobustScan(filename(nChar+1:end));
RemainingName = filename(nChar+i:end);
% This will have the fu 4chamber.txt. Next thing is to extract the
% condition, which is 'fu' or 'birth'.
ch = [];
bCorrect =1;
for ic = 1:numel(RemainingName)
    digit = sscanf(RemainingName(ic),'%i');
    if numel(digit)>0
        ch = digit;
        break;        
    else
        condition(ic) = RemainingName(ic);
    end
end
if ic==1
    % there was no description of the condition
    bCorrect = 0;
    condition = '';
else
    condition = deblank2(condition);
end
if isempty(ch)
    bCorrect = 0;
end
if isempty(condition)
    condition = 'birth';
end
CleanName = sprintf('%s%03i%s%ich.txt',rootname,caseID,condition,ch);


function [ID,i] = RobustScan(name)
   % Do not understand why, but sometimes the sscanf will return two
   % numbers out of 013, 11 and 4, and 12 and 4 out off 014...
   
   for i=1:numel(name)
       digit = sscanf(name(i),'%i');
       if numel(digit)>0
           validdigit(i) = digit;
       else
           break;
       end
   end
   ID = 0;
   nDig = numel(validdigit);
   for ii = 1:nDig
       ID = ID + validdigit(ii)*10^(nDig-ii);
   end
  

%call Ploting Modal Variation function

bStep2_ViewModalVariations = 1;

iEig2plot = 3;
if(bStep2_ViewModalVariations)
    for iMode = 1:iEig2plot
        iStd = 2;
        ViewModalVariation(OutputDirectory,iMode,iStd,options);        
    end
end
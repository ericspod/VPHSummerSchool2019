function [ output_args ] = ReorientMeshes( directory, options )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

surname                 = '';
Cases2exclude           = [];

postfix = '/AtlasData/';


if nargin==2
    if isfield(options,'SubDirectory'),  SubDirectory = options.SubDirectory;  end
    if isfield(options,'BinaryName'),    BinaryName = options.BinaryName;  end
    if isfield(options,'surname'),       surname  = options.surname;  end
end

DataDirectory = [directory postfix];
OutputDirectory = [directory '/AtlasOutput/']; 
CurrentDirectory = pwd;

if strcmp(BinaryName,'SubDirectoryName')
    bSearchSubDirectoryNameFile = 1;
else
    bSearchSubDirectoryNameFile = 0;
end

direct = dir(DataDirectory);
nCases = numel(direct) - 2;

nCasesForPCA = nCases;

for iCase = 1:nCasesForPCA
    iD = iCase + 2;
	CaseDir = direct(iD).name;
    CaseDirectory = [DataDirectory CaseDir SubDirectory];
    if bSearchSubDirectoryNameFile
        BinaryName = SearchSubDirectoryNameFile(CaseDir,CaseDirectory,surname);        
    end
    
    if ~isnan(BinaryName)
        MeshName = [RemovePathAndExtension(BinaryName) '_mesh']; %'_meshLagrange']; %GGG        
        DiaryFileDirectory = [CaseDirectory 'Output_heartgen/'];
        CaseNumber = GetNumberFromName(CaseDir);
        DiaryFileName = ['Diary' num2str(CaseNumber)];
        
        if find(Cases2exclude == CaseNumber)>0
                fprintf('Case %i is excluded\n',CaseNumber);
        else
            if exist([DiaryFileDirectory MeshName '.exnode'],'file')
                CH = CubicMeshClass([DiaryFileDirectory MeshName]);   
                
                %translate to origin and de-rotate if 'RVPosition.mat' exists:
                if isfield(options,'iNodeSecondAxis')
                    optionsRigidMotion.iNodeSecondAxis = options.iNodeSecondAxis;
                end
                optionsRigidMotion.CaseDirectory = CaseDirectory;
                CH = SolveRigidBodyMotion(CH,optionsRigidMotion); 
                
                %read rotation matrix from Diary file
                DiaryFile = [DiaryFileDirectory DiaryFileName '.txt'];
                RotMat = ReadDiaryFile( DiaryFile );
                
                %de-rotate mesh
                CH = CH.rotateMesh(RotMat,[0 0 0]);
                
            end
        end
        
        
        
        
        
    end
            
end

end


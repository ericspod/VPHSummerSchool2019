function [ output_args ] = BullsEyeDifferences(directory, CHmesh1, CHmesh2)
%Differences of wall thickness between two mesh models and displayed as bulls eyes

bSaveSkeleton = 0; 
bWallThicknessDifference = 1;
bSaveBullsEye = 1;

MRTopology      = GetCardiacMeshTopology(CHmesh1);
MRNodeLayers    = MRTopology.NodeLayer;

[medialAxisInfo1, ~] = MedialAxis(CHmesh1, bSaveSkeleton);
wallThickness1 = medialAxisInfo1(:,4); %4th column is wall thickness

[medialAxisInfo2, ~] = MedialAxis(CHmesh2, bSaveSkeleton);
wallThickness2 = medialAxisInfo2(:,4); %4th column is wall thickness

differenceWallThick = wallThickness2 - wallThickness1;
axis = [-1.5 1.5];

h1 = WallThicknessMesh2BullsEyePlot( differenceWallThick, MRNodeLayers, bWallThicknessDifference, axis);
if(bSaveBullsEye)
    export_fig([directory 'BullsEye' sprintf('DifferenceAverageWallThickness') '.png'],'-png','-m2',h1);
end

end


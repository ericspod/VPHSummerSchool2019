function [ outputMedialDofs, outputMedialMesh ] = MedialAxis( MRMesh, saveSkeletonMesh)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%for 1:1
    bSaveSkeletonMesh = 1;
    if(exist('saveSkeletonMesh','var'))
        bSaveSkeletonMesh = saveSkeletonMesh;
    end
    
    %MRMesh = CubicMeshClass([MRMeshDirectory MeshName]);
    MRDofs = MRMesh.GetDofs();

    %MeanMRDofs = MeanMRDofs + MRDofs./nValidFiles;
    
    MRTopology      = GetCardiacMeshTopology(MRMesh);
    MRNodeLayers    = MRTopology.NodeLayer;
    MRMedialDofs    = [];

    %copy current mesh and flatten it out to no derivatives
    CH = MRMesh;    
    derivativesList = [0 0 0 0 0 0 0]; %keep no derivatives
	model = NeglectMeshDerivatives(CH.GetDofs(), derivativesList, CH.nNodes);                    
    CH = CH.SetDofs(model);
    MeshDofs = CH.GetDofs();
                        
    for iL = 1:numel(MRNodeLayers)

        nNodes      = length(MRNodeLayers(iL).EndoNodes);

        EpiNodeIdx  = MRNodeLayers(iL).EpiNodes;
        EndoNodeIdx = MRNodeLayers(iL).EndoNodes;

        EpiNodePos  = MRDofs(EpiNodeIdx,:);
        EndoNodePos = MRDofs(EndoNodeIdx,:);

        MeanPos     = (EpiNodePos + EndoNodePos)/2;
        
        if(bSaveSkeletonMesh)
            %set epi and endo with same medial axis coordinates
            MeshDofs(EpiNodeIdx,:) = MeanPos;
            MeshDofs(EndoNodeIdx,:) = MeanPos;
        else
            %set epi and endo with original coords
            MeshDofs(EpiNodeIdx,:) = EpiNodePos;
            MeshDofs(EndoNodeIdx,:) = EndoNodePos;
        end

        Dist        = (MeanPos - EndoNodePos);
        MedialDist  = arrayfun(@(idx) norm(Dist(idx,:)), 1:size(Dist,1));

        for iN = 1:nNodes

            iNext = iN+1;
            iPrev = iN-1;

            if iNext>nNodes,     iNext = 1; end
            if iPrev<1,          iPrev = nNodes; end

            V1          = MeanPos(iNext,:) - MeanPos(iN,:);
            V2          = MeanPos(iPrev,:) - MeanPos(iN,:);

            TurnAngle 	= acos(dot(V1,V2)/(norm(V1)*norm(V2)));

            if isnan(TurnAngle),   TurnAngle = 0; end
            if isnan(MedialDist(iN)),   MedialDist(iN) = 0; end

            MRMedialDofs = [MRMedialDofs; [MeanPos(iN,:), MedialDist(iN),TurnAngle]];
        end        
    end

%end    
%CHMeanMR = MRMesh.SetDofs(MeanMRDofs);
outputMedialDofs = MRMedialDofs;
outputMedialMesh = MRMesh.SetDofs(MeshDofs);

end


classdef CubicMeshClass
    % Class implemented to handle Cubic Hermite Meshes. 
    % 
    % List of TODOs:
    % - Write an efficient affine transformation of the mesh 
    % - Make the get and set DOFS with second versions, and robust to the
    % number of nodes used or not. 
    % 
    % Revision history:
    % 31/10/13: Adapt to I/O of q.Lagrange
    % 18/09/13: Merge from changes that were introduced in
    % CubicHermiteMesh4.m
    % 15/04/13: Remane into CubicMesh.m, with a constructor with elements
    % of a cubic Lagrange mesh.
    % 13/04/13: ExportCubicLagrangeMesh(): conversion into cubic Lagrange
    % from cubic Hermite
    % 12/12/12: Update SetNodeCoorValue and GetNodeCoorValue, with default
    % options and change order of parametes in SetNodeCoorValue
    % 14/06/12: Update of the generation of images with cmGui, now able to
    % account for resolution isotropic in other planes than Z.
    % 18/05/12: ExportLinearCubicMesh(): conversion into linear cubic meshes
    % 03/04/12: addition of function MoveCentre2Origin
    % 17/10/11: rotateMeshOnAxis, make rotateMesh working with second
    % versions
    % 12/10/11: I/O to get the GroupName
    % 21/03/11: I/O to read c.Lagrange
    % 14/10/10: introduction of a faster way of calculating xi coordintes
    % of a point, contribution by Jiahe.
    % 23/06/10: introduction of obj.GenerateListSurfacePoints in order to
    % calculate distances to mesh using cmiss
    % 23/04/10: introduction of obj.CalculateDistancePoint2Mesh(point);
    % 26/02/10: introduction of obj.NodeValueVersionInElement (coping with
    % second versions of derivatives and so for fitting processes)
    % 23/02/10 (V3): cope with the fact that the global index of nodes
    % mi/ht not be from 1 to nNodes, adding obj.GIN.
    % 10/02/10 (V2): cope with the second version of derivatives.
    % Implementation of writting exelem with collapsed elements and choice
    % of node versions. 
    % 18/12/09: fitting of a field in the mesh (import the code from
    % FittingInto3DCubicHermiteMesh6)
    % 15/12/09: calculi of the element volume and gauss coordinates
    % ...
    
   properties
      DataDir % Directory where the data was read/written to file
      name
      GroupName
      exNodeFileName
      exElemFileName
      
      element            % (1) cube; (2) tetrahedral; (3) triangular surface
      InterpolationBasis % (1) c.Hermite; (2) c.Lagrange; (3) q.Lagrange
      nScaleFactorsDefs  % number of scale factors definitions, usually 1, but possible 2, 3, etc (as written in an exelem file)
      ScaleFactorSet     % cell array with strings like "c.Hermite*c.Hermite*c.Hermite" (as written in an exelem file)
      nScales            % number of scale factors required per set (vector of nScaleFactorsDefs values)
      
      nNodes    % Number of nodes in the mesh (used by elements)
      nNodesUnused
      GIN       % GlobalIndexNumber: vector of (nNodes x 1) of the global index of the nodes indicated in the original EXNODE file.
      OLDGIN    % GlobalIndexNumber: vector of (nNodes x 1) of the global index of the nodes in a previous topology of the mesh.
      nElems    % Number of elements in the mesh
      OLDGIE    % Old GlobalIndexElement: vector of (nElems x 1) of the global index of the element in a previous topology of the mesh.
      OrientationOption % Field to code the convention of how the xi coordinates are oriented during the creation of shapes (see CreateExDeformedShape)
      %--------------------------
      % Path variables
      %--------------------------
      TempBinaryDir
      TempcmGuiDir      
      TempExampleDataDir
      %--------------------
      % System
      %--------------------
      % A flag to distinguish between linux and windows
      WhichOperatingSystem
      %--------------------
      % Element definition:
      %--------------------
      FormatOrder %Depending on the format, the order is different! This variable refers to c.Hermite
      % ATTENTION! Node values are ordered in exnode files as
      % (u,d/ds1,d/ds2,d2/ds1ds2,d/ds3,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3),
      % whereas the inexes used in this class takes a different node value
      % order, replacing 4th and 5th components, leaving the simple derivatives before:
      % (u,d/ds1,d/ds2,d/ds3,d2/ds1ds2,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3),
      FormatOrderCL % Depending on the format, the order is different (refers to c.Lagrange). Two options:
      % 'C.Heart': ordering using in CHeart code (from KCL)
      % 'Sequential': sequential ordering, like in a medical image.
      nNofElem  % Number of nodes in each elem (nElems x 1), 6 or 8.
      giNofElem % Global indexes of nodes of each element (nElems x n). n = 6 or 8 nodes. They are
                % ordered corresponding to the 1st-8th local node of a cube
      liNofElem % Local indexes of the eight nodes of each elements (nElems x n). 
                % This will normally be 1-8, except from collapsed elements, 
                % which will have some idexes repeated
                % - Collapse xhi3=0 plane 1-2-1-2-3-4-5-6 (Fernandez2004)
                % - Collapse xhi1=1 plane 1-2-3-2-4-5-6-5
                % - Collapse xhi1=0 plane 1-2-1-3-4-5-4-6
                % - Collapse xhi2=0 plane 1-1-2-3-4-4-5-6 (heart.exnode by S.Niederer)
      valueIndices % indexes of the value to be taken. (nElems x 3coordinates x 8nodes x 8values)
                % This will normally be 1-8, except from nodes with several
                % versions
      valueOrderInExFile % Vector of length 8 with the order of the values 
                % It is always given as [1 2 3 5 4 6 7 8], reflecting the
                % change of  ordering (u,d/ds1,d/ds2,d2/ds1ds2,d/ds3,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3)
      % VARIABLE MADE REDUNDANT TO DECREASE COMPLEXITY AND REDUNDANCY WITH
      % VALUEINDICES:
      % NodeValueVersionInElement  % Matrix (nElems x 3 coord fields x 8nodes x 8values) with the number of version to be used for interpolation. 
                                 % It is a "processed" version of valueIndices. 
      
      % For the fitting process (definition of additional basis):
      nNewVersionsBasis % (3 values) Number of new basis required for handling second versions of node values (both coordinates and derivatives) in elements in 
                        % each of the coordinate fields (nNewVersionsBasis(1)= in X coord field)
      NewBasisIndex     % Matrix (3 coord fields x nNodes x 8 continuities x 8 maximum number versions) indicating the index of the new basis of additional versions
      % Needed for those meshes that have second versions of coordinates,
      % but we want them to be the same after deformation:
      nNewVersionsC1Basis % (3 values) Number of new basis required for handling second versions of the derivative node values (not coordinates) in elements in 
                        % each of the coordinate fields
      NewC1BasisIndex   % Analogous, but only for indexing of derivative basis: Matrix (3 coord fields x nNodes x 8 continuities x 8 maximum number versions) 
                       
      ExternalFaces % Matrix (nElems x 6) of booleans indexing which surfaces are external
      bExternalFacesFound
      nExternalFaces
      Neighbours % Matrix (nElems x 6) with the ID of adjacent elements (in the corresponding position of the Internal Face)
      
      ElemCentre % Matrix (nElems x 3) of the 3D global coordinate value of local point (0.5,0.5,0.5)
      bCentreElementsCalculated
      
      ElemValues    % variable to store fields that are defined per element, not per node
                    % (nElems x 1) Only a scalar field in this first implementation (04/02/14) 
      bElemValues   % flag to indicate if it is there.
      %--------------------
      % Node definition:
      %--------------------
      versions  % (nNodes x 3) versions of each of the coordinate fields
      dofsUsed  % (nNodes x 8) matrix of booleans to codify which of the DOFS are actually used (in case of collapsed elements, some won't)
      CubicLagrangeMapping
      MaxNeighbours
      mapping
      % Struct with (rebuilt after any Update())
      % - IndexOf64CHBasis: (3x64) indexes (in range 1:4) of the 3 CH functions
      % that makes each of the 64 basis functions of an element.
      % - ContinuityOfNode: (1x64) index (1 to 8) of the local node in
      % which the corresponding basis function is continuous
      % - ElemsOfNode (nNodes x MaxNeighbours): indexes of the elements to which a node
      % belongs. (an apex node in Steven's toplogy can belong to many
      % elements...)
      % - NodesOfElem (nElems x 8): indexes of the nodes to which an
      % element belongs. Redundant with "giNofElem"
      % - ... many other things, see DefaultInitialization

      % TODO: make the indexing of new basis possible for more than two
      % versions!!!
      
      coordinates  % (nNodes x 3 x max(versions)) coordinates, (x,y,z)
      derivatives  
      % Struct with:
      % - duds1      (nNodes x 3 x max(versions))
      % - duds2      (nNodes x 3 x max(versions))
      % - duds3      (nNodes x 3 x max(versions))
      % - duds12     (nNodes x 3 x max(versions))
      % - duds13     (nNodes x 3 x max(versions))
      % - duds23     (nNodes x 3 x max(versions))
      % - duds123    (nNodes x 3 x max(versions))
      %--------------------
      % Fibres:
      %--------------------
      bFibres % Boolean to control if there's fibre information
      % versions and mapping is the same as in coordinates!
      FibreDescriptionType % variable to know whether fibres are described
      % cartesian vector (1) or as two angles, elevation and imbrication (2)
      FibDim % Number of components of each fibre (3 if a cartesian vector,
      % 2 if a set of elevation and imbrication angles)
      bExportLinearFibres % flag to export a linear description of the fibre
      % field, a hacky way to get the SCACOM2014 results.
      fibres
      % Struct with:
      % - value      (nNodes x FibDim x max(versions))
      % - dfds1      (nNodes x FibDim x max(versions))
      % - dfds2      (nNodes x FibDim x max(versions))
      % - dfds3      (nNodes x FibDim x max(versions))
      % - dfds12     (nNodes x FibDim x max(versions))
      % - dfds13     (nNodes x FibDim x max(versions))
      % - dfds23     (nNodes x FibDim x max(versions))
      % - dfcds123    (nNodes x FibDim x max(versions))
      %--------------------
      % Other:
      %--------------------
      nFields    % Number of fields represented in the mesh
      CoordinatesName % name of the coordinate field (needed to be changed for computations of strains)
      % TODO: CLEANER WAY TO MANAGE THE NAMING OF FIELDS NEEDED!
      fieldNames % Matrix with the names of the fields (:,nFields)
                 % The first character in the string codifies the length of
                 % the name!!!
      MM         % MassMatrix used for fitting purposes (see FitField)
      fields
      % Struct with:
      % - value      (nNodes x nFields x versionsXcoord)
      % - dfds1      (nNodes x nFields x versionsXcoord)
      % - dfds2      (nNodes x nFields x versionsXcoord)
      % - dfds3      (nNodes x nFields x versionsXcoord)
      % - dfds12     (nNodes x nFields x versionsXcoord)
      % - dfds13     (nNodes x nFields x versionsXcoord)
      % - dfds23     (nNodes x nFields x versionsXcoord)
      % - dfds123    (nNodes x nFields x versionsXcoord)
      % TODO: increase the flexibility of this structure, currently limited
      % to only secondary versions of the X component of the coord. field
      SecondaryVersionsDefinitionOption % Variable that takes values 1 to 3
      % corresponding to x,y,z components, meaning tha fields take the
      % secondary versions definition from the choice of that component.
      % Default option is 1. (currently the CubicHermiteClass4 only supports versions
      % definition for the coordinate field).
      ListOfFields
      FieldValues
      % Structures with the definition and values of fields, as in ReadExNode

      %--------------------
      Quality
      % Struct with:
      % - Quality.AspectRatio
      % - Quality.Q1 = average AspectRatio
      % - Quality.OrthogonalityPerElement
      % - Quality.OrthogonalityPerNode
      % - Quality.OrthogonalityPerNodeInElement
      % - Quality.Q2 = average Orthogonality
      % - Quality.JacobianRatio
      % - Quality.Q3 = average JacobianRatio
      % - Quality.DirecJacRatio
      % - Quality.Q4 = average DirecJacRatio
      % - Quality.QShIRT = % of overlap between binary images at the end of
      % - Quality.Q5 = average Condition number
      % - Quality.ConditionNumber
      % registration
      bQualityCalculated
      bQ1Calculated
      bQ2Calculated
      bQ3Calculated
      bQ4Calculated
      bQ5Calculated       
      TetrahedralCanvas
      bTetrahedralCanvasBuilt
      % Struct with a linear mesh TetrahedralCanvas to plot quality
      % - TetrahedralCanvas.nDel(1:nElems) = Number of tetrahedra
      % - TetrahedralCanvas.nNod(1:nElems) = Number of nodes
      % - TetrahedralCanvas.Tes(1:nElems,:)= Delanuy triangularization
      % - TetrahedralCanvas.X(1:nElems,1:3)= Coordinates of the nodes
      Wireframe
      bWireframeBuilt
      % Struct with the list of points of each element to draw a wireframe:
      % - Wireframe.Point(1:nElems,1:n,1:3). n = 6 or 8 nodes
      OrderVisit8Nodes
      OrderVisit6Nodes
      OrderVisit4Nodes
      OrderVisit27Nodes
      OrderVisit64NodesCHeart
      OrderVisit64NodesEX
      % Nodes to be visited to draw a cube (used in Wireframe)
      eBB
      beBBbuilt
      % element bounding box
      BB
      DefaultBBmargin  % In % to the maximum side of the box
      % Bounding Box of the geometry: 
      % - BB = [xmin, xmax, ymin, ymax, zmin, zmax, margin]
      %image
      % Binary image with three fields
      % - binary
      % - origin
      % - spacing

      bWarnings
     
   end
   methods
% Initialization, Update and mapping
       function obj         = CubicMeshClass(exNodeFileName, exElemFileName, element)
           % Needed to read the exelem file correctly!   
           % Constructor adapted to work with surface triangular meshes,
           % where the default option is a 'cube':
           obj.element = 'cube';
           if nargin >=4 
               obj.element = element;
           end
           obj.bWarnings = 0;
           obj.valueOrderInExFile = [1 2 3 5 4 6 7 8];
           obj.CoordinatesName = 'coordinates';
           obj.ScaleFactorSet = java_array('java.lang.String',3);
           bLoadExFiles = 0;
           bLoadLinearMesh = 0;
           switch nargin
               case 0 % Default initialization here:
                   obj = obj.EXmeshInitialization();
               case 1 % Two options here:
                   if ischar(exNodeFileName(1))
                       [name,path,extension,decomposedpath] = RemovePathAndExtension(exNodeFileName);
                       if isempty(extension)
                           % First argument can be the root of the name, without
                           % extensions:
                           temp =exNodeFileName;
                           exNodeFileName = [temp '.exnode'];
                           exElemFileName = [temp '.exelem'];
                           bLoadExFiles  = 1;
                       else
                           switch extension
                               case {'.VTK','.vtk'}
                                   bLoadLinearMesh = 1;
                               otherwise
                                   fprintf('ERROR! file extension not recognised: %s\n',extension);
                                   return;
                           end
                       end
                   end
                   if isnumeric(exNodeFileName(1))
                       % The first argument is an orientative number of the
                       % number of elements, to allocate memory:      
                       nE = exNodeFileName;
                       nEcircunf = nE(2);
                       obj.MaxNeighbours = 2*(nEcircunf + 8);
                       fprintf('Creating a Cubic Mesh expecing %i maximum neighbours\n',obj.MaxNeighbours);               
                       obj = obj.EXmeshInitialization();  
                   end
               case 2
                   bLoadExFiles  = 1;
           end
           if (bLoadExFiles)
               obj.DataDir = GetPath(exNodeFileName);               
               EXmesh = obj.ReadExFiles(exNodeFileName,exElemFileName);
%                if EXmesh.nNodes == 0
%                    return;
%                end
               % In case of big meshes, the default MaxNeighbours is not
               % going to be enough:
               EstimatedElementsCircunferential = round(sqrt(size(EXmesh.giNofElem,1)));
               EstimatedMaxNeighbours = 2*(EstimatedElementsCircunferential + 8);
               obj.MaxNeighbours = EstimatedMaxNeighbours;
               obj = obj.EXmeshInitialization(EXmesh);
               obj = obj.Update();           
           end
           if (bLoadLinearMesh)               
               mesh = obj.ReadLinearMesh(exNodeFileName);               
               obj.MaxNeighbours = size(mesh.giNofElem , 2);
               obj = obj.EXmeshInitialization(mesh);
               obj = obj.Update();           
           end
       end
       function obj         = EXmeshInitialization(obj,EXmesh)
           bNullInitialization=0;
           bDebug=0;
           if isempty(obj.MaxNeighbours)
               obj.MaxNeighbours = 80;
           end
           obj.bFibres = 0;
           obj.FormatOrder = 'EXformat';
           obj.FormatOrderCL = 'Sequential';
           % Check if there is information of fibres in the EXmesh
           % structure:           
           if  nargin > 1 
               if isfield(EXmesh,'FormatOrder'),  obj.FormatOrder  = EXmesh.FormatOrder; end
               if EXmesh.nNodes>0   
                   if isfield(EXmesh,'InterpolationBasis'), obj.InterpolationBasis = EXmesh.InterpolationBasis;    end               
                    % if empty, it'll be filled in Update();
                   if isfield(EXmesh,'nScaleFactorsDefs'),  obj.nScaleFactorsDefs  = EXmesh.nScaleFactorsDefs; end
                   if isfield(EXmesh,'ScaleFactorSet'),     obj.ScaleFactorSet  = EXmesh.ScaleFactorSet;       end
                   if isfield(EXmesh,'nScales'),            obj.nScales  = EXmesh.nScales;                     end
                   if isfield(EXmesh,'GroupName'),          obj.GroupName = EXmesh.GroupName;                  end
                   if isfield(EXmesh,'liNofElem'),          
                       obj.liNofElem = int8(EXmesh.liNofElem);
                   else
                       if isempty(obj.liNofElem), fprintf('WARNING! no local indexes of each node is provided (assumption of no collapsed surfaces is taken)\n'); end
                   end
                   if isfield(EXmesh,'nNofElem')
                       obj.nNofElem = EXmesh.nNofElem;
                   else                 
                       if isempty(obj.nNofElem), fprintf('WARNING! no number of nodes to define an element is provided (assumption of no collapsed surfaces is taken)\n'); end
                   end
                   if isfield(EXmesh,'versions')          
                       obj.versions = int8(EXmesh.versions);
                   else
                       if isempty(obj.versions), fprintf('WARNING! no versions of each node is provided (assumption of no secondary versions is taken)\n'); end
                   end
                   if isfield(EXmesh,'valueIndices')          
                       obj.valueIndices = int8(EXmesh.valueIndices);
                   else
                       if isempty(obj.valueIndices), fprintf('WARNING! no indexing of which value to take in element definition is given (assumption of no secondary versions is taken)\n'); end
                   end
                   
                   % if they don't exist, they'll remain empty:
                   if isfield(EXmesh,'exNodeFileName'),     obj.exNodeFileName = EXmesh.exNodeFileName;        end
                   if isfield(EXmesh,'exElemFileName'),     obj.exElemFileName = EXmesh.exElemFileName;        end
                   obj.name = EXmesh.name;
                   if isfield(EXmesh,'GIN')    
                       obj.GIN = int16(EXmesh.GIN);
                   else
                       obj.GIN = 1:obj.nNodes;
                   end
                   if isfield(EXmesh,'giNofElem')    
                       obj.giNofElem = int16(EXmesh.giNofElem);
                   end
                   if isfield(EXmesh,'coordinates')
                        obj.coordinates = EXmesh.coordinates;
                   else
                       fprintf('WARNING! mesh did not have a field named "coordinates" as expected. Looking for a field with type "coordinate" and 3 dimensions instead...\n');
                       % look for the field that is of type 'coordinate'
                        for iF=1:EXmesh.ListOfFields.nFields
                            iFieldType = EXmesh.ListOfFields(iF).field.Type;
                            if strcmp(iFieldType,'coordinate')
                                % Check if it has 3 dimensions:
                                if EXmesh.ListOfFields(iF).field.nComponents == 3
                                    % Get this field:
                                    nP = size(EXmesh.FieldValues,2);                                    
                                    for iP =1:nP, 
                                        values = EXmesh.FieldValues(iF,iP).values'; 
                                        obj.coordinates(iP,:) = values(1,:);
                                        if obj.InterpolationBasis == 1                                            
                                           obj.derivatives.duds1(iP,:) = values(2,:);
                                           obj.derivatives.duds2(iP,:) = values(3,:);
                                           obj.derivatives.duds3(iP,:) = values(5,:);
                                           obj.derivatives.duds12(iP,:) = values(4,:);
                                           obj.derivatives.duds13(iP,:) = values(6,:);
                                           obj.derivatives.duds23(iP,:) = values(7,:);
                                           obj.derivatives.duds123(iP,:) = values(8,:);
                                        end
                                    end
                                end
                            end
                        end
                   end
                   switch obj.InterpolationBasis
                       case 1 % A cubic Hermite mesh:
                           if isfield(EXmesh,'duds1')
                               %if the field is not named "coordinates", it
                               %will be not loades as duds1:
                               obj.derivatives.duds1 = EXmesh.duds1;
                               obj.derivatives.duds2 = EXmesh.duds2;
                               obj.derivatives.duds3 = EXmesh.duds3;
                               obj.derivatives.duds12 = EXmesh.duds12;
                               obj.derivatives.duds13 = EXmesh.duds13;
                               obj.derivatives.duds23 = EXmesh.duds23;
                               obj.derivatives.duds123 = EXmesh.duds123;
                           end
                       case 2 % A cubic Lagrange mesh: do nothing
                           
                   end
                   obj.nNodes = EXmesh.nNodes;
                   obj.nElems = size(obj.giNofElem,1);
                   % Allocation
                   obj.Quality.OrthogonalityPerNodeInElement=zeros(obj.nElems,8);
                   obj.Quality.AspectRatio                  =zeros(obj.nElems,1);
                   obj.Quality.OrthogonalityPerNode         =zeros(obj.nNodes,1);
                   obj.Quality.OrthogonalityPerElement      =zeros(obj.nElems,1);

                   obj.bFibres = 0;
                   obj.nFields = 0;
                   obj.fieldNames   = repmat(' ',128,1);
                   if isfield(EXmesh,'ListOfFields')
                       for iField =1:EXmesh.ListOfFields.nFields
                       if (strcmp(EXmesh.ListOfFields.field(iField).Name,'fibres'))
                           if (obj.bFibres==1)
                               fprintf(1,'WARNING! Apparently, more than one field was called "fibres"\n');
                           end
                           obj.bFibres = 1;
                           iFieldFibre= iField;
                           if strcmp(EXmesh.ListOfFields.field(iField).SubType,'fibre')
                               obj.FibreDescriptionType = 2;
                           else
                               obj.FibreDescriptionType = 1;
                           end
                           obj.FibDim = EXmesh.ListOfFields.field(iField).nComponents;
                           for iNode = 1:obj.nNodes                      
                               data = EXmesh.FieldValues(iField,iNode).values;                               
                               for iComponent=1:obj.FibDim                                   
                                   nVers = EXmesh.ListOfFields.field(iField).component(iComponent).nVersions;
                                   if(bDebug), fprintf('node %i: nVers=%i\n',iNode,nVers); end
                                   obj.fibres.value(iNode,iComponent,1:nVers)  = data(iComponent,obj.valueOrderInExFile(1));
                                    if EXmesh.ListOfFields.field(iField).component(iComponent).nValues>1
                                       obj.fibres.dfds1(iNode,iComponent,1:nVers)   = data(iComponent,obj.valueOrderInExFile(2));
                                       obj.fibres.dfds2(iNode,iComponent,1:nVers)   = data(iComponent,obj.valueOrderInExFile(3));
                                       obj.fibres.dfds3(iNode,iComponent,1:nVers)   = data(iComponent,obj.valueOrderInExFile(4));
                                       obj.fibres.dfds12(iNode,iComponent,1:nVers)  = data(iComponent,obj.valueOrderInExFile(5));
                                       obj.fibres.dfds13(iNode,iComponent,1:nVers)  = data(iComponent,obj.valueOrderInExFile(6));
                                       obj.fibres.dfds23(iNode,iComponent,1:nVers)  = data(iComponent,obj.valueOrderInExFile(7));
                                       obj.fibres.dfds123(iNode,iComponent,1:nVers) = data(iComponent,obj.valueOrderInExFile(8));
                                    end
                               end
                           end
                       else
                           % Load the rest of fields (not the coordinate field):
                           fieldname = EXmesh.ListOfFields.field(iField).Name;
                           if ~strcmp(EXmesh.ListOfFields.field(iField).Type,'coordinate') || (EXmesh.ListOfFields.field(iField).nComponents~=3)%strcmp(fieldname,'coordinates')
                               % New field:
                               NewFieldID = obj.nFields + 1;
                               obj.nFields = NewFieldID;
                               obj = obj.SetFieldName(NewFieldID,fieldname);
                               %fprintf(' WARNING! I/O functionality not implemented yet to read field %s (CubicMeshClass.m)\n',fieldname);
                               obj.ListOfFields.field(NewFieldID) = EXmesh.ListOfFields.field(iField);
                               for iN = 1:obj.nNodes
                                    obj.FieldValues(NewFieldID,iN).values = EXmesh.FieldValues(iField,iN).values; % matrix of size (nComponents x nFieldValues x nVersions)
                               end
                           end
                       end
                   end
                   end
               else
                   bNullInitialization=1;
               end
           else
               bNullInitialization=1;
           end
           if (bNullInitialization)
               obj.InterpolationBasis = 0;
               obj.name = '';
               obj.nNodes = 0;
               obj.nElems = 0;
               obj.bFibres = 0;
               obj.nFields = 0;
               obj.nNewVersionsBasis = [0 0 0];
               obj.nNewVersionsC1Basis = [0 0 0];
           end
           if isempty(obj.bQualityCalculated)
               obj = obj.DefaultInitialization;
           else
               obj = obj.Update();
           end
           obj = obj.UpdateDOFs();
       end
       function obj         = ReadAndUpdateNodes(obj,ExNodeFile)
           % Function to update the dofs of a topology, by simply reading
           % the ExNodeFile, without the need of the ExElem - a speed up
           % when running atlas functions!
           mesh = obj.ReadExNode(ExNodeFile);
           % Update the variables:
           obj = obj.EXmeshInitialization(mesh);
       end
       function obj         = UpdateDOFs(obj)
           % Function to fill the variable "dofsUsed", in order to codify
           % the use or not of certain DOFs in the presence of collapsed
           % elements. This is used during field fitting processes.
           bDebug=0;
           hack1=0;
           hack2=0;
           % Default: all nodes are used
           obj.dofsUsed = ones(obj.nNodes,8);
           
           % Not needed in linear meshes (also the lagrange ones?)
           switch obj.InterpolationBasis
               case {4, 5}
                   return
           end
           
           % Now, check the definition of the elements, looking for
           % collapsed nodes:
           coldef = obj.mapping.collapseDefinition;
           for iElem=1:obj.nElems
               if obj.nNofElem(iElem)~=8                   
                   clear dofsDisabled;
                   LocalIndexes = obj.liNofElem(iElem,:);
                   switch obj.InterpolationBasis
                       case 1
                           switch num2str(LocalIndexes)
                               % DOFs definition from "GetNodeCoorValue"
                               % See also mapping.collapseDefinition in "DefaultInitialization"
                               case {num2str(coldef(1,:)),num2str(coldef(2,:)),num2str(coldef(3,:)),num2str(coldef(4,:))} % derivatives in xhi2 make no sense...
                                   dofs = [1 1 0 1 0 1 0 0];
                               case {num2str(coldef(5,:)),num2str(coldef(6,:)),num2str(coldef(7,:)),num2str(coldef(8,:))} % xhi2=0,1 is collapsed
                                   dofs = [1 0 1 1 0 0 1 0];
                                   % hack to try the cancelation of xi1&2 while
                                   % fitting the apex:
                                   if(hack1), dofs = [1 0 0 0 0 0 0 0]; end %[1 0 0 0 0 0 0 0]
                               case {num2str(coldef(9,:)),num2str(coldef(10,:)),num2str(coldef(11,:)),num2str(coldef(12,:))} % xhi3=0,1 is collapsed
                                   dofs = [1 1 1 0 1 0 0 0];
                               case {num2str(coldef(13,:))}
                                    % Case with two collapsed faces, xhi2=0
                                    % and xhi3=0
                                    dofs = [1 1 0 0 0 0 0 0];
                               otherwise
                                   fprintf('WARNING! local indexes pattern (%i %i %i %i %i %i %i %i) not recognised, needed for fitting purposes!\n',LocalIndexes);
                                   dofs = [1 1 1 1 1 1 1 1];
                           end
                           % Hack to try the original version (no dofs cancelation)
                           if(hack2), dofs = [1 1 1 1 1 1 1 1]; end
                       case {2,3}
                           dofs = 1;
                   end
                   % Check with nodes are "collapsed", the ones that are
                   % repeated in LocalIndexes:
                   clear Icollapsed;
                   Icollapsed = [];
                   for iL=1:numel(unique(LocalIndexes))
                       I = find(LocalIndexes==iL);
                       if numel(I)>1 % when a local index of a node appears more than once:
                           Icollapsed = [Icollapsed iL];
                       end
                   end
                   if(bDebug)
                       fprintf(' In element %i there were %i collapsed nodes: ',iElem,numel(Icollapsed));
                       for i=1:numel(Icollapsed)
                           fprintf(' %i (local index %i),',obj.giNofElem(iElem,Icollapsed(i)),Icollapsed(i));
                       end
                       fprintf('\n');
                   end
                   for iC=1:numel(Icollapsed)
                       iNode = obj.giNofElem(iElem,Icollapsed(iC));
                       obj.dofsUsed(iNode,:) = dofs;
                   end
               end
           end
       end
       function obj         = DefaultInitialization(obj)  
           obj.CoordinatesName = 'coordinates';
           obj.bQualityCalculated       = false;
           obj.bQ1Calculated            = false;
           obj.bQ2Calculated            = false;
           obj.bQ3Calculated            = false;
           obj.bQ4Calculated            = false;
           obj.bQ5Calculated            = false;
           obj.bTetrahedralCanvasBuilt  = false;
           obj.bWireframeBuilt          = false;
           obj.bExternalFacesFound      = false;
           obj.nExternalFaces           = 0;
           obj.OrderVisit8Nodes = [1 2 4 3 1 5 6 2 6 8 4 8 7 3 7 5];
           %obj.OrderVisit6Nodes = [1 2 4 3 1 5 2 5 6 4 6 3];
           obj.OrderVisit6Nodes = [1 2 3 6 4 1 4 5 2 5 6 3];
           obj.OrderVisit4Nodes = [1 2 3 4 1 3 2 4];
           % The 8 corners are ;
           Corners64 = [1 4 13 16 49 52 61 64];
           Corners27 = [1 3 7 9 19 21 25 27];
           obj.OrderVisit27Nodes = Corners27(obj.OrderVisit8Nodes);
           obj.OrderVisit64NodesCHeart = obj.OrderVisit8Nodes;
           obj.OrderVisit64NodesEX = Corners64(obj.OrderVisit8Nodes); 
% MAPPING FOR AN ORDER OF VALUES: [u, duds1, duds2, duds3, duds12...]
                                           %C0                C1 df/dx1         C1 df/dx2         C1 df/dx3         C1 df/dx12        C1 df/dx13        C1 df/dx23        C1 df/dx123
            obj.mapping.IndexOf64CHBasis = [1 3 1 3 1 3 1 3   2 4 2 4 2 4 2 4   1 3 1 3 1 3 1 3   1 3 1 3 1 3 1 3   2 4 2 4 2 4 2 4   2 4 2 4 2 4 2 4   1 3 1 3 1 3 1 3   2 4 2 4 2 4 2 4; 
                                            1 1 3 3 1 1 3 3   1 1 3 3 1 1 3 3   2 2 4 4 2 2 4 4   1 1 3 3 1 1 3 3   2 2 4 4 2 2 4 4   1 1 3 3 1 1 3 3   2 2 4 4 2 2 4 4   2 2 4 4 2 2 4 4;
                                            1 1 1 1 3 3 3 3   1 1 1 1 3 3 3 3   1 1 1 1 3 3 3 3   2 2 2 2 4 4 4 4   1 1 1 1 3 3 3 3   2 2 2 2 4 4 4 4   2 2 2 2 4 4 4 4   2 2 2 2 4 4 4 4];
           obj.mapping.ContinuityOfNode = [ 1 2 3 4 5 6 7 8   1 2 3 4 5 6 7 8   1 2 3 4 5 6 7 8   1 2 3 4 5 6 7 8   1 2 3 4 5 6 7 8   1 2 3 4 5 6 7 8   1 2 3 4 5 6 7 8   1 2 3 4 5 6 7 8];
           % Now the mapping for the 64 nodes inside a cubic lagrange
           % element, if ordered sequentially:
           obj.mapping.IndexOf64CLBasis(1,:) = repmat([1,2,3,4],1,16);
           obj.mapping.IndexOf64CLBasis(2,:) = repmat([1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4],1,4); 
           obj.mapping.IndexOf64CLBasis(3,:) = [repmat(1,1,16) repmat(2,1,16) repmat(3,1,16) repmat(4,1,16)];
           % Xhi coordinates of the 8 local nodes of an element:
           obj.mapping.xhi_LocalNode    = [0 1 0 1 0 1 0 1;
                                           0 0 1 1 0 0 1 1;
                                           0 0 0 0 1 1 1 1];
           % Kind of continuity that is kept in that line: 
           % -2: du/dx1 in lines along xhi1
           % -3: du/dx1 in lines along xhi2
           % -4: du/dx1 in lines along xhi3
           obj.mapping.Lines.Continuity = [2 2 2 2 3 3 3 3 4 4 4 4];
           obj.mapping.Lines.Nodes      = [1 3 5 7 1 2 5 6 1 2 3 4;
                                           2 4 6 8 3 4 7 8 5 6 7 8];
           obj.mapping.Surfaces.Continuity=[5 5 6 6 7 7; % cross derivative
                                            3 3 4 4 4 4; % First simple derivative
                                            2 2 2 2 3 3; % Second simple derivative
                                            1 1 1 1 1 1;]; % Value of the node
           obj.mapping.Surfaces.Nodes     =[1 5 1 3 1 2;
                                            2 6 2 4 5 4;
                                            3 7 5 7 3 6;
                                            4 8 6 8 7 8];
           % Definition of the collapsed elements: the repetition pattern 
           % of the local nodes. Each row is a definition type!
           obj.mapping.collapseDefinition = [1 2 1 3 4 5 4 6; % xhi1=0 is collapsed, xhi2 derivatives make no sense in nodes 1 and 4
                                             1 2 3 2 4 5 6 5; % xhi1=1 is collapsed, xhi2 derivatives make no sense in nodes 3 and 5 
                                             1 2 1 2 3 4 5 6; % xhi3=0 is collapsed, xhi2 derivatives make no sense
                                             1 2 3 4 5 6 5 6; % xhi3=1 is collapsed, xhi2 derivatives make no sense
                                             1 1 2 3 4 4 5 6; % xhi2=0 is collapsed, xhi1 derivatives make no sense in nodes 1 and 4
                                             1 2 3 3 4 5 6 6; % xhi2=1 is collapsed, xhi1 derivatives make no sense in nodes 3 and 6
                                             1 1 2 2 3 4 5 6; % xhi3=0 is collapsed, xhi1 derivatives make no sense
                                             1 2 3 4 5 5 6 6; % xhi3=1 is collapsed, xhi1 derivatives make no sense
                                             1 2 3 4 1 5 3 6; % xhi1=0 is collapsed, xhi3 derivatives make no sense
                                             1 2 3 4 5 2 6 4; % xhi1=1 is collapsed, xhi3 derivatives make no sense
                                             1 2 3 4 1 2 5 6; % xhi2=0 is collapsed, xhi3 derivatives make no sense
                                             1 2 3 4 5 6 3 4;% xhi2=1 is collapsed, xhi3 derivatives make no sense
                                             1 1 2 2 1 1 3 4]; % xhi2=0 is collapsed, xhi1 derivatives make no sense in nodes 1 and 4
                                                               % AND xhi3=0 is collapsed, xhi1 derivatives make no sense 
           % and each collapsed definition has a collapsed face (these two
           % structures have the same indexing)
           obj.mapping.collapsedFace      = [   5
                                                6
                                                1
                                                2
                                                3
                                                4
                                                1
                                                2
                                                5
                                                5
                                                3
                                                4];
                                            
                                         
           obj.CubicLagrangeMapping.nodesOfSurface(1,1:16) = 1:16;                              % face xhi3 = 0;
           obj.CubicLagrangeMapping.nodesOfSurface(2,1:16) = 49:64;                             % face xhi3 = 1;
           obj.CubicLagrangeMapping.nodesOfSurface(3,1:16) = [1:4 17:20 33:36 49:52];           % face xhi2 = 0;
           obj.CubicLagrangeMapping.nodesOfSurface(4,1:16) = [13:16 29:32 45:48 61:64];         % face xhi2 = 1;
           obj.CubicLagrangeMapping.nodesOfSurface(5,1:16) = [1:4:16 17:4:32 33:4:48 49:4:64];  % face xhi1 = 0;
           obj.CubicLagrangeMapping.nodesOfSurface(6,1:16) = [4:4:16 20:4:32 36:4:48 52:4:64];  % face xhi1 = 1;
           obj.BB            = [0 0 0 0 0 0 0];
           obj.eBB           = zeros(2,3,1);
           obj.beBBbuilt     =0;
           obj.DefaultBBmargin = 10; % Expressed in %
           obj.bCentreElementsCalculated=0;
           obj.bElemValues = false;
           %obj.nFields      =0;
           %obj.fieldNames   = repmat(' ',128,1);
           obj.SecondaryVersionsDefinitionOption = 1;
           obj.MM           = 0;
           obj.OrientationOption = 3; % This is the default orientation, the correct one for hearts and fibres
           obj.TempBinaryDir='./Binary/';
           obj.TempcmGuiDir ='./cmGui/';
           obj.TempExampleDataDir ='./ExampleData/';
           obj.WhichOperatingSystem = 'windows';
           obj              = obj.Update(1);
       end
       function [vals]      = DefaultLocalValueIndicesPerElement(obj)
           switch obj.InterpolationBasis
               case 1
                   vals = zeros(3,8,8);
                   for iC=1:3
                        vals(iC,1:8,1:8) = repmat(1:8',8,1);                
                   end
               case 2
                   % In a cubic lagrange cube there are 64 nodes with only
                   % coordinate values
                   vals = ones(3,64,1);
               case 3
                   % In a quadratic lagrange cube there are 27 nodes with only
                   % coordinate values
                   vals = ones(3,27,1);
               case 4
                   % In a linear cubic mesh there are 8 nodes
                   vals = ones(3,8,1);
               case 5
                   % In a linear triangular surface mesh there are 3 nodes
                   vals = ones(3,3,1);
               otherwise
                   vals = NaN;
                   fprintf('ERROR! Class not properly initialised (no Interpolation Basis chosen for DefaultLocalValueIndicesPerElement)\n')
           end
       end
       function obj         = FindSecondVersionBasis(obj)
            % New basis are needed for each node that belongs to an element calling a
            % second version of any of his 8 node values in each coordinate.
            bDebug=0;
            nNewBasis   = [0 0 0];
            nNewC1Basis = [0 0 0];
            % There are a total of (3 coord fields x nNodes x 8 node values x 8 possible
            % elements having the node - indexed as the local node index that this node would represent in the element)
            NewVersionsBasisIndex   = zeros(3,obj.nNodes,8,8);
            NewVersionsC1BasisIndex = zeros(3,obj.nNodes,8,8);
            %NodeFieldVerInElement   = zeros(obj.nElems,3,8,8);
            nSeemsNewBasis=0;
            for iElem=1:obj.nElems
                if obj.nNofElem(iElem)>0 % Check if element exists
                    for iCoor=1:3
                        for iln=1:8
                            for iCont=1:8
                                if (iCont~=obj.valueIndices(iElem,iCoor,iln,iCont))
                                    nSeemsNewBasis = nSeemsNewBasis+1;
                                    % In case a collapsed element:
                                    iLocal = obj.liNofElem(iElem,iln);
                                    iN = obj.mapping.NodesOfElem(iElem,iLocal);
                                    IndexNewVersion = double(obj.valueIndices(iElem,iCoor,iln,iCont));
                                    if(IndexNewVersion==0)
                                        fprintf('ERROR! in element definition (NULL index) \n')
                                        fprintf('       Element %i, coordinate field component %i, local node %i. Continuity %i\n',iElem,iCoor,iln,iCont);
                                    end
                                    Version = ceil(IndexNewVersion/8);
                                    if (NewVersionsBasisIndex(iCoor,iN,iCont,Version)==0)
                                        nNewBasis(iCoor) = nNewBasis(iCoor) + 1;
                                        NewVersionsBasisIndex(iCoor,iN,iCont,Version) = nNewBasis(iCoor);
                                        if iCont>1
                                            nNewC1Basis(iCoor) = nNewC1Basis(iCoor) + 1; 
                                            NewVersionsC1BasisIndex(iCoor,iN,iCont,Version) = nNewC1Basis(iCoor);
                                        end
                                    end
                                    %NodeFieldVerInElement(iElem,iCoor,iln,iCont) = Version;
                                else
                                    %NodeFieldVerInElement(iElem,iCoor,iln,iCont) = 1;
                                end
                            end
                        end
                    end
                end
            end
            
            obj.nNewVersionsBasis   = nNewBasis;
            obj.nNewVersionsC1Basis = nNewC1Basis;
            obj.NewBasisIndex          = NewVersionsBasisIndex;
            obj.NewC1BasisIndex        = NewVersionsC1BasisIndex;
            %obj.NodeValueVersionInElement = NodeFieldVerInElement;
            
            if (bDebug)
                fprintf(1,'    FindSecondVersionBasis: nNewBasisX,Y,Z = %i,%i,%i (nSeemsNewBasis=%i)\n',nNewBasis,nSeemsNewBasis);
                figure('Color',[1 1 1]); hold on;
                for c=1:3
                    subplot(1,3,c)
                    imagesc(squeeze(NewVersionsBasisIndex(c,:,:,2)));
                end
            end
       end
       function obj         = Update(obj,bDefault)
           if nargin<2
               bDefault = 0;
           end
           %fprintf('... ... updating Hermite class %s...\n',obj.name);
           if(~bDefault)
               % It needs to know at least the Interpolation Basis!
               if isempty(obj.nScaleFactorsDefs)               
                   switch(obj.InterpolationBasis)
                       case 1, % This is a cubic Hermite mesh
                           obj.ScaleFactorSet(1) = java.lang.String('c.Hermite*c.Hermite*c.Hermite');
                           obj.nScales = 64;
                           obj.nScaleFactorsDefs = 1;
                       case 2, % This is a cubic Lagrange mesh
                           obj.ScaleFactorSet(1) = java.lang.String('c.Lagrange*c.Lagrange*c.Lagrange');
                           obj.nScales = 64;
                           obj.nScaleFactorsDefs = 1;
                       case 3, % This is a quadratic Lagrange mesh
                           obj.ScaleFactorSet(1) = java.lang.String('q.Lagrange*q.Lagrange*q.Lagrange');
                           obj.nScales = 27;
                           obj.nScaleFactorsDefs = 1;
                       case 4, % This is a linear cubic mesh
                           obj.ScaleFactorSet(1) = java.lang.String('l.Lagrange*l.Lagrange*l.Lagrange');
                           obj.nScales = 8;
                           obj.nScaleFactorsDefs = 1;
                       case 5, % Linear triangular surface mesh
                           obj.ScaleFactorSet(1) = java.lang.String('l.simplex(2)*l.simplex');
                           obj.nScales = 3;
                           obj.nScaleFactorsDefs = 1;
                       otherwise
                           fprintf('WARNING! No basis functions identified while updating the mesh %s\n',obj.name);
                   end
               end
               if isempty(obj.liNofElem)
                   switch(obj.InterpolationBasis)
                       case 1,
                           obj.liNofElem(1:obj.nElems,1:8) = repmat(1:8,obj.nElems,1);
                       case 2,
                           switch obj.FormatOrder
                               case 'EXformat'
                                   Order64 = 1:64;
                               case 'CHeart'
                                   Order64 = [1 4 13 16 49 52 61 64 2 3 5:12 14 15 17:48 50 51 53:60 62 63];
                               otherwise
                                   Order64 = 1:64;
                           end
                           obj.liNofElem(1:obj.nElems,1:64) = repmat(Order64,obj.nElems,1);
                       case 3
                           obj.liNofElem(1:obj.nElems,1:27) = repmat(1:27,obj.nElems,1);
                       case 4
                           obj.liNofElem(1:obj.nElems,1:8) = repmat(1:8,obj.nElems,1);
                       otherwise
                           fprintf('WARNING! No basis functions identified while updating the mesh %s\n',obj.name);
                   end
               end
               if isempty(obj.nNofElem)
                   [nNodesPerElement] = obj.GetBasisCharacteristics(obj.InterpolationBasis);
                   obj.nNofElem(1:obj.nElems) = nNodesPerElement;
               end               
               if isempty(obj.versions)
                   obj.versions(1:obj.nNodes,1:3) = 1;
               end
               if isempty(obj.valueIndices)
                   switch obj.InterpolationBasis
                       case 5
                           % A much quicker in usually large meshes:
                           obj.valueIndices = ones(obj.nElems,3,3,1);
                       otherwise
                           for iE = 1:obj.nElems
                               obj.valueIndices(iE,:,:,:) = obj.DefaultLocalValueIndicesPerElement();
                           end
                   end
               end
           end
           obj = obj.BuildMapping();
           switch obj.InterpolationBasis
               case 1 % Only in cubic Hermite:
                   obj = obj.FindSecondVersionBasis();
                   obj = obj.BuildWireframe();
               otherwise
                   obj.nNewVersionsBasis = [0 0 0];
                   obj.nNewVersionsC1Basis = [0 0 0];
           end
           %obj = obj.CalculateQuality();
           %obj = obj.BuildTetrahedralCanvas();           
           
           obj = obj.BuildBoundingBox();
           if isempty(obj.GroupName),     obj.GroupName = obj.name;  end
           if isempty(obj.nFields), obj.nFields = 0; end
           if isempty(obj.bFibres), obj.bFibres = 0; end
           if isempty(obj.bExportLinearFibres), obj.bExportLinearFibres = 0; end
           
           % Quality check of class:
           [nNods,foo] = size(obj.versions);
           if nNods~= obj.nNodes
               fprintf('WARNING! %s does not have the versions of size nNodes (=%i), whereas it has %i definitions!\n',obj.name,obj.nNodes,nNods);
               % Sometimes the mesh has additional nodes, like in the
               % definition of the blood pool:
               if nNods<obj.nNodes
                   temp = obj.versions;
                   clear obj.versions;
                   obj.versions = ones(obj.nNodes,foo);
                   obj.versions(1:nNods,:) = temp;
               end
           end
       end      
       function obj         = BuildMapping(obj)
           bDebug=0;
           obj.mapping.NodesOfElem = int16(obj.giNofElem);
           % The size of this matrix is so big to take into accound the
           % indexing of collapsed elements (in the apex, with 12 elements
           % in circumferential direction, a node can belong up to 24
           % elems, plus 8 to avoid the indexing crash with regular elems
           obj.mapping.ElemsOfNode = int16(zeros(obj.nNodes,obj.MaxNeighbours));
           for iElem=1:obj.nElems
%                if iElem==2
%                    bDebug=0;
%                else
%                    bDebug=0;
%                end
               nNodesOfElement = obj.nNofElem(iElem);
               if nNodesOfElement>0 % check if element exists
                   for j=1:nNodesOfElement
                       iNode = obj.mapping.NodesOfElem(iElem,j);
                       if iNode == 0
                           fprintf('ERROR! Element %i is not defined yet!\n',iElem);
                           fprintf('       Its local node %i was not defined.\n',j);
                       else
                           LocalIndexPosition = j;
                           if nNodesOfElement==6 || nNodesOfElement==4
                               % Also, the LocalIndexPosition should be
                               % accordingly to the "repetition pattern":
                               LocalNodeRepetitionPattern = obj.liNofElem(iElem,1:8);
                               LocalIndexPosition = find(LocalNodeRepetitionPattern==j);
                               if(numel(LocalIndexPosition)>1)
                                   % This happens if this is a collapsed node:
                                   LocalIndexPosition = LocalIndexPosition(1);
                               end
                               % In case of a collapsed element, the rule of "one
                               % node can only be a local node i in one only
                               % element" does not apply:
                               % In order to avoid crashes with regular
                               % elements, indexed by their local indexes from
                               % 1 to 8, the "reindexing" is done from 9 on
                               % only if that position has already been taken:
                               if (obj.mapping.ElemsOfNode(iNode,LocalIndexPosition)~=0)
                                   LocalIndexPosition=9;
                                   while (obj.mapping.ElemsOfNode(iNode,LocalIndexPosition)~=0)
                                       LocalIndexPosition=LocalIndexPosition+1;
                                       if LocalIndexPosition>size(obj.mapping.ElemsOfNode,2)
                                           fprintf('ERROR! obj.mapping.ElemsOfNode did not have enough possibilities (need of larger memory allocation)\n');
                                           fprintf(' MaxNeighbours = %i\n',obj.MaxNeighbours);
                                       end
                                   end
                               end
                           end
                           if obj.mapping.ElemsOfNode(iNode,LocalIndexPosition)==0
                                obj.mapping.ElemsOfNode(iNode,LocalIndexPosition)=int16(iElem);
                           else
                               bErrorMapping = 1;
                               switch obj.InterpolationBasis
                                   case 1,  % In case of a Cubic Hermite
                                   otherwise
                                       bErrorMapping = 0;
% % in a cubic Lagrange, a collapsed node has a very high number of "roles" 
% % (16 roles per collapsed face, one face per adjacent element). It does not 
% % make sense to track all of them. So we check if this is a collapsed node
% There is also the possibility that we have the squared apex/patch
% topology of the left ventricle: here, the rule of unique mapping does not
% hold any more, and some nodes do have the same role in different
% elements. 
%                                        [Elements,I,J] = unique(obj.mapping.ElemsOfNode(iNode,:));
%                                        if numel(Elements) > 2
%                                            % 0 is always present in this obj.mapping.ElemsOfNode. If any other is repeated:
%                                            if ~numel(find(J==2)) == 1
%                                                bErrorMapping = 0;
%                                            end
%                                        else
%                                            bErrorMapping = 0;
%                                        end
                               end

                               if(bErrorMapping)
                                   fprintf('ERROR! in CubicMeshClass.BuildMapping: trying to overwrite a preliminary definition!\n');
                                   fprintf('       Node %i playing the role of local node %i\n',iNode,LocalIndexPosition);
                                   fprintf('       Element %i already there, new attempt from element %i\n',obj.mapping.ElemsOfNode(iNode,LocalIndexPosition),iElem);
                               end
                           end
                           if (bDebug), 
                               if iNode==1, 
                                   fprintf('Node %i belongs to element %i (local node %i)\n',iNode,iElem,LocalIndexPosition); 
                               end; 
                           end
                       end
                   end
               end
           end
           if obj.nNodes>1
               % Memory release in case there were too many possible
               % neighbours:
               MaxNeig=0;
               for iNode=1:obj.nNodes
                   Neig = find(obj.mapping.ElemsOfNode(iNode,:)>0, 1, 'last' );
                   if Neig>MaxNeig
                       MaxNeig = Neig;
                   end
               end
               ElemsOfNodeTemp = obj.mapping.ElemsOfNode;
               clear obj.mapping.ElemsOfNode;
               obj.mapping.ElemsOfNode = ElemsOfNodeTemp(:,1:MaxNeig);
               if (bDebug), fprintf(' MaxNeighbours = %i (and it was %i)\n',MaxNeig,obj.MaxNeighbours); end
               obj.MaxNeighbours = MaxNeig;
           end
           if obj.nNodes>0
               if (bDebug), fprintf('Node 1 belongs to elements: %i, %i, %i, %i, %i, %i, %i, %i\n',obj.mapping.ElemsOfNode(1,1:8)); end
           end
       end
       function [ib]        = CLmapping(obj,k,b)
           % function to return the  mapping of the 64 basis functions
           % inside in each cubic lagrange element, depending on the
           % convention used:
           switch obj.FormatOrderCL
               case 'Sequential'
                   MapFunction = obj.mapping.IndexOf64CLBasis;
               case 'C.Heart'
                   c=obj.LagrangeCorners();  no64 = [c setdiff(1:64,c)];
                   MapFunction = obj.mapping.IndexOf64CLBasis(:,no64);
           end                  
           ib = MapFunction(k,b);
       end
       function [ind,nn]    = GetNodeIndexesOfElement(obj,iElem)
           % Update 08/10/12 to read any number of nodes per element,
           % maximum 8
           % Update 28/03/2013: enable th epossibility of all collapsed
           % elements, with only 6 global nodes in each definition:          
           MaxNumberNodes = max(obj.nNofElem);
           ind = obj.giNofElem(iElem,1:MaxNumberNodes); 
           nn = numel(find(ind>0));
           ind = ind(1:nn);
           
%           ind = obj.giNofElem(iElem,1:6); % 6 or 8 indexes of the element
%           nn = 6; % Number of nodes in the element
%           if obj.giNofElem(iElem,7)>0
%               ind = [ind obj.giNofElem(iElem,7:8)];
%               nn = 8; % Number of nodes in the element
%           end
          if max(ind)>obj.nNodes
              fprintf(1,' WARNING!! Indexes in the elem field pointing to a non existing Node! The node %i is not inside the range [1,%i]\n',max(ind),obj.nNodes);
          end
          if min(ind)<1
              iLocalNode = find(ind==min(ind));
              fprintf(1,' ERROR!! Negative or null indexes in the elem field! In element %i, local node %i \n',iElem,iLocalNode(1));
          end
       end
       function ListOf8Ns   = GetListOf8GlobalNodes(obj,iElem)
           nN = obj.nNofElem(iElem);
           if nN ==8
               % TODO: check if it requires giNofElem and not GIN!!
               ListOf8Ns = obj.giNofElem(iElem,1:8);
           else
               LocalNodeRepetitionPattern = obj.liNofElem(iElem,1:8);
               ListOf6Nodes = obj.giNofElem(iElem,1:6);
               ListOf8Ns = ListOf6Nodes(LocalNodeRepetitionPattern);
           end
       end
       function obj         = FindExternalSurfaces(obj)
           % Function which defines the external surfaces in a mesh. This
           % information is stored: 
           % - Per element: which of the 6 surfaces of a cube is external
           bDebug = 0;
           bIntenseDebug = 0;
           ExtFaces   = zeros(obj.nElems,6);
           Neighbours = zeros(obj.nElems,6);
           for iElem=1:obj.nElems
%                if iElem==3
%                    bDebug=1;
%                else
%                    bDebug=0;
%                end

               for iFace=1:6
                   if (bDebug), fprintf('\n Analysing element %i, face %i.\n',iElem,iFace); end
                   bExternalSurface = 1;
                   if(obj.InterpolationBasis == 1) 
                       %c.Hermite
% Find out if this face is external (only one element defines it) or internal (shared among two or more
% elements)
                        ListOf4LocalNodes  = obj.mapping.Surfaces.Nodes(:,iFace);
% Local Nodes taking into accound collapsed elements:
                        FourLocalNodes = obj.liNofElem(iElem,ListOf4LocalNodes);
                        nLocNods = numel(unique(FourLocalNodes));
% Check whether this is a collapsed face, in which case there's nothing else to do
% Update(13/04/13): search external surface anyway, in this case it will be
% another element sharing the collapsed face:

                        if nLocNods==2
                            if (bDebug), fprintf('Collapsed face in element %i, face %i.\n',iElem,iFace); end
                            bExternalSurface = 1;
                        end
                           FourGlobalNodes = obj.giNofElem(iElem,FourLocalNodes);
                   else
                         %c.Lagrange
                         %Get 16 global indices directly, then the process is
                         %similar to 4 nodes as in the case of c.Hermite
                         FourGlobalNodes    = obj.GetFaceNodes(iElem,iFace); 
                         nLocNods = numel(unique(FourGlobalNodes));
                         if nLocNods==4
                            if (bDebug), fprintf('Collapsed face in element %i, face %i.\n',iElem,iFace); end
                            bExternalSurface = 1;
                         end                                                  
                   end
% Check if there's another element using all these nodes in its definition. 
% 1. Take one of these nLocNods, NodeA:
                       NodeA = FourGlobalNodes(1);
% 2. Find all elements with this NodeA:
                       ElemsWithNodeA = sort(obj.mapping.ElemsOfNode(NodeA,:),'descend');
%   ... remove iElem from this list: 
                       position= ElemsWithNodeA==iElem;
                       ElemsWithNodeA(position)=0;
                       ElemsWithNodeA=sort(ElemsWithNodeA,'descend');
                       iE=0;
                       numElems = numel(find(ElemsWithNodeA));
                       if (bDebug), fprintf('Element %i has node %i, which belongs to other %i elements\n',iElem,NodeA,numElems); end
                       while (bExternalSurface)&&(iE<numElems)
                           iE=iE+1;
                           iElem2 = ElemsWithNodeA(iE);
% 3. Find the 8 nodes of Elem2:
                           ListOf8GlobalNodes = obj.giNofElem(iElem2,:);
                           if (bIntenseDebug), fprintf('  ... Neighbour element %i has these global nodes: %i, %i, %i, %i, %i, %i, %i, %i\n',iElem2,ListOf8GlobalNodes); end
% 4. Check if the ListOf4LocalNodes has all FourGlobalNodes
                           Nodes2find = unique(FourGlobalNodes);
                           if (bIntenseDebug), fprintf('  ... And the four global nodes to find are: %i, %i, %i, %i\n',Nodes2find); end
                           iN=0;
                           bAllFound=1;
                           while (bAllFound)&&iN<numel(Nodes2find) 
                               iN=iN+1;
                               TargetNode = Nodes2find(iN);
                               if (bIntenseDebug), fprintf('    . Checking neighbour element %i. Is %i in the list?',iElem2,TargetNode); end
                               if numel(find(ListOf8GlobalNodes==TargetNode)==0)
                                   if (bIntenseDebug), fprintf(' YES!\n'); end
                               else
                                   bAllFound=0;
                                   if (bIntenseDebug), fprintf(' NO!\n'); end
                               end
                           end
                           if bAllFound
                               if (bDebug), fprintf(' INTERNAL FACE: There is an element next to %i which shares the nodes of face %i.\n',iElem,iFace); end
                               bExternalSurface=0;
                               Neighbours(iElem,iFace) = iElem2;
                           end
                       end
                       
                   if bExternalSurface
                       if (bDebug), fprintf(' ** EXTERNAL FACE **: element %i, face %i.\n',iElem,iFace); end
                       ExtFaces(iElem,iFace)=1;
                   end
                   
               end
               if(bDebug)
                   pause();
               end
           end
           obj.nExternalFaces = sum(ExtFaces(:));
           obj.ExternalFaces = ExtFaces;
           obj.bExternalFacesFound = true;
           obj.Neighbours = Neighbours;
       end
       function [iElems,iFaceEpi]    = FindEpiElements(obj)
           % Find elements that have an external surface with xi3=1
           %        5: xhi1=0
           %        6: xhi1=1
           %        3: xhi2=0
           %        4: xhi2=1
           %        1: xhi3=0
           %        2: xhi3=1
           iFaceEpi = 2;
           if (~obj.bExternalFacesFound)
               obj = obj.FindExternalSurfaces();
               fprintf(' WARNING! Consider the pre-computation of external surfaces to speed up the search of Epi elements\n');
           end
           iElems = find(obj.ExternalFaces(:,iFaceEpi)==1);
       end
       function [iElems,iFaceEndo]    = FindEndoElements(obj)
           % Find elements that have an external surface with xi3=1
           if (~obj.bExternalFacesFound)
               obj = obj.FindExternalSurfaces();
               fprintf(' WARNING! Consider the pre-computation of external surfaces to speed up the search of Epi elements\n');
           end
           iFaceEndo = 1;
           iElems = find(obj.ExternalFaces(:,iFaceEndo)==1);
       end
       function [iNodes]    = FindEpiNodes(obj)
           [iElems,iFaceEpi] = obj.FindEpiElements();
           % Now get the nodes of all faces:
           [iNodes] = obj.GetFaceNodes(iElems,iFaceEpi);
       end
       function [iNodes]    = FindEndoNodes(obj)
           [iElems,iFace] = obj.FindEndoElements();
           % Now get the nodes of all faces:
           [iNodes] = obj.GetFaceNodes(iElems,iFace);
       end           
       function [iNodes]    = GetFaceNodes(obj,iElems,iFace)
           % Function to extract the nodes corresponding to a face.
           iNodes = [];
           switch obj.InterpolationBasis
               case 1 
                   % Get the local nodes of the iFaceEpi:
                   iLocNods = obj.mapping.Surfaces.Nodes(:,iFace);
               case 2
                   iLocNods = obj.CubicLagrangeMapping.nodesOfSurface(iFace,1:16);
           end
           for i = 1:numel(iElems)
               iElem = iElems(i);
               % Map the possible collapsed definition
               iL = unique(obj.liNofElem(iElem,iLocNods));
               iNodes = [iNodes obj.giNofElem(iElem,iL)];
           end
           iNodes = unique(iNodes);
       end
       function [iElems]    = FindElemsWithExternalSurfaces(obj,nSurf)
           % Function to identify the elements that have external surfaces,
           % in a number of at least nSurf
           if nargin<2
               nSurf = 2;
           end
           iElems = [];
           for iElem = 1:obj.nElems
               nS = sum(obj.ExternalFaces(iElem,:));
               if nS >= nSurf
                   iElems = [iElems iElem];
               end
           end 
       end
       function obj         = SetFibres(obj,options)
           % Defualt: fibres in elevation and imbrication definition
           FibreDescriptionType = 2;
           FibreElevation= 0;
           FibreImbrication =0;
           OptionValues = 'NullValues';
           if nargin==2
               if isfield(options,'FibreDescriptionType')
                   FibreDescriptionType = options.FibreDescriptionType;
               end
               if isfield(options,'FibreElevation')
                   FibreElevation = options.FibreElevation;
                   OptionValues = 'ConstantValues';
               end
               if isfield(options,'FibreImbrication')
                   FibreImbrication = options.FibreImbrication;
                   OptionValues = 'ConstantValues';
               end
           end
           obj.bFibres =1;
           obj.FibreDescriptionType = FibreDescriptionType;
           switch FibreDescriptionType
               case 1
                   FibDim = 3;
               case 2
                   FibDim = 2;
           end
           obj.FibDim = FibDim;
           switch OptionValues
               case 'NullValues'
                   values = zeros(obj.nNodes,obj.FibDim,1);
                   derivs = zeros(obj.nNodes,obj.FibDim,1);
               case 'ConstantValues'
                   values(:,1,1) = FibreElevation*ones(obj.nNodes,1,1);
                   values(:,2,1) = FibreImbrication*ones(obj.nNodes,1,1);
                   derivs = zeros(obj.nNodes,obj.FibDim,1);
           end
           obj.fibres.value = values;
           obj.fibres.dfds1 = derivs;
           obj.fibres.dfds2 = derivs;
           obj.fibres.dfds3 = derivs;
           obj.fibres.dfds12 = derivs;
           obj.fibres.dfds13 = derivs;
           obj.fibres.dfds23 = derivs;
           obj.fibres.dfds123 = derivs;
       end
       function obj         = SetName(obj,name)
           obj.name = name;
           obj.GroupName = name;
       end
       function ListNs      = GetIndexesInternalNodes(obj)
           % function that outputs the list of internal nodes, those which
           % belong to 8 elements
           ListNs = [];
           for iNode = 1:obj.nNodes
               if numel(find(obj.mapping.ElemsOfNode(iNode,:)))==8
                   ListNs = [ListNs iNode];
               end
           end
           
       end
       function bCollap     = isCollapsedElem(obj,iElem)
            if numel(unique(obj.liNofElem(iElem,:)))<8
                bCollap = 1;
            else
                bCollap = 0;
            end
       end
       function iFace       = identifyCollapsedFace(obj,iElem)
           iFace = NaN;
           I = [];
           if obj.isCollapsedElem(iElem)
               LocalElemPattern = obj.liNofElem(iElem,:);
               for iCD = 1:size(obj.mapping.collapseDefinition,1)
                   Def = obj.mapping.collapseDefinition(iCD,:);
                   if Def == LocalElemPattern
                       I = iCD;
                   end
               end
               if numel(I)>0
                   iFace = obj.mapping.collapsedFace(I);
               else
                   fprintf('ERROR! Collapsed pattern not recognised!\n')
               end
           end
       end
       
% I/O functions
       function []          = ExportCubicLagrangeMesh(obj,OutputDir,OutputName)
           % Function to generate a cubic Lagrange mesh from the cubic
           % Hermite one. It samples each element in regular xi locations
           % (0, 1/3, 2/3 and 1), merges the repeated nodes, and saves them
           % in EX format.
           
           bDebug = 0;
           bRemoveDuplicateNodes = 0;
           bFailedAttemptRemoveDuplicatedCollapsedNodes = 0;
           
           if nargin <2
               OutputDir = obj.DataDir;
           end
           if nargin<3
               OutputName = [obj.name 'CL'];
           end
           
           
           xiRange = [0 1/3 2/3 1];
           [xiCoords]  = obj.BuildXiSamples(xiRange,xiRange,xiRange);
           nNodesPerElem = 64;
           nElems = obj.nElems;
           nodesOfElem = zeros(nElems,nNodesPerElem);
           Coords      = zeros(64*nElems,3);
           if obj.bFibres
               Fibres  = zeros(64*nElems,3);
           end
           
           % Create the class (based on the CubicHermite):
           CLmesh = CubicMeshClass();
           CLmesh.InterpolationBasis= 2;
           CLmesh               = CLmesh.SetName(OutputName);
           CLmesh.nElems        = nElems;
           CLmesh.nNodes        = size(Coords,1);
           
           if (~obj.bExternalFacesFound)
                obj = obj.FindExternalSurfaces();
           end
           % Build a data mapping structure to track the conversion and
           % node indexing:
           for iElem = 1:obj.nElems
               % Duplicated nodes can only occur in the faces. This set
               % of flags is used to track which surface have already been
               % visited in the conversion of nodes (each element has 6
               % possible surfaces)
               ConvMap(iElem).ConvertedSurfaces = zeros(1:6);
               % Once visited, each face will be defined by a set of node
               % indexes (16 per face):
               ConvMap(iElem).Facenodes = zeros(6,16); 
           end
           nodeOffset = 0;
           nNodsLastElem = 0;
           for iElem = 1:obj.nElems  
               if iElem == 129
                    a = 1;
                end
                nodeOffset = nodeOffset + nNodsLastElem;
                % Get the coordinates of the nodes, as if there were no
                % repeated ones (in collapsed elements)
                Points(1:nNodesPerElem,1:3) = obj.fastCoordinateEvaluation(iElem,xiCoords)';                
                                
                % The list of 64 nodes per element:
                iVP = 1:nNodesPerElem;
                % A priori definition o the global indexes of the nodes:
                elemNodes = zeros(1,64);
                % Check if all surfaces of this element have not been visited before:
                if sum(ConvMap(iElem).ConvertedSurfaces(1:6)) > 0
                    % Remove valid points from the list depending on which
                    % is the face that is already visited.
                    for iFace = 1:6
                        if ConvMap(iElem).ConvertedSurfaces(iFace)
                            % The indexes of the 64 nodes to be removed
                            % from the list:
                            Nodes2Remove = obj.CubicLagrangeMapping.nodesOfSurface(iFace,1:16);
                            for in=1:numel(Nodes2Remove)
                                iVP = iVP(iVP~=Nodes2Remove(in));
                            end
                            % In the definition of the element, these
                            % Nodes2Remove need to take the global index of
                            % previously saved surfaces:
                            GlobalNodes = ConvMap(iElem).Facenodes(iFace,1:16);
                            if numel(find(GlobalNodes==0))>0
                                fprintf('ERROR! null values for previously saved nodes...\n');
                                fprintf('       iElem = %i;, iFace = %i\n',iElem,iFace);
                            else
                                if(bDebug), fprintf('In element %i face %i 16 nodes were taken from before:\n',iElem,iFace);
                                            fprintf('%i, ',GlobalNodes);
                                end
                                elemNodes(Nodes2Remove) = GlobalNodes;
                            end
                        end
                    end
                end

                
                % Now the rest of the node indexes should be filled,
                elemNodes(iVP) = nodeOffset + [1:numel(iVP)];
                
                % if there is a collapsed element:
                if obj.isCollapsedElem(iElem)
                    % Identify the collapsed face:
                    iFace = obj.identifyCollapsedFace(iElem);
                    % Identify the collapsed nodes:
                    CollapsedNodes = obj.CubicLagrangeMapping.nodesOfSurface(iFace,1:16);
                    % These 16 nodes should reduce to 4.
                    % The 16 3D points are:
                    Coll3Dpoints = Points(CollapsedNodes,:);
                    % If we compute the approximate distance to the centre
                    % of the 16 points, signed distance, that will help us
                    % to group them in 4x4:
                    Centre = mean(Coll3Dpoints,1);
                    AproxDistan = sum((Coll3Dpoints - repmat(Centre,16,1)),2);
                    % We define a threshold of neighbourhood:
                    Epsilon = mean(abs(AproxDistan)) / 100;
                    Grouping = zeros(1,16);
                    Grouping(1) = 1;
                    CopyNode(1) = 1;
                    RefDistan(1) = AproxDistan(1);
                    RootNode(1) = 1;
                    for icp = 2:16
                        for iG = 1:numel(RefDistan)
                            if abs(AproxDistan(icp)-RefDistan(iG)) < Epsilon;
                                Grouping(icp) = iG;
                                CopyNode(icp) = RootNode(iG);
                            end
                        end
                        if Grouping(icp)==0
                            Grouping(icp) = iG+1;
                            RefDistan(Grouping(icp)) = AproxDistan(icp);
                            RootNode(Grouping(icp)) = icp;
                            CopyNode(icp) = RootNode(Grouping(icp));
                        end
                    end      
                    % The definition of the element has repeated nodes:
                    NodesThatCouldBeRepeated = elemNodes(CollapsedNodes);
                    elemNodes(CollapsedNodes) = NodesThatCouldBeRepeated(CopyNode);
                end                
                
                % Now tick the neighbour surfaces, saving the global
                % indexes of nodes that are shared:
                for iFace = 1:6
                    if ~obj.ExternalFaces(iElem,iFace)
                        % This is an internal surface, so need to find the
                        % neighbour element 
                        % in case of a collapsed face, this is going to
                        % introduce an issue when the "circunferential
                        % loop" is closed. The safe solution is not to
                        % "propagate" collapsed surfaces:
                        bContinue = 1;
                        if obj.isCollapsedElem(iElem)
                            % Identify the collapsed face:
                            iColFace = obj.identifyCollapsedFace(iElem);
                            if iColFace == iFace
                                bContinue = 0;
                            end
                        end
                        if(bContinue)
                            iElem2 = obj.Neighbours(iElem,iFace);
                            % If surfaces are adyacent, the local index of face
                            % does change in the neighbour element (it is a
                            % xhi1=0 in one element, and a xhi1=1 in the
                            % opposite)
                            switch iFace
                                case 1, iFace2 = 2;
                                case 2, iFace2 = 1;
                                case 3, iFace2 = 4;
                                case 4, iFace2 = 3;
                                case 5, iFace2 = 6;
                                case 6, iFace2 = 5;
                            end
                            ConvMap(iElem2).ConvertedSurfaces(iFace2) = 1;
                            % And save the global indexes of the 16 nodes
                            % shared by the surfaces:
                            NodesFace1 = obj.CubicLagrangeMapping.nodesOfSurface(iFace,1:16);
                            ConvMap(iElem2).Facenodes(iFace2,1:16) = elemNodes(NodesFace1);
                        end
                    end
                end
                
                
                % Save the 3D coordinates of the nodes that are valid (not
                % repeated):
                nNodsLastElem = numel(iVP);
                Coords(nodeOffset+1:nodeOffset+nNodsLastElem,1:3) = Points(iVP,:);
                % Define the connectivity:
                nodesOfElem(iElem,:) = elemNodes; %nodeOffset+1:nodeOffset+nNodesPerElem;
                if obj.bFibres
                    opt.whichField = 1;
                    Fibres(nodeOffset+1:nodeOffset+nNodesPerElem,1:3) = obj.fastCoordinateEvaluation(iElem,xiCoords,opt)';
                end
           end                     
           
            % Core data:
           CLmesh.coordinates   = Coords;
           CLmesh.giNofElem     = nodesOfElem;
           if obj.bFibres
               CLmesh.fibres.value = Fibres;
               CLmesh.bFibres = obj.bFibres;
               CLmesh.FibDim  = obj.FibDim;
               CLmesh.FibreDescriptionType  = obj.FibreDescriptionType;
           end
            % Other key pieces of default data in EX files:
           CLmesh.liNofElem     = repmat(1:64,nElems,1);
           CLmesh.nNofElem      = 64 * ones(1,nElems);
           CLmesh.valueIndices  = ones(nElems,3,64,1);
           CLmesh.versions      = ones(CLmesh.nNodes,3);
           CLmesh = CLmesh.Update();
           
%            if(bRemoveDuplicateNodes)
%                epsilon = abs(sum(obj.coordinates(1,1:3) - obj.coordinates(2,1:3))) * (10^-6);
%                % Remove duplicated nodes: create the list of nodes belonging to
%                % inner surfaces:
%                bDebug = 0;
% 
%                %... inner surfaces are not external surfaces:
%                if (~obj.bExternalFacesFound)
%                     obj = obj.FindExternalSurfaces();
%                end
%                ElemsOfNode = zeros(CLmesh.nNodes,64);
%                for iElem = 1:obj.nElems
%                    % Check internal surfaces:
%                    ExtFacs = obj.ExternalFaces(iElem,:);
%                     IintSur = find(ExtFacs==0);
%                     nInterSurfaces = numel(IintSur);
%                     Neighs = obj.Neighbours(iElem,IintSur);
%                    for iIntSurface = 1:nInterSurfaces
%                        iElem2 = Neighs(iIntSurface);
%                        if iElem2 == 0
%                            fprintf('ERROR while removing duplicate nodes. Element %i has an internal surface %i, but no neighbour there!\n',iElem,iSurf);
%                        else
%                            iSurf1 = IintSur(iIntSurface);
%                            LocalNodesSurface1 = obj.CubicLagrangeMapping.nodesOfSurface(iSurf1,:);
%                            nodesElem1 = CLmesh.giNofElem(iElem,LocalNodesSurface1);
%                            if unique(obj.liNofElem(iElem))<8
%                                % A collapsed element (neighbours are not
%                                % easy to manage):
%                                nodesElem2 = CLmesh.giNofElem(iElem2,:);
%                            else
%                                % Not collapsed element:
%                                % Complentary surface:
%                                switch iSurf1
%                                    case 1, iSurf2 = 2;
%                                    case 2, iSurf2 = 1;
%                                    case 3, iSurf2 = 4;
%                                    case 4, iSurf2 = 3;
%                                    case 5, iSurf2 = 6;
%                                    case 6, iSurf2 = 5;
%                                end
%                                LocalNodesSurface2 = obj.CubicLagrangeMapping.nodesOfSurface(iSurf2,:);
%                                nodesElem2 = CLmesh.giNofElem(iElem2,LocalNodesSurface2);
%                            end
%                            if(bDebug)
%                                figure('color',[1 1 1])
%                                obj.plotElement(iElem,0);
%                                hold on
%                                obj.plotElement(iElem2,1);
%                                plot3(CLmesh.coordinates(nodesElem1,1),CLmesh.coordinates(nodesElem1,2),CLmesh.coordinates(nodesElem1,3),'k+')
%                                plot3(CLmesh.coordinates(nodesElem2,1),CLmesh.coordinates(nodesElem2,2),CLmesh.coordinates(nodesElem2,3),'go')
%                            end
%                            for in1=1:numel(nodesElem1)
%                                iNod1 = nodesElem1(in1);
%                                Coor1 = CLmesh.coordinates(iNod1,1:3);
% %                                 II = find(ElemsOfNode(iNod1,:)==iElem2);
% %                                 if numel(II)>0
% %                                     % It has been already processed in
% %                                     % previous removals of other elems
% %                                     bFound = 1;
% %                                     CLmesh.giNofElem(iElem2,II) = iNod1;
% %                                 else
%                                      bFound = 0;
% %                                 end
%                                for in2=1:numel(nodesElem2)
% %                                    if(~bFound)
%                                        iNod2 = nodesElem2(in2);
%                                        Coor2 = CLmesh.coordinates(iNod2,1:3);
%                                        if abs(sum(Coor1 - Coor2)) <= epsilon
%                                            % Check if this node is not already
%                                            % taken:
% %                                            if(ElemsOfNode(iNod1,in2)~=0)&&(CLmesh.mapping.ElemsOfNode(iNod1,in2)~=0)
%                                                 %fprintf('Local node position already taken! keep looking in the list of 64...\n');
% %                                            else
%                                                 CLmesh.giNofElem(iElem2,in2) = iNod1;
%                                                 ElemsOfNode(iNod1,in2) = iElem2;
%                                                 bFound = 1;
% %                                            end
%                                        end
% %                                    end
%                                end
%                                if(~bFound)
%                                    fprintf('WARNING! Duplicated node not found as expected (elem %i, node %i)\n',iElem,iNod1);
%                                end
%                             end 
%                        end
%                    end
%                end
%            end
           
%            if(bFailedAttemptRemoveDuplicatedCollapsedNodes)
%                % Last thing, remove duplicated nodes in the collapsed edges
%                % (not well managed beforehand)
%                CollapsedNodes = [];
%                GlobalIndexes  = [];
%                LocalIndex     = [];
%                for iElem = 1:obj.nElems
%                    if unique(obj.liNofElem(iElem,:))<8
%                        % This is a collapsed element, check the "collapsed
%                        % pattern"
%                        for iCD = 1:size(obj.mapping.collapseDefinition,1)
%                            Def = obj.mapping.collapseDefinition(iCD,:);
%                            if Def == obj.liNofElem(iElem,:)
%                                I = iCD;
%                            end
%                        end
%                        if numel(I)>0
%                            iFace = obj.mapping.collapsedFace(I);
%                        else
%                            fprintf('ERROR! Collapsed pattern not recognised!\n')
%                        end
%                        LocalNodesSurface = obj.CubicLagrangeMapping.nodesOfSurface(iFace,:);
%                        GIN = CLmesh.giNofElem(iElem,LocalNodesSurface);
%                        nNods = numel(GIN);
%                        for iN = 1:nNods
%                            Coor1 = CLmesh.coordinates(GIN(iN),1:3);
%                            bFound = 0;
%                            nNewSoFar = numel(GlobalIndexes);
%                            for iN2 = 1:nNewSoFar
%                                if(~bFound)
%                                    if(LocalIndexes(iN2))==iN
%                                        % Only if it makes the same local node
%                                        % function!
%                                        Coor2 = CollapsedNodes(iN2,1:3);
%                                        if abs(sum(Coor1 - Coor2)) <= epsilon
%                                             bFound = 1;
%                                             CLmesh.giNofElem(iElem,iN) = GlobalIndexes(iN2);
%                                        end
%                                    end
%                                end
%                            end
%                            if(~bFound)
%                                GlobalIndexes(nNewSoFar+1) = GIN(iN);
%                                LocalIndexes(nNewSoFar+1) = iN;
%                                CollapsedNodes(nNewSoFar+1,1:3) = Coor1;
%                            end
%                        end
%                    end
%                end
%            end
           CLmesh = CLmesh.ReorderNodes();
           CLmesh = CLmesh.Update();
                   
                   
           
           % Export in EX format:
           CLmesh.WriteExFiles(OutputDir);       
       end
       function []          = ExportLinearCubicMesh(obj,OutputDir,OutputName)
            % Funciton to generate a set of linear cubic elements out of the cubic
            % Hermite mesh, and save them in EX format. Each original cubic Hermite
            % element is subdivided in a set of cubes.
            
            bViewOutputMeshCmgui = 1;
            if nargin<3
                OutputName = [obj.name 'LinearHex'];
            end
            %SubdivisionResolution:
            sRes = [4 4 4];
            nLinElems = prod(sRes);
            nNodesXi1 = sRes(1) + 1;
            nNodesXi2 = sRes(2) + 1;
            nNodesXi3 = sRes(3) + 1;
            nLinNodes = nNodesXi1*nNodesXi2*nNodesXi3;
            LinCoords = zeros(3,obj.nElems*nLinNodes);
            nodesOfLinElem = zeros(obj.nElems*nLinElems,8);
            for iXi = 1:3
                xiRange(iXi).range = 0:1/sRes(iXi):1;
            end
            [xiCoords]  = obj.BuildXiSamples(xiRange(1).range,xiRange(2).range,xiRange(3).range);
            for iElem = 1:obj.nElems             
                nodeOffset = (iElem-1) * nLinNodes;
                elemOffset = (iElem-1) * nLinElems;   
                % Get the coordinates of the nodes:
                LinCoords(1:3,nodeOffset+1:nodeOffset+nLinNodes) = obj.fastCoordinateEvaluation(iElem,xiCoords);
                
                % Define the connectivity:
                for iLinHexElem = 1:nLinElems
                    iFirstNode = nodeOffset + iLinHexElem + floor((iLinHexElem-1)/sRes(1)) + (sRes(1)+1) * floor((iLinHexElem-1)/(sRes(1)*sRes(2)));
                    nodesOfLinElem(elemOffset+iLinHexElem,:) = [iFirstNode
                                                iFirstNode + 1
                                                iFirstNode + nNodesXi1
                                                iFirstNode + nNodesXi1 + 1
                                                iFirstNode + nNodesXi1*nNodesXi2
                                                iFirstNode + nNodesXi1*nNodesXi2 + 1
                                                iFirstNode + nNodesXi1*nNodesXi2 + nNodesXi1
                                                iFirstNode + nNodesXi1*nNodesXi2 + nNodesXi1 + 1];
                end         
            end
            WriteTrilinearCubicMeshExFormat(OutputDir,OutputName,LinCoords,nodesOfLinElem);
            if(bViewOutputMeshCmgui)
                parameters.RegionName = OutputName;
                cmGuiViewMesh(OutputDir,OutputName,parameters);
            end
       end

       function []          = WriteVTKLinearMesh(obj,filename)
           % Write the vertexes and the topology of the linear triangular mesh
           V = obj.GetPoints(); % these are the coordinates of the nodes
           opt.t = obj.giNofElem;
           io_writeVTK(filename,V,opt);
       end
       
       function []          = WriteExFiles(obj,exNodeFileNameORdir,exElemFileName,GroupName,options)
           % Function to write the information of the mesh into the exElem
           % and exNode file format.
           %
           % INPUT:
           % - Names of the files
           % - Name to give to the group
           % - options.basis: choice between a complete 'c.Hermite' description 
           % or a trilinear simplification, 'l.Lagrange'.
           
           %fprintf('Writing exNode and exElem files:\n   %s \n   %s\n',exNodeFileName,exElemFileName);
           % Default basis:
           basis = 'c.Hermite';
           if nargin==2
               % In this case, the only parameter, besides the class, is
               % the directory:
               direct = exNodeFileNameORdir;
               FileName = obj.name;
               exNodeFileName = fullfile(direct,[ FileName '.exnode']);
               exElemFileName = fullfile(direct,[ FileName '.exelem']);
           else
               exNodeFileName = exNodeFileNameORdir;
               direct = GetPath(exNodeFileName);
           end
           obj.DataDir = direct;
           if nargin<4
               if isempty(obj.GroupName)
                   obj.GroupName = obj.name;
               end
               GroupName=obj.GroupName;
           end
           if nargin<5
               basis = obj.GetBasisString(); 
               options.basis = basis; 
               options.VersionWritting = 'WriteVersionsForFitting';
           end
           WriteExNodeFile(obj,exNodeFileName,GroupName,options);
           WriteExElemFile(obj,exElemFileName,GroupName,options);
       end
       function []          = WriteExFibres(obj,exNodeFileName,GroupName,options)
           if ~obj.bFibres
               fprintf('ERROR! No fibre definition in the mesh %s!\n',obj.name);
           end
           if nargin<3
               GroupName=obj.GroupName;
           end
           options.bOnlyFibres = 1;
           obj.WriteExNodeFile(exNodeFileName,GroupName,options);
       end
       function []          = WriteExNodeFile(obj,exNodeFileName,GroupName,options)
           fprintf('Writing exNode file:   %s \n',exNodeFileName);
           % Default options:
           basis = obj.GetBasisString(); %'c.Hermite'; %'l.Lagrange' is the other option
           bOnlyFibres = 0;
           if nargin<3
               GroupName=obj.GroupName;
           end
           if nargin>=4
               if isfield(options,'basis')
                   basis = options.basis; end
               if isfield(options,'bOnlyFibres')
                   bOnlyFibres = options.bOnlyFibres; end
           end
       % -------------------------
       % 1) Write the exNode file:
       % -------------------------
           obj = obj.FillEmptyVersionsOfNodeValues();
           if obj.bExportLinearFibres
               if obj.InterpolationBasis == 2
                   if strcmp(obj.FormatOrderCL,'Sequential')
                       % need to change into having the eight first nodes
                       % encoding the fibre information of the corners of
                       % the element
                       nodesPermuted = [];
                       for iElem = 1:obj.nElems
                           oldElemDef = obj.giNofElem(iElem,:);
                           newElemDef = oldElemDef(obj.LagrangeCorners());
                           % check that every node is only permuted once:
                           iOrig = [];
                           for in = 1:8
                               I = find(nodesPermuted,newElemDef(in));
                               if numel(I)==0
                                   iOrig = [iOrig in];
                               end
                           end
                           newElemDef = newElemDef(iOrig);                                   
                           for iFibDim = 1:obj.FibDim
                               obj.fibres.value(newElemDef,iFibDim) = obj.fibres.value(oldElemDef(iOrig),iFibDim);
                           end
                           nodesPermuted = unique([nodesPermuted newElemDef]);
                       end
                   end
               end
           end
           
           f2 = fopen(exNodeFileName,'wb');
           if (f2==-1)
               fprintf(1,'Error while opening %s\n',exNodeFileName); return; 
           end
           %fprintf(f2,'Region: /Pablo\n');
           %fprintf(f2,'Region: /%s\n',GroupName);
           fprintf(f2,'Group name: %s\n',GroupName);
           % Versions of the first node:
           obj.PrintNodeVersionsDefinition(f2,1,basis,bOnlyFibres);           
           CurrentVersions=obj.versions(1,:);
           for iMatNode=1:obj.nNodes
               if ( CurrentVersions == obj.versions(iMatNode,:) )
                   obj.PrintNodeValues(f2,iMatNode,basis,bOnlyFibres);
               else
                   CurrentVersions = obj.versions(iMatNode,:);
                   obj.PrintNodeVersionsDefinition(f2,iMatNode,basis,bOnlyFibres);
                   obj.PrintNodeValues(f2,iMatNode,basis,bOnlyFibres);
               end
           end
           fclose(f2);
       end
       function []          = WriteExElemFileWithConstantField(obj,exElemFileName,GroupName,ConstantFieldName,values)
           if numel(values)~=obj.nElems
               fprintf('ERROR! The number of elements in the mesh (%i) is not the same as the number of constant values (%i)\n',obj.nElems,numel(values));
           end
           f2 = fopen(exElemFileName,'wb');
           if (f2==-1)
               fprintf(1,'Error while opening %s\n',exElemFileName); return; 
           end
           %fprintf(f2,'Region: /Pablo\n');
           %fprintf(f2,'Region: /%s\n',GroupName);
           fprintf(f2,'Group name: %s\n',GroupName);
           fprintf(f2,'Shape.  Dimension=3\n');
           fprintf(f2,'#Scale factor sets=0\n');
           fprintf(f2,'#Nodes=0\n');
           fprintf(f2,'#Fields=1\n');
           fprintf(f2,'1) %s, field, rectangular cartesian, #Components=1\n',ConstantFieldName);
           fprintf(f2,' value. constant*constant*constant, no modify, grid based.\n');
           fprintf(f2,' #xi1=0, #xi2=0, #xi3=0\n');

           for iElem=1:obj.nElems
               fprintf(f2,'Element: %i 0 0\n',iElem);
               fprintf(f2,'  Values :\n');
               fprintf(f2,'  %1.1f\n',values(iElem));
           end
           fclose(f2);
       end
       
       function []          = WriteVTKSurfaceMesh(obj,options)
           % Extract the faces and verteces of the surface, with a given discretization:
            OutDir = '';
            discretization = 4;
            if nargin >= 2
                if isfield(options,'OutDir'), OutDir = options.OutDir; end
                if isfield(options,'discretization'), discretization = options.discretization; end
            end
            % Extract the faces and verteces of the surface, with a given discretization:
            [V,F] = obj.TesselateExternalSurfaces(discretization);
            opt.t = F;
            io_writeVTK(fullfile(OutDir , [obj.name '.vtk']),V,opt);
       end
       
       function []          = WriteNodalCoords2VTK(obj,VTKfileGP)
           points = obj.GetNodeCoorValue(1:obj.nNodes);
           opt.Poly = 1; % need to write as POLYDATA for ptransformation to work:
           io_writeVTK(VTKfileGP,points,opt);
       end
       function []          = WriteGaussPoints2VTK(obj,VTKfileGP,GaussOrder)
           if nargin<3
               GaussOrder = 4;
           end
           points = obj.GetAllGaussPoints(GaussOrder);
           opt.Poly = 1; % need to write as POLYDATA for ptransformation to work:
           io_writeVTK(VTKfileGP,points,opt);
       end
       function [basis]     = GetBasisString(obj)
           switch obj.InterpolationBasis
               case 1
                   basis = 'c.Hermite'; 
               case 2
                   basis = 'c.Lagrange';
               case 3
                   basis = 'q.Lagrange';
               case 4
                   basis = 'l.Lagrange';
               case 5
                   basis = 'l.simplex';
           end
       end
       function []          = WriteExElemFile(obj,exElemFileName,GroupName,options)
           fprintf('Writing exElem file:   %s\n',exElemFileName);
           bDebugWritingElems=0;
           basis = obj.GetBasisString();           
           basis = [basis; basis; basis];
                   
           if nargin<3
               GroupName=obj.GroupName;
           end
           if nargin<4               
               VersionWritting = 'WriteVersionsForFitting';
           else
               if (isfield(options,'basis'))
                   basis = options.basis;
                   basis = [basis; basis; basis];
               else 
                   if (isfield(options,'basis1')), basis1 = options.basis1;
                   else basis1 = basis; end
                   if (isfield(options,'basis2')), basis2 = options.basis2;
                   else basis2 = basis; end
                   if (isfield(options,'basis3')), basis3 = options.basis3;
                   else basis3 = basis; end
                   basis = [basis1; basis2; basis3];
               end
               if (isfield(options,'VersionWritting'))
                   VersionWritting = options.VersionWritting;
               else
                   VersionWritting = 'WriteVersionsForFitting';
               end                   
           end           
           % When there is no scale factor (all one), simply a zero will be written:
           ScaleOne=false;
           if obj.nScaleFactorsDefs == 0
               ScaleOne = true;
           end
           % An easy way to codify which basis is used (see the writting of
           % node values and element values)
           CaseBasis = 0;
           for iC=1:3
               switch basis(iC,1:9)
                   case 'c.Hermite'
                       cb = 1;
                   case {'c.Lagrang','q.Lagrang','l.Lagrang','l.simplex'}
                       cb = 0;
                   otherwise
                        fprintf(1,'ERROR!, wrong basis specified! %s not recognised\n',basis(iC,:));
               end
               CaseBasis = CaseBasis + cb*2^(iC-1);
           end
           switch obj.InterpolationBasis
               case 2
                    CaseBasis = 8;
               case 3
                    CaseBasis = 6;
               case 5
                    CaseBasis = 1;
           end
           if(bDebugWritingElems), fprintf(1,' ... debugging WriteExElemFile. Basis case %i detected!\n',CaseBasis); end
       % -------------------------
       % 2) Write the exElem file:
       % -------------------------
       [nNodesPerElement,nVariablesPerNode] = obj.GetBasisCharacteristics(obj.InterpolationBasis);
               
           f2 = fopen(exElemFileName,'wb');
           if (f2==-1)
               fprintf(1,'Error while opening %s\n',exElemFileName); return; 
           end
           %fprintf(f2,'Region: /Pablo\n');
           %fprintf(f2,'Region: /%s\n',GroupName);
           fprintf(f2,'Group name: %s\n',GroupName);
           switch obj.InterpolationBasis
               case {1,2,3,4} % Cubic element:
                   fprintf(f2,'Shape.  Dimension=3 line*line*line\n');
               case 5 % Triangular surface
                   fprintf(f2,'Shape.  Dimension=2 simplex(2)*simplex\n');
           end
           bElementNotExists=1; iElem0=0;
           while(bElementNotExists) % Find first element which exists
               iElem0 = iElem0+1;
               if obj.nNofElem(iElem0)>0
                   bElementNotExists=0;
               end
           end
           CurrentLocalIndexDefinition = obj.liNofElem(iElem0,1:nNodesPerElement);
           %if isfield(obj,'valueIndices')
               CurrentLocalValueIndices = squeeze(obj.valueIndices(iElem0,1:3,1:nNodesPerElement,1:nVariablesPerNode));
           %else
           %    fprintf('WARNING! No definition of value indices, default assumed (no second versions)!\n')
           %    CurrentLocalValueIndices = obj.DefaultLocalValueIndicesPerElement;
           %end
           CurrentnNodesInElement = obj.nNofElem(iElem0);
           obj.PrintElemDefinition(f2,ScaleOne,CurrentnNodesInElement,CurrentLocalIndexDefinition,CurrentLocalValueIndices,CaseBasis,VersionWritting);
           obj.PrintElemValues(f2,1,CaseBasis);
           for iE=iElem0+1:obj.nElems
               if obj.nNofElem(iE)>0
                   bUpdateElementDefinition=1;
                   bUpdateElementDefinitionByLocalIndex=1;
                   bUpdateElementDefinitionByLovalValues=1;
                   if (bDebugWritingElems), fprintf(1,' ... debugging CubicMeshClass:WriteExFiles. Checking if element definition has to be updated...\n'); end
                   if (bDebugWritingElems), fprintf(1,'     Current LocalIndexDefinition: [%i %i %i %i %i %i %i %i].\n',CurrentLocalIndexDefinition); end
                   if (bDebugWritingElems), fprintf(1,'     New     LocalIndexDefinition: [%i %i %i %i %i %i %i %i].\n',obj.liNofElem(iE,1:8)); end
    %                if (bDebugWritingElems), 
    %                    dim=['xyz'];
    %                    for c=1:3
    %                        for ln=1:8
    %                            fprintf(1,' ... Current LocalValueIndices: %s.%i [%i %i %i %i %i %i %i %i].\n',dim(c),ln,CurrentLocalValueIndices(c,ln,1:8)); 
    %                        end
    %                    end
    %                end
                   % TODO: check this UNEXPECTED MATLAB BEHAVIOUR: 
                   % if(CurrentLocalIndexDefinition~=obj.liNofElem(iE,1:8))
                   % returns alwas a "false", no matter if they're different!
                   if (CurrentLocalIndexDefinition==obj.liNofElem(iE,1:nNodesPerElement)), bUpdateElementDefinitionByLocalIndex=0; end
                   %if isfield(obj,'valueIndices')
                   %18/02/2013: FOR SOME UNKNOWN REASON, THE PREVIOUS
                   %CONDITION IS NEVER MET!!!
                        if (CurrentLocalValueIndices==squeeze(obj.valueIndices(iE,:,:,:))), bUpdateElementDefinitionByLovalValues=0; end
                   %end
                   if (~bUpdateElementDefinitionByLocalIndex)&&(~bUpdateElementDefinitionByLovalValues)
                       bUpdateElementDefinition=0;
                   end
                   if (bUpdateElementDefinition)
                       if (bDebugWritingElems), fprintf(1,'debugging CubicMeshClass:WriteExFiles. Element Definition updated!\n'); end
                       CurrentLocalIndexDefinition = obj.liNofElem(iE,1:nNodesPerElement);
                       %if isfield(obj,'valueIndices')
                            CurrentLocalValueIndices = squeeze(obj.valueIndices(iE,:,:,:));
                       %else
                       %    CurrentLocalValueIndices = obj.DefaultLocalValueIndicesPerElement();
                       %end
                       CurrentnNodesInElement = obj.nNofElem(iE);
                       obj.PrintElemDefinition(f2,ScaleOne,CurrentnNodesInElement,CurrentLocalIndexDefinition,CurrentLocalValueIndices,CaseBasis,VersionWritting);
                   end
                   obj.PrintElemValues(f2,iE,CaseBasis);
               end
           end
           fclose(f2);
       end
       function []          = WriteTrinilearIPELFB(obj,ipelfbFileName,basisType)
           % Function to write the toplogy of a trilinear mesh starting
           % from the topology of the Cubic Hermite. The output format is
           % tailored to the "ipelfb" format needed for the simulation of a
           % heart cycle
           if nargin<3
               basisType = 2;
           end
           f2 = fopen(ipelfbFileName,'wb');
           if (f2==-1)
               fprintf(1,'Error while opening %s\n',ipelfbFileName); return; 
           end
           fprintf(1,'  Writting trilinear element file: %s\n',ipelfbFileName); 
           fprintf(f2,' CMISS Version 2.1  ipelfb File Version 1 \n');
           fprintf(f2,' Heading: Trilinear mesh taken from the Cubic Hermite %s\n\n', obj.name);
           fprintf(f2,' The number of elements is [  %i]:   %i\n\n',obj.nElems,obj.nElems);
           for iElem=1:obj.nElems               
               fprintf(f2,' Element number [    %i]:     %i\n',iElem,iElem);
               fprintf(f2,' The basis function type for the fibre angle is [%i]:  %i\n',basisType,basisType);
               fprintf(f2,' The basis function type for the imbrication angle is [%i]:  %i\n',basisType,basisType);
               fprintf(f2,' The basis function type for the sheet angle is [%i]:  %i\n',basisType,basisType);
               ListOf8Nodes = obj.GetListOf8GlobalNodes(iElem);
               fprintf(f2,' Enter the 8 numbers for basis 2 [prev]:  %i %i %i %i %i %i %i %i\n',ListOf8Nodes);
               % TODO: IMPLEMENT THE VERSIONS ISSUE (NOT UNDERSTOOD FROM
               % THE EXAMPLE:
% The version number for occurrence  1 of node    47, njj=1 is [ 1]:  3
% The version number for occurrence  1 of node    48, njj=1 is [ 1]:  3
% The version number for occurrence  1 of node   142, njj=1 is [ 1]:  2
               fprintf(f2,'\n');
           end
           fclose(f2);
       end
       function []          = WriteIpFiles(obj,name,DestinyDir,dirEx,nameOut)
            % cmGui script to generate the IP format
            obj.TempcmGuiDir = obj.ReplaceSlash(obj.TempcmGuiDir);
            if nargin<4
                dirEx = obj.TempcmGuiDir;
                options.basis = 'c.Hermite';
                options.VersionWritting = 'WriteVersionsForIPconversion';
                obj.WriteExFiles([dirEx name '.exnode'],[dirEx name '.exelem'],name,options);
            end
            if nargin<5
                nameOut = name;
            end
            fprintf('Writing IP files:   %s in %s\n',nameOut,DestinyDir);
            file= [obj.TempcmGuiDir 'ex2ip.com'];
            f=fopen(file,'w');
            fprintf(f,'${dirEx}="%s"\n',obj.ReplaceSlash(dirEx));
            fprintf(f,'${ExMeshName}="%s"\n',name);
            fprintf(f,'${IpMeshName}="%s"\n',nameOut);
            fprintf(f,'gfx r n "${dirEx}/${ExMeshName}.exnode"\n');
            fprintf(f,'gfx r e "${dirEx}/${ExMeshName}.exelem"\n\n');
            fprintf(f,'${dirIp}="%s"\n',obj.ReplaceSlash(DestinyDir));
            fprintf(f,'gfx export cm field coordinates region ${ExMeshName} ');
            fprintf(f,'ipnode_filename "${dirIp}/${IpMeshName}.ipnode" ');
            fprintf(f,'ipcoor_filename "${dirIp}/${IpMeshName}.ipcoor" ');
            fprintf(f,'ipbase_filename "${dirIp}/${IpMeshName}.ipbase" ');
            fprintf(f,'ipelem_filename "${dirIp}/${IpMeshName}.ipelem" \n');
            %fprintf(f,'\nexit \n\n');
            fclose(f);
            flags.bExit = 1;
            comfile = [obj.TempcmGuiDir 'ex2ip.com'];
            CallcmGui(comfile,flags);
            ChangeBasisIndexInIPfile([DestinyDir nameOut '.ipelem'],[DestinyDir nameOut 'ForBasisFuncs3.ipelem'],2,1);
       end
       function [NF]        = GeneratecmGuIScript2writeImages(obj,ImageKind,tempname,options)
           % Avoid the windows '/' symbols
           obj.TempcmGuiDir = obj.ReplaceSlash(obj.TempcmGuiDir);
           obj.TempBinaryDir= obj.ReplaceSlash(obj.TempBinaryDir);
           % Default options:
           NF = 1; %Normalization factor of the intensities
               elementDiscretization = 5;
               dirMesh = obj.TempBinaryDir;
               nameMesh= 'shape2genBinary';
               SlicePlane = 'Z';
               bOneImage = 0;
               bNeedAccurateGrayscale = 0;
           if nargin==4
               if isfield(options,'bOneImage'),              bOneImage = options.bOneImage;                              end
               if isfield(options,'elementDiscretization'),  elementDiscretization = options.elementDiscretization;      end
               if isfield(options,'SlicePlane'),             SlicePlane = options.SlicePlane; end
               if isfield(options,'bNeedAccurateGrayscale'), bNeedAccurateGrayscale = options.bNeedAccurateGrayscale; end
               if isfield(options,'dirMesh'),
                   if ~isnan(options.dirMesh);
                        dirMesh = options.dirMesh;
                   end
               end
               if isfield(options,'nameMesh'), 
                   if ~isnan(options.nameMesh)
                        nameMesh = options.nameMesh; 
                   end
               end
               
           end
           file = [obj.TempcmGuiDir 'genBinary.cmgui'];
           fid = fopen(file,'w');
           fprintf(fid,'# Script to generate an image from a cubic Hermite mesh\n'); 
           fprintf(fid,'# ImageKind = %s\n', ImageKind);
           fprintf(fid,'# Geometry to be "imaged":\n'); 
           fprintf(fid,'${dir} ="%s"\n',obj.ReplaceSlash(dirMesh));
           fprintf(fid,'${model} ="%s"\n',nameMesh); 
           fprintf(fid,'gfx r n "${dir}${model}.exnode"\n'); 
           fprintf(fid,'gfx r e "${dir}${model}.exelem"\n'); 
           fprintf(fid,'gfx define face egroup ${model}\n'); 

           fprintf(fid,'gfx create win 1\n'); 
           fprintf(fid,'gfx modify g_element ${model} general element_discretization %i\n',elementDiscretization); 
           fprintf(fid,'gfx modify g_element ${model} lines invisible \n'); 
           
           % It looks as if in cmGui the light vector is referred to a
           % different coordinate system, centred in the camera. We always
           % want the illumination falling into the object directly:
           if(bNeedAccurateGrayscale)
               % In order to avoid saturation, this tilted illumination is
               % introduced. The max grayvalue is at 231 as empirically
               % tested in a surface cube rendering xi component (see
               % CalibrateCmGui.m script)
                lightvector = [0 -1 -1];      
                fprintf(' ... Light vector chosen to avoid saturation: %1.2f %1.2f %1.2f\n',lightvector)
           else
                lightvector = [0 0 -1];           
           end
           switch SlicePlane
               case {'z','Z'}, 
                   fprintf(fid,'gfx define field CoordISO component coordinates.z\n'); 
                   %lightvector = [0 0 -1];
               case {'y','Y'}, 
                   fprintf(fid,'gfx define field CoordISO component coordinates.y\n'); 
                   %lightvector = [0 -1 0];
               case {'x','X'}, 
                   fprintf(fid,'gfx define field CoordISO component coordinates.x\n'); 
                   %lightvector = [-1 0 0];
               otherwise
                   fprintf('ERROR! Not recognised option for SlicePlane (%s) in GeneratecmGuIScript2writeImages\n',SlicePlane);
           end
           bGrayscale=1;
           bMinGraySet=0;
           MaxMin=1;
           switch ImageKind
               case 'binary'
               case 'labels'
                   % Render the field labels that is in the mesh:
                   fprintf(fid,'gfx define field GrayscaleField component labels.label\n');                    
               case 'fibres_Xcomponent'
                   fprintf(fid,'gfx define field GrayscaleField component fibres.x\n');                    
               case 'fibres_Ycomponent'
                   fprintf(fid,'gfx define field GrayscaleField component fibres.y\n'); 
               case 'fibres_Zcomponent'
                   fprintf(fid,'gfx define field GrayscaleField component fibres.z\n'); 
               case 'fibres_Elevationn'
                   fprintf(fid,'gfx define field GrayscaleField component fibres.elevation\n'); 
                   MaxMin= pi/2;
               case 'fibres_Imbricatin'
                   fprintf(fid,'gfx define field GrayscaleField component fibres.imbrication\n'); 
                   MaxMin= pi/2;
               case 'fibres_SheetAngle'
                   fprintf(fid,'gfx define field GrayscaleField component fibres.sheet\n'); 
                   MaxMin= pi/2;
               % 15/09/11: PL trying to export a deformation field as an
               % image (not tried out)
               case 'deformation_Xcomponent'
                   fprintf(fid,'gfx define field GrayscaleField component deformation.x\n'); 
               case 'deformation_Ycomponent'
                   fprintf(fid,'gfx define field GrayscaleField component deformation.y\n'); 
               case 'deformation_Zcomponent'
                   fprintf(fid,'gfx define field GrayscaleField component deformation.z\n');                
               otherwise
                   if strcmp(ImageKind(1:2),'xi')||strcmp(ImageKind(1:2),'XI')
                       % Image to get the local material coordinate or derivative, each of
                       % the components:
                       iXhi = str2num(ImageKind(3));
                       if numel(ImageKind)==3
                           % This is an image of the xi coordinate symply
                           fprintf(fid,'	\n');
                           fprintf(fid,'gfx def field GrayscaleField component xi.%i\n',iXhi);
                           bMinGraySet = 1;
                           MinGray = 0;
                           if(bNeedAccurateGrayscale)
                               NF = 231;
                           else
                               NF = 255;
                           end
                       else
                           % This is an image of the derivative:                       
                           iCom = str2num(ImageKind(4));
                           switch iCom
                               case 1, Comp = 'x';
                               case 2, Comp = 'y';
                               case 3, Comp = 'z';
                           end
                           bNormalisePhysical = 1;
                           if(bNormalisePhysical)
                               fprintf(fid,'	\n');
                               fprintf(fid,'gfx def field CX component coordinates.x\n');
                               fprintf(fid,'gfx def field dCXdxi gradient field CX coordinate xi\n');
                               fprintf(fid,'gfx def field CY component coordinates.y\n');
                               fprintf(fid,'gfx def field dCYdxi gradient field CY coordinate xi\n');
                               fprintf(fid,'gfx def field CZ component coordinates.z\n');
                               fprintf(fid,'gfx def field dCZdxi gradient field CZ coordinate xi\n');
                               fprintf(fid,'gfx def field dCdxi%i composite dCXdxi.%i dCYdxi.%i dCZdxi.%i\n',iXhi,iXhi,iXhi,iXhi);
                               fprintf(fid,'gfx def field NormdC normalise field dCdxi%i\n',iXhi);
                               fprintf(fid,'gfx def field GrayscaleField component NormdC.%i\n',iCom);
                           else
                               % Define this field in cmGui:
                               fprintf(fid,'gfx def field CX component coordinates.%s\n',Comp);
                               fprintf(fid,'gfx def field dCXdxi gradient field CX coordinate xi\n');
                               % The elevation and imbrication do not make sense.
                               % It sounds sensible that normalization is only
                               % needed at physical space, not at xi space:
                               bNormaliseXi = 0;
                               if(bNormaliseXi)
                                   fprintf(fid,'gfx def field NormdC normalise field dCXdxi\n');
                                   fprintf(fid,'gfx def field GrayscaleField component NormdC.%i\n',iXhi);
                               else
                                   fprintf(fid,'gfx def field GrayscaleField component dCXdxi.%i\n',iXhi);
                               end
                           end                       
                           %fprintf(fid,'gfx define field dx_ds1 node_value fe_field coordinates d/ds%i\n',iXhi);
                           %fprintf(fid,'gfx define field NormalisedDX normalise d/ds%i\n',iXhi);
                           %fprintf(fid,'gfx define field GrayscaleField component NormalisedDX.%i\n',iCom); 
                       end
                   else
                       fprintf('ERROR! ImageKind %s not recognsied\n',ImageKind);
                       bGrayscale = 0;
                   end
           end
           fprintf(fid,'# File to set the camera and the parameters needed after:\n');
           % This is one way to avoid the windows path symbols, which are
           % problematic in cmgui afterwards:
           obj.Print2FileWithoutScapes(fid,['read com ' obj.TempcmGuiDir 'SetCameraForBinarisation'])
           fprintf(fid,'\n'); 
           % Change the direction of light to remove undesirable "shading effects"
           fprintf(fid,'gfx mod light default direction %1.2f %1.2f %1.2f;\n',lightvector);
           if(bGrayscale)
               fprintf(fid,'gfx create spectrum grayscale clear overwrite_colour;\n');
               MaxGray = MaxMin;
               if(~bMinGraySet)
                    MinGray = -MaxMin;
               end
               fprintf(fid,sprintf('gfx modify spectrum grayscale linear range %1.5f %1.5f extend_above extend_below red colour_range 0 1 ambi diffuse component 1;\n',MinGray,MaxGray));
               fprintf(fid,sprintf('gfx modify spectrum grayscale linear range %1.5f %1.5f extend_above extend_below green colour_range 0 1 ambi diffuse component 1;\n',MinGray,MaxGray));
               fprintf(fid,sprintf('gfx modify spectrum grayscale linear range %1.5f %1.5f extend_above extend_below blue colour_range 0 1 ambi diffuse component 1;\n',MinGray,MaxGray));
           end

           %fprintf(fid,'print "Camera set and parameters read: Zspacing = $res_Z, Zorigin = $origin3, Nframes = $nFrames". \n'); 
           if (bOneImage)
               lastImage = '1';
           else
               lastImage = '$nFrames';
           end

           fprintf(fid,'for($Fj=1+1000;$Fj<=%s+1000;$Fj++){\n',lastImage); 
           fprintf(fid,'	$i=$origin3 + ($Fj-1001)*$res_Z\n'); 

           fprintf(fid,'	gfx modify g_element ${model} iso_surfaces as XC iso_scalar CoordISO iso_values $i use_elements select_on');
           switch ImageKind
                   case 'binary'
                       fprintf(fid,'\n');
                   otherwise
                       fprintf(fid,' data GrayscaleField spectrum grayscale\n'); 
           end
           
           fprintf(fid,'	#print "saving Frame $Fj with iso value $i (Zspacing = $res_Z)";\n'); 
           fprintf(fid,'	gfx print win 1 file "%s/Frame_${Fj}_%s.tiff";\n',dirMesh,tempname); 
           fprintf(fid,'};\n'); 

           %fprintf(fid,'exit\n'); 
           fclose(fid);
       end
       function []          = WriteIpFilesManual(obj,fileName,dir)
           % TO BE DEPRECATED (28/06/10: function calling cmgui)
           % TODO: write ipnode, and write versions in ipelem
           %ipNodeFile = [dir fileName '.ipnode'];
           ipElemFile = [dir fileName '.ipelem'];

       % -------------------------
       % 1) Write the ipNode file:
       % -------------------------
       
       
       % -------------------------
       % 2) Write the ipElem file:
       % -------------------------       
           f2 = fopen(ipElemFile,'wb');
           if (f2==-1)
               fprintf(1,'Error while opening %s\n',filename); return; 
           end
           fprintf(f2,' CMISS Version 2.1  ipelem File Version 2\n');
           fprintf(f2,' Heading: ipElem generated from Cubic Hermite Mesh %s\n\n',obj.name);
           fprintf(f2,' The number of elements is [1]: %i\n\n',obj.nElems);
           for iElem=1:obj.nElems
               obj.WriteIpElement(f2,iElem);
           end
       end
       function []          = WriteIpElement(f2,iElem)
           fprintf(f2,' Element number [   %i]:    %i\n',iElem,iElem);
           fprintf(f2,' The number of geometric Xj-coordinates is [3]: 3\n');
           fprintf(f2,' The basis function type for geometric variable 1 is [1]:  1\n');
           fprintf(f2,' The basis function type for geometric variable 2 is [1]:  1\n');
           fprintf(f2,' The basis function type for geometric variable 3 is [1]:  1\n');
           ListOf8Nodes = obj.GetListOf8GlobalNodes(iElem);
           fprintf(f2,' Enter the 8 global numbers for basis 1:    %i %i %i %i %i %i %i %i\n',ListOf8Nodes);
           fprintf(f2,' Enter the 8 numbers for basis 2 [prev]:    %i %i %i %i %i %i %i %i\n',ListOf8Nodes);
           fprintf(f2,' Enter the 8 numbers for basis 3 [prev]:    %i %i %i %i %i %i %i %i\n',ListOf8Nodes);
           fprintf(f2,' Enter the 8 numbers for basis 4 [prev]:    %i %i %i %i %i %i %i %i\n',ListOf8Nodes);
           fprintf(f2,' Enter the 8 numbers for basis 5 [prev]:    %i %i %i %i %i %i %i %i\n',ListOf8Nodes);
           fprintf(f2,' Enter the 8 numbers for basis 6 [prev]:    %i %i %i %i %i %i %i %i\n',ListOf8Nodes);
           fprintf(f2,' Enter the 8 numbers for basis 13 [prev]:    %i %i %i %i %i %i %i %i\n',ListOf8Nodes);
       end
       function []          = PrintNodeVersionsDefinition(obj,f2,iMatNode,basis,bOnlyFibres)
           % An exnode with a geometry and other fields:
           % Quick hack to make the writting of elevation and
           % imbrication from DTmri work:
           if nargin<5
               bOnlyFibres = 0;
           end
           if obj.nFields > 0
               nameFi= obj.GetFieldName(1);
               % TODO: make number of fields robust
               if strcmp(nameFi,'elevation')
                   nFields2write = 1+obj.nFields+obj.bFibres-1;
               else
                   nFields2write = 1+obj.nFields+obj.bFibres;
               end
               if strcmp(nameFi,'labels')
                   % This is a constant field per element, no need to write
                   % its definitin in an exnode!!
                   nFields2write = nFields2write - 1;
               end
           else
               nFields2write = 1 + obj.bFibres;
           end
           if(bOnlyFibres)
               nFields2write=1;
           end
           fprintf(f2,'#Fields=%i\n',nFields2write);
           % The geometry:
           CurrVers = obj.versions(iMatNode,:);
           CHermiteDerivs = ', #Derivatives= 7 (d/ds1,d/ds2,d2/ds1ds2,d/ds3,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3)';
           CLagrangeDerivs = ', #Derivatives= 0';
           switch basis
               case 'c.Hermite'
                   Derivs = CHermiteDerivs;
                   nVxN = 8; % number of Values per Node                   
               case {'c.Lagrange','q.Lagrange','l.Lagrange','l.simplex'}
                   Derivs = CLagrangeDerivs;
                   nVxN = 1;
           end
           % The coordinates
           if(~bOnlyFibres)
               FieldIndexFibres=2;
               fprintf(f2,' 1) %s, coordinate, rectangular cartesian, #Components=3\n',obj.CoordinatesName);
               fprintf(f2,'   x.  Value index= %i%s, #Versions= %i\n',1,Derivs,CurrVers(1)); 
               fprintf(f2,'   y.  Value index= %i%s, #Versions= %i\n',1+nVxN*CurrVers(1),Derivs,CurrVers(2));
               fprintf(f2,'   z.  Value index= %i%s, #Versions= %i\n',1+nVxN*(CurrVers(1)+CurrVers(2)),Derivs,CurrVers(3));
           else
               FieldIndexFibres=1;
           end
           % The fibres
           if (obj.bFibres)
               if obj.bExportLinearFibres
                   nVxN = 1;
                   Derivs = CLagrangeDerivs;
                   CurrVers = [1 1 1];
               end
               FirstValueIndex = 3*nVxN*(FieldIndexFibres-1)+1;                   
               switch obj.FibreDescriptionType
                   case 1
                       fprintf(f2,' %i) fibres, field, rectangular cartesian, #Components=3\n',FieldIndexFibres);                               
                       fprintf(f2,'   x.  Value index= %i%s, #Versions= %i\n',FirstValueIndex,Derivs,CurrVers(1)); 
                       fprintf(f2,'   y.  Value index= %i%s, #Versions= %i\n',FirstValueIndex+nVxN*CurrVers(1),Derivs,CurrVers(2));
                       fprintf(f2,'   z.  Value index= %i%s, #Versions= %i\n',FirstValueIndex+nVxN*(CurrVers(1)+CurrVers(2)),Derivs,CurrVers(3));
                   case 2
                       % From: http://cmiss.bioeng.auckland.ac.nz/development/examples/a/a3/cmiss_input/heart.exnode
                       fprintf(f2,' %i) fibres, anatomical, fibre, #Components=3\n',FieldIndexFibres);
                       fprintf(f2,' elevation.  Value index= %i%s, #Versions= %i\n',FirstValueIndex,Derivs,CurrVers(1)); 
                       fprintf(f2,' imbrication.  Value index= %i%s, #Versions= %i\n',FirstValueIndex+nVxN*CurrVers(1),Derivs,CurrVers(2));
                       fprintf(f2,' sheet.  Value index=%i%s, #Versions= %i\n',FirstValueIndex+nVxN*CurrVers(1)+nVxN*CurrVers(2),Derivs,CurrVers(3));
               end
           end
           % The fields:
           FirstValueIndex = 3*nVxN + obj.bFibres * 3*nVxN*(FieldIndexFibres-1)+1;
           LastFieldnValues= 0;
           for iF=1:obj.nFields
               FirstValueIndex = FirstValueIndex + LastFieldnValues;
               nameFi = obj.GetFieldName(iF);
               if ~strcmp(nameFi,'labels')
                   % Quick hack to make the writting of elevation and
                   % imbrication from DTmri work:
                   if strcmp(nameFi,'elevation')
                       if obj.bExportLinearFibres
                           nVxN = 1;
                           Derivs = CLagrangeDerivs;                           
                       end
                       fprintf(f2,' %i) fibres, anatomical, fibre, #Components=3\n',iF+FieldIndexFibres);
                       fprintf(f2,'   elevation.  Value index= %i%s, #Versions= 1\n',FirstValueIndex,Derivs);
                       % It is supposed that the next field is the
                       % imbrication one!!!
                       fprintf(f2,'   imbrication.  Value index= %i%s, #Versions= 1\n',FirstValueIndex+nVxN,Derivs);
                       fprintf(f2,'   sheet.  Value index= %i%s, #Versions= 1\n',FirstValueIndex+2*nVxN,Derivs);
                       LastFieldnValues = 3*nVxN;
                   else if strcmp(nameFi,'imbrication')
                           % do nothing, it was done before
                       else
                           % A condition to know that the field has all
                           % the detailed information:
                           if isfield(obj.ListOfFields,'field')
                               iFfile = iF + 1 + obj.bFibres;
                               fname = obj.ListOfFields.field(iF).Name;
                               Type  = obj.ListOfFields.field(iF).Type;
                               SubType  = obj.ListOfFields.field(iF).SubType;
                               nComp = obj.ListOfFields.field(iF).nComponents;
                               fprintf(f2,' %i) %s, %s, %s, #Components=%i\n',iFfile,fname,Type,SubType,nComp);
                               LastFieldnValues = 0;
                               for iComp = 1:nComp
                                   ComName = obj.ListOfFields.field(iF).component(iComp).Name;
                                   %index0  = obj.ListOfFields.field(iF).component(iComp).Indexes;
                                   %not the index stored, but the one
                                   %corresponding to how data is written this
                                   %time:
                                   index0  = FirstValueIndex + LastFieldnValues;
                                   nVals   = obj.ListOfFields.field(iF).component(iComp).nValues;
                                   nVers   = obj.ListOfFields.field(iF).component(iComp).nVersions;
                                   bWriteValueIndex = 1;
                                   switch nVals
                                       case 0
                                           bWriteValueIndex = 0;
                                       case 1
                                            Derivs = CLagrangeDerivs;
                                       case 8
                                            Derivs = CHermiteDerivs;
                                       otherwise
                                           fprintf('I/O ERROR! Class not prepared to handle a field with %i values per node! (CubicMeshClass.PrintNodeVersionsDefinition)\n',nVals);
                                   end
                                   if(bWriteValueIndex)
                                       fprintf(f2,'   %s.  Value index= %i%s, #Versions= %i\n',ComName,index0,Derivs,nVers);
                                       LastFieldnValues = LastFieldnValues + nVals;
                                   end
                               end
                           else
                               fprintf(f2,' %i) %s, field, rectangular cartesian, #Components= 1\n',iF+FieldIndexFibres,char(nameFi));
                               fprintf(f2,'   value.  Value index= %i%s, #Versions= 1\n',FirstValueIndex,CHermiteDerivs);
                               LastFieldnValues = 1;
                           end
                       end
                   end
               end
           end
       end
       
       function []          = PrintNodeValues(obj,f2,iMatNode,basis,bOnlyFibres)
           % 01/10/10: write a 0 when a NaN 
           if nargin<5
               bOnlyFibres = 0;
           end
           bDebug=0;
           fprintf(f2,' Node: %i\n',iMatNode);
           if(~bOnlyFibres)
               for iCoor=1:3
                   for v=1:obj.versions(iMatNode,iCoor)
                       Vtake = int8(v) * int8(ones(1,8));
                       if v>1
                           % Check if the additional version is really
                           % used or not (after checking the list of value
                           % indexes in the EXELEM file, information stored
                           % in obj.NewBasisIndex
                           for iValue=1:8
                               if obj.NewBasisIndex(iCoor,iMatNode,iValue,v)==0
                                   % In this case, take the first version
                                   % of this value to be written in the
                                   % exnode:
                                   Vtake(iValue) = 1;
                               end
                           end
                       end
                       u = obj.coordinates(iMatNode,iCoor,Vtake(1));
                       
                       switch obj.InterpolationBasis
                           case 1 %c.Hermite
                               duds1  =   obj.derivatives.duds1(iMatNode,iCoor,Vtake(2));
                               duds2  =   obj.derivatives.duds2(iMatNode,iCoor,Vtake(3));
                               duds3  =   obj.derivatives.duds3(iMatNode,iCoor,Vtake(4));
                               duds12 =  obj.derivatives.duds12(iMatNode,iCoor,Vtake(5));
                               duds13 =  obj.derivatives.duds13(iMatNode,iCoor,Vtake(6));
                               duds23 =  obj.derivatives.duds23(iMatNode,iCoor,Vtake(7));
                               duds123= obj.derivatives.duds123(iMatNode,iCoor,Vtake(8));
                               values = [u,duds1,duds2,duds12,duds3,duds13,duds23,duds123];
                           case {2,3,4,5} % cubic, linear or quadratic Lagrange, or linear triangular
                               values = [u];
                           otherwise
                               display('NO BASIS DEFINED');
                       end
                       obj.PrintValues(f2,values,basis);
                       if(iMatNode==1)&&(bDebug)
                           fprintf(1,'Node %i, version %i, values printed: %i, %i, %i, %i, %i, %i, %i, %i.',iMatNode,v,values);
                           fprintf(1,'  Vtake : %i, %i, %i, %i, %i, %i, %i, %i.\n',Vtake);
                       end
                   end
               end
           end
           if (obj.bFibres)
               if obj.bExportLinearFibres
                   Basis2exportFibres = 3;
               else
                   Basis2exportFibres = obj.InterpolationBasis;
               end
               for j=1:obj.FibDim
                   for v=1:obj.versions(iMatNode,j)
                       u = obj.fibres.value(iMatNode,j,1);                       
                       switch Basis2exportFibres
                           case 1 %c.Hermite
                               duds1  =   obj.fibres.dfds1(iMatNode,j,v);
                               duds2  =   obj.fibres.dfds2(iMatNode,j,v);
                               duds3  =   obj.fibres.dfds3(iMatNode,j,v);
                               duds12 =  obj.fibres.dfds12(iMatNode,j,v);
                               duds13 =  obj.fibres.dfds13(iMatNode,j,v);
                               duds23 =  obj.fibres.dfds23(iMatNode,j,v);
                               duds123= obj.fibres.dfds123(iMatNode,j,v);
                               values = [u,duds1,duds2,duds12,duds3,duds13,duds23,duds123];
                           case {2,3,4} % cubic, linear or quadratic Lagrange
                               values = [u];
                           otherwise
                               display('NO BASIS DEFINED');
                       end
                       obj.PrintValues(f2,values,basis);
                   end
               end
               if obj.FibreDescriptionType==2&&obj.FibDim==2
                   % Case of an anatomical definition of fibres when there
                   % is no information about sheet angle
                   for v=1:obj.versions(iMatNode,j)
                       switch Basis2exportFibres
                           case 1, nVariablesPerNode= 8;
                           otherwise, nVariablesPerNode= 1;
                       end
                       values = zeros(1,nVariablesPerNode);
                       obj.PrintValues(f2,values,basis);
                   end
               end
           end
           for iF=1:obj.nFields
               % A condition to know that the field has all
               % the detailed information:
               if isfield(obj.ListOfFields,'field')
                   % FieldValues(iField,iNode).values: matrix of size (nComponents x nFieldValues x nVersions)
                   nComps = obj.ListOfFields.field(iF).nComponents;
                   for iComp = 1:nComps
                       nVals = obj.ListOfFields.field(iF).component(iComp).nValues;
                       nVers = obj.ListOfFields.field(iF).component(iComp).nVersions;
                       for iVer = 1:nVers
                           bValues = 0;
                           if isempty(obj.FieldValues)
                               if numel(obj.fields.value(iMatNode,iF)) > 0
                                   values = obj.fields.value(iMatNode,iF);
                                   bValues = 1;
                               end
                           else
                               if numel(obj.FieldValues(iF,iMatNode).values)>0
                                    values = squeeze(obj.FieldValues(iF,iMatNode).values(iComp,1:nVals,iVer));
                                    bValues = 1;
                               end
                           end
                           if(bValues)
                                obj.PrintValues(f2,values);
                           else
                               fprintf('ERROR! field values were empty!\n');
                               fprintf('	Field name: %s\n',obj.ListOfFields.field(iF).Name);
                               fprintf('	Values of node %i, component %i, version %i.\n',iMatNode,iComp,iVer);
                           end
                       end
                   end
               else
                   u =        obj.fields.value(iMatNode,iF);
                   duds1  =   obj.fields.dfds1(iMatNode,iF);
                   duds2  =   obj.fields.dfds2(iMatNode,iF);
                   duds3  =   obj.fields.dfds3(iMatNode,iF);
                   duds12 =  obj.fields.dfds12(iMatNode,iF);
                   duds13 =  obj.fields.dfds13(iMatNode,iF);
                   duds23 =  obj.fields.dfds23(iMatNode,iF);
                   duds123= obj.fields.dfds123(iMatNode,iF);
                   values = [u,duds1,duds2,duds12,duds3,duds13,duds23,duds123];
                   obj.PrintValues(f2,values,basis);
               end
           end
       end
       function []          = PrintElemDefinition(obj,f2,ScaleOne,nNodesInElement,LocalNodeIndex,CurrentLocalValueIndices,CaseBasis,VersionWritting)
           %Still a hacky way to cope with this:
           bScaleFactorsPerField = 0;
           bDebug=0;
           if(bDebug), fprintf(1,'    ... debugging PrintElemDefinition, case %i of basis functions!\n',CaseBasis); end
           [basis1,basis2,basis3,nScaleFactors] = obj.GetBasisFromCase(CaseBasis);
           [nNodesPerElement,nVariablesPerNode] = obj.GetBasisCharacteristics(obj.InterpolationBasis);
           % A condition to know that the field has all
           % the detailed information:
           if isfield(obj.ListOfFields,'field')&&bScaleFactorsPerField
               % This is yet a hacky way to interpret the presence of
               % number of scale factors in a exelem file. This will
               % determine the number of scale factors at each element!
               nScaleSets = 1 + obj.nFields;
               %fprintf('WARNING! (writting %s): scale factors will be guessed for the fields\n',obj.name)
           else
               nScaleSets = obj.nScaleFactorsDefs;
               %fprintf('WARNING! (writting %s): no different scale factors for the fields\n',obj.name)
           end
           fprintf(f2,'#Scale factor sets= %i \n',nScaleSets);
           for iSS = 1:nScaleSets
               if iSS==1
                   % Print the main scale factors, the one of the
                   % coordinates:
                   if isempty(basis3)
                       fprintf(f2,'  %s*%s, #Scale factors=%i\n',basis1,basis2,nScaleFactors);
                   else
                       fprintf(f2,'  %s*%s*%s, #Scale factors=%i\n',basis1,basis2,basis3,nScaleFactors);
                   end
               else
                   if isfield(obj.ListOfFields,'field')
                       switch obj.ListOfFields.field(1).component(1).nValues
                       case 1, CaseBasisField = 0;
                       case 27, CaseBasisField = 6;
                       case 8, CaseBasisField = 7;
                       case 64, CaseBasisField = 8;
                       otherwise
                           fprintf('ERROR! Not possible to know what was the scale factor set (not read yet into CubicMeshClass.m)\n');
                       end
                       [Fbasis1,Fbasis2,Fbasis3,FnScaleFactors] = obj.GetBasisFromCase(CaseBasisField);
                   end
                   fprintf(f2,'  %s*%s*%s, #Scale factors=%i\n',Fbasis1,Fbasis2,Fbasis3,FnScaleFactors);
               end
               
           end
           % HERE is where a collapsed node is defined, and the way it is
           % collapsed is defined by 'LocalNodeIndex', where the repetition
           % of indexes indicate which nodes are repeated. 
           fprintf(f2,'#Nodes=  %i\n',nNodesInElement);
           % Quick hack to make the writting of elevation and
           % imbrication from DTmri work:
           nameFi= obj.GetFieldName(1);
           if strcmp(nameFi,'elevation')
               nFields2write = 1+obj.nFields+obj.bFibres-1;
           else
               nFields2write = 1+obj.nFields+obj.bFibres;
           end
           fprintf(f2,'#Fields=%i\n',nFields2write);
           coord=['x' 'y' 'z'];
           ValueIndexes=CurrentLocalValueIndices;
           % Conversion from CubicMeshClassOrder to EXELEM order, based
           % on the variable obj.valueOrderInExFile:
           valueIndicesEXELEMorder = zeros(3,nNodesPerElement,nVariablesPerNode);
           % Make a careful ordering of indices, suitable for a definition
           % of second version per node variables (and not the 8 node
           % variables together enforced by IP format). THis is the
           % suitable solution for understanding the Degrees of Freedom of
           % the mesh in the fitting process. (VersionWritting=='WriteVersionsForFitting')
           for iCoor=1:3
               for iLocalNode=1:nNodesPerElement
                   for iValue = 1:nVariablesPerNode
                       if iValue==obj.valueOrderInExFile(iValue)
                           valueIndicesEXELEMorder(iCoor,iLocalNode,iValue) = ValueIndexes(iCoor,iLocalNode,iValue);
                       else
                           diff = iValue - mod(obj.valueOrderInExFile(iValue),nVariablesPerNode);
                           valueIndicesEXELEMorder(iCoor,iLocalNode,obj.valueOrderInExFile(iValue)) = ValueIndexes(iCoor,iLocalNode,iValue) - diff;
                       end
                   end
               end
           end
           % But, if the purpose is to have this exfile converted by cmGui
           % to IP format, then ALL nodal variables should have indexes
           % pointing to the second version. And we should take care that
           % the second versions that are not really second versions have
           % the same value of the first versions.
           if strcmp(VersionWritting,'WriteVersionsForIPconversion')
               % TODO: ADAPT THIS CODE TO HANDLE MORE THAN SECOND VERSIONS
               for iCoor=1:3
                   for iLocalNode=1:nNodesPerElement      
                       bSecondVersions=false;
                       for iValue = 1:nVariablesPerNode
                           if iValue~=valueIndicesEXELEMorder(iCoor,iLocalNode,iValue)
                               bSecondVersions=true;
                           end
                       end
                       if (bSecondVersions)
                           % Make sure the node values, the additional
                           % versions, have the same values of the first
                           % version in case this is not used! (this has to
                           % be done in the writting of the EXNODE.
                           valueIndicesEXELEMorder(iCoor,iLocalNode,1:nVariablesPerNode) = nNodesPerElement + [1:nNodesPerElement];
                       end
                   end
               end
           end
           if ScaleOne==true
               ScaleFactorIndexes=zeros(nNodesPerElement,nVariablesPerNode);
           else
               switch obj.InterpolationBasis
                   case 1
                       ScaleFactorIndexes=[1:8;9:16;17:24;25:32;33:40;41:48;49:56;57:64];
                   case 2
                       ScaleFactorIndexes= [1:64]';
                   case 3
                       ScaleFactorIndexes= [1:27]';
                   case 4
                       ScaleFactorIndexes= [1:8]';
                   case 5
                       ScaleFactorIndexes= [1:3]';
               end
           end
           % 1) Definition of the coordinates:
           
           for iCoor=1:3
               switch obj.InterpolationBasis
                   case 5
                       stringbasis = sprintf('%s*%s',basis1,basis2);
                   otherwise
                       stringbasis = sprintf('%s*%s*%s',basis1,basis2,basis3);
               end
               nComponents = 3; % x,y,z components
               if iCoor==1
                   fprintf(f2,' 1) %s, coordinate, rectangular cartesian, #Components=%i\n',obj.CoordinatesName,nComponents);
               end
               fprintf(f2,'  %c.  %s, no modify, standard node based.\n',coord(iCoor),stringbasis);
               fprintf(f2,'    #Nodes= %i\n',nNodesPerElement);
               obj.PrintValueAndScaleFactorIndices(f2,CaseBasis,LocalNodeIndex,ScaleFactorIndexes,valueIndicesEXELEMorder,iCoor);
           end
           % 2) The fibres:
           if (obj.bFibres)
               switch obj.FibreDescriptionType
                   case 1 % Fibres in cartesian space:
                       fprintf(f2,' 2) fibres, field, rectangular cartesian, #Components=3\n');   
                       nameFibComp(1).string='x_Fibre';
                       nameFibComp(2).string='y_Fibre';
                       nameFibComp(3).string='z_Fibre';                    
                   case 2 % Anatomical fibres:
                       fprintf(f2,' 2) fibres, anatomical, fibre, #Components=3\n');
                       nameFibComp(1).string='elevation';
                       nameFibComp(2).string='imbrication';
                       nameFibComp(3).string='sheet';
               end
               if obj.bExportLinearFibres
                   % A linear field:
                   FCB = 0;
                   [FB1,FB2,FB3] = obj.GetBasisFromCase(FCB);
                   FnNPE = 8;
                   FvIEo = ones(3,8);
                   FSFI  = zeros(8,1);
                   FLNI  = 1:8;
               else
                   FB1 = basis1; FB2 = basis2; FB3 = basis3; 
                   FnNPE = nNodesPerElement;
                   FvIEo = valueIndicesEXELEMorder;
                   FSFI  = ScaleFactorIndexes;
                   FLNI = LocalNodeIndex;
                   FCB = CaseBasis;
               end
               for iCoor=1:3
                   fprintf(f2,'  %s.  %s*%s*%s, no modify, standard node based.\n',nameFibComp(iCoor).string,FB1,FB2,FB3);
                   fprintf(f2,'    #Nodes= %i\n',FnNPE);
                   obj.PrintValueAndScaleFactorIndices(f2,FCB,FLNI,FSFI,FvIEo,iCoor);
               end
           end
           % 3) Definition of the fields:
           % There are no second versions or scale factors!
           for iF=1:obj.nFields
               iFfile = 1 + iF + obj.bFibres;
               % A condition to know that the field has all
               % the detailed information:
               if isfield(obj.ListOfFields,'field')
                   fname = obj.ListOfFields.field(iF).Name;
                   Type  = obj.ListOfFields.field(iF).Type;
                   SubType  = obj.ListOfFields.field(iF).SubType;
                   nComp = obj.ListOfFields.field(iF).nComponents;
                   fprintf(f2,' %i) %s, %s, %s, #Components=%i\n',iFfile,fname,Type,SubType,nComp);
                   for iComp = 1:nComp
                       ComName = obj.ListOfFields.field(iF).component(iComp).Name;
                       % Default writing options:
                            InterpolationBase = 'standard node based';
                            % Like the coordinate field:
                            SSet = obj.ScaleFactorSet(1);
                       if isfield(obj.ListOfFields,'field')
                           if isfield(obj.ListOfFields.field(iF).component(iComp),'ScaleFactorSet')
                                SSet = obj.ListOfFields.field(iF).component(iComp).ScaleFactorSet;
                           end
                           if isfield(obj.ListOfFields.field(iF).component(iComp),'InterpolationBase')
                               InterpolationBase = obj.ListOfFields.field(iF).component(iComp).InterpolationBase;
                           end
                       end
                       if ~ischar(SSet)
                           SSet = toCharArray(SSet)';
                       end
                       FieldCaseBasis = obj.MapSSet2CaseBasis(SSet);
                       fprintf(f2,'   %s. %s, no modify, %s.\n',ComName,SSet,InterpolationBase);
                       switch InterpolationBase
                           case 'standard node based'
                               % Need to write element definition:
                               fprintf(f2,'    #Nodes= %i\n',nNodesPerElement);
                               % The local node index can be different to that of
                               % the main coordinate field, accordingly to SSet:
                               %FieldLocalNodeIndex = obj.UpdateLocalNodeIndex(LocalNodeIndex,SSet);
                               %fprintf('WARNING! Indexing of scale factors in fields is wrong!\n')
        %                       fprintf('  ... need to start the indexing of fields correctly, \n')
                               obj.PrintValueAndScaleFactorIndices(f2,FieldCaseBasis,LocalNodeIndex);
                           case 'grid based'
                               % Need to print grid interpolation. Now only
                               % constant fields:
                               fprintf(f2,'    #xi1=0, #xi2=0, #xi3=0\n');
                           otherwise
                               fprintf('ERROR! Not recognised InterpolationBase: %s\n',InterpolationBase);
                       end
                   end
               else
                   nameFi = obj.GetFieldName(iF);
                   % Quick hack to make the writting of elevation and
                   % imbrication from DTmri work:
                   if strcmp(nameFi,'elevation')
                       fprintf(f2,' %i) fibres, anatomical, fibre, #Components=3\n',1+iF);
                       fprintf(f2,'  %s.  %s*%s*%s, no modify, standard node based.\n','elevation',basis1,basis2,basis3); 
                       fprintf(f2,'    #Nodes= %i\n',nNodesPerElement);
                       obj.PrintValueAndScaleFactorIndices(f2,CaseBasis,LocalNodeIndex);
                       % It is supposed that the next field is the
                       % imbrication one!!!
                       fprintf(f2,'  %s.  %s*%s*%s, no modify, standard node based.\n','imbrication',basis1,basis2,basis3); 
                       fprintf(f2,'    #Nodes= %i\n',nNodesPerElement);
                       obj.PrintValueAndScaleFactorIndices(f2,CaseBasis,LocalNodeIndex);
                       fprintf(f2,'  %s.  %s*%s*%s, no modify, standard node based.\n','sheet',basis1,basis2,basis3); 
                       fprintf(f2,'    #Nodes= %i\n',nNodesPerElement);
                       obj.PrintValueAndScaleFactorIndices(f2,CaseBasis,LocalNodeIndex);
                   else if strcmp(nameFi,'imbrication')
                           % do nothing
                       else
                           fprintf(f2,' %i) %s, field, rectangular cartesian, #Components=1\n',1+iF,char(nameFi));
                           fprintf(f2,'  %s.  %s*%s*%s, no modify, standard node based.\n','value',basis1,basis2,basis3); 
                           fprintf(f2,'    #Nodes= %i\n',nNodesPerElement);
                           obj.PrintValueAndScaleFactorIndices(f2,CaseBasis,LocalNodeIndex);
                       end
                   end
               end                          
           end
       end
       function []          = PrintElemValues(obj,f2,iElem,CaseBasis)
%             switch obj.InterpolationBasis
%                 case 5
%                     fprintf(f2,' Element: 		0   %i	0\n',iElem);
%                 otherwise
                    fprintf(f2,' Element: 		%i	0	0\n',iElem);
            %end
            % In case of values per element, this should be the first
            % thing:
            if obj.bElemValues
                % only need to write the value of the element:
                fprintf(f2,'	Values:\n');
                % TODO: define data structure for element field values,
                % and export it here:
                fprintf(f2,'	  %1.6f\n',obj.ElemValues(iElem));
            end
                
            switch CaseBasis
                case -1
                    % Do nothing else
                otherwise
                    % Need to write element defintion by nodes:
                    fprintf(f2,'	Nodes:\n');

                    switch obj.nNofElem(iElem)
                        case {64,27}
                            fprintf(f2,' %i	',obj.giNofElem(iElem,:));
                            fprintf(f2,'\n');
                        case 8
                            fprintf(f2,'	%i	%i	%i	%i	%i	%i	%i	%i\n',obj.giNofElem(iElem,1:8));
                        case 7
                            fprintf(f2,'	%i	%i	%i	%i	%i	%i %i\n',obj.giNofElem(iElem,1:7));
                        case 6
                            fprintf(f2,'	%i	%i	%i	%i	%i	%i\n',obj.giNofElem(iElem,1:6));
                        case 5
                            fprintf(f2,'	%i	%i	%i	%i	%i\n',obj.giNofElem(iElem,1:5));
                        case 4
                            fprintf(f2,'	%i	%i	%i	%i	\n',obj.giNofElem(iElem,1:4));
                        case 3
                            fprintf(f2,'	%i	%i	%i	\n',obj.giNofElem(iElem,1:3));
                        otherwise
                            fprintf(1,'WARNING! Wrong number of nodes in the element (must be 3, 4, 6, 7, 8, 27 or 64). 8 nodes is assumed\n');
                            fprintf(f2,'	%i	%i	%i	%i	%i	%i	%i	%i\n',obj.giNofElem(iElem,1:8));
                    end
                    for iSS = 1:obj.nScaleFactorsDefs
                        % Only write if there were scale factors:
                        if iSS==1
                            % The coordinate field:
                            fprintf(f2,'	Scale factors:\n');
                        end

                        SSet = toCharArray(obj.ScaleFactorSet(iSS))';
                        if isempty(SSet)
                            % If synthesis of cubic Hermite
                            CaseBasis = 7;
                        else
                            CaseBasis = obj.MapSSet2CaseBasis(SSet);
                        end
                        switch CaseBasis
                            case -1                        
                                nScaleFactors = 0;
                            case 0
                                nScaleFactors = 8;
                            case 1
                                nScaleFactors = 3;
                            case 3
                                nScaleFactors = 32;
                            case 6
                                nScaleFactors = 27;
                            case {7,8}
                                nScaleFactors = 64;
                        end
                        for j=1:nScaleFactors
                            fprintf(f2,'	%i',1);
                        end
                        fprintf(f2,'	\n');
                    end
            end
        end
       
       function obj2        = Copy(obj)
           obj2.name = [obj.name '_copy'];
           obj2.nElems = obj.nElems;
           obj2.giNofElem = obj.giNofElem;
           obj2.versions = obj.versions;
           obj2.coordinates = obj.coordinates;
           obj2.mapping = obj.mapping;
           obj2.derivatives = obj.derivatives; 
           obj2.Quality = obj.Quality;
           obj2.bQualityCalculated = obj.bQualityCalculated;
           obj2.bQ1Calculated = obj.bQ1Calculated;
           obj2.bQ2Calculated = obj.bQ2Calculated;
           obj2.bQ3Calculated = obj.bQ3Calculated;
           obj2.bQ4Calculated = obj.bQ4Calculated;
           obj2.bQ5Calculated = obj.bQ5Calculated;
           obj2.TetrahedralCanvas = obj.TetrahedralCanvas;
           obj2.bTetrahedralCanvasBuilt = obj.bTetrahedralCanvasBuilt;
           obj2.Wireframe = obj.Wireframe ; 
           obj2.bWireframeBuilt =obj.bWireframeBuilt;
           obj2.OrderVisit8Nodes=obj.OrderVisit8Nodes;
           obj2.OrderVisit6Nodes=obj.OrderVisit6Nodes;
       end
       function EXmesh      = ReadExFiles(obj,exNodeFileName,exElemFileName)
           %EXmesh = obj.ReadExNode(exNodeFileName);
           EXmesh = ReadExNode(exNodeFileName);
%            if EXmesh.nNodes == 0
%                return;
%            end
           EXmesh = ReadExElem(exElemFileName,EXmesh);
       end
       function EXmesh      = ReadExNode(obj,exNodeFileName)
           EXmesh = ReadExNode(exNodeFileName);           
       end
       function EXmesh      = ReadExElem(obj,exElemFileName,EXmesh)
           EXmesh = ReadExElem(exElemFileName,EXmesh);
       end
       function mesh        = ReadLinearMesh(obj, file)
           % Function to load a linear mesh (i.e. VTK format) into this
           % structure "mesh":
        % Name of the mesh:
        % - mesh.name (given the name of the file! Legacy for consistency with CubicMeshClass)
        % Name of the file with the data (no path):
        % - mesh.exNodeFileName
        % Number of nodes of the mesh:
        % - mesh.nNodes
        % Basis function (I guess it will be linear)
        % - mesh.Basis = linear
        % Main field: the coordinates of the nodes
        % - mesh.coordinates(nNodes,1:3) = NodeCoordinates(:,1);
        % DEFINITION OF THE ELEMENTS:
        % � number of elements:
        % - mesh.nElems
        % � with the number of nodes per element (4 always if a triangular surface mesh):
        % - mesh.nNofElem(1: nElems) = 3;
        % � local index of the 3 nodes of each of the elements, usually a 1:3 in each:
        % - mesh.liNofElem(1:nElems,1:nNodesPerElement)= 1:3;
        % � global index of the 3 nodes o each triangle (the topology):
        % - mesh.giNofElem(1:nElems,1:ElementDefinition.NumNodes) = 0;
           mesh = ReadLinearMesh(file);
           mesh.InterpolationBasis = 5;
           mesh.versions(1:mesh.nNodes,1:3) = 1;
       end

       function [obj]       = FillEmptyVersionsOfNodeValues(obj)
           % Function to fill the second, third, etc... versions of node values with the
           % values of the first version. This is done because:
           % - Fitting a deformation field requires the specification of
           % which nodal values has second versions or not. This is
           % specified in the exelem file with the indexes of the values to
           % be taken
           % - Nevertheless, an ipelem file does not have this way of
           % specification, whereas this issue is solved because the cmiss
           % simulation enables the specification of the kind of continuity
           % enforced (C0,C1), what makes that node values that are similar
           % remain similar.
           % 
           % Therefore, the solution for this issue is to fill the
           % secondary versions of the node values that are not used with
           % the values of their first versions
           
           bDebug=0;
           % 1. Find which node versions are used
           NodeVersionsUsed = false(obj.nNodes,3,8,max(max(obj.versions))-1);
           for iElem = 1:obj.nElems
               nLN = obj.nNofElem(iElem);
               GlobalNodes_iElem(1:nLN) =  obj.giNofElem(iElem,1:nLN);
               switch obj.InterpolationBasis
                   case {1,2,3,4}, nElementVertex = 8;
                   case 5, nElementVertex = 3;
               end
               for iln=1:nElementVertex
                   % In case of collapsed elements:
                   iLocalNode = obj.liNofElem(iElem,iln);
                   iNode = GlobalNodes_iElem(iLocalNode);
                   [nNodsVers nCoordsVers] = size(obj.versions);
                   if iNode>nNodsVers
                       fprintf('Error! the local node %i of element %i points to a global node greater than the number of nodes in versions variable (node %i, total %i)\n',iln,iElem,iNode,nNodsVers);
                   end                       
                   for ic=1:3
                       % Check if this node has different versions:
                       if (obj.versions(iNode,ic)>1)
                           % Check if the secondary versions are used:
                           if (bDebug), fprintf(1,'Elem %i, coor %i, local node %i, ValueIndexes = %i %i %i %i %i %i %i %i \n',iElem,ic,iln,obj.valueIndices(iElem,ic,iln,:)); end 
                           for iNodeValue=1:8
                               valIndex = obj.valueIndices(iElem,ic,iln,iNodeValue);
                               version = floor((valIndex-1)/8)+1;
                               if version>1
                                   NodeVersionsUsed(iNode,ic,iNodeValue,version-1)=true;
                                   if (bDebug), fprintf(1,'  Used version %i in node %i, coordinate %i, value %i!\n',version,iNode,ic,iNodeValue); end 
                               end
                           end
                       end
                   end
               end
           end
           % 2. Fill the node values not used:
           for iNode = 1:obj.nNodes
               for iCoor=1:3
                   % Only those nodes with more than 1 version:
                   if (obj.versions(iNode,iCoor)>1)
                       % check that there is at least some second versions
                       % used (for debugging previous steps):
                       if sum(sum(sum((NodeVersionsUsed(iNode,:,:,:)))))==0
                           fprintf('WARNING! Node %i has second versions, but none of them used!!\n',iNode);
                       end
                       for iVersion=2:obj.versions(iNode,iCoor)
                           for iNodeValue=1:8
                               if (~NodeVersionsUsed(iNode,iCoor,iNodeValue,iVersion-1))
                                   % Read the first version:
                                   Value = obj.GetNodeCoorValue(iNode,iCoor,iNodeValue,1);
                                   % Writ the non used version:
                                   obj = obj.SetNodeCoorValue(Value,iNode,iCoor,iNodeValue,iVersion);
                                   if (bDebug)
                                       fprintf(1,'version %i of node %i, coord %i, value %i not used, duplicated from V1\n',iVersion,iNode,iCoor,iNodeValue);
                                   end
                               end
                           end
                       end
                   end
               end
           end
       end
       
       function [Im1,Im2,Im3,hImOut] = WriteFibreImages(obj,dir,name,dirMesh,nameMesh)
           % Function to generate the image of fibres
           % INPUT:
           % - hIm: header of the image to be generated (hIm.origin, hIm.spacing)
           % - dir: directory where images will be written
           % - name: of the images (_x, _y and _z will be added)
           margin = obj.DefaultBBmargin;
           obj = obj.BuildBoundingBox(margin);
           %if nargin<4
               hIm.origin = [obj.BB(1) obj.BB(3) obj.BB(5)];
               hIm.spacing= [1 1 1];
           %end
           if nargin<4
               dirMesh = NaN;
               nameMesh =NaN;
           end
           switch obj.FibreDescriptionType
               case 1
                   ImageKind = ['fibres_Xcomponent';'fibres_Ycomponent';'fibres_Zcomponent'];
               case 2
                   ImageKind = ['fibres_Elevationn';'fibres_Imbricatin';'fibres_SheetAngle'];                   
           end
           nImages = obj.FibDim;
           for iC=1:nImages    
               % Generate three images, one per component:
               ImK = ImageKind(iC,:);
               options.marginORnVoxs    = margin;
               options.ImageKind        = ImK;
               options.dirMesh          = dirMesh;
               options.nameMesh         = nameMesh;
               options.bNeedAccurateGrayscale = 1;
               [BinImage,originAdjusted] = obj.GenerateIm_cmGUI(hIm.spacing,hIm.origin,options);
               hImOut = hIm;
               hImOut.origin = originAdjusted;
               imname = [dir name '_' ImageKind(iC,:) '.vtk'];
               fprintf('Writing %s\n',imname);
               write_image_vtk2(imname,BinImage,hImOut,'binary','b');
               switch iC
                   case 1
                       Im1 = BinImage;
                   case 2
                       Im2 = BinImage;
                   case 3
                       Im3 = BinImage;
               end
           end
       end
               
       function [hdr]       = ExportFieldDescription(obj,dir,EXname,spacing)
           % Function to export a field as a set of regular samples in
           % space
           % Currently only the fibre field with 3 components is possible!
           % 16/09/2010, by PL. 
           ExNodeFileName = [dir EXname '.exdata'];
           if nargin<4
               spacing = [5 5 5];
           else
               if numel(spacing)==1
                   spacing(2) = spacing(1);
                   spacing(3) = spacing(1);
               end
           end
           % The regular set of samples is defined from the Bounding Box of
           % the mesh:
           origin = [obj.BB(1) obj.BB(3) obj.BB(5)];
            % A quick way to know whether a point is in or out is to
           % generate a binary image!
           margin = obj.DefaultBBmargin;
           options.marginORnVoxs = margin;
           options.bNeedAccurateGrayscale = 1;
           [BinIm,OriginAdj] = obj.GenerateIm_cmGUI(spacing,origin,options);
           [nxB,nyB,nzB] = size(BinIm);
           hdr.origin = OriginAdj;
           hdr.spacing= spacing;
           hdr.dim = size(BinIm);
           x = OriginAdj(1):spacing(1):obj.BB(2); nx=numel(x);
           y = OriginAdj(2):spacing(2):obj.BB(4); ny=numel(y);
           z = OriginAdj(3):spacing(3):obj.BB(6); nz=numel(z);
           if nx~=nxB || ny ~=nyB || nz~=nzB
               fprintf('Warning! Image size (%i,%i,%i) does not match expected value (%i,%i,%i)!\n',nxB,nyB,nzB,nx,ny,nz);
               nx=nxB;
               ny=nyB;
               nz=nzB;
           end
           nEvals = nx*ny*nz;
           Points = zeros(3,nEvals);
           nDims = 3;
           Values = zeros(nDims,nEvals);
           iPoint = 0; iEval  = 0; iDecil=0;
           t=tic();
           fprintf('Progress report (CubicMeshClass.ExportFieldDescription)...\n');
           for ix=1:nx
               for iy = 1:ny
                   for iz = 1:nz  
                       iEval = iEval + 1;
                       progress = 10*iEval/nEvals -1;
                       if progress-iDecil>0
                           iDecil = iDecil+1;
                           fprintf('   ... %02.0f%% of points screened\n',iDecil*10);
                       end 
                       GlobalPoint = [x(ix) y(iy) z(iz)]; 
                       Points(1:3,iEval) = GlobalPoint;
                       if(BinIm(ix,iy,iz)>0)                                                 
                           [iElem,xiCoord]  = obj.evaluate_inverse(GlobalPoint);
                           if numel(xiCoord)>0
                               % Only samples inside the domain will be written
                               % out:
                               iPoint = iPoint+1;
                               Value = obj.evaluate(iElem,xiCoord,1,1);
                               Values(1:nDims,iEval) = Value;
                           end
                       end                           
                   end
               end
           end
           time = toc(t);
           fprintf('   ... FINISH! %i points inside the doman sampled. Time taken = %f\n',iPoint,time);
           options.VectorField = Values;
           save([dir EXname '.mat'],'Values','Points');
           WriteExnode(ExNodeFileName,Points,options);
       end
% Image creation
       function [Image,originAdjusted]    = GenerateIm_cmGUI(obj,spacing,origin,options)
           % OUTPUT:
           % - Grayscale image with 256 graylevels!!
           bDebug=1; %Marta, 07/10/2014 from 0
           
           SizingOption=1;
           % variable to control the size of the image:
           %  - 1 (default): a margin is added to the bounding box of the
           %  linear mesh, and increased in case of tiny images.
           %  - 2: the fourth parameter is the size of the image to
           %  generate         
           bAccurateBinary = 0;
           bNeedAccurateGrayscale = 0;
           bRenderLabels = 0;
           
           % Calls to cmGui with absolute windows path will lead to a failure:
           if obj.TempcmGuiDir(2)==':' %comfile(1)=='D' || comfile(1)=='C' || comfile(1)=='E' || comfile(1)=='H'
                % cmGui does not work with absolute windows paths!
                CurrentDir = pwd;
                TargetDir = obj.TempcmGuiDir;
                relativePath = GetRelativePath(CurrentDir,TargetDir);
                obj.TempcmGuiDir = relativePath;
                fprintf('  replaced path of TempcmGuiDir to: %s\n',obj.TempcmGuiDir);
           end
                   
           obj.TempcmGuiDir = obj.ReplaceSlash(obj.TempcmGuiDir);
           dirBinary = obj.TempBinaryDir;
           obj.CheckDir(obj.TempcmGuiDir);
           obj.CheckDir(dirBinary);
           
       %1. Parse parameters:
           % Generate an image of booleans
           if nargin<2, spacing=[1 1 1];        end
           if nargin<3, origin=[obj.BB(1) obj.BB(3) obj.BB(5)]; end
           % Default options:
            margin=obj.DefaultBBmargin;  
            ImageKind = 'binary';
            dirMesh = NaN;
            nameMesh = NaN;
            SlicePlane = obj.ChooseSlicePlaneForCMGUI(spacing);
           if nargin>=4, 
                if isfield(options,'marginORnVoxs')
                    marginORnVoxs = options.marginORnVoxs; 
                    if numel(marginORnVoxs)==1 %It's a margin if numel=1
                        margin=marginORnVoxs;                   
                    else if numel(marginORnVoxs)==3 %It's a size if numel==3
                        SizingOption=2;
                        nVoxels = marginORnVoxs;
                        end
                    end
                end
                if isfield(options,'nVoxels')
                    SizingOption=2;
                    nVoxels = options.nVoxels;
                end
                if isfield(options,'ImageKind'), ImageKind = options.ImageKind; end
                if isfield(options,'dirMesh'), dirMesh = options.dirMesh; end
                if isfield(options,'nameMesh'), nameMesh = options.nameMesh; end
                if isfield(options,'SlicePlane'), SlicePlane = options.SlicePlane; end
                if isfield(options,'bAccurateBinary'), bAccurateBinary = options.bAccurateBinary; end
                if isfield(options,'bDebug'), bDebug = options.bDebug; end
                if isfield(options,'bNeedAccurateGrayscale'), bNeedAccurateGrayscale = options.bNeedAccurateGrayscale; end
                if isfield(options,'MaterialProperties'), MaterialProperties = options.MaterialProperties; end
                if isfield(options,'bRenderLabels'), bRenderLabels = options.bRenderLabels; end
           end
           if(bRenderLabels)
               fprintf(' ... generation of image of kind %s (ignoring previous %s)\n','labels',ImageKind);
               ImageKind = 'labels';
           end
           obj = obj.BuildBoundingBox(margin);
           % The default values are the ones of the binary image (first implementation of this function) 

           if(bDebug), fprintf('At the beginning...\n'); end
           
           
           
           if (numel(spacing)==1), spacing(2:3)=spacing(1);
           else if (numel(spacing)~=3)
               fprintf('ERROR in CubicMeshClass.GenerateIm_cmGUI!! The spacing has not the right size!!\n');
               end
           end
           switch SizingOption
               case 1
                   BBsize=zeros(1,3);nVoxReal=zeros(1,3);nVoxels=zeros(1,3);
                   for j=1:3
                       MarginOrigin2BB = obj.BB((2*(j-1))+1) - origin(j);
                       BBsize(j)  = obj.BB((2*(j-1))+2)-obj.BB((2*(j-1))+1) + 2*MarginOrigin2BB;
                       % The number of voxels is at least 1 (the voxels are centred
                       % in the vertexes of the BB)
                       nVoxReal(j) = BBsize(j)/spacing(j);
                       nVoxels(j) = round(nVoxReal(j));                
                   end
               %2. The origin is the centre of the first voxel: Correct the subvoxel accuracy:
                   %origin = origin + ((nVoxReal - nVoxels).*spacing)/2;
               % - Add half a voxel: 
                   %origin = origin - spacing/2;
                   % A minimum of 10 voxels in Y is set for avoiding problems
                   % with cmGui
                   MinL=10;
                   while nVoxels(1)<MinL||nVoxels(2)<MinL
                       fprintf(1,'nVoxels min not reached!!!! Generation of image with cmGui with (%i,%i,%i) voxels, origin=(%1.1f,%1.1f,%1.1f) and spacing (%1.1f,%1.1f,%1.1f). \n',nVoxels,origin,spacing);
                       AproxSize = [obj.BB(2) obj.BB(4) obj.BB(6)] - [obj.BB(1) obj.BB(3) obj.BB(5)];
                       margin = margin*2;
                       origin = origin - (AproxSize*margin/100);
                       options.marginORnVoxs = margin;
                       options.ImageKind = ImageKind;
                       [Image,originAdjusted]    = obj.GenerateIm_cmGUI(spacing,origin,options);
                       return;
                   end
               case 2
                   % do nothing
           end
                   
           %3. Build the cmGui camera parameters:
               [height width RemoveOneSliceInCoordinate] = obj.WriteCMGUIcamera(spacing,origin,nVoxels,SlicePlane);
               tempname = 'shape2genBinary';
               obj.WriteExFiles([dirBinary tempname '.exnode'],[dirBinary tempname '.exelem'],tempname);
               if(bDebug), fprintf('Just before calling...\n'); end
               options.dirMesh = dirMesh;
               options.nameMesh = nameMesh;
               options.SlicePlane = SlicePlane;
               EstimationElementSize = mean(obj.BB(1:6))/mean(obj.nElems);
               if(bAccurateBinary)
                    ED = 5 * round( EstimationElementSize / mean(spacing));
                    if ED < 5
                        % A mininum of five is prescribed
                        ED = 5; 
                    end
                    options.elementDiscretization = ED;
                    fprintf(1,'Generation of image with cmGui with (%i,%i,%i) voxels, origin=(%1.1f,%1.1f,%1.1f), spacing (%1.1f,%1.1f,%1.1f) and element discretization of %i. \n',nVoxels,origin,spacing,options.elementDiscretization);               
               end
               comfile = [obj.TempcmGuiDir 'genBinary.cmgui'];
               flags.bExit = 1;
               % Generate one image and check that the resolution asked is
               % available with current hardware:
               options.bOneImage = 1;
               NormalizationFactor = obj.GeneratecmGuIScript2writeImages(ImageKind,tempname,options);
               %flags.version = '2.8'; %Added GGG 25/09/13
               
               CallcmGui(comfile,flags);
               temp = imread(sprintf('%sFrame_%i_%s.tiff',dirBinary,1001,tempname));
               [nx ny]=size(temp(:,:,1));
               if ny==width && nx==height
                   fprintf('hardware check passed (enough resolution returned by cmGui)\n')
                   fprintf('       Image resolution asked to cmGui: %i, %i (height,width)\n',height,width)
                   % Now call the generation of the complete stack:
                   options.bOneImage = 0;
                   obj.GeneratecmGuIScript2writeImages(ImageKind,tempname,options);
                   CallcmGui(comfile,flags);
               else
                   fprintf('ERROR! hardware available in this machine does not support resolution requested!\n')
                   fprintf('       Image resolution asked to cmGui: %i, %i (height,width)\n',height,width)
                   fprintf('       Image resolution returned: %i, %i\n',nx,ny)
                   return;
               end
               
               if(RemoveOneSliceInCoordinate>0)
                   % There is one more slice in that dimension:
                   nVoxels(RemoveOneSliceInCoordinate) = nVoxels(RemoveOneSliceInCoordinate) + 1;
               end
               if (strcmp(ImageKind,'binary'))
                   Image=false(nVoxels);
               else
                   Image=zeros(nVoxels);
               end
               switch SlicePlane
                   case {'x','X'}, nSlices = nVoxels(1); IndexingOption = 1;
                   case {'y','Y'}, nSlices = nVoxels(2); IndexingOption = 2;
                   case {'z','Z'}, nSlices = nVoxels(3); IndexingOption = 3;
                   otherwise, fprintf('ERROR! SlicePlane option not recognised (%s) in GenerateIm_cmGUI\n',SlicePlane);
               end
               for i=1:nSlices
                   % For each image generated:
                   % f=i+1000   ->127 NO DATA RANGE, MAX IS 127!
                   f=uint16(i)+1000; 
                   temp = imread(sprintf('%sFrame_%i_%s.tiff',dirBinary,f,tempname));
                   temp = temp(:,:,1);
                   % As it is a binary image, any of the 3 channels is enough:
                   if (strcmp(ImageKind,'binary'))
                       % Enable a much bigger binary image:
                       temp = logical(temp(:,:,1)); 
                   end
                   [t1 t2] = size(temp);
                   [i1 i2 i3] = size(Image);
                   bPermute = 1;
% This should not be an issue any more, cmGui camera and retrieval of images has been adapted (see RemoveOneSliceInCoordinate)                   
%                    if (t1 == t2)
%                        bPermute = 0; 
%                        if i==1
%                            fprintf('WARNING! Image has the same number of voxels in each dimension, and there is a 50%% probability of having a flip in the slice plane while generating images!\n');
%                        end
%                    end
                    switch IndexingOption
                       case 1, 
                           if t1==i3 && t2==i2, if(bPermute), temp = temp'; end; end
                           Image(i,:,:) = temp(:,:);
                       case 2, 
                           if t1==i3 && t2==i1, if(bPermute),  temp = temp'; end; end
                           Image(:,i,:) = temp(:,:);                           
                       case 3, 
                           if t1==i2 && t2==i1, if(bPermute),  temp = temp'; end; end
                           Image(:,:,i) = temp(:,:);
                   end
               end
               switch(RemoveOneSliceInCoordinate>0)
                   case 1, Image = Image(1:end-1,:,:);
                   case 2, Image = Image(:,1:end-1,:);
                   case 3, Image = Image(:,:,1:end-1);
               end                       

               Image = Image/NormalizationFactor;
               if(bDebug),
                   fprintf(1,' Generation of the image finished (now deleting temporary tiff files). \n'); 
                   fprintf(1,'            Max value = %1.1f; \n',max(Image(:))); 
                   fprintf(1,'            Min value = %1.1f; \n',min(Image(:))); 
               end
                
               delete(sprintf('%sFrame_*.tiff',dirBinary));
               originAdjusted=origin;           
       end
       function [BT,hBT]    = CreateBinImageVTK(obj,filenameBinImageVTK,VoxSpacing,origin)
           if nargin<3
               VoxSpacing = 1;
           end
           if nargin<4
               origin=[obj.BB(1) obj.BB(3) obj.BB(5)];
           end
           fprintf(1,'  == CREATING BINARY %s ==\n', filenameBinImageVTK);
           optionsGenBin.origin = origin;
           [BT hBT]    = obj.GenerateBinaryImage(VoxSpacing,optionsGenBin);
           write_image_vtk2(filenameBinImageVTK,BT,hBT,'ascii');
       end
       function [image,h]   = GenerateTarantulaBinary(obj,spacing)
           % Default parameters in these options:
           origin=[obj.BB(1) obj.BB(3) obj.BB(5)];
           nVoxs = round(([obj.BB(2) obj.BB(4) obj.BB(6)]-origin)./spacing);  
           iElems= 1:obj.nElems;
           % And choose the accurate binary!
           bAccurateBinary = 1;
           tempdir = './TarantulaTemp/';
           obj.TempcmGuiDir = tempdir;
           obj.TempBinaryDir= tempdir;
           if exist(tempdir,'dir')==0
               mkdir(tempdir);
           end
           optionsGenBin.origin = origin;
           optionsGenBin.nVoxs = nVoxs;
           optionsGenBin.iElems = iElems;
           optionsGenBin.bAccurateBinary = bAccurateBinary;
           [image,h] = obj.GenerateBinaryImage(spacing,optionsGenBin);
       end
       function [image,h]   = GenerateBinaryImage(obj,spacing,options)
           % 04/02/14: group the options nVoxs,iElems,bAccurateBinary into options
           % 06/08/10: margin (nargin=4) is removed, and nVoxs is used
           % Generate an image of booleans. Two options:
           % 1. By a strategy visiting voxels and labeling them if visited.
           % This is unaccurate, it "overestimates" the volume.
           % 2. By the rendering of isosurfaces with cmGui
           bDebug=0;
           OPTION=2;
           if nargin<2
               spacing=[1 1 1];
           end
               if numel(spacing)==1
                   spacing(2) = spacing(1);
                   spacing(3) = spacing(1);
               end
               % TODO: REVERT TO ORIGINAL VERSION:
               %if spacing(1)~=spacing(2)           
           [SlicePlane] = obj.ChooseSlicePlaneForCMGUI(spacing);
           if strcmp(SlicePlane,'E')
               fprintf(1,'Reverting to non-accurate generation option!\n');               
               OPTION = 1;
           end
           % Remake the bounding box (in case it was not updated before). A
           % bigger margin is specified because it seems that 5 was not
           % enough in some heart cases.
           margin=obj.DefaultBBmargin;
           obj = obj.BuildBoundingBox(margin);
           % Default options
           origin=[obj.BB(1) obj.BB(3) obj.BB(5)];
           nVoxs = round(([obj.BB(2) obj.BB(4) obj.BB(6)]-origin)./spacing);   
           elements=1:obj.nElems;
           if nargin == 3
               if isfield(options,'origin'), origin = options.origin; end
               if isfield(options,'Origin'), origin = options.Origin; end
               if isfield(options,'nVoxs'), nVoxs = options.nVoxs; end
               if isfield(options,'nVox'), nVoxs = options.nVox; end
               if isfield(options,'iElems'), elements = options.iElems; end
               if isfield(options,'bAccurateBinary'), optionsCmgui.bAccurateBinary = options.bAccurateBinary; end
               if isfield(options,'bRenderLabels'), optionsCmgui.bRenderLabels = options.bRenderLabels; end
               if isfield(options,'SlicePlane'), 
                   fprintf('  ...option in generation of image: take plane %s instead of %s\n',options.SlicePlane,SlicePlane);
                   SlicePlane = options.SlicePlane;
               end
               
           end
           
           if nVoxs(1)==0 || nVoxs(2)==0 || nVoxs(3)==0
               fprintf(1,'ERROR! The number of voxels for the image to create is 0 in some of its dimensions!\n');
               fprintf(1,'  Most likely reason is that the units do not agree between data introduced\n');
               fprintf(1,'  (for example, binary image with spacing in mm, and template mesh with units in m)\n');
               return;
           end
           % Add a tiny number to origin in order to avoid cmGUI rendering
           % artifacts when voxel centre is in the edge of an element
           origin = origin + pi*mean(spacing)/1000;          

           fprintf(1,' Generation of binary image of spacing (%1.1f,%1.1f,%1.1f), origin in (%1.1f,%1.1f,%1.1f) and size %i,%i,%i. \n',spacing,origin,nVoxs);
           switch OPTION
               case 1
                   [image,h] = obj.InitialiseBinaryImage(spacing,origin);
                   for iE=elements
                       if (bDebug), fprintf(1,'Filling binary from element %i\n',iE); end
                       image = obj.FillBinaryImage(iE,image,h);
                   end
               case 2
                   optionsCmgui.SlicePlane = SlicePlane;
                   optionsCmgui.marginORnVoxs = nVoxs;
                   [Bin,originAdjusted] = obj.GenerateIm_cmGUI(spacing,origin,optionsCmgui);
                   image     = Bin;
                   h.origin     = originAdjusted;
                   h.spacing    = spacing;
                   h.dim       = size(Bin);
           end
           fprintf(1,' Generation of the binary image finished. \n');
           if (bDebug)
               figure('Color',[1 1 1]); hold on;
               obj.plotWireframe();
               show_segment_surface(image,h.origin,h.spacing);
               title(sprintf('Origin = (%1.1f,%1.1f,%1.1f)',image.origin));
           end
       end
       function [image,h]   = InitialiseBinaryImage(obj,spacing,origin)
           % Initialize a image of booleans
           bDebug=0;
           if nargin<2
               spacing=[1 1 1];
           end
           if nargin<3
               origin=[obj.BB(1) obj.BB(3) obj.BB(5)];
           end
           if (numel(spacing)==1)
               spacing(2:3)=spacing(1);
           else if (numel(spacing)~=3)
               fprintf('ERROR in CubicMeshClass.InitialiseBinaryImage!! The spacing is not well defined!!\n');
               spacing
               end
           end
           %TODO: make it more efficient, with a number of samples
           %different for each xhi dimension!
           nVoxels=zeros(1,3);
           for j=1:3
               BBsize(j)=obj.BB((2*(j-1))+2)-obj.BB((2*(j-1))+1);
               % The number of voxels is at least 1 (the voxels are centred
               % in the vertexes of the BB)
               nVoxels(j)=1+round(BBsize(j)/spacing(j));
           end
           if (bDebug), fprintf(1,'   CubicMeshClass:InitialiseBinaryImage. Size = (%i, %i, %i) voxels\n',nVoxels); end
           image=false(nVoxels(1),nVoxels(2),nVoxels(3));
           % TOCHECK: this is a small hack to force the coordinates to be
           % integers, what will solve the "empty gap in the base of the
           % heart template".
           h.origin     = floor(origin);
           h.spacing    = spacing;
           h.dim       = nVoxels;
       end
       function [image]     = FillBinaryImage(obj,iElem,image,h)
           bDebug    = 0;
           origin    = h.origin;
           spacing   = h.spacing;
           if (bDebug), fprintf(1,'   CubicMeshClass:FillBinaryImage. Origin = (%f,%f,%f); Spacing = (%f,%f,%f).\n',origin,spacing); end
           % Estimation of the number of pointss:
           iE=iElem;
               % Assess the size of the element to get the number of points
               % to generate:
               [ind,nn] = obj.GetNodeIndexesOfElement(iE);
               points(1:nn,1:3) = obj.coordinates(ind(1:nn),:,1);

               % TODO: fix this "hacked" interpretation of the collapsed
               % elements with the new fields (see .evaluate)
               if nn==6
               % In case of a collapsed element, the values are
               % repeated in a fashion shown in the exelem file. Four 
               % options are coded here: 
               % - Collapse xhi3=0 plane 1-2-1-2-3-4-5-6 (Fernandez2004)
               % - Collapse xhi1=1 plane 1-2-3-2-4-5-6-5
               % - Collapse xhi1=0 plane 1-2-1-3-4-5-4-6
               % - Collapse xhi2=0 plane 1-1-2-3-4-4-5-6 (heart.exnode
               % given by S.Niederer)
               CollapseOption=4;
                   if (CollapseOption==1)
                       points(8,1:3)=points(6,1:3);
                       points(7,1:3)=points(5,1:3);
                       points(6,1:3)=points(4,1:3);
                       points(5,1:3)=points(3,1:3);
                       points(4,1:3)=points(2,1:3);
                       points(3,1:3)=points(1,1:3);
                   end
                   if (CollapseOption==2)
                       points(8,1:3)=points(5,1:3);
                       points(7,1:3)=points(6,1:3);
                       points(6,1:3)=points(5,1:3);
                       points(5,1:3)=points(4,1:3);
                       points(4,1:3)=points(2,1:3);
                   end
                   if (CollapseOption==3)
                       points(8,1:3)=points(6,1:3);
                       points(7,1:3)=points(4,1:3);
                       points(6,1:3)=points(5,1:3);
                       points(5,1:3)=points(4,1:3);
                       points(4,1:3)=points(3,1:3);
                       points(3,1:3)=points(1,1:3);
                   end
                   if (CollapseOption==4)
                       points(8,1:3)=points(6,1:3);
                       points(7,1:3)=points(5,1:3);
                       points(6,1:3)=points(4,1:3);
                       points(5,1:3)=points(4,1:3);
                       points(4,1:3)=points(3,1:3);
                       points(3,1:3)=points(2,1:3);
                       points(2,1:3)=points(1,1:3);
                   end
               end
               % Get the linear length of each xhi component:
               BBxhi=zeros(1,3);
               for ixhi=1:3
                   % In each element there are twelve "edges" to be
                   % compared, taking the longest one. In the mapping
                   % structure we have defined mapping.Lines.Nodes, which
                   % point to the right nodes to check the length:
                   i1=[1 5 9];
                   i2=[4 8 12];
                   for inode=i1(ixhi):i2(ixhi)
                       in1=obj.mapping.Lines.Nodes(1,inode);
                       in2=obj.mapping.Lines.Nodes(2,inode);
                       length=sqrt(sum((points(in1,:)-points(in2,:)).^2));
                       if length>BBxhi(ixhi)
                           BBxhi(ixhi)=length;
                       end
                   end
               end
               % Number of samples in each xhi dimension to "sample the
               % space":
               ShapeMargin = 0.51; % Increase this number if holes in the volume!
               % This is a factor between the ratio between the actual 
               % arclenght of the element and the the linear
               % distance between nodes. 
               nXhiSamples(1:3)=ceil((1+ShapeMargin)*BBxhi./spacing + ShapeMargin);
               
               % This leads to a number of nSamples of 3D points:
               nSamples = prod(nXhiSamples);
               %fprintf(1,'   ...generation of binary image, processing element %i with (%i,%i,%i) samples in xhi direction. nSamples=%i\n',iE,nXhiSamples,nSamples);
               % Each point will be have xhi coordinates equally spaced:
                   % Samples of each dimension:
                   if nXhiSamples(1)==1, nXhiSamples(1)=2; end
                   if nXhiSamples(2)==1, nXhiSamples(2)=2; end
                   if nXhiSamples(3)==1, nXhiSamples(3)=2; end
                   xh1=0:1/(nXhiSamples(1)-1):1;
                   xh2=0:1/(nXhiSamples(2)-1):1;
                   xh3=0:1/(nXhiSamples(3)-1):1;
                   xh1=single(xh1);
                   xh2=single(xh2);
                   xh3=single(xh3);
                   % Matrixes of xhi coordinates:
                   xhi1=repmat(xh1,1,nXhiSamples(2)*nXhiSamples(3));
                   xhi2=single(zeros(1,nSamples));
                   xhi3=single(zeros(1,nSamples));
                   for i=1:nXhiSamples(2)
                       % The first nXhiSamples(1)*nXhiSamples(2) values of xhi2:
                       xhi2(1+(i-1)*nXhiSamples(1):i*nXhiSamples(1))=repmat(xh2(i),1,nXhiSamples(1));
                   end
                   for i=1:nXhiSamples(3)
                       % Xhi3 is a repetition of each xhi a number of
                       % nXhiBlok3 times:
                       nXhiBlok3=nXhiSamples(1)*nXhiSamples(2);
                       xhi3(1+(i-1)*nXhiBlok3:i*nXhiBlok3)=repmat(xh3(i),1,nXhiBlok3);
                       xhi2(1+(i-1)*nXhiBlok3:i*nXhiBlok3)=xhi2(1:nXhiBlok3);
                   end
                   clear xh1 xh2 xh3;

               bGoPointbyPoint=0;
               % Each of these points is visited and the voxel is marked as 1:
               if (bGoPointbyPoint)
                   for i=1:nSamples
                       xiCoordinate=[xhi1(i) xhi2(i) xhi3(i)];
                       point=obj.evaluate(iE,xiCoordinate);
                       %voxelIndex=obj.Point2VoxelCoords(point);
                       voxelIndex(1:3) = [1 1 1] + round((point(1:3)-origin(1:3))./spacing(1:3));
                       if (voxelIndex(1)<1)||(voxelIndex(2)<1)||(voxelIndex(3)<1)
                           fprintf(1,' Index null, INDEX=(%i,%i,%i), point = (%d,%d,%d), origin = (%d,%d,%d)\n',voxelIndex,point,origin);
                       else
                           image(voxelIndex(1),voxelIndex(2),voxelIndex(3))=1;
                           % CAUTION!!!! binary(voxelIndex)=1; DOES NOT PRODUCE
                           % THE SAME EFFECT AT ALL!!!!
                           nVoxelChanged1=nVoxelChanged1+1;
                       end

                   end
               else
                   %XhiCoordinates = [xhi1;xhi2;xhi3];
                   %clear xhi1 xhi2 xhi3;
                   if(~isunix())
                       mem = memory;
                       % Estimated that in the function we'll need 200
                       % variables of 8 Bytes... and the biggest has 64+margin
                       MaxnSamples1 = floor(mem.MaxPossibleArrayBytes/(150*8));
                       MaxnSamples2 = floor(mem.MemAvailableAllArrays/(200*8));
                       MaxnSamples=min(MaxnSamples1,MaxnSamples2);
                   else
                       % Guess of the block that can be instantiated in
                       % memory in a linux machine:
                       MaxnSamples = 1000;
                   end
                   if nSamples<MaxnSamples
                       points = obj.fastCoordinateEvaluation(iE,[xhi1;xhi2;xhi3]);
                       voxelIndexes(1:3,1:nSamples)= ([1 1 1]'*ones(1,nSamples)) + round(  (points(1:3,1:nSamples) - (origin(1:3)'*ones(1,nSamples)) ) ./ (spacing(1:3)'*ones(1,nSamples)));
                       if numel(find(isnan(voxelIndexes)))>0
                           fprintf(' ERROR! NaN in voxelIndexes (N = %i)\n',numel(find(isnan(voxelIndexes))));
                       end
                       for i=1:nSamples                           
                           image(voxelIndexes(1,i),voxelIndexes(2,i),voxelIndexes(3,i))=1;
                       end
                   else                       
                       nBlocks = ceil(nSamples/MaxnSamples);
                       if (~isunix())
                           fprintf(1,'      nSamples divided in %i blocks of %i samples (MaxPossibleArrayBytes = %i, MemAvailableAllArrays=%i)\n',nBlocks,MaxnSamples,mem.MaxPossibleArrayBytes,mem.MemAvailableAllArrays);
                       end
                       for iB=1:nBlocks
                           iXhi1 = 1 + (iB-1)*MaxnSamples;
                           if (iB == nBlocks)
                               iXhi2 = nSamples;
                           else
                               iXhi2 = iB*MaxnSamples;
                           end
                           nSamplesiB = iXhi2-iXhi1+1;
                           voxelIndexes(1:3,1:nSamplesiB)=zeros(3,nSamplesiB,'uint16');
                           points = obj.fastCoordinateEvaluation(iE,reshape([xhi1(iXhi1:iXhi2);xhi2(iXhi1:iXhi2);xhi3(iXhi1:iXhi2)],3,iXhi2-iXhi1+1));
                           temp = round(  (points(1:3,1:nSamplesiB) - (origin(1:3)'*ones(1,nSamplesiB)) ) ./ (spacing(1:3)'*ones(1,nSamplesiB)));
                           voxelIndexes(1:3,1:nSamplesiB)= ([1 1 1]'*ones(1,nSamplesiB)) + temp;
                           for i=1:nSamplesiB                        
                               image(voxelIndexes(1,i),voxelIndexes(2,i),voxelIndexes(3,i))=1;
                           end
                           clear voxelIndexes points temp;
                       end
                   end
                   clear points;
                   if ~isunix()
                       clear mem;
                   end
                   
                   
                   clear temp voxelIndexes points;
               end
       end
       function [height width RemoveOneSliceInCoordinate]    = WriteCMGUIcamera(obj,spacing,origin,nVoxels,SlicePlane)
           % Function to write the cmGUI parameters needed for the
           % binarization. The flag RemoveOneSliceInCoordinate is used to
           % indicate that the camera is prepared with an additional column
           % in order to know uniquely what is the height and what the
           % width of the image by its size.
           bDebug = 0;
           RemoveOneSliceInCoordinate = 0;
           obj.TempcmGuiDir = obj.ReplaceSlash(obj.TempcmGuiDir);
           obj.CheckDir(obj.TempcmGuiDir);
           file=[obj.TempcmGuiDir 'SetCameraForBinarisation.com'];
           [f msg]=fopen(file,'w');
           if(f==-1)
             disp(msg);
             disp('Could not open file:');
             disp(file);
             return;
           end
           if nargin<5
               axisView = '+Z';
           end
           
           
           % Image Size: tricky and important number:
           % - not exactly the same as the Bounding Box, it is a discrete
           % number of voxels
           % - the "length" in each dimension is one less voxel, since this
           % measures the distance between the centres of the voxels, this
           % is what should be used for the calculi of view_angle
           ImSize = (nVoxels-1).*spacing;
           switch SlicePlane
               case {'z','Z','+z','+Z'}
                   widthCoord = 1;
                   nFrames = nVoxels(3);
                   height  = nVoxels(2);                   
                   StackDepth=ImSize(3);
               case {'x','X','+x','+X'}
                   nFrames = nVoxels(1);
                   height  = nVoxels(2);
                   widthCoord = 3;
                   StackDepth = ImSize(1);
               case {'y','Y','+y','+Y'}            
                   nFrames = nVoxels(2);
                   height  = nVoxels(1);
                   widthCoord = 3;
                   StackDepth = ImSize(2);
           end
           width   = nVoxels(widthCoord);
           % Break the symetry of height and width:
           if height == width
               % Addition of two voxels, so the IP and EP need to be sifted
               % one voxel
               nPixelsAdded = 1;
               fprintf(' cmGui camera preparation: adding %i voxels to break same size in X and Y\n',nPixelsAdded);
               width = width + nPixelsAdded;
               RemoveOneSliceInCoordinate = widthCoord;
               % 16/12/13: it is detected that the solution introduces a
               % shape bias in this dimension of one pixel!
           end
           % Needed for float calculi:
           nVoxels=double(nVoxels);   
           ImSize =double(ImSize);
           
           % IP3EPdist is an arbitrary distance from IP to EP
           IP3EPdist = 5*StackDepth;
           % Interest Point:
           %IP = origin + BBsize/2';
           IP = origin + ImSize/2';% - 3*[spacing(1) spacing(2) 0];
           % 16.12.13: the additional offset was with +, not with -!! 
           if(RemoveOneSliceInCoordinate>0)
               AddedWidthOffset = [0 0 0];
               AddedWidthOffset(widthCoord) = nPixelsAdded * spacing(widthCoord) / 2;
               IP = IP + AddedWidthOffset;
           end
           % Eye Point: 
           switch SlicePlane
               case {'z','Z','+z','+Z'}
                   % "from above": Up is in Y direction (can't be in Z, as
                   % it was before, otherwise up and view directions are
                   % colinear! (fixed 11/09/2012)
                   % In order to have the same orientation as before, need
                   % to have -Y (checked in Sheffield cases, 02/10/12),
                   % chances of not being completely robust).                   
                   up_vector = [0 -1 0];
                   view_vector = [0 0 IP3EPdist];  
                   EP = IP - view_vector;                 
                   FirstSliceOri = origin(3);
                   sliceDistance = spacing(3);
                   MinAxis = min(spacing(1)*nVoxels(1),spacing(2)*nVoxels(2));
               case {'x','X','+x','+X'}
                   bFirstDefinitionChanged30072012 = 1;
                   if(bFirstDefinitionChanged30072012)
                       up_vector = [0 -1 0];
                       EP = IP + [IP3EPdist 0 0];
                   else
                       up_vector = [0 -1 0];
                       EP = IP - [IP3EPdist 0 0];                       
                   end
                   FirstSliceOri = origin(1);
                   sliceDistance = spacing(1);
                   MinAxis = min(spacing(2)*nVoxels(2),spacing(3)*nVoxels(3));
               case {'y','Y','+y','+Y'}
                   % P.Lamata (18/12/2013): quite important to have the
                   % right up_vector sign, and this seems to be positive
                   % (otherwise a mirrowed image is generated)
                   up_vector = [-1 0 0];
                   view_vector = [0 IP3EPdist 0];  
                   EP = IP - view_vector;  
                   FirstSliceOri = origin(2);
                   sliceDistance = spacing(2);     
                   MinAxis = min(spacing(1)*nVoxels(1),spacing(3)*nVoxels(3));
           end
           % view angle: with respect to the minimum length of the canvas           
           theta = 2*atan(MinAxis/(sqrt(2)*IP3EPdist)) *180/pi;
           
           %Clipping planes taking into account the position of the camera:
           minZBB = 3*StackDepth;
           maxZBB = 7*StackDepth;
           
           fprintf(f,'# Set the right orthographic camera canvas:\n');
           fprintf(f,'gfx mod win 1 layout 2d ortho_axes Z Y\n');
           fprintf(f,'gfx mod win 1 layout height %i width %i\n',height,width);
           fprintf(f,'gfx mod win 1 view up_vector %1.5f %1.5f %1.5f\n',up_vector);
           fprintf(f,'# The angle of the camera is related to the distance from the EyePoint to the InterstPoint: \n');
           fprintf(f,'gfx mod win 1 view eye_point %1.5f %1.5f %1.5f \n',EP);
           fprintf(f,'gfx mod win 1 view interest_point %1.5f %1.5f %1.5f \n',IP);
           fprintf(f,'gfx mod win 1 view view_angle %1.5f \n',theta);
           fprintf(f,'gfx mod win 1 view near_clipping_plane %1.5f \n',minZBB);
           fprintf(f,'gfx mod win 1 view far_clipping_plane %1.5f \n',maxZBB);
           %fprintf(f,'gfx mod win 1 view up_vector %1.5f %1.5f %1.5f\n',[ 0 0 1]);
           fprintf(f,'$nFrames = %i \n',nFrames);
           fprintf(f,'$origin3 = %1.5f \n',FirstSliceOri);
           fprintf(f,'$res_Z   = %1.5f \n',sliceDistance);
           fprintf(f,' \n');
           fclose(f);
           if (bDebug)
               figure('Color',[1 1 1]); hold on;
               obj.plotWireframe();
               obj.plotBB();
               plot3(IP(1),IP(2),IP(3),'r*');
               plot3(EP(1),EP(2),EP(3),'r*');
               title('Linear mesh and Bounding Box. Interest Point and Eye Point');
           end
       end
       
% Evaluation functions:
       function [iCoor iNode iValue version] = GetDofMeaning(obj,iDof)
           TotalDofsFirstVersion = obj.nNodes * 8;
           if iDof<=TotalDofsFirstVersion
               fprintf('GetDofMeaning: functionality not implemented yet!\n');
           else
               Matrix = obj.NewBasisIndex(:,:,:,:);
               iDof = iDof - TotalDofsFirstVersion;
               I=find(Matrix==iDof);
               [iCoor iNode iValue version] = ind2sub(size(Matrix),I);
           end
       end
       function [index]     = GlobalBasisIndexComplete(obj,iElem,iLocalNode,iContinuity,iCoor)
           % This is taking into accound secondary versions
           % In case collapsed elements:           
            iLocal = obj.liNofElem(iElem,iLocalNode);
            iGlobalNode = obj.giNofElem(iElem,iLocal);
            index = (iGlobalNode-1)*8 + iContinuity;
            % Now, check if it should be the second version:
            version = ceil(double(obj.valueIndices(iElem,iCoor,iLocalNode,iContinuity))/8);
            if version>1
                index = obj.NewBasisIndex(iCoor,iGlobalNode,iContinuity,version);
            end
       end
       function [points,xiC]= ReconstructSurface(obj,iElem,iFace,nSamples)
           % Function to reconstruct a cloud of points of a surface of an
           % element.
           % INPUT:
           % - iElem: global index of the element
           % - iFace: which surface to reconstruct:
           %        0: all surfaces (6 of them)
           %        5: xhi1=0
           %        6: xhi1=1
           %        3: xhi2=0
           %        4: xhi2=1
           %        1: xhi3=0
           %        2: xhi3=1
           % - nSamples: number of points in each xhi dimension
           % OUTPUT:
           % - points: 3D global coordinates of the points
           % - xiC: 3D local coordinates of the points
           
           if nargin<3
               option = 0;
           end
           if nargin<4
               nSamples = 5;
           end
           if nSamples==1
               xhi=0.5;
               xhia=xhi;
               xhib=xhi;
           else
               xhi=0:1/(nSamples-1):1;
               xhia=repmat(xhi,1,nSamples);
               xhib=zeros(1,nSamples*nSamples);
           end
           for i=1:nSamples
               xhib(1+(i-1)*nSamples:i*nSamples)=repmat(xhi(i),1,nSamples);
           end
           XiCoor2D = [xhia;xhib];
           points   = obj.evaluateFace(iElem,iFace,XiCoor2D);
           xiC      = XiCoor2D;
       end
       function [GaussPts2D]= GetSurfaceGaussPoints(obj,iElem,iFace,GaussOrder)
           % Function which gets the Gauss Points of a surface
           % INPUT:
           % - iElem: global index of the element
           % - iFace: which surface to reconstruct:
           %        0: all surfaces (6 of them)
           %        5: xhi1=0
           %        6: xhi1=1
           %        3: xhi2=0
           %        4: xhi2=1
           %        1: xhi3=0
           %        2: xhi3=1
           % - GaussOrder: number of points in each xhi dimension
           % OUTPUT:
           % - points: 3D global coordinates of the points
           % - xiC: 3D local coordinates of the points
           
           if nargin<3
               option = 0;
           end
           if nargin<4
               GaussOrder = 3;
           end
           if GaussOrder==1
               xhi=0.5;
               xhia=xhi;
               xhib=xhi;
               gw2d = 1;
           else
               LocalGaussPoints1D = obj.GetLocalGaussCoords1D(GaussOrder);
               gw   = LocalGaussPoints1D.GaussWeights;
               gw2d = gw'*gw;
               GaussPointLocalCoordinate = LocalGaussPoints1D.GPxhi;
               xhi  = GaussPointLocalCoordinate;
               xhia=repmat(xhi,1,GaussOrder);
               xhib=zeros(1,GaussOrder*GaussOrder);
           end
           for i=1:GaussOrder
               xhib(1+(i-1)*GaussOrder:i*GaussOrder)=repmat(xhi(i),1,GaussOrder);
           end
           XiCoor2D = [xhia;xhib];
           points   = obj.evaluateFace(iElem,iFace,XiCoor2D);
           %xiC      = XiCoor2D;
           GaussPts2D.LocalCoordinates = XiCoor2D;
           GaussPts2D.GlobalCoordinates = points;
           GaussPts2D.GaussWeights2D = gw2d;     
       end
       function [points]    = GetAllGaussPoints(obj,GaussOrder)       
           nPtsPerElem = GaussOrder^3;
           nPoints = obj.nElems * nPtsPerElem;
           points = zeros(3,nPoints);
           for iElem=1:obj.nElems
               GaussPts = obj.GetGlobalGaussPoints(iElem,GaussOrder);
               iP0 = (iElem-1)*nPtsPerElem + 1;
               iP1 = iP0 + nPtsPerElem - 1;
               for iC=1:3
                   points(iC,iP0:iP1) = reshape( GaussPts.GlobalCoordinates(:,:,:,iC),1,nPtsPerElem);
               end
           end
       end
       function [value]     = fastCoordinateEvaluation(obj,iElem,xiCoordinates,options)
           % Function to make an "optimised" evaluation of coordinates (an
           % optimised version of "obj.evaluate" for a big set of xiCoordinates:
           %
           % INPUT: options
           % - continuity: code to indicate which value to evaluate (only
           % if c.Hermite)
           %        1: (default) the value of the field, u 
           %        2: the derivative vs. xi1, duds1
           %        3: the derivative vs. xi2, duds2
           %        4: the derivative vs. xi3, duds3 
           %        5: the derivative vs. xi1&xi2, duds12
           %        6: the derivative vs. xi1&xi3, duds13
           %        7: the derivative vs. xi2&xi3, duds23
           %        8: the derivative vs. xi1&xi2&xi3, duds123
           % - whichField:
           %        0: coordinate field
           %        1: fibre field
           % 
           % CAUTION! Numbering of continuity is different in a exelem file.
           
           
           % Default options:
               % Evaluate the nodal value (not derivative):
               continuity=1;
               % Evaluate the coordinate field
               whichField = 0;
           if nargin==4
               if isfield(options,'continuity'), continuity = options.continuity; end
               if isfield(options,'whichField'), whichField = options.whichField; end
           end
           
           bParametersAreCorrect=1;
       % 0.Check the correctness of the parameters:
           if iElem<1 || iElem>obj.nElems
               fprintf(1,'ERROR!! in parameters of CubicMeshClass:fastCoordinateEvaluation. iElem = %i is not a valid index\n',iElem);
               bParametersAreCorrect=0;
           end
           if numel(find(isnan(xiCoordinates)))>0
               I=find(isnan(xiCoordinates));
               fprintf(1,'ERROR!! in parameters of CubicMeshClass:fastCoordinateEvaluation. xiCoordinates have NaN values (for example the coordinate %i)!\n',I(1));
               bParametersAreCorrect=0;
           end
           if numel(find(xiCoordinates>1))>0 || numel(find(xiCoordinates<0))>0
               fprintf(1,'ERROR!! in parameters of CubicMeshClass:fastCoordinateEvaluation. xiCoordinates introduced are not valid, i.e. in the range [0 1]\n');
               bParametersAreCorrect=0;
           end
           if (bParametersAreCorrect)
               nCoordinates = numel(xiCoordinates)/3;
               xiCoordinates=reshape(xiCoordinates,3,nCoordinates);
               %fprintf(1,'      ... FastCoordinateEvaluation of %i points\n',nCoordinates);
               BasisValues = zeros(64,nCoordinates);
               value       = zeros(3,nCoordinates);
           % 1. Get the value of the basis function in these coordinates:
               switch obj.InterpolationBasis
                   case {1,'c.Hermite'}
                       value1DCH   = zeros(3,4,nCoordinates);           
                       value1DdCH  = zeros(3,4,nCoordinates);
                       for k=1:3
                           value1DCH(k,1:4,1:nCoordinates) = obj.CubicHermite(xiCoordinates(k,:));
                           if numel(find(isnan(value1DCH(k,1:4,1:nCoordinates))))>0
                               I=find(isnan(value1DCH(k,1:4,1:nCoordinates)));
                               fprintf('   ERROR! NaN in the Cubic Hermite function value, with k=%i. First problematic xiCoordinate = %i\n',k,xiCoordinates(k,I(1)));
                           end
                           value1DdCH(k,1:4,1:nCoordinates) = obj.derivCubicHermite(xiCoordinates(k,:));
                       end
                       for b=1:64
                           multiplicands=zeros(3,nCoordinates);
                           for k=1:3
                               % 'ib': index (1 to 4) of the Cubic Hermite function
                               ib=obj.mapping.IndexOf64CHBasis(k,b);
                               for ic=1:nCoordinates
                                   switch continuity
                                       case 1,
                                           multiplicands(k,ic) = value1DCH(k,ib,ic);
                                       case 2
                                           if k==1
                                               multiplicands(k,ic)=value1DdCH(k,ib,ic);        
                                           else
                                               multiplicands(k,ic)=value1DCH(k,ib,ic);
                                           end
                                       case 3
                                           if k==2
                                               multiplicands(k,ic)=value1DdCH(k,ib,ic);        
                                           else
                                               multiplicands(k,ic)=value1DCH(k,ib,ic);
                                           end
                                       case 4
                                           if k==3
                                               multiplicands(k,ic)=value1DdCH(k,ib,ic);        
                                           else
                                               multiplicands(k,ic)=value1DCH(k,ib,ic);
                                           end                                   
                                       case 5
                                           if k==3
                                               multiplicands(k,ic)=value1DCH(k,ib,ic);        
                                           else
                                               multiplicands(k,ic)=value1DdCH(k,ib,ic);
                                           end                                   
                                       case 6
                                           if k==2
                                               multiplicands(k,ic)=value1DCH(k,ib,ic);        
                                           else
                                               multiplicands(k,ic)=value1DdCH(k,ib,ic);
                                           end                                   
                                       case 7
                                           if k==1
                                               multiplicands(k,ic)=value1DCH(k,ib,ic);        
                                           else
                                               multiplicands(k,ic)=value1DdCH(k,ib,ic);
                                           end
                                       case 8
                                           multiplicands(k,ic)=value1DdCH(k,ib,ic);
                                       otherwise,
                                           fprintf(' ERROR: wrong selection of continuity in CubicMeshClass.fastCoordinateEvaluation\n');                           
                                   end
                               end
                           end
                           if numel(find(isnan(multiplicands)))>0
                               fprintf('  ERROR! NaN in multiplicands. b=%i. ib=%i Continuity=%i\n',b,ib,continuity);
                           end
                           BasisValues(b,1:nCoordinates)=prod(multiplicands,1);
                       end
                   case {2,'c.Lagrange'}
                       % A variable to store the values of the 1D c.Lagrange
                       % function, with shifts of 1/3
                       value1DCL = zeros(3,4,nCoordinates);    
                       for k=1:3
                           value1DCL(k,1:4,1:nCoordinates) = obj.CubicLagrange(xiCoordinates(k,:));
                       end
                       % The value of the 3D basis function is the prod of the
                       % 3 functions in 1D:
                       for b=1:64
                           multiplicands = zeros(3,nCoordinates);                       
                           for k=1:3
                               ib=obj.CLmapping(k,b);
                               for ic=1:nCoordinates
                                   multiplicands(k,ic) = value1DCL(k,ib,ic);
                               end
                           end
                           BasisValues(b,1:nCoordinates)=prod(multiplicands,1);
                       end
                   otherwise
                       fprintf('ERROR! evaluation not implemented yet in class for basis function %s\n',obj.InterpolationBasis);
               end
               switch obj.InterpolationBasis
                   case {1,'c.Hermite'}
                       % 2. Get the coefficients from the nodes of the element, one set
                       % for each (x,y,z) coordinate:
                           u = obj.Get192elementValues(iElem,whichField);
                       % 3. Multiply coefficients and basis:
                           Coefficients= zeros(3,64);
                           for icontinuity=1:8
                               for inode=1:8
                                   ic=(icontinuity-1)*8+inode;
                                   Coefficients(1:3,ic)=u(1:3,icontinuity,inode);
                               end
                           end
                   case {2,'c.Lagrange'}
                       % Get the 64 nodes of the element: CAUTION! the
                       % ordering of these 64 nodes is assumed to be known!
                       Coefficients(1:3,1:64) = obj.GetNodeCoorValue(obj.giNofElem(iElem,:))';
                   otherwise
                       fprinf('ERROR! evaluation not implemented yet in class for basis function %s\n',obj.InterpolationBasis);
               end
               for k=1:3
                   for ic=1:nCoordinates
                       value(k,ic)=sum(BasisValues(:,ic)'.*Coefficients(k,:));
                   end
               end
               if numel(find(isnan(value)))>0
                   fprintf(' ERROR!! NaN returned by CubicMeshClass:fastCoordinateEvaluation, iElem = %i (N = %i out of nCoordinates = %i)\n',iElem,numel(find(isnan(value))),nCoordinates);
                   fprintf('             ... NaN in %i elements of the Basis Values\n',numel(find(isnan(BasisValues))));
                   fprintf('             ... NaN in %i elements of the Coefficients\n',numel(find(isnan(Coefficients))));
               end    
           end
       end
       function [value]     = evaluate(obj,iElem,xiCoordinate,whichNodalValue,whichField)
           % Evaluate a field (the value or derivative) of a mesh in an 
           % element 'iElem' at xi coordinates 'xiCoordinate'
           % INPUT:
           % - whichNodalValue: code to indicate which value to evaluate (coding
           % similar to the 'Continuity'
           %        1: (default) the value of the field, u 
           %        2: the derivative vs. xi1, duds1
           %        3: the derivative vs. xi2, duds2
           %        4: the derivative vs. xi3, duds3
           %        5: the derivative vs. xi1&xi2, duds12
           %        6: the derivative vs. xi1&xi3, duds13
           %        7: the derivative vs. xi1&xi3, duds23
           %        8: the derivative vs. xi1&xi2&xi3, duds123
           % - whichField:
           %        0: coordinate field
           %        1: fibre field
           if nargin<4
               whichNodalValue=1;
           end
           if nargin<5
               whichField = 0;
           end
           option = whichNodalValue;
           value=zeros(1,3);
       % 1. Get the value of the basis function in this coordinate:
           BasisValues = zeros(1,64);
           value1DCH=zeros(3,4);
           value1DdCH=zeros(3,4);
           for k=1:3
               value1DCH(k,1:4) = obj.CubicHermite(xiCoordinate(k));
               value1DdCH(k,1:4) = obj.derivCubicHermite(xiCoordinate(k));
           end
           for b=1:64
               multiplicands=zeros(1,3);
               for k=1:3
                   % 'ib': index (1 to 4) of the Cubic Hermite function
                   ib=obj.mapping.IndexOf64CHBasis(k,b);
                   switch option
                       case 1,
                           multiplicands(k)=value1DCH(k,ib);        
                       case {2,3,4},
                           if k==(option-1) % a way to code which dimension has the derivative:
                               multiplicands(k)=value1DdCH(k,ib);        
                           else
                               multiplicands(k)=value1DCH(k,ib);        
                           end
                       case {5,6,7}
                           if k==(8-option) % a way to code with dimension has the value:
                               multiplicands(k)=value1DCH(k,ib);        
                           else
                               multiplicands(k)=value1DdCH(k,ib);        
                           end
                       case 8
                           multiplicands(k)=value1DdCH(k,ib);
                       otherwise,
                           fprintf(' ERROR: wrong selection of option in CubicMeshClass.evaluate\n');
                   end
               end
               BasisValues(b)=prod(multiplicands);
           end
           %fprintf('Max(basis), should be in <1    =  %1.3f\n',max(BasisValues));
           %fprintf('Min(basis), should be in >-0.2 =  %1.3f\n',min(BasisValues));
       % 2. Get the coefficients from the nodes of the element, one set
       % for each (x,y,z) coordinate:
           switch whichField
               case 0
                    u = obj.Get192elementValues(iElem);
               otherwise
                   u = obj.Get192elementValues(iElem,whichField);
           end
       
       % 3. Multiply coefficients and basis:
           Coefficients= zeros(3,64);
           for icontinuity=1:8
               for inode=1:8
                   ic=(icontinuity-1)*8+inode;
                   Coefficients(1:3,ic)=u(1:3,icontinuity,inode);
               end
           end
           for k=1:3
               value(k)=sum(BasisValues.*Coefficients(k,:));
           end
%            if value(3)<0.5
%                fprintf(' Evaluation in element %i, xiCoords(%1.1f,%1.1f,%1.1f)=(%1.1f,%1.1f,%1.1f)\n',iElem,xiCoordinate,value);
%                for inode=1:8
%                     fprintf('     coords node%i (globalnode%i): (%1.1f,%1.1f,%1.1f) \n',inode,nodes(inode),u(:,1,inode));
%                     % TODO: nodes(inode) only works for normal elements,
%                     % not for collapesed ones! In this case, the two last
%                     % elements will have globalnode=0, they are indexed in
%                     % order 1-2-1-2-3-4-5-6
%                end
% %                figure
% %                hold on
% %                cc=['r' 'g' 'b'];
% %                for k=1:3
% %                 plot(Coefficients(k,:),cc(k));
% %                end
% %                plot(10*BasisValues,'k')
%            end

       end
    % ROBERT'S VERSION:
       function [value, LocalShapeMatrix, LocalDofToGloalMapping]     = evaluateByRobert(obj,iElem,xiCoordinate,option)
           % Evaluate the field (the value or derivative) of a mesh in an 
           % element 'iElem' at xi coordinates 'xiCoordinate'
           % INPUT:
           % - option: code to indicate which value to evaluate (coding
           % similar to the 'Continuity'
           %        1: (default) the value of the field, u 
           %        2: the derivative vs. xi1, duds1
           %        3: the derivative vs. xi2, duds2
           %        4: the derivative vs. xi3, duds3
           %        5: the derivative vs. xi3, duds3
           %        6: the derivative vs. xi1&xi2, duds12
           %        7: the derivative vs. xi1&xi3, duds23
           %        8: the derivative vs. xi1&xi2&xi3, duds123
           if nargin<4
               option=1;
           end
           value=zeros(1,3);
       % 1. Get the value of the basis function in this coordinate:
           BasisValues = zeros(1,64);
           value1DCH=zeros(3,4);
           value1DdCH=zeros(3,4);
           for k=1:3
               value1DCH(k,1:4) = obj.CubicHermite(xiCoordinate(k));
               value1DdCH(k,1:4) = obj.derivCubicHermite(xiCoordinate(k));
           end
           for b=1:64
               multiplicands=zeros(1,3);
               for k=1:3
                   % 'ib': index (1 to 4) of the Cubic Hermite function
                   ib=obj.mapping.IndexOf64CHBasis(k,b);
                   switch option
                       case 1,
                           multiplicands(k)=value1DCH(k,ib);        
                       case {2,3,4},
                           if k==(option-1) % a way to code which dimension has the derivative:
                               multiplicands(k)=value1DdCH(k,ib);        
                           else
                               multiplicands(k)=value1DCH(k,ib);        
                           end
                       case {5,6,7}
                           if k==(8-option) % a way to code with dimension has the value:
                               multiplicands(k)=value1DCH(k,ib);        
                           else
                               multiplicands(k)=value1DdCH(k,ib);        
                           end
                       case 8
                           multiplicands(k)=value1DdCH(k,ib);
                       otherwise,
                           fprintf(' ERROR: wrong selection of option in CubicMeshClass.evaluate\n');
                   end
               end
               BasisValues(b)=prod(multiplicands);
           end
           %fprintf('Max(basis), should be in <1    =  %1.3f\n',max(BasisValues));
           %fprintf('Min(basis), should be in >-0.2 =  %1.3f\n',min(BasisValues));
       % 2. Get the coefficients from the nodes of the element, one set
       % for each (x,y,z) coordinate:
           u = obj.Get192elementValues(iElem);
       
       % 3. Multiply coefficients and basis:
           if(1) %for LocalDofToGloalMapping
               LocalDofToGloalMapping = zeros(length(BasisValues),1);
               GlobalNodes = obj.giNofElem(iElem,:);
               U = obj.GetDofs();
           end           
           Coefficients= zeros(3,64);
           for icontinuity=1:8
               for inode=1:8
                   % Old version: ic=(icontinuity-1)*8+inode;
                   % Restorted in P.Lamata's correction (06/05/11)
                   ic=(icontinuity-1)*8+inode;
                   Coefficients(1:3,ic)=u(1:3,icontinuity,inode);
                   for dd = 1:3
                       % Commented in P.Lamata's correction (06/05/11)
                       % [ic] = obj.GlobalBasisIndexComplete(iElem,inode,icontinuity,dd);
                       % Coefficients(dd,ic)=u(dd,icontinuity,inode);
                       if(1) %for LocalDofToGloalMapping
                           LocalIndex = obj.liNofElem(iElem,inode); %handles repeated node!!
                           GlobalIndex = GlobalNodes(LocalIndex); %this agrees with u!!
                           LocalDofToGloalMapping(ic) = (icontinuity-1)*obj.nNodes + GlobalIndex; %shift + global node
                       end
                   end
               end
           end
           
           % TODO: solve this in order to be able to incorporate the second
           % versions!!!
           
           if(1) %debug  LocalDofToGloalMapping
               LocalDofToGloalMapping';
               if(norm(U(LocalDofToGloalMapping,:) - Coefficients') > 1e-8)
                   keyboard;
               end
           end
           
           LocalShapeMatrix = BasisValues;
           
           for k=1:3
               value(k)=sum(BasisValues.*Coefficients(k,:));
           end
%            if value(3)<0.5
%                fprintf(' Evaluation in element %i, xiCoords(%1.1f,%1.1f,%1.1f)=(%1.1f,%1.1f,%1.1f)\n',iElem,xiCoordinate,value);
%                for inode=1:8
%                     fprintf('     coords node%i (globalnode%i): (%1.1f,%1.1f,%1.1f) \n',inode,nodes(inode),u(:,1,inode));
%                     % TODO: nodes(inode) only works for normal elements,
%                     % not for collapesed ones! In this case, the two last
%                     % elements will have globalnode=0, they are indexed in
%                     % order 1-2-1-2-3-4-5-6
%                end
% %                figure
% %                hold on
% %                cc=['r' 'g' 'b'];
% %                for k=1:3
% %                 plot(Coefficients(k,:),cc(k));
% %                end
% %                plot(10*BasisValues,'k')
%            end
       end
       function [points]    = evaluateFace(obj,iElem,iFace,xi2Dcoor)
           % Build the matrix of 3D coordinates:
           bDebug1= 0;
           bDebug2= 0;
           coords = obj.Build_Face_3DxiCoor_from2Dxicoor(xi2Dcoor,iFace);
           points = obj.fastCoordinateEvaluation(iElem,coords);
           if(bDebug1)
               figure('color',[1 1 1])
               % build the axes of the image:
               xipoints = sort(unique(coords));
               % 1. identify the xi coordinates that have been indexed:
                   for ixhi = 1:3
                       nXi(ixhi) = numel(unique(coords(ixhi,:)));
                   end
                   iValid = find(nXi == max(nXi));
               % 2. Reconstruct images of coordinates
                   ImCoor = zeros(max(nXi),max(nXi),3);
                       for ip = 1:size(coords,2)
                           xipoint = coords(iValid,ip);
                           xypoint = [find(xipoints == xipoint(1)) find(xipoints == xipoint(2))];
                           for iCoor = 1:3
                                ImCoor(xypoint(1),xypoint(2),iCoor) = points(iCoor,ip);
                           end
                       end
                    for iCoor = 1:3, 
                        subplot(1,3,iCoor)
                        imagesc(ImCoor(:,:,iCoor))
                        axis equal
                    end                                  
           end
           if(bDebug2)
               figure('color',[ 1 1 1])
               plot3(points(1,:),points(2,:),points(3,:))
               for iP = 1:numel(points)/3
                   text(points(1,iP),points(2,iP),points(3,iP),sprintf('%1.1f,%1.1f,%1.1f',coords(1,iP),coords(2,iP),coords(3,iP)));
               end
           end
       end
       function [u]         = Get192elementValues(obj,iElem,whichField)
           % Function that gets the 192 element values in a vector u, of
           % size (3 coordinates x 8 values x 8 nodes)
           % INPUT:
           % - iElem
           % - whichField:
           %      0: coordinate field
           %      1: fibre field
           nCoords = 3;
           if nargin<3
               whichField=0;
           end
           if whichField == 1
               nCoords = obj.FibDim;
           end
           bDebug=0;
           nodes = obj.giNofElem(iElem,:);
           u=zeros(3,8,8);
               for ilnode=1:8 % 1 to 8 local node index
                   % Get the real Local indexes of the eight nodes (in
                   % collapsed elements cases there will be repeated indexes):
                   LocalIndex = obj.liNofElem(iElem,ilnode);
                   % The giNofElem points to the global index as defined in
                   % the exelem file. The MatrixNodeIndex (from 1 to
                   % nNodes) is:
                   MatrixNodeIndex = nodes(LocalIndex);
                   
                   for iCoor=1:nCoords
                       % valueIndices are encoded in exElem file with the
                       % index from 1 to 8 (first version) or index 9 to 18
                       % (second version)                       
                       for ilv=1:8 %value index
                           version = ceil(double(obj.valueIndices(iElem,iCoor,ilnode,ilv))/8);
                           NodeValue = obj.GetNodeCoorValue(MatrixNodeIndex,iCoor,ilv,version,whichField);

                           u(iCoor,ilv,ilnode) = NodeValue;
% TODELETE:
%                            if (obj.valueIndices(iElem,c,LocalIndex,ilv)==ilv)
%                                version(c,ilv)=1;
%                            else if (obj.valueIndices(iElem,c,LocalIndex,ilv)==ilv+8)
%                                    version(c,ilv)=2;
%                                    if (bDebug), fprintf(1,'Version 2 in element %i node (local %i, global %i)!\n',iElem,LocalIndex,nodes(ilnode)); end
%                                else
%                                    fprintf(1,'ERROR! in CubicMeshClass.evaluate: wrong valueIndices - not corresponding to any version of the value or derivative - FIRST VERSION ASSUMED!\n');
%                                    fprintf(1,'                                   : valueIndice = %i, ilv = %i, LocalIndex = %i, coordinate=%i, iElem=%i\n\n',obj.valueIndices(iElem,c,LocalIndex,ilv),ilv,LocalIndex,c,iElem);
%                                    version(c,ilv)=1;
%                                end
%                            end
                       end
                   end
               end
           switch nCoords
               case 3, % do nothing
               case 2, % fill with null values:
                   u(3,:,:) = 0;
           end               
       end
      
       function [surface]   = GetMeshSurface(obj)
           bDebug = 0;
           if (~obj.bExternalFacesFound)
               fprintf('  ... ADVICE: call FindExternalSurfaces before to save computational time in multiple calls to GetMeshSurface() and similar\n');
               obj = obj.FindExternalSurfaces();
           end
           surface = 0;
           for iElem=1:obj.nElems
               for iFace=1:6
                   if obj.ExternalFaces(iElem,iFace)
                       SurfaceContribution = obj.GetFaceSurface(iElem,iFace);
                       if (bDebug)
                           fprintf('Element %i, face %i. Surface = %f\n',iElem,iFace,SurfaceContribution);
                       end   
                       surface = surface + SurfaceContribution;
                   end
               end
           end           
       end
       function [surface]   = GetFaceSurface(obj,iElem,iFace)
           % Function to calculate the area of a face of an element. It
           % implements the double integral of the cross product of the
           % tangential vectors
           % http://mathworld.wolfram.com/SurfaceArea.html
           bGraphicalDebug  = 0;
           GaussOrder       = 4;
           GaussPts2D       = obj.GetSurfaceGaussPoints(iElem,iFace,GaussOrder);  
           GaussLocalCoords = reshape(GaussPts2D.LocalCoordinates,2,GaussOrder*GaussOrder);
           GaussWeights     = reshape(GaussPts2D.GaussWeights2D  ,1,GaussOrder*GaussOrder);
           CrossTangents    = obj.GetCrossTangents(iElem,iFace,GaussLocalCoords);
           surface          = sum(CrossTangents.*GaussWeights);           
           if (bGraphicalDebug)
               figure('Color',[1 1 1]); hold on;
               plot(CrossTangents,'b');
               plot(GaussWeights,'r');
               title(sprintf('Elem %i, face %i. CrossTangents (blue,%f) and weights (red).',iElem,iFace,mean(CrossTangents)));
           end
       end
       function [CrossTg]   = GetCrossTangents(obj,iElem,iFace,xi2DCoordinate)
           bGraphicDebug1=0;
           bGraphicDebug2=0;
           bDebug = 0;
           % Function that calculates the cross product of the tangential
           % vectors to the surface of the face "iFace" of element "iElem"
           nPoints      = numel(xi2DCoordinate)/2;
           xi2DCoordinate = reshape(xi2DCoordinate,2,nPoints);
           % Build the two tangential vectors. It is needed to know which
           % local coordinates correspond to "iFace":
           xi3DCoordinate = obj.Build_Face_3DxiCoor_from2Dxicoor(xi2DCoordinate,iFace);
           switch iFace 
               % For the meaining of "iFace", look at the definition of
               % indexes in Build_Face_3DxiCoor_from2Dxicoor
               % iT1 and iT2 are the node value indexes (the kind of
               % continuity as described in fastCoordinateEvaluation)
               case {1 2} % 1: xhi3=0 or xhi3=1
                   iT1 = 3; iT2 = 2; 
               case {3 4} % 2: xhi2=0 or xhi2=1
                   iT1 = 4; iT2 = 2; 
               case {5 6} % 1: xhi3=0 or xhi3=1
                   iT1 = 3; iT2 = 4;
               case {0}
                   fprintf('ERROR! evaluation of CrossTangents in all 6 faces at the same time is not implemented!\n');
               otherwise
                   fprintf('ERROR! wrong face index (%i)!\n',iFace);
           end
           opt1.continuity = iT1;
           opt2.continuity = iT2;
           V1(1:3,1:nPoints) = obj.fastCoordinateEvaluation(iElem,xi3DCoordinate,opt1);
           V2(1:3,1:nPoints) = obj.fastCoordinateEvaluation(iElem,xi3DCoordinate,opt2);
           CrossTg = zeros(1,nPoints);
           for i=1:nPoints
               A(1,1:3) = ones(1,3);
               A(2,1:3) = V1(1:3,i);
               A(3,1:3) = V2(1:3,i);
               
               % since the tangential vectors can be "oposed", the
               % determinant can be negative... And we need the absolute
               % value:
               %CrossTg(i) = abs(det(A));
               CC = cross(V1(1:3,i),V2(1:3,i));
               CrossTg(i) = sqrt(sum(CC.^2));
           end
           if(bGraphicDebug2)
               figure('Color',[1 1 1]); hold on;
               title(sprintf('Elem %i, face %i',iElem,iFace));
               subplot(211), hold on
               plot(V1(1,:),'r');
               plot(V1(2,:),'g');
               plot(V1(3,:),'b');
               plot(CrossTg,'k');
               subplot(212), hold on
               plot(V2(1,:),'r');
               plot(V2(2,:),'g');
               plot(V2(3,:),'b');
               plot(CrossTg,'k');
               title(sprintf('Elem %i, face %i',iElem,iFace));
           end
           if (bGraphicDebug1|bDebug)
               modV1 = sum(V1.^2,1);
               modV2 = sum(V2.^2,1);
           end
           if (bGraphicDebug1)  
               fprintf('Graphic debug of calculation of Cross of Tg...\n');
               figure('Color',[1 1 1]); hold on;
               obj.plotWireframe();
               obj.plotElementFace(iElem,iFace,5);
               points3D = obj.fastCoordinateEvaluation(iElem,xi3DCoordinate);
               points3D_xi1 = points3D + V1;
               points3D_xi2 = points3D + V2;
               for i=1:nPoints
                   P1 = points3D(1:3,i);
                   P2 = points3D_xi1(1:3,i);
                   P3 = points3D_xi2(1:3,i);
                   plot3(P1(1),P1(2),P1(3),'b*');
                   plot3([P1(1) P2(1)],[P1(2) P2(2)],[P1(3) P2(3)],'r');
                   plot3(P2(1),P2(2),P2(3),'r*');
                   plot3([P1(1) P3(1)],[P1(2) P3(2)],[P3(3) P3(3)],'g');
                   plot3(P3(1),P3(2),P3(3),'g*');
               end
               str = sprintf('Sum cross products = %f ',sum(CrossTg));
               title(str);
               fprintf('                modV1=  %f +/- %f ;modV2=   %f +/- %f \n',mean(modV1),std(modV1),mean(modV2),std(modV2));
           end
           if (bDebug)
               fprintf('Cross products: sum = %f / mean = %f\n',sum(CrossTg),mean(CrossTg));
               fprintf('                modV1=  %f +/- %f ;modV2=   %f +/- %f \n',mean(modV1),std(modV1),mean(modV2),std(modV2));
           end
       end
       function [volume]    = GetMeshVolume(obj)
           vol = zeros(1,obj.nElems);
           for iE = 1:obj.nElems
               vol(iE) = obj.GetElementVolume(iE);
           end
           volume = sum(vol);
       end
       function [volume]    = GetElementVolume(obj,iElem)
           % Function to calculate the volume of an element. It implements
           % the triple integral of the Jacobian determinant
           % http://www-math.mit.edu/~djk/18_022/chapter11/section04.html
           GaussOrder       = 4;
           GaussPoints      = obj.GetGlobalGaussPoints(iElem,GaussOrder);
           % JacobianDeterminant=zeros(GaussOrder*GaussOrder*GaussOrder,1);
  % 21/11/2011: BUG DETECTED! THIS DOES INTRODUCE QUITE DIFFERENT NUMBERS!
  % GaussLocalCoords = reshape(GaussPoints.LocalCoordinates,3,nPoints);   
           GaussLocalCoords = reshape(GaussPoints.LocalCoordinates,GaussOrder*GaussOrder*GaussOrder,3)';           
           GaussWeights     = reshape(GaussPoints.GaussWeights3D  ,1,GaussOrder*GaussOrder*GaussOrder);
           JacobianDeterminant=obj.GetJacobianDeterminant(iElem,GaussLocalCoords);
           volume           = sum(JacobianDeterminant.*GaussWeights);
       end
       function [JacMat]    = GetJacobianMatrix(obj,iElem,xiCoordinate)
           % Function that returns the jacobian matrix in a point indicated
           % by a local coordinate of a element:
           dudxi1 = obj.evaluate(iElem,xiCoordinate,2);
           dudxi2 = obj.evaluate(iElem,xiCoordinate,3);
           dudxi3 = obj.evaluate(iElem,xiCoordinate,4);
           JacMat= [dudxi1' dudxi2' dudxi3'];
       end
       function [JacDet]    = GetJacobianDeterminant(obj,iElem,xiCoordinate)
           % Function that returns the jacobian determinant in a set of
           % points indicated by local coordinates of an element
           bMakeOptimisedCalculi=1;
           bDebug = 0;
           nPoints = numel(xiCoordinate)/3;
           Points = reshape(xiCoordinate,3,nPoints);
           % 1. Build the Jacobian matrix
           J = zeros(3,3,nPoints);
           JacDet=zeros(1,nPoints);
           if (bMakeOptimisedCalculi)
               for j=1:3
                   % CHECKED: this is the right indexing of the Jacobian (it could be
                   % transposed, but this has no effect in the determinant).
                   opt.continuity = j+1;
                   J(j,1:3,1:nPoints) = obj.fastCoordinateEvaluation(iElem,Points,opt);
               end
           end
           for iP=1:nPoints
               if (~bMakeOptimisedCalculi)
                   for j=1:3
                       % TOCHECK: the right indexing of the Jacobian (it could be
                       % transposed, but this has no effect in the determinant).
                       J(j,1:3,iP) = obj.evaluate(iElem,Points(:,iP),j+1);
                   end
               end
               JacDet(iP) = det(J(:,:,iP));
           end
           if(bDebug)
               figure
               obj.plotWireframe();
               obj.plotElement(iElem,1,0.3);
               centre = obj.evaluate(iElem,Points(:,iP),1);              
               for iJ=1:3
                   direction = J(iJ,1:3,iP);
                   scale = 5;
                   widthLine = 2.5;
                   RGBcolor  = [0 0 0];
                   RGBcolor(iJ) = 1;
                   [x y z] = obj.BuildVector(centre,direction,scale);
                   plot3(x,y,z,'Color',RGBcolor,'LineWidth',widthLine);  
               end
           end
       end
       function [GaussPts]  = GetGlobalGaussPoints(obj,iElem,GaussOrder)
           % Function that returns the Gauss Points of the element 'iElem'
           % TODO: make a faster evaluation, all points in a block!
           if nargin<3
               GaussOrder=3;
           end
           LocalGaussPoints1D = obj.GetLocalGaussCoords1D(GaussOrder);
           gw   = LocalGaussPoints1D.GaussWeights;
           gw2d = gw'*gw;
           gw3d =zeros(GaussOrder,GaussOrder,GaussOrder);
           for k=1:GaussOrder
               gw3d(k,:,:)=gw(k)*gw2d;
           end
            xhiCoordLength1  = [1 0 0];
            xhiCoordLength2  = [0 1 0];
            xhiCoordLength3  = [0 0 1];
            points     =zeros(GaussOrder,GaussOrder,GaussOrder,3);
            localCoord =zeros(GaussOrder,GaussOrder,GaussOrder,3);
            GaussPointLocalCoordinate = LocalGaussPoints1D.GPxhi;
            for i=1:GaussOrder
                for j=1:GaussOrder
                    for k=1:GaussOrder
                        xiCoord1 = GaussPointLocalCoordinate(i)*xhiCoordLength1;
                        xiCoord2 = GaussPointLocalCoordinate(j)*xhiCoordLength2;
                        xiCoord3 = GaussPointLocalCoordinate(k)*xhiCoordLength3;
                        localCoord(i,j,k,:)=xiCoord1+xiCoord2+xiCoord3;            
                        points(i,j,k,:)=obj.evaluate(iElem,localCoord(i,j,k,:));
                    end
                end
            end
           GaussPts.LocalCoordinates = localCoord;
           GaussPts.GlobalCoordinates = points;
           GaussPts.GaussWeights3D = gw3d;           
       end
       function [Indexes]   = GetTheThreeNeighbourNodes(obj,iElem,iNode,OptionLocalOrGlobal)
           % Function to return the three neighbour nodes to a given one.
           % It can be called either by global (1) index or by local (0) index
           if nargin<4
               OptionLocalOrGlobal = 0; % (local indexing by default)
           end
           
           NumberOfNodes = obj.nNofElem(iElem);
           TheEigthNodes = obj.giNofElem(iElem,1:NumberOfNodes);
           LocalIndexing = obj.liNofElem(iElem,1:8);
           
           if (OptionLocalOrGlobal)
               % Transfor from global to local index:
               iLocalNode = find(TheEigthNodes==iNode);
           else
               iLocalNode = iNode;
           end
           
           % Now, looking at the connectivity of an elementary cube:
           switch iLocalNode
               case 1
                   LocalIndexes = [2 3 5];
               case 2
                   LocalIndexes = [1 4 6];
               case 3
                   LocalIndexes = [1 4 7];
               case 4
                   LocalIndexes = [2 3 8];
               case 5
                   LocalIndexes = [1 6 7];
               case 6
                   LocalIndexes = [2 5 8];
               case 7
                   LocalIndexes = [3 5 8];
               case 8
                   LocalIndexes = [4 6 7];
           end
           Indexes = TheEigthNodes(LocalIndexing(LocalIndexes));
       end
       
       function [answer]    = SetORGetDofs(obj,flags,u)
       % Main set/get DOF function of the class!! for all the
       % coordinate, fibre and field DOFs!!
       %
       % INPUT:
       % - flags.OrderOption = (1) per dof or (2) per node
            bDebug=0;
            FlagSetORGet = flags.FlagSetORGet;            
            FlagWhichField = flags.FlagWhichField;
            if isfield(flags,'FieldID'), FieldID = flags.FieldID;
            else                         FieldID = NaN; end
            if isfield(flags,'OrderOption'), OrderOption = flags.OrderOption;
            else                             OrderOption = 1; end
            [nNodesPerElement,nVariablesPerNode] = obj.GetBasisCharacteristics(obj.InterpolationBasis);               
            % Check the number of components and correctness of info:
            switch FlagWhichField
                case 1 % The coordinate values
                    nComponents = 3;
                case 2 % Get the fibre values, 
                    if obj.FibreDescriptionType==1
                        nComponents = 3; %cartesian description
                        if nComponents~=obj.FibDim
                            text = sprintf('Fibre dimensions (FibDim) do not match with the description type (FibreDescriptionType)!');
                            ME1 = MException('CubicMeshClass:InconsistentData',text);
                            throw(ME1);
                        end
                    else if obj.FibreDescriptionType==2
                            nComponents = 2;%elevation/imbrication description
                            if nComponents~=obj.FibDim
                                text = sprintf('CubicMeshClass, Setting dofs: Fibre dimensions (FibDim) do not match with the description type (FibreDescriptionType)!');
                                ME1 = MException('CubicMeshClass:InconsistentData',text);
                                throw(ME1);
                            end
                        else 
                            nComponents = 2;%elevation/imbrication description
                            fprintf(' WARNING!!! No fibre description tipe is present in the class CubicMeshClass!! Elevation/Imbrication description is assumed\n');
                        end
                    end
                case 3
                    % In current implementation, fields only have one component
                    nComponents = 1;
                otherwise
                    text = sprintf('No FlagWhichField was provided!');
                    ME1 = MException('CubicMeshClass:InconsistentData',text);
                    throw(ME1);                    
            end
            
            if(OrderOption==2)&&(FlagSetORGet==2) % A set where data is indexed per node, not per dof
                fprintf('Degrees of freedom introduced are indexed per node. This is changed, since dofs are stored per nodal variable\n');
                temp = u; clear u; u=zeros(size(temp));    
                dimensions = min(size(u));
                if dimensions~=nComponents
                    text = sprintf('CubicMeshClass, Setting dofs: Field dimensions introduced (%i) do not match with the description type (FlagWhichField)!',dimensions);
                    ME1 = MException('CubicMeshClass:InconsistentData',text);
                    throw(ME1);
                end
                for iContinuity=1:nVariablesPerNode
                    for iNode=1:obj.nNodes
                        indexPerNode = (iNode-1)*nVariablesPerNode + iContinuity;
                        indexPerDof  = (iContinuity-1)*obj.nNodes + iNode;
                        u(indexPerDof,1:nComponents) = temp(indexPerNode,1:nComponents);
                    end
                end                
            end
            
            [TotalNodes b c]=size(obj.coordinates);
            if(obj.InterpolationBasis == 1)
                TotalDofsFirstVersion = TotalNodes*8; %why 8? what if mesh is c.Lagrange? %GGG
            else
                TotalDofsFirstVersion = TotalNodes*1; 
            end
            
            nNewVers(1:3) = obj.nNewVersionsBasis(1:3);
            TotalDofs = TotalDofsFirstVersion + max(nNewVers);
            if FlagSetORGet==1 %this is a get:
                u=zeros(TotalDofs,nComponents);
            end
            

            %------------------
            % First versions:
            %------------------
            for i=1:nComponents
                switch FlagSetORGet
                    case 1 % This is a get
                        switch obj.InterpolationBasis
                            case 1
                                switch FlagWhichField
                                    case 1 
                                        u(1:TotalNodes * nVariablesPerNode,i) = [obj.coordinates(:,i,1);
                                                                 obj.derivatives.duds1(:,i,1);
                                                                 obj.derivatives.duds2(:,i,1);
                                                                 obj.derivatives.duds3(:,i,1);
                                                                 obj.derivatives.duds12(:,i,1);
                                                                 obj.derivatives.duds13(:,i,1);
                                                                 obj.derivatives.duds23(:,i,1);
                                                                 obj.derivatives.duds123(:,i,1)];
                                    case 2
                                        u(1:TotalNodes * nVariablesPerNode,i) = [obj.fibres.value(:,i,1);
                                                                 obj.fibres.dfds1(:,i,1);
                                                                 obj.fibres.dfds2(:,i,1);
                                                                 obj.fibres.dfds3(:,i,1);
                                                                 obj.fibres.dfds12(:,i,1);
                                                                 obj.fibres.dfds13(:,i,1);
                                                                 obj.fibres.dfds23(:,i,1);
                                                                 obj.fibres.dfds123(:,i,1)];
                                    case 3
                                        u(1:TotalNodes * nVariablesPerNode) = [  obj.fields.value(:,FieldID,1);
                                                                 obj.fields.dfds1(:,FieldID,1);
                                                                 obj.fields.dfds2(:,FieldID,1);
                                                                 obj.fields.dfds3(:,FieldID,1);
                                                                 obj.fields.dfds12(:,FieldID,1);
                                                                 obj.fields.dfds13(:,FieldID,1);
                                                                 obj.fields.dfds23(:,FieldID,1);
                                                                 obj.fields.dfds123(:,FieldID,1)];
                                end
                            otherwise
                                % Assumption of no derivatives in rest of
                                % basis schemes:
                                switch FlagWhichField
                                    case 1 
                                        u(1:TotalNodes * nVariablesPerNode,i) = [obj.coordinates(:,i,1);];
                                    case 2
                                        u(1:TotalNodes * nVariablesPerNode,i) = [obj.fibres.value(:,i,1);];
                                    case 3
                                        u(1:TotalNodes * nVariablesPerNode) = [  obj.fields.value(:,FieldID,1);];
                                end
                                
                        end
                    case 2 % This is a set
                        [a b] = size(u);
                        if a==1
                            u = reshape(u,b,a); % a=1 for single-component field, u does not have second index then, and this reshape solves it.
                        end
                        U    =   u(TotalNodes*0+1:TotalNodes*1,i);
                        if(obj.InterpolationBasis ==1) %16/12/13: updated by P.Lamata, only the c.Hermite needs derivatives. Before: ~= 2) %c.Lagrange doesn't use derivatives? %GGG
                            dU1  =   u(TotalNodes*1+1:TotalNodes*2,i);
                            dU2  =   u(TotalNodes*2+1:TotalNodes*3,i);
                            dU3  =   u(TotalNodes*3+1:TotalNodes*4,i);
                            dU12 =   u(TotalNodes*4+1:TotalNodes*5,i);
                            dU13 =   u(TotalNodes*5+1:TotalNodes*6,i);
                            dU23 =   u(TotalNodes*6+1:TotalNodes*7,i);
                            dU123=   u(TotalNodes*7+1:TotalNodes*8,i);
                        end
                        switch FlagWhichField
                            case 1
                                obj.coordinates(:,i,1)           =   U;
                                if(obj.InterpolationBasis  ==1) %16/12/13: updated by P.Lamata, only the c.Hermite needs derivatives. Before: ~= 2) %c.Lagrange doesn't use derivatives? %GGG
                                    obj.derivatives.duds1(:,i,1)     = dU1;
                                    obj.derivatives.duds2(:,i,1)     = dU2;
                                    obj.derivatives.duds3(:,i,1)     = dU3;
                                    obj.derivatives.duds12(:,i,1)    =dU12; 
                                    obj.derivatives.duds13(:,i,1)    =dU13;  
                                    obj.derivatives.duds23(:,i,1)    =dU23;   
                                    obj.derivatives.duds123(:,i,1)   =dU123;   
                                end
                            case 2
                                 obj.fibres.value(:,i,1)        =   U;
                                 if(obj.InterpolationBasis  ==1) %16/08/14: updated by P.Lamata, only the c.Hermite needs derivatives. Before: ~= 2) %c.Lagrange doesn't use derivatives? %GGG
                                     obj.fibres.dfds1(:,i,1)        = dU1;
                                     obj.fibres.dfds2(:,i,1)        = dU2;
                                     obj.fibres.dfds3(:,i,1)        = dU3;
                                     obj.fibres.dfds12(:,i,1)       = dU12;
                                     obj.fibres.dfds13(:,i,1)       = dU13;
                                     obj.fibres.dfds23(:,i,1)       = dU23;
                                     obj.fibres.dfds123(:,i,1)      = dU123;
                                 end
                            case 3
                                 obj.fields.value(:,FieldID,1)        =   U;
                                 if(obj.InterpolationBasis  ==1) %16/08/14: updated by P.Lamata, only the c.Hermite needs derivatives. Before: ~= 2) %c.Lagrange doesn't use derivatives? %GGG
                                     obj.fields.dfds1(:,FieldID,1)        = dU1;
                                     obj.fields.dfds2(:,FieldID,1)        = dU2;
                                     obj.fields.dfds3(:,FieldID,1)        = dU3;
                                     obj.fields.dfds12(:,FieldID,1)       = dU12;
                                     obj.fields.dfds13(:,FieldID,1)       = dU13;
                                     obj.fields.dfds23(:,FieldID,1)       = dU23;
                                     obj.fields.dfds123(:,FieldID,1)      = dU123;                                
                                 end 
                        end
                end
            end
            %------------------
            % Second versions:
            %------------------
            for iCoor=1:nComponents
                if (obj.nNewVersionsBasis(iCoor)>0)
                    % The matrix where the identification of new versions is coded:
                    Matrix = squeeze(obj.NewBasisIndex(iCoor,:,:,:));
                    % The number of new versions for all DOFS for each iCoor (x, y and z):
                    for iNewDof = 1:nNewVers(iCoor)
                        DofIndex = TotalDofsFirstVersion + iNewDof;
                        I=find(Matrix==iNewDof);
                        [iNode iValue version] = ind2sub(size(Matrix),I);
                        switch FlagSetORGet
                            case 1 % This is a get
                                u(DofIndex,iCoor) = obj.GetMeshDof(iValue,iNode,iCoor,version,FlagWhichField,FieldID);
                            case 2 % This is a set
                                [a b] = size(u);
                                if a==1
                                    u = reshape(u,b,a); % a=1 for single-component field, u does not have second index then, and this reshape solves it.
                                end
                                switch iValue
                                    case 1
                                        switch FlagWhichField
                                            case 1
                                                obj.coordinates(iNode,iCoor,version) = u(DofIndex,iCoor);
                                            case 2
                                                obj.fibres.value(iNode,iCoor,version) = u(DofIndex,iCoor);
                                            case 3
                                                obj.fields.value(iNode,FieldID,version) = u(DofIndex,iCoor);
                                        end                                            
                                    case 2
                                        switch FlagWhichField
                                            case 1
                                                obj.derivatives.duds1(iNode,iCoor,version) = u(DofIndex,iCoor);
                                            case 2
                                                obj.fibres.dfds1(iNode,iCoor,version) = u(DofIndex,iCoor);
                                            case 3
                                                obj.fields.dfds1(iNode,FieldID,version) = u(DofIndex,iCoor);
                                        end
                                    case 3
                                        switch FlagWhichField
                                            case 1
                                                obj.derivatives.duds2(iNode,iCoor,version) = u(DofIndex,iCoor);
                                            case 2
                                                obj.fibres.dfds2(iNode,iCoor,version) = u(DofIndex,iCoor);
                                            case 3
                                                obj.fields.dfds2(iNode,FieldID,version) = u(DofIndex,iCoor);
                                        end
                                    case 4
                                        switch FlagWhichField
                                            case 1
                                                obj.derivatives.duds3(iNode,iCoor,version) = u(DofIndex,iCoor);
                                            case 2
                                                obj.fibres.dfds3(iNode,iCoor,version) = u(DofIndex,iCoor);
                                            case 3
                                                obj.fields.dfds3(iNode,FieldID,version) = u(DofIndex,iCoor);
                                        end
                                    case 5
                                        switch FlagWhichField
                                            case 1
                                                obj.derivatives.duds12(iNode,iCoor,version) = u(DofIndex,iCoor);
                                            case 2
                                                obj.fibres.dfds12(iNode,iCoor,version) = u(DofIndex,iCoor);
                                            case 3
                                                obj.fields.dfds12(iNode,FieldID,version) = u(DofIndex,iCoor);
                                        end
                                    case 6
                                        switch FlagWhichField
                                            case 1
                                                obj.derivatives.duds13(iNode,iCoor,version) = u(DofIndex,iCoor);
                                            case 2
                                                obj.fibres.dfds13(iNode,iCoor,version) = u(DofIndex,iCoor);
                                            case 3
                                                obj.fields.dfds13(iNode,FieldID,version) = u(DofIndex,iCoor);
                                        end
                                    case 7
                                        switch FlagWhichField
                                            case 1
                                                obj.derivatives.duds23(iNode,iCoor,version) = u(DofIndex,iCoor);
                                            case 2
                                                obj.fibres.dfds23(iNode,iCoor,version) = u(DofIndex,iCoor);
                                            case 3
                                                obj.fields.dfds23(iNode,FieldID,version) = u(DofIndex,iCoor);
                                        end
                                    case 8
                                        switch FlagWhichField
                                            case 1
                                                obj.derivatives.duds123(iNode,iCoor,version) = u(DofIndex,iCoor);
                                            case 2
                                                obj.fibres.dfds123(iNode,iCoor,version) = u(DofIndex,iCoor);
                                            case 3
                                                obj.fields.dfds123(iNode,FieldID,version) = u(DofIndex,iCoor);
                                        end
                                end
                        end
                    end
                end
            end
            
            if(bDebug)
                figure('Color',[1 1 1]); hold on;
                plot(u);
                title('DOFs of the mesh. They should be indexed per nodal variable');
            end
            if(OrderOption==2)&&(FlagSetORGet==1) % A get where data is indexed per node, not per dof
                fprintf('Output degrees of freedom are shorted, not by nodal variable, but per node\n');
                temp = u; clear u; u=zeros(size(temp));               
                for iContinuity=1:nVariablesPerNode
                    for iNode=1:obj.nNodes
                        indexPerNode = (iNode-1)*nVariablesPerNode + iContinuity;
                        indexPerDof  = (iContinuity-1)*obj.nNodes + iNode;
                        if indexPerNode > size(u,1)
                            fprintf('WARNING! dof index found (%i) is bigger than expected (nDofs = %i)\n',indexPerNode,size(u,1));
                        end
                        if indexPerDof > size(temp,1)
                            fprintf('WARNING! dof index estimated (%i) is bigger than expected (nDofs = %i)\n',indexPerNode,size(u,1));
                        end
                        u(indexPerNode,1:nComponents) = temp(indexPerDof,1:nComponents);
                    end
                end                
            end
            switch FlagSetORGet
                case 1
                    answer = u;
                case 2
                    answer = obj;
            end
       end
       function value       = GetMeshDof(obj,iValue,iNode,iCoor,version,FlagWhichField,FieldID) 
           switch iValue
                case 1
                    switch FlagWhichField
                        case 1
                            value = obj.coordinates(iNode,iCoor,version);
                        case 2
                            value = obj.fibres.value(iNode,iCoor,version);
                        case 3
                            value = obj.fields.value(iNode,FieldID,version);
                    end
                case 2
                    switch FlagWhichField
                        case 1
                            value = obj.derivatives.duds1(iNode,iCoor,version);
                        case 2
                            value = obj.fibres.dfds1(iNode,iCoor,version);
                        case 3
                            value = obj.fields.dfds1(iNode,FieldID,version);
                    end
                case 3
                    switch FlagWhichField
                        case 1
                            value = obj.derivatives.duds2(iNode,iCoor,version);
                        case 2
                            value = obj.fibres.dfds2(iNode,iCoor,version);
                        case 3
                            value = obj.fields.dfds2(iNode,FieldID,version);
                    end
                case 4
                    switch FlagWhichField
                        case 1
                            value = obj.derivatives.duds3(iNode,iCoor,version);
                        case 2
                            value = obj.fibres.dfds3(iNode,iCoor,version);
                        case 3
                            value = obj.fields.dfds3(iNode,FieldID,version);
                    end
                case 5
                    switch FlagWhichField
                        case 1
                            value = obj.derivatives.duds12(iNode,iCoor,version);
                        case 2
                            value = obj.fibres.dfds12(iNode,iCoor,version);
                        case 3
                            value = obj.fields.dfds12(iNode,FieldID,version);
                    end
                case 6
                    switch FlagWhichField
                        case 1
                            value = obj.derivatives.duds13(iNode,iCoor,version);
                        case 2
                            value = obj.fibres.dfds13(iNode,iCoor,version);
                        case 3
                            value = obj.fields.dfds13(iNode,FieldID,version);
                    end
                case 7
                    switch FlagWhichField
                        case 1
                            value = obj.derivatives.duds23(iNode,iCoor,version);
                        case 2
                            value = obj.fibres.dfds23(iNode,iCoor,version);
                        case 3
                            value = obj.fields.dfds23(iNode,FieldID,version);
                    end
                case 8
                    switch FlagWhichField
                        case 1
                            value = obj.derivatives.duds123(iNode,iCoor,version);
                        case 2
                            value = obj.fibres.dfds123(iNode,iCoor,version);
                        case 3
                            value = obj.fields.dfds123(iNode,FieldID,version);
                    end
            end
       end
       function [name]      = GetFieldName(obj,iF)
           name = [];
           if obj.nFields >= iF
               nCaracters = obj.fieldNames(1,iF);
               name= obj.fieldNames(2:nCaracters+1,iF)';
           end
       end
       function obj         = SetFieldName(obj,iF,name)
           nCaracters = numel(name);
           obj.fieldNames(2:nCaracters+1,iF) = name;
           obj.fieldNames(1,iF) = nCaracters;
       end
       
       function [w]         = GetDofWeights(obj,dimension,OrderOption)
           % Function to retun a weighting of each dof accordingly to the
           % amplitude of the base function they codify. By "amplitude" we
           % mean the integral of the basis in the unit element. This is
           % used to build a statistical shape model, and having an
           % equalised weight of the dofs to build a PCA.
           
           switch obj.InterpolationBasis
               case 1
                   switch dimension
                       case 1, weights = [1 1/6 1/6 0 1/6 0 0 0];
                       case 2, weights = [1 1/6 1/6 1/36 1/6 1/36 1/36 0];
                       case 3, weights = [1 1/6 1/6 1/36 1/6 1/36 1/36 1/216];
                   end
                   % Concatenate the weights depending on OrderOption
                   switch OrderOption
                       case 1 % Order per dof
                           dd = ones(1,obj.nNodes);
                           w = [weights(1)*dd weights(2)*dd weights(3)*dd weights(4)*dd weights(5)*dd weights(6)*dd weights(7)*dd weights(8)*dd];
                       case 2 % Order per node:
                           w = repmat(weights,1,obj.nNodes);
                   end
               otherwise
                   % Assumption one basis per node, equal weight:
                   w = ones(1,obj.nNodes);
                   %fprintf('GetDofWeights not implemented yet for this basis function\n');
           end
       end
       function [u]         = GetDofs(obj,OrderOption)
           ImplementationChoice = 1;
           if nargin<2
               OrderOption = 1; % Default order NOT corresponding to Jiahe's code (per dof)
           end
           switch ImplementationChoice
               case 1 % Correct one
                    flags.FlagWhichField =1;
                    flags.FlagSetORGet = 1;
                    flags.OrderOption = OrderOption;
                    u = obj.SetORGetDofs(flags);
               case 2 % Old incomplete one: no secondary versions!!! (corresponding to Jiahe's GetDofs)
                   u = zeros(obj.nNodes * 8, 3);
                   for i=1:3
                       u(:,i) = [obj.coordinates(:,i,1);obj.derivatives.duds1(:,i,1);obj.derivatives.duds2(:,i,1);obj.derivatives.duds3(:,i,1);obj.derivatives.duds12(:,i,1);obj.derivatives.duds13(:,i,1);obj.derivatives.duds23(:,i,1);obj.derivatives.duds123(:,i,1)];
                   end
           end
       end
       function [obj]       = SetDofs(obj,u,OrderOption)
           if nargin<3
               OrderOption=1;
           end
           % Check dofs come in a matrix. If they come in a line, reshape:
           [a, b] = size(u);
           if a==1 || b==1
               [~,nVariablesPerNode] = obj.GetBasisCharacteristics(obj.InterpolationBasis);
               [TotalNodes, ~, ~]=size(obj.coordinates);
               nDofsPerCoord = TotalNodes * nVariablesPerNode;
               u = reshape(u,nDofsPerCoord,3);
           end
           flags.OrderOption = OrderOption;
           flags.FlagWhichField =1;
           flags.FlagSetORGet = 2;
           obj = obj.SetORGetDofs(flags,u);
           obj = obj.Update();
       end
       function [Ind]       = GetIndexDofsExtSurf(obj)
           
           if (~obj.bExternalFacesFound)
               obj = obj.FindExternalSurfaces();
           end
           
           % Need to label which is a valid dof (same index in all 3
           % coordinate fields):
           [nNodesPerElement,nVariablesPerNode] = obj.GetBasisCharacteristics(obj.InterpolationBasis);
           Ind = NaN * ones(1,obj.nElems*nNodesPerElement*nVariablesPerNode*6);   % Preallocation to save time
           i = 0; % Variable to keep track of the new iDofs loaded
           for iElem = 1:obj.nElems
               for iFace=1:6
                   if obj.ExternalFaces(iElem,iFace)
                       % Local nodes that build that surface:
                       iSurf = obj.mapping.Surfaces.Nodes(:,iFace);
                       for iln = 1:numel(iSurf);
                           iLocalNode = iSurf(iln);
                           % Each local node should keep 4 continuities
                           % (value, 2x simple derivatives, 1x cross deriv)
                           for iCont = 1:4
                               iContinuity = obj.mapping.Surfaces.Continuity(iCont,iFace);
                               i = i+1;
                               Ind(i) = obj.GlobalBasisIndexComplete(iElem,iLocalNode,iContinuity,1);
                           end
                       end                       
                   end
               end
           end
               
           Ind = Ind(~isnan(Ind));
           Ind = unique(Ind);
           Ind = sort(Ind);
       end
       function [pu,Ind]    = GetExtSurfaceDofs(obj)
           % FUnction to get only part of the dofs, the ones corresponding
           % to the encoding of the external surfaces:
           
           % Get all dofs, in a matrix:
           u = obj.GetDofs(2);
           % Get indexes of the dofs of the external surfaces:
           [Ind] = obj.GetIndexDofsExtSurf();
           % Select the ones wanted:
           pu = u(Ind,:);
       end
       function [obj]       = SetExtSurfaceDofs(obj,u)
           % GEt the complete list of dofs:
           u0    = obj.GetDofs(2);
           Ind  = obj.GetIndexDofsExtSurf();
           % CHeck input has the right size:
           [nD,nC] = size(u);
           if nD ~= numel(Ind) || nC ~= 3
               fprintf('ERROR! input matrix of dofs did not have the expected number of dofs\n');
               return;
           end
           u0(Ind,:) = u;
           obj = obj.SetDofs(u0,2);
       end
       
       
       function [obj]       = SetFieldDofs(obj,iField,CHdescription,bOrderedPernode)
          % INPUT:
          % - iField: identifier of the field. Either an integer (ID) or a
          % name (char).
          % - CHdescription: list of DOFs
          % 
          % OUTPUT:
          % - updated class with field values in.                   
          if nargin<4
              bOrderedPernode=0;
          end
          ImplementationChoice = 1;
          bDebug=0;
            if isnumeric(iField)
                % Do nothing
            else
                fieldname = iField; clear iField;
                [obj,iField,bNewField] = obj.GetFieldID(fieldname);
            end
            if(bDebug),fprintf(1,'      ... CubicMeshClass.SetFieldDofs - Setting new values to field "%s"!\n',fieldname);end
          
          switch ImplementationChoice
              case 1 % New one, coping with second versions
                  flags.FlagWhichField =3;
                  flags.FlagSetORGet = 2;
                  flags.FieldID = iField;
                  if(bOrderedPernode)
                      flags.OrderOption=2;
                  end
                  u = CHdescription;
                  obj = obj.SetORGetDofs(flags,u);
              case 2 % Old one...
                    if length(CHdescription)~= 8*obj.nNodes
                        fprintf(1,'WARNING!! CubicMeshClass.SetFieldDofs. The number of field values and derivatives does not correspond with the size of the mesh (8*nNodes)\n!!');
                    end

                    % Retrieve the description:
                    nN = obj.nNodes;
                    obj.fields.value(1:nN,iField)   = CHdescription(1:8:nN*8);
                    obj.fields.dfds1(1:nN,iField)   = CHdescription(2:8:nN*8);
                    obj.fields.dfds2(1:nN,iField)   = CHdescription(3:8:nN*8);
                    obj.fields.dfds3(1:nN,iField)   = CHdescription(4:8:nN*8);
                    obj.fields.dfds12(1:nN,iField)  = CHdescription(5:8:nN*8);
                    obj.fields.dfds13(1:nN,iField)  = CHdescription(6:8:nN*8);
                    obj.fields.dfds23(1:nN,iField)  = CHdescription(7:8:nN*8);
                    obj.fields.dfds123(1:nN,iField) = CHdescription(8:8:nN*8);   
                    if (bFitWithSecondVersions)
                        for iMatNode=1:obj.nNodes
                    for iCont=1:8 % Index of the nodal value (continuity enforced)
                       if (iCont==1)
                           % Same value for the fibre node values, there is
                           % no second version for this.
                           ibasis  = (iMatNode-1)*8 + iCont;                           
                           FibreValue = CHd(ibasis,1:dim);
                           for iCoord=1:3
                               if obj.versions(iMatNode,iCoord)>1
                                   % If one has second versions, all are
                                   % reproduced:
                                   for v=2:obj.versions(iMatNode,iCoord)
                                       obj = obj.SetFibreValue(iMatNode,iCont,v,FibreValue);
                                   end
                               end
                           end
                       else
                           % But different story for the derivatives:
                           for version=2:3
                               % check if this component of the fibre needs
                               % second versions:
                               for iCoord=1:dim
                                   % Index from 0 (no new basis) to nNewBasis:
                                   iNewBasis = obj.NewC1BasisIndex(iCoord,iMatNode,iCont,version);
                                   if (iNewBasis>0)
                                       % The index of the basis in the matrix must
                                       % be added to the last "regular" basis
                                       % index:
                                       iNewBasis = iNewBasis + 8*obj.nNodes;
                                       FibreValue = CHd(iNewBasis,iCoord);
                                       obj = obj.SetFibreValue(iMatNode,iCont,version,FibreValue,iCoord);
                                   end
                               end
                           end
                       end
                   end
                        end
                    end
          end
       end
       function [u]         = GetFieldDofs(obj,iField)
            bDebug=0;
            if isnumeric(iField)
                % Do nothing
            else
                fieldname = iField; clear iField;
                [obj,iField,bNewField] = obj.GetFieldID(fieldname);
            end
            if(bNewField)
                text = sprintf(['Field "' fieldname '" (ID=' num2str(iField) ') does not exist! \n']);
                ME1 = MException('CubicMeshClass:DataConsistency',text);
                throw(ME1);                
            end
            if(bDebug),fprintf(1,'     DEBUGGING ... CubicMeshClass.GetFieldDofs - Getting new values to field "%s" (ID=%i)!\n',fieldname,iField);end
          
            flags.FlagWhichField =3;
            flags.FlagSetORGet = 1;
            flags.FieldID = iField;            
            u = obj.SetORGetDofs(flags);         
       end
       function [obj]       = SetLinearField(obj,u,fieldname)
           % function to creat a new field, with linear interpolation, and
           % nodal values u
           [a,b] = size(u);
           nComponents = min(a,b);
           u = reshape(u,obj.nNodes,nComponents);
           CHdescription = [u;repmat(zeros(obj.nNodes,nComponents),7,1)];
           obj = obj.SetFieldDofs(fieldname,CHdescription);           
           [obj,iF] = obj.GetFieldID(fieldname);
           obj.ListOfFields.field(iF).Name      = fieldname;
           obj.ListOfFields.field(iF).Type          = 'field';
           obj.ListOfFields.field(iF).SubType       = 'rectangular cartesian';
           obj.ListOfFields.field(iF).nComponents   = nComponents;
           for iComp = 1:nComponents
               obj.ListOfFields.field(iF).component(iComp).Name = sprintf('c%i',iComp);
               obj.ListOfFields.field(iF).component(iComp).ScaleFactorSet = 'l.Lagrange*l.Lagrange*l.Lagrange';
               obj.ListOfFields.field(iF).component(iComp).InterpolationBase = 'standard node based';
               obj.ListOfFields.field(iF).component(iComp).nValues = 1;
               obj.ListOfFields.field(iF).component(iComp).nVersions = 1;
           end               
       end
       function [obj]       = SetFibreDofs(obj,CHdescription,FibreComponentIndex)
          ImplementationChoice = 1;
          bDebug=0;
          bPartialUpdate=0;
          if nargin==3
              bPartialUpdate=1;
          end
          % Important for a correct retrieval of Fibres:
          flags.OrderOption=2;
          switch ImplementationChoice
              case 1 % New one, coping with second versions
                  flags.FlagWhichField =2;
                  if (bPartialUpdate)
                      if ~obj.bFibres
                          % Initialise empty fibres:
                          obj = obj.SetFibres();
                      end
                      % First get all the components:                  
                      flags.FlagSetORGet = 1;
                      u = obj.SetORGetDofs(flags);
                      % Now change the dofs of the component indicated:
                      u(:,FibreComponentIndex) = CHdescription;                
                      flags.FlagSetORGet = 2;
                      obj = obj.SetORGetDofs(flags,u);
                  else
                      % Simply set all dofs:
                      flags.FlagSetORGet = 2;
                      u = CHdescription;
                      obj = obj.SetORGetDofs(flags,u);
                  end
              case 2 % Old one...            
                    if length(CHdescription)~= 8*obj.nNodes
                        fprintf(1,'WARNING!! CubicMeshClass.SetFibreDofs. The number of field values and derivatives does not correspond with the size of the mesh (8*nNodes)\n!!');
                    end
                    % Retrieve the description:
                    v=1; % First version only so far
                    nN = obj.nNodes;
                    obj.fibres.value(1:nN,FibreComponentIndex,v)   = CHdescription(1:8:nN*8);
                    obj.fibres.dfds1(1:nN,FibreComponentIndex,v)   = CHdescription(2:8:nN*8);
                    obj.fibres.dfds2(1:nN,FibreComponentIndex,v)   = CHdescription(3:8:nN*8);
                    obj.fibres.dfds3(1:nN,FibreComponentIndex,v)   = CHdescription(4:8:nN*8);
                    obj.fibres.dfds12(1:nN,FibreComponentIndex,v)  = CHdescription(5:8:nN*8);
                    obj.fibres.dfds13(1:nN,FibreComponentIndex,v)  = CHdescription(6:8:nN*8);
                    obj.fibres.dfds23(1:nN,FibreComponentIndex,v)  = CHdescription(7:8:nN*8);
                    obj.fibres.dfds123(1:nN,FibreComponentIndex,v) = CHdescription(8:8:nN*8); 
          end
       end
       function [u]         = GetFibreDofs(obj,FibreComponentIndex)
          bPartialUpdate=0;
          if nargin==2
              bPartialUpdate=1;
          end
          flags.FlagWhichField =2;                 
          flags.FlagSetORGet = 1;
          uAllComponents = obj.SetORGetDofs(flags);
          if (bPartialUpdate)
              u = uAllComponents(:,FibreComponentIndex);
          else
              u = uAllComponents;
          end
       end

       function [obj,iFirstNode] = SetDofsFrom2DUS(obj,iCh,EndoCont,EpiCont)
           % Function to set the degrees of freedom found from 2D US images
           % Assumptions on input data:
           % - A set of 2ch, 3ch and 4ch views (iCh tells which)
           % - EndoCont,EpiCont are the result of the c.Hermite fitting on the
           % segmentation contour (as in Fitting1D.m) after being set in
           % vertical.
           %
           % P.Lamata. 08/11/2013
           bDebug = 0;
           iFirstNode =  NaN;
           if obj.nNodes == 0
               % This is the first call, need to allocate the dofs: the
               % topology is a collapsed ellipsoid:
               options.MeshKind = 'LV';
               nRadial = 1;
               nCircunferential = 6;
               nLongitudinal = EndoCont.nElems/2;
               options.nE = [nLongitudinal nCircunferential nRadial];
               options.bViewResult = 0;
               obj = SynthetiseHeart(options);               
           end
           topology = GetCardiacMeshTopology(obj);
           
           switch iCh
               case 2, 
                   iFirstNode = 2;
                   RotationAngle = - pi/3; %0;
               case 3, 
                   iFirstNode = 3;
                   RotationAngle = - 2*pi/3;
               case 4, 
                   iFirstNode = 1;
                   RotationAngle = 0; %2*pi/3;
           end           
           
           [dofsEndo3DMesh,dofsEpi3DMesh] = obj.GetLVEndoEpiNodes(topology,iFirstNode);
           
           if(bDebug)
               figure('color',[1 1 1]); 
               original = obj;
           end
           nD = numel(dofsEndo3DMesh);
           % The apical node is the one in the middle (even number):
           iApical = ceil(nD/2);
           Apicaldofs = EpiCont.GetNodalDofs(iApical);
           ApicalPoint= [0 Apicaldofs(1,2) Apicaldofs(1,1)];
           for iCont = 1:2
               for iN = 1:nD;
                   switch iCont,
                       case 1, 
                           dofs = EndoCont.GetNodalDofs(iN);
                           Dofs3DMesh = dofsEndo3DMesh;
                       case 2, 
                           dofs = EpiCont.GetNodalDofs(iN);
                           Dofs3DMesh = dofsEpi3DMesh;
                   end
                   iNode3D = Dofs3DMesh(iN);
                   % The coordinate and derivative:
                   Point3D = [0 dofs(1,2) dofs(1,1)];
                   Derivat = [0 dofs(2,2) dofs(2,1)];
                   % Rotate them accordingly to the slice number:
                   RotationMatrix = [   cos(RotationAngle) -sin(RotationAngle) 0;
                                        sin(RotationAngle) cos(RotationAngle) 0;
                                        0 0 1];
                   
                   % Center all contours with apex at [0 0 0}, so the centre of rotation is also [0 0 0]:                   
                   Point3D = Point3D - ApicalPoint;
                   center_matrix = [0 0 0];
                   %center_matrix  = [0 EndoCont.Centre];
                   %center_matrix = [0 Apicaldofs(1,2) EndoCont.Centre(2)];%ApicalPoint;
                   Point3D = (Point3D - center_matrix)* RotationMatrix + center_matrix;
                   Derivat = Derivat* RotationMatrix;
                   
                   % Caution! the orientation of the derivative should be
                   % from apex to base: the first half of samples need to
                   % have this inverted:
                   if iN<nD/2
                       Derivat2write = - Derivat;
                   else
                       Derivat2write = Derivat;
                   end

                   if iN==1
                       % This is the first node, corresponding to the first
                       % point clicked in TomTec:
                       fprintf(' ANATOMICAL CONVENTION: node %i is the first in %i chamber view\n',iNode3D,iCh);
                       iFirstNode = iNode3D;
                   end
                   % now set the point:
                   obj = obj.SetNodeCoorValue(Point3D,iNode3D,1:3,1);
                   % and the derivative: longitudinal is xi2, the third dof:
                   obj = obj.SetNodeCoorValue(Derivat2write,iNode3D,1:3,3);
                   % Fix also the other two derivatives: this does not work
                   % because the longitudinal derivative can be pointing
                   % out or in (radially), breaking the assumption taken
                   % here of being pointing out.
%                    indexesOtherTwoDerivatives = [2 5];
%                    for iOD = 1:2
%                        iDeri = indexesOtherTwoDerivatives(iOD);
%                        OriginalDeriv = obj.GetNodeCoorValue(iNode3D,1:3,iDeri);
%                        Module = sqrt(sum(OriginalDeriv.^2));
%                        switch iOD
%                            case 1 % this is the circunferential, only xy component and perpendicular to the elongation:
%                                 Direct = -[Derivat(2) -Derivat(1) 0];
%                                 Module = sqrt(sum(Derivat.^2));
%                            case 2 % this is the radial direction, a bit from the same of elongation
%                                 Direct = [Derivat(1) Derivat(2) 0];
%                        end
%                        Direct = Direct / sqrt(sum(Direct.^2));
%                        NewDeriv = Direct * Module;                   
%                        obj = obj.SetNodeCoorValue(NewDeriv,iNode3D,1:3,iDeri);
%                     end
               end
               if (bDebug)
                   original.plotWireframe();
                   hold on;
                   obj = obj.Update();
                   obj.plotWireframe('r');
                   hold off;
               end
           end 
           obj = obj.Update();
       end
       function [obj] = PostProcessUSfitting(obj)
           bDebugRad = 0;
           bDebugLong = 0;
          if (bDebugRad)||bDebugLong
            figure('color',[1 1 1]);
          end
           % Post-processing steps:
           % ... remove derivatives at apex:
           topology = GetCardiacMeshTopology(obj);
           [dofsEndo3DMesh,dofsEpi3DMesh] = obj.GetLVEndoEpiNodes(topology);
           nLayers = numel(topology.NodeLayer);
           ApicalNodes = [topology.NodeLayer(nLayers).EndoNodes(:) topology.NodeLayer(nLayers).EpiNodes(:)];
           for iDof = 2:8
               for iApical = 1:numel(ApicalNodes)
                   iNode = ApicalNodes(iApical);
                   obj = obj.SetNodeCoorValue([0 0 0],iNode,1:3,iDof);
               end
           end
           % ... refine radial derivatives: from endo to epi
           nNods = numel(dofsEndo3DMesh);
           for iN =1:nNods
               iNodeEndo = dofsEndo3DMesh(iN);
               Pendo = obj.GetNodeCoorValue(iNodeEndo,1:3,1);
               iNodeEpi  = dofsEpi3DMesh(iN);
               Pepi  = obj.GetNodeCoorValue(iNodeEpi,1:3,1);
               RadialDeri = Pendo - Pepi;
               iRadial = 4;
               obj = obj.SetNodeCoorValue(RadialDeri,iNodeEpi,1:3,iRadial);
               obj = obj.SetNodeCoorValue(RadialDeri,iNodeEndo,1:3,iRadial);
               if (bDebugRad)
                   obj.plotWireframe();
                   hold on;
                   obj.plotNodeCoordinates(iNodeEpi);
                   obj.plotNodeCoordinates(iNodeEndo);
                   obj.plotNodeFirstDerivatives(iNodeEpi,1);
                   obj.plotNodeFirstDerivatives(iNodeEndo,100);
                   hold off;
               end
           end
           % ... refine cicunferential derivative: look at the adjacent in
           % the same level
           for iLayer = 1:nLayers-1
               for iCont = 1:2
                   switch iCont
                       case 1, nodes = topology.NodeLayer(iLayer).EndoNodes(:);
                       case 2, nodes = topology.NodeLayer(iLayer).EpiNodes(:);
                   end
                   nNlay = numel(nodes);
                   for iN = 1:nNlay
                       iNn = rem(iN,nNlay) + 1;
                       iNp = iN - 1; if iNp == 0, iNp = nNlay; end
                       iNnext = nodes(iNn);
                       iNprev = nodes(iNp);
                       iNode  = nodes(iN);
                       P1 = obj.GetNodeCoorValue(iNprev,1:3,1);
                       P2 = obj.GetNodeCoorValue(iNnext,1:3,1);
                       CircDer = -(P1 - P2)/1.5;
                       iCirc = 2;
                       obj = obj.SetNodeCoorValue(CircDer,iNode,1:3,iCirc);
                       if(bDebugLong)
                           obj.plotWireframe();
                           hold on;
                           obj.plotNodeCoordinates(iNprev);
                           obj.plotNodeCoordinates(iNnext);
                           obj.plotNodeFirstDerivatives(iNode,0.1);
                       end
                   end
               end
           end
           obj = obj.Update();
       end
           
       
       
       function [NodeValue] = GetNodeCoorValue(obj,iNode,iCoor,iNodeValue,version,whichField)
       % whichField:
       %         0: coordinate field
       %         1: fibre field
          if nargin<3,          iCoor = 1:3;         end
          if nargin<4,          iNodeValue = 1;         end
          if nargin<5,          version = 1;         end
          if nargin<6,          whichField = 0;         end
          switch iNodeValue
               case 1
                   switch whichField
                       case 0
                            NodeValue = obj.coordinates(iNode,iCoor,version);
                       case 1
                            NodeValue = obj.fibres.value(iNode,iCoor,version);
                   end
               case 2
                   switch whichField
                       case 0
                           NodeValue = obj.derivatives.duds1(iNode,iCoor,version);
                       case 1
                            NodeValue = obj.fibres.dfds1(iNode,iCoor,version);
                   end
               case 3
                   switch whichField
                       case 0
                           NodeValue = obj.derivatives.duds2(iNode,iCoor,version);
                       case 1
                            NodeValue = obj.fibres.dfds2(iNode,iCoor,version);
                   end
               case 5  % (not 4 in order to be congruent with the exelem definition!)
                   switch whichField
                       case 0
                           NodeValue = obj.derivatives.duds12(iNode,iCoor,version);
                       case 1
                            NodeValue = obj.fibres.dfds12(iNode,iCoor,version);
                   end
               case 4  
                   switch whichField
                       case 0
                           NodeValue = obj.derivatives.duds3(iNode,iCoor,version);
                       case 1
                            NodeValue = obj.fibres.dfds3(iNode,iCoor,version);
                   end
               case 6
                   switch whichField
                       case 0
                           NodeValue = obj.derivatives.duds13(iNode,iCoor,version);
                       case 1
                            NodeValue = obj.fibres.dfds13(iNode,iCoor,version);
                   end
               case 7
                   switch whichField
                       case 0
                           NodeValue = obj.derivatives.duds23(iNode,iCoor,version);
                       case 1
                            NodeValue = obj.fibres.dfds23(iNode,iCoor,version);
                   end
               case 8
                   switch whichField
                       case 0
                           NodeValue = obj.derivatives.duds123(iNode,iCoor,version);
                       case 1
                            NodeValue = obj.fibres.dfds123(iNode,iCoor,version);
                   end
          end
       end
       function [obj]       = SetNodeCoorValue(obj,Value,iNode,iCoor,iNodeValue,version)
       % 
            if iNode > obj.nNodes
                if obj.bWarnings
                    fprintf('Warning (while setting node values)! node %i does not belong to the mesh %s! (nNodes = %i)\n',iNode,obj.name,obj.nNodes);
                end
            end
          if nargin<4,          iCoor = 1:3;         end
          if nargin<5,          iNodeValue = 1;         end
          if nargin<6,          version = 1;         end
          switch iNodeValue
               case 1
                   obj.coordinates(iNode,iCoor,version) = Value;
               case 2
                   obj.derivatives.duds1(iNode,iCoor,version) = Value;
               case 3
                   obj.derivatives.duds2(iNode,iCoor,version) = Value;
               case 5  % (not 4 in order to be congruent with the exelem definition!)
                   obj.derivatives.duds12(iNode,iCoor,version) = Value;
               case 4  
                   obj.derivatives.duds3(iNode,iCoor,version) = Value;
               case 6
                   obj.derivatives.duds13(iNode,iCoor,version) = Value;
               case 7
                   obj.derivatives.duds23(iNode,iCoor,version) = Value;
               case 8
                   obj.derivatives.duds123(iNode,iCoor,version) = Value;                        
          end
       end
       function obj         = SetFibreValue(obj,iMatNode,iCont,version,FibreValue,iCoor)
           % Function to set a fibre value:
           if nargin<6
               iCoor=1:3;
               if size(FibreValue)~=3
                   fprintf('error! FibreValue is not 3D as it should be!\n');
               end
           end
           switch iCont
               case 1
                   obj.fibres.value(iMatNode,iCoor,version) = FibreValue;
               case 2
                   obj.fibres.dfds1(iMatNode,iCoor,version)=FibreValue;
               case 3
                   obj.fibres.dfds2(iMatNode,iCoor,version)=FibreValue;
               case 4 % (not 4 in order to be congruent with the exelem definition!)
                   obj.fibres.dfds3(iMatNode,iCoor,version)=FibreValue;
               case 5
                   obj.fibres.dfds12(iMatNode,iCoor,version)=FibreValue;
               case 6
                   obj.fibres.dfds13(iMatNode,iCoor,version)=FibreValue;
               case 7
                   obj.fibres.dfds23(iMatNode,iCoor,version)=FibreValue;
               case 8
                   obj.fibres.dfds123(iMatNode,iCoor,version)=FibreValue;
               otherwise
                   fprintf(1,'ERROR!!! In CubicMeshClass:SetFibreValue, wrong selection of nodal value index!!\n');
           end
       end

       
       function [points]    = GetPoints(obj)
           % TODO: get all versions of the coordinates...
           [nPoints nCoords nVersions] = size(obj.coordinates);
           if nVersions==1
               points=reshape(obj.coordinates,nPoints,nCoords);
           else % Only 2 versions per coordinate are expected!!!!
               points=reshape(obj.coordinates(:,:,1),nPoints,nCoords);
               points(nPoints+1:2*nPoints,1:3)=reshape(obj.coordinates(:,:,1),nPoints,nCoords);
           end
       end
       function iE          = FindElementGivenPointCoordinates(obj,P,XiCoor)
           % Function to get the global coordinates of all elements in
           % local point XiCoor, and retur the index of the elemnt closest
           % to the global point P           
           distances = zeros(obj.nElems,1);
           for iE=1:obj.nElems
               P2 = obj.evaluate(iE,XiCoor);
               distances(iE)  = sum(abs(P-P2));
           end
           iE = find(distances == min(distances));
           if numel(iE)>1
               fprintf('ERROR! There were at least two elements whose local coordinate (%1.2f,1.2f,1.2f)\n',XiCoor)
               fprintf('       were in the 3D point (%1.2f,1.2f,1.2f)!\n', P);
               fprintf('       These were elements: %i, %i - Returning the first one\n', iE(1:2));
               temp = iE;
               clear iE;
               iE = temp(1);
           end
       end
       function [dudxi1,dudxi2,dudxi3,iE,xiCoordinate,dist] = GetXiDirections(obj,Point,XiCoor,bIncludeOutside)
          % Function to calculate the projection of a vector into the
          % unitary direction in Xi1 material coordinate.
          %
          % OUTPUT:
          % - dist: metric of the distance between the Point and the
          % physical location of the point corresponding to xiCoordinates
          % (because of optimization resolution in the search of the
          % inverse coordinate, or because Point was outside the domain).
          %
          % Version control:
          % 23/06/14: if a point is not inside the domain, a closest point
          % is found, and xi directions are extracted from it
                if nargin<4
                    bIncludeOutside = 0;
                end

                    
                %[iE,xiCoordinate,error]= obj.GetLocalCoords(Point);
                bNeedComputeXi = 1;
                if nargin==3
                    if ~isempty(XiCoor) && ~inan(XiCoor)
                        bNeedComputeXi = 0;                    
                        % Xi coordinate is available! only need to know the
                        % element now:
                        xiCoordinate = XiCoor;
                        iE = obj.FindElementGivenPointCoordinates(Point,XiCoor);
                        dist = 0;
                    end
                end
                if(bNeedComputeXi)
                    % Need to compute coordinates...
                    [iE,xiCoordinate,error]= obj.evaluate_inverse(Point);
                    dist = sum(error.^2);
                end
                    
                 if(isempty(xiCoordinate))
                     % The point is external to the mesh. The closest point
                     % is searched and given instead.
                     if(bIncludeOutside)
                        [dist CP iE xiCoordinate]   = obj.CalculateDistancePoint2Mesh(Point);
                     else
                        iE=NaN; xiCoordinate = NaN; dist=NaN;
                        dudxi1 = NaN;dudxi2= NaN;dudxi3= NaN;
                        return;
                     end
                 end
                 %else
                    % 2. Get the cartesian direction of du/dxi1,2,3:
                    dudxi1 = obj.evaluate(iE,xiCoordinate,2);
                    dudxi2 = obj.evaluate(iE,xiCoordinate,3);
                    % No need of: dudxi3 = obj.evaluate(iE,xiCoordinate,4);
                    % 3. Unitary versions of directions of local coordinate
                    % system:
                    dudxi1 = obj.Normalise(dudxi1);

                    % 4. Get the orthonormal coordinate system: find the vector
                    % perpendicular to dudxi1 and in the plane of dudxi1-dudxi2
                    dudxi3 = cross(dudxi1,dudxi2);
                    dudxi2 = cross(dudxi3,dudxi1);
                    dudxi2 = obj.Normalise(dudxi2);
                    dudxi3 = obj.Normalise(dudxi3);                    
%                  else
%                      fprintf(1,' WARNING (CubicMeshClass:GetXiDirections)! Point (%1.3f,%1.3f,%1.3f) not found inside the mesh!\n',Point);
%                      figure; obj.plotExternalSurfaces();
%                      plot3(Point(1),Point(2),Point(3),'rx');
%                      [iE,xiCoordinate,error]= obj.GetLocalCoords(Point)
%                      dudxi1 = NaN;dudxi2= NaN;dudxi3= NaN;
                  
       end
       function [vector]    = GetXi1LocalCoordinateDirection(obj,point)
           % Function which returns the xi1 local coordinate direction (in
           % global cartesian space)
           %1. Find the local coordinates corresponding to "point"
           %[iElem,xiCoordinate]= obj.GetLocalCoords(point);
           [iElem,xiCoordinate]= obj.evaluate_inverse(point);
           %2. Get du/dxi1 at this point:
           vector = obj.evaluate(iElem,xiCoordinate,2);
       end
       function [iE,xiCoordinate,error]= GetLocalCoords(obj,point)
           fprintf(1,' GetLocalCoords: FUNCTION DEPRECATED, use evaluate_inverse instead!\n');
           %[iE,xiCoordinate,error]= obj.evaluate_inverse(point);
           bDebug = 0;
           point = reshape(point,1,3);
           %1. Calculate which are the closest elements:
           RelativeCloseDefinitionInPercentage = 1;
           Elements = obj.FindClosestElements(point,RelativeCloseDefinitionInPercentage);
           nE = length(Elements);
           if(bDebug), fprintf('Closest element is %i. Other %i added in the search\n',Elements(1),nE-1); end 
           
           %2. Find xiCoordinate in these elements:
           candidate = zeros(nE,3);
           QualityCandidate = zeros(1,nE);
           for iE=1:nE
               iElem = Elements(iE);
               nSteps = 5;
               xiMin=1/1000; xiMax=1-xiMin; xiStep=(xiMax-xiMin)/nSteps;
               xi1Range = xiMin:xiStep:xiMax;
               xi2Range = xiMin:xiStep:xiMax;
               xi3Range = xiMin:xiStep:xiMax;
               xiCoords = obj.BuildXiSamples(xi1Range,xi2Range,xi3Range);
               Points3D = obj.fastCoordinateEvaluation(iElem,xiCoords);
               distance = (sum( (Points3D-repmat(point',1,length(Points3D))).^2 , 1));
               I = find (distance==min(distance));
               QualityCandidate(iE)=min(distance);
               candidate(iE,:) = [xiCoords(1,I) xiCoords(2,I) xiCoords(3,I)];
               if(bDebug), fprintf('Candidate from element %i (coords %1.1f,%1.1f,%1.1f): ',iElem,candidate(iE,:)); end
               if(bDebug), fprintf(' 3D point = %1.1f,%1.1f,%1.1f. Distance=%1.1f \n',obj.evaluate(iElem,candidate(iE,:)),QualityCandidate(iE)); end
           end
           Iwinner = find(QualityCandidate==min(QualityCandidate));
           xiCoordinate = candidate(Iwinner,:);
           error = QualityCandidate(Iwinner);
           iE = Elements(Iwinner);
           if(bDebug), fprintf('Winner in element %i (coords %1.1f,%1.1f,%1.1f): 3D point = %1.1f,%1.1f,%1.1f \n',iE,xiCoordinate,obj.evaluate(iElem,xiCoordinate)); end
       end
       function [iElem, xiC, FVAL]= evaluate_inverse(obj,value,options)
           % By Jiahe
           % retrieve the an element 'iElem' at xi coordinates 'xiCoordinate'
           % for the field (only the spatial coordinate implemented) of a mesh
           % INPUT:
           % - value : Real ^ {1 x 3}
           % - options.TolFun: solution (xiC) accuracy,default 1e-6
           % OUPUT:
           % iElem: integer
           % xiC: 1 by 3 xi coordinates (empty if this point is not inside any element)
           % FVAL: 1 by 3 double, residual vector for each dimension (should be [0,0,0])
           % example:  [iElem xiC]=CH.evaluate_inverse(point_true,struct('iElem_guess',iElem,'eBB',eBB));
           
           bDebug=0;
           if nargin<3
               options='';
           end           
           if(isfield(options,'TolFun'))
             TolFun=options.TolFun;
           else
             TolFun=1e-6;
           end
           if(isfield(options,'option')) 
             option=options.option;
           else
             option=1;
           end
           if(isfield(options,'iElem_guess'))
               iElem_guess=options.iElem_guess;
           else
               iElem_guess=[];
           end
           if(option~=1)
               disp('only u implemented yet');
           end
           if(isfield(options,'eBB'))
               eBB=options.eBB; %cell, each is 2 by n matrix
           else
               if (obj.beBBbuilt)
                   eBB=obj.eBB;
               else
                   fprintf(1,'   WARNING! CubicMeshClass:evaluate_inverse, element bounding boxes were not precomputed. Consider to do so for speed-up reasons in several evaluations.\n');
                   obj = obj.BuildElementBoundingBoxes();
                   eBB=obj.eBB;
               end
           end
           if(isfield(options,'method'))
               method=options.method; 
           else
               method=1;
           end
           
           [a,b] = size(value);
           if a>b, value = value'; end
           
           xiC=[];
           iElem=[];
           FVAL=[];
           xiC_all = [];
           iElem_all = [];
           FVAL_all = [];
           for iElem_temp=[iElem_guess obj.nElems:-1:1]
               %check the bounding box for each element
               if(~isempty(eBB) && ~obj.inRange(value, eBB(:,:,iElem_temp), 0.5)) %x 1 by n; range: 2 by n
                   continue;
               end
               
               f = @(x)obj.evaluate(iElem_temp,x,option)-value;
               %norm(f([0.1; 0.1; 0.1])) %0
                if(method==1)
                    if (bDebug),  dis='iter';
                    else          dis='off';
                    end
                   [xiC_temp FVAL,EXITFLAG] = fsolve(f,0.5+zeros(3,1), optimset('TolFun',TolFun,'MaxIter',10,'Display',dis));
%                  if(EXITFLAG==1 && xiC_temp(1)<=1 && xiC_temp(1)>=0 && xiC_temp(2)<=1 && xiC_temp(2)>=0 && xiC_temp(3)<=1 && xiC_temp(3)>=0)       
                   tolerance = 1e-5; %set a tolerance for the range check!
                   if(EXITFLAG==1 && obj.inRange(xiC_temp,[0 0 0; 1 1 1], tolerance))
                       xiC = xiC_temp;
                       iElem =iElem_temp;
                       break;
                   else
                       if(bDebug)
                        disp(['no solution when iElem_temp=' num2str(iElem_temp)]);
                       disp(['exit flag(1:coverged to a root) :' num2str(EXITFLAG)]);
                       disp(num2str(xiC_temp(:)'));
                       end
                   end
                elseif(method==2)
                   [xiC_temp, FVAL,RESIDUAL, EXITFLAG] = lsqnonlin(f,0.5+zeros(3,1),zeros(3,1),ones(3,1), optimset('TolFun',TolFun,'MaxIter',10,'Display','iter'));
                   %EXITFLAG: 
                   %1  LSQNONLIN converged to a solution X.
                   %3  Change in the residual smaller than the specified tolerance.
                   FVAL
                   EXITFLAG
                   if(bDebug), if(EXITFLAG~=1 && EXITFLAG~=3 && EXITFLAG~=0 )
                       disp('check EXITFLAG'); keyboard;
                   end; end
                   xiC_all = [xiC_all xiC_temp];
                   iElem_all = [iElem_all;iElem_temp];
                   FVAL_all = [FVAL_all; FVAL];
                   %if(FVAL < 5.41315e-6) 
                   %     break;
                   %end
                else
                    disp('wrong method choice'); keyboard
                end
           end
           
           if(method==2) %find the minimum
               if(~isempty(FVAL_all))
                   [FVAL_all_sorted Index] = sort(FVAL_all);
                   xiC = xiC_all(:,Index(1));
                   iElem = iElem_all(Index(1));
                   FVAL = FVAL_all(Index(1));
               end
           end
       end
       
       function [ShapeSurfError]     = SurfaceWeightedIntegration(obj,valuesAtGaussPoints)
           % Function to integrate the error value obtained by cmiss. A set
           % of Gauss Points were evaluated and compared, obtaining an
           % error per coordinate component, x-y-z:
           nPoints = numel(valuesAtGaussPoints)/3;
           if ~obj.bExternalFacesFound
               obj = obj.FindExternalSurfaces();
           end;
           nPointsPerSurface = nPoints/obj.nExternalFaces;
           GaussOrder = sqrt(nPointsPerSurface);
           bTimingDebug = 0;
           % The definition of the weights:
           GaussPts2D    = obj.GetSurfaceGaussPoints(1,1,GaussOrder);
           GaussWeights2D= reshape(GaussPts2D.GaussWeights2D,1,nPointsPerSurface);
           Gauss2DLocCoords=GaussPts2D.LocalCoordinates;
           
            
            iS = 0;    
            if (bTimingDebug), tT=tic(); end
            for iElem=1:obj.nElems                
                for iFace=1:6
                    if obj.ExternalFaces(iElem,iFace)
                        iS = iS +1;          
                        I1 = 1 + (iS-1)*nPointsPerSurface;
                        I2 =      iS   *nPointsPerSurface;
                        er3D = valuesAtGaussPoints(I1:I2,1:3);
                        er = sqrt(sum(er3D.^2,2)); % a [npoints] vector of the error in each point
                        if (bTimingDebug), t1=tic(); end
                        
                        CrossTangents    = obj.GetCrossTangents(iElem,iFace,Gauss2DLocCoords);
                        SurfaceContribution(iS) = sum(CrossTangents.*GaussWeights2D);   
                        [a,b] = size(er); if a<b, er=er'; end
                        err(iS) = (er'.*CrossTangents)*GaussWeights2D';
                        if (bTimingDebug), time=toc(t1); fprintf(1,' ****  Time = %d ****\n',time);end
                    end   
                 end
            end
            TotalSurf = sum(SurfaceContribution);
            ShapeSurfError = sum(err)/TotalSurf; % after having made the sqrt before (RMS)
            fprintf(1,' ====  END. Shapes surf error = %d (Total Surface = %d) ====\n\n',ShapeSurfError,TotalSurf);
            if (bTimingDebug), time=toc(tT); fprintf(1,' ****  Time = %d ****\n',time);end
                       
%             % A) 3D coordinates of the Gauss Points of the Ground Truth:
%                     
%                     TemplateCoord = GaussPts2D.GlobalCoordinates';
%                     for iC=1:nCoords
%                         switch shape
%                             case 'cylinder'
%                                 GTcoordinate = CylinderValues(Test,TemplateCoord(iC,1:3),dimensions,0);
%                             case 'cube'
%                                 GTcoordinate = CubeValues(Test,TemplateCoord(iC,1:3),dimensions,0);
%                         end
%                         GPcoord2(iC,1:3)=GTcoordinate;   
%                     end
%                     if (bSurfaceError2MaterialPoint)  
%             % B) 3D coordinates of the Gauss Points of the data:
%                         GaussPts2D = Shape1.GetSurfaceGaussPoints(iElem,iFace,GaussOrder); 
%                         % BUG DETECTED! do not reshape to transpose... it mixes
%                         % things up!
%                         % GPcoord1   = reshape(GaussPts2D.GlobalCoordinates,nCoords,3); 
%                         GPcoord1   = GaussPts2D.GlobalCoordinates';
%                         er = GPcoord1-GPcoord2;
%                         er =  sqrt(sum(er.^2,2));
%                     end
%                     if (bSurfaceError2ClosestPoint)
%                         for iC=1:nCoords
%                             point = GPcoord2(iC,1:3); 
%                             [er(iC) CP(iC,1:3)] = Shape1.CalculateDistancePoint2Mesh(point);
%                         end
%                     end
%                     if (bGraphicalDebug)
%                         figure('Color',[1 1 1]); hold on;
%                         plot(er)
%                         title(sprintf('Distance to the closest point of the %i Gauss Points of face %i of element %i',nCoords,iFace,iElem));
%                     end

          
       end
       
       function [thickness,ThickSTD] = EstimateThickness(obj)
           % Function to estimate the thickness of a cardiac mesh: the
           % distance between nodes of "epi" and "endo" surfaces.
           % Assumptions taken:
           % - obj.FindEpiElements and obj.FindEndoElements work
           
           discretisation = 5;
           
           if obj.bExternalFacesFound==0
               obj = obj.FindExternalSurfaces();
           end   
           [iElemEpi,iEpiFace] = obj.FindEpiElements();           
           [iElemEndo,iEndoFace] = obj.FindEndoElements();
           nPPS = discretisation^2;
           EpiPoints = zeros(nPPS * numel(iElemEpi),3);
           EndoPoints= zeros(nPPS * numel(iElemEndo),3); 
           % Build a list of epicardial points:
           for iE = 1:numel(iElemEpi)
               iElEpi = iElemEpi(iE);
               % Get a sample of surface points
               [foo,Points1] = obj.tesselateElementFace(iElEpi,iEpiFace,discretisation);
               i0 = (iE-1)*nPPS + 1;
               i1 = iE*nPPS;
               EpiPoints(i0:i1,:) = Points1;
           end           
           % Build a list of endocardial points:
           for iE = 1:numel(iElemEndo)
               iElEndo = iElemEndo(iE);
               % Get a sample of surface points
               [foo,Points2] = obj.tesselateElementFace(iElEndo,iEndoFace,discretisation);
               i0 = (iE-1)*nPPS + 1;
               i1 = iE*nPPS;
               EndoPoints(i0:i1,:) = Points2;
           end         
           % Find the closest point from one to the other:
           nPoints = numel(EndoPoints)/3;
           Dist = zeros(1,nPoints);
           for iP = 1:nPoints
               P1 = EndoPoints(iP,:);
               dist = repmat(P1,nPoints,1) - EpiPoints;
               dist = sum(abs(dist),2);
               iClosest = find(dist==min(dist));
               D = P1 - EpiPoints(iClosest(1),:);
               Dist(iP) = sqrt(sum(D.^2));
           end
           thickness = mean(Dist);
           ThickSTD  = std(Dist);
       end
       
% Mesh deformation functions:
       function [obj]       = rotateMeshOnAxis(obj,angle,whichaxis)
            % Function to rotate a mesh around one of the cartesian axis:
            % - angle: in degrees
            centre = obj.GetMeshCentre(1);
            rotX=0; rotY=0; rotZ=0;
            switch whichaxis
                case {1,'x','X'}
                    rotX = angle;
                case {2,'y','Y'}
                    rotY = angle;
                case {3,'z','Z'}
                    rotZ = angle;
                otherwise
                    fprintf('ERROR! Wrong selection of the axis in rotateMeshOnAxis!\n');
            end    
            R = CreateRotationMatrix(rotX,rotY,rotZ);
            %obj = obj.TransformMesh(1,R,centre);
            obj = obj.rotateMesh(R,centre);
       end
       function [obj]       = translateMesh(obj,Translation)
            Translation = reshape(Translation,1,3);
            u = obj.GetDofs();
            nDofs = numel(u)/3;
            if(obj.InterpolationBasis == 1)
                Translation_matrix = [repmat(Translation, obj.nNodes, 1); repmat([0 0 0], obj.nNodes*7, 1)];
                nDofsExpected = obj.nNodes* 8; %why 8? what if mesh is c.Lagrange? %GGG
            else
                Translation_matrix = [repmat(Translation, obj.nNodes, 1)];
                nDofsExpected = obj.nNodes* 1;%8; %why 8? what if mesh is c.Lagrange? %GGG
            end
            
            
            if nDofs~=nDofsExpected
                for iSecondDof=1:obj.nNewVersionsBasis
                    iDof = nDofsExpected + iSecondDof;
                    [iCoor iNode iValue version] = obj.GetDofMeaning(iDof);
                    if iValue==1
                        % This is a coordinate, need to put the centre:
                        Translation_matrix(nDofsExpected+iSecondDof,:) = Translation;
                    else
                        Translation_matrix(nDofsExpected+iSecondDof,:) = zeros(1,3);
                    end
                end
            end
            u_corrected = (u + Translation_matrix);
            obj=obj.SetDofs(u_corrected);
       end
       function [obj]       = rotateMesh(obj,RotationMatrix,center)
            if nargin<3
                center = obj.GetMeshCentre();
            end
            center = reshape(center,1,3);
            u = obj.GetDofs();
            nDofs = numel(u)/3;
            if(obj.InterpolationBasis == 1)
                % If it is a c.Hermite:
                center_matrix = [repmat(center, obj.nNodes, 1); repmat([0 0 0], obj.nNodes*7, 1)];
                nDofsExpected = obj.nNodes*8; %why 8? what if mesh is c.Lagrange? %GGG
            else
                % If it is not a c.hermite it is supposed that there is one
                % dof per node:
                center_matrix = [repmat(center, obj.nNodes, 1);];
                nDofsExpected = obj.nNodes*1; 
            end
            if nDofs~=nDofsExpected
                for iSecondDof=1:obj.nNewVersionsBasis
                    iDof = nDofsExpected + iSecondDof;
                    [iCoor iNode iValue version] = obj.GetDofMeaning(iDof);
                    if iValue==1
                        % This is a coordinate, need to put the centre:
                        center_matrix(nDofsExpected+iSecondDof,:) = center;
                    else
                        center_matrix(nDofsExpected+iSecondDof,:) = zeros(1,3);
                    end
                end
            end
            u_corrected = (u - center_matrix)* RotationMatrix' + center_matrix;
            obj=obj.SetDofs(u_corrected);
        end
       function [obj,M_v2w] = rotateBasedOnDicom(obj,dicomFile)
            %correct the this mesh based on origin and rotation from dicom
            %file. 
            % OUTPUT: 
            % - obj
            % - M_v2w: matrix to transform voxel to world coordinates
             
             if(exist(dicomFile,'file')~=2)
                 disp(['rotateBasedOnDicom: File does not exits: ' dicomFile]);
                 keyboard;
             end
             info = dicominfo(dicomFile);
             center = info.ImagePositionPatient(:)';
             vecB1=info.ImageOrientationPatient(1:3);
             vecB2=info.ImageOrientationPatient(4:6);
             RotationMatrix = [vecB1(:) vecB2(:) cross(vecB1(:), vecB2(:))];
             % Bug corrected 22/01/2013: spacing replaced by center. Not
             % tested though!
             %obj = obj.rotateMesh(obj,RotationMatrix,spacing);
             obj = obj.rotateMesh(obj,RotationMatrix,center);
             
             % Now, build the voxel to world coordinates transfomation
             % matrix:
             M_v2w = zeros(3,4);
             M_v2w(1:3,1:3) = RotationMatrix;
             M_v2w(1:3,4)   = center;
       end
       function [obj,M_v2w] = rotateBasedOnHeaderData(obj,IMAGEfile)
           % Generic funciton that rotates the mesh relying on the
           % possibility of building the M_v2w matrix from the header of
           % the image file
           % Get the header information:
           [foo,hd] = io_ReadMedicalImage(IMAGEfile);
           M_v2w = hd.Mv2w;
           spacingUsed = hd.spacing;           
           obj = obj.RotateWithM_v2w(M_v2w,spacingUsed);
       end
       function [obj,M_v2w] = rotateBasedOnNII(obj,NIIfile,spacingUsed)
           % Function to rotate a not-rotated mesh (from image headers).  
           % All the meshing has been done with the assumption of an identity
            % rotation matrix. The mesh needs now to be rotated back.

             if(exist(NIIfile,'file')~=2)
                 disp(['rotateBasedOnNII. File does not exits: ' NIIfile]);
                 keyboard;
             end
             [M_v2w,foo,header] = GetMv2wMatrixFromNifti(NIIfile);
             if nargin<3
                 spacingUsed = header.spacing;
             end
             if ~isnan(M_v2w(1))
                obj = obj.RotateWithM_v2w(M_v2w,spacingUsed);   
             else
                 fprintf('ERROR! Not possible to rotate mesh, it was not possible to get the voxel to world transformation matrix\n');
             end
       end
       
       function obj         = RotateWithM_v2w(obj,M_v2w,spacingUsed)
            % M_v2w:
            % This matrix is a 4x4 cannonical form that translates original
            % voxel
            % coordinates to world coordinates. But the mesh is already with the
            % right origin and spacing. The correction should be then:
            %  - For coordinates: U_corr = ( (U-origin)/spacing )*M_v2w';
            %  - For derivatives: U_corr = ( (U)/spacing )*M_v2w(1:3,1:3)';
            % where origin and spacing are the ones used before to create
            % the mesh in world coordinates (without taking rotation into
            % account)
             
             spacing= spacingUsed;            
             origin = reshape(M_v2w(1:3,4),1,3);
             
             % todo: DEFINE THE ROTATION MATRIX, AND USE RotateMesh()!!
             
             u = obj.GetDofs();
             u_voxel = zeros(size(u));
             [nN b c]= size(obj.coordinates);
             origin_matrix = repmat(origin, nN, 1);
             spacing_matrix = repmat(spacing, nN, 1);
             % Nodal coordinates, only first versions:
             iDOF = 1;
                is   = 1+(iDOF-1)*nN:(iDOF)*nN;
                u_voxel(is,1:3,1) = (u(is,1:3,1) - origin_matrix)./spacing_matrix;
                % Now, the canonical form:
                u_voxel(is,4,1) = ones(nN,1);
                u_corrected(is,1:3,1) = u_voxel(is,:,1) * M_v2w';
                if(obj.InterpolationBasis == 1)
                     % Nodal derivatives, only first versions:
                     for iDOF=2:8
                        is   = 1+(iDOF-1)*nN:(iDOF)*nN;
                        u_voxel(is,1:3,1) = u(is,1:3,1)./spacing_matrix;
                        u_corrected(is,1:3,1) = u_voxel(is,1:3,1) * M_v2w(1:3,1:3)';
                     end
                end
             % SECOND VERSIONS:
             % Second versions might be only in X, not in Y or Z:
             nNewVers = max(obj.nNewVersionsBasis(:));
             %for iCoor=1:nComponents
            if (nNewVers>0)
                nDofsFirstVersion = nN * 8;
                bWarning = 0;
                bWarningGiven = 0;
                % The number of new versions for all DOFS for each iCoor (x, y and z):
                for iNewDof = 1:nNewVers
                    iDof = nDofsFirstVersion + iNewDof;
                    for iCoor = 1:3
                        % Check all 3 field components (x,y,z) have second
                        % versions:
                        if obj.nNewVersionsBasis(iCoor)<iNewDof
                            bWarning = 1;
                            version = 1;
                        else
                            % The matrix where the identification of new versions is coded:
                            Matrix = squeeze(obj.NewBasisIndex(iCoor,:,:,:));
                            I=find(Matrix==iNewDof);
                            [iNode iValue version] = ind2sub(size(Matrix),I);
                        end
                        value(iCoor) = obj.GetMeshDof(iValue,iNode,iCoor,version,1);
                    end
                    switch iValue
                        case 1
                            ValueRotated = [value 1] * M_v2w';
                        otherwise % this is a derivative
                            value = value./spacing;
                            ValueRotated = value * M_v2w(1:3,1:3)';                       
                    end
                    u_corrected(iDof,1:3) = ValueRotated;
                    if(bWarning)&&(bWarningGiven==0)
                        fprintf('WARNING! rotation of a coordinate field with second versions assumes that all X,Y,Z components are consistent in their definition\n');
                        fprintf(' i.e., all three components have second versions - needed to define the nodal 3D value or derivative direction!\n');
                        bWarningGiven = 1;
                    end
                end
            end
            obj=obj.SetDofs(u_corrected(:,1:3,1));
       end
       function obj         = DeformNode(obj,iMatNode,deformation,updateTripe,updateDouble,updateSingle)
           if nargin<4
               updateTripe=true;
           end
           if nargin<5
               updateDouble=true;
           end
           if nargin<6
               updateSingle=true;
           end
           
           % Single, double and triple derivatives only to be updated if
           % c.Hermite (strange to need to add this on 16.12.2013, where
           % this code was working with c.Lagrange before!
           if obj.InterpolationBasis ~= 1
                updateSingle = false;
                updateDouble = false;
                updateTripe = false;
           end
           % deformation is a structure with the:
           %     deformation.D    : 1x3 vector (DX,DY,DZ)
           %     deformation.d1DX : 1x3 vector (dDX/dx,dDX/dy,dDX/dz)
           %     deformation.d1DY : 1x3 vector (dDY/dx,dDY/dy,dDY/dz)
           %     deformation.d1DZ : 1x3 vector (dDZ/dx,dDZ/dy,dDZ/dz)
           %     deformation.d2DX : 3x3 matrix (d2DX/dx2 ,d2DX/dxdy,d2DX/dxdz;
           %                                    d2DX/dxdy,d2DX/dy2 ,d2DX/dydz;
           %                                    d2DX/dxdz,d2DX/dydz,d2DX/dz2  )
           %     deformation.d2DY : 3x3 matrix, analogous with DY
           %     deformation.d2DZ : 3x3 matrix, analogous with DZ
           %     deformation.d3DX : 3x3x3 matrix, (the 27 d3DX/dxdydz combinations)
           %     deformation.d3DY : 3x3x3 matrix, (the 27 d3DX/dxdydz combinations)
           %     deformation.d3DZ : 3x3x3 matrix, (the 27 d3DX/dxdydz combinations)
           
           % 0. CHECK THE CORRECTNESS OF deformation:
           bDeformationCorrect=true;
           if numel(deformation.D   )~=3, bDeformationCorrect=false; fprintf('WARNING! The deformation.D does not have the right numel\n'); end
           if numel(deformation.d1DX)~=3, bDeformationCorrect=false; fprintf('WARNING! The deformation.d1DX does not have the right numel\n'); end
           if numel(deformation.d1DY)~=3, bDeformationCorrect=false; fprintf('WARNING! The deformation.d1DY does not have the right numel\n'); end
           if numel(deformation.d1DZ)~=3, bDeformationCorrect=false; fprintf('WARNING! The deformation.d1DZ does not have the right numel\n'); end
           if numel(deformation.d2DX)~=9, bDeformationCorrect=false; fprintf('WARNING! The deformation.d2DX does not have the right numel\n'); end
           if numel(deformation.d2DY)~=9, bDeformationCorrect=false; fprintf('WARNING! The deformation.d2DY does not have the right numel\n'); end
           if numel(deformation.d2DZ)~=9, bDeformationCorrect=false; fprintf('WARNING! The deformation.d2DZ does not have the right numel\n'); end
           if numel(deformation.d3DX)~=27, bDeformationCorrect=false; fprintf('WARNING! The deformation.d3D  does not have the right numel\n'); end
           if numel(deformation.d3DY)~=27, bDeformationCorrect=false; fprintf('WARNING! The deformation.d3D  does not have the right numel\n'); end
           if numel(deformation.d3DZ)~=27, bDeformationCorrect=false; fprintf('WARNING! The deformation.d3D  does not have the right numel\n'); end
           
           nv=max(obj.versions(iMatNode,1:3));
           for v=1:nv
               % 1. UPDATE COORDINATES
               %if bDeformationCorrect==true
                   p3D = obj.coordinates(iMatNode,1:3,v);
                   obj.coordinates(iMatNode,1:3,v) = p3D + deformation.D;
%                    if iMatNode==80
%                     fprintf('Debugging deformation node %i. Pos before (%1.1f,%1.1f,%1.1f) ',iMatNode,p3D(1),p3D(2),p3D(3));
%                     fprintf('and after (%1.1f,%1.1f,%1.1f)\n',obj.coordinates(iMatNode,1:3,v));
%                    end

               %end

               % 2. UPDATE SINGLE DERIVATIVES
               if bDeformationCorrect==true && updateSingle==true
                   v1 = reshape(obj.derivatives.duds1(iMatNode,1:3,v),1,3);
                   v2 = reshape(obj.derivatives.duds2(iMatNode,1:3,v),1,3);
                   v3 = reshape(obj.derivatives.duds3(iMatNode,1:3,v),1,3);
                   M1 = reshape(deformation.d1DX,1,3);
                   M2 = reshape(deformation.d1DY,1,3);
                   M3 = reshape(deformation.d1DZ,1,3);
                   Md1  = [M1;M2;M3];
                   obj.derivatives.duds1(iMatNode,1:3,v) = v1' + Md1*v1';
                   obj.derivatives.duds2(iMatNode,1:3,v) = v2' + Md1*v2';
                   obj.derivatives.duds3(iMatNode,1:3,v) = v3' + Md1*v3';
               end

               % 2. UPDATE DOUBLE CROSS DERIVATIVES
               if bDeformationCorrect==true && updateDouble==true         
                   v12=obj.derivatives.duds12(iMatNode,1:3,v);
                   v13=obj.derivatives.duds13(iMatNode,1:3,v);
                   v23=obj.derivatives.duds23(iMatNode,1:3,v);
                   Md2x = reshape(deformation.d2DX,3,3);
                   Md2y = reshape(deformation.d2DY,3,3);
                   Md2z = reshape(deformation.d2DZ,3,3);
                        % Matrix of products of derivatives:
                        Mv1v2=v1'*v2;
                        Mv1v3=v1'*v3;
                        Mv2v3=v2'*v3;
                        % Third summand in each case:
                        S12=[sum(sum(Md2x.*Mv1v2)) sum(sum(Md2y.*Mv1v2)) sum(sum(Md2z.*Mv1v2))];
                        S13=[sum(sum(Md2x.*Mv1v3)) sum(sum(Md2y.*Mv1v3)) sum(sum(Md2z.*Mv1v3))];
                        S23=[sum(sum(Md2x.*Mv2v3)) sum(sum(Md2y.*Mv2v3)) sum(sum(Md2z.*Mv2v3))];
                   obj.derivatives.duds12(iMatNode,1:3,v) = v12' + Md1*v12' + S12';
                   obj.derivatives.duds13(iMatNode,1:3,v) = v13' + Md1*v13' + S13';
                   obj.derivatives.duds23(iMatNode,1:3,v) = v23' + Md1*v23' + S23';
               end
               
               % 3. UPDATE TRIPLE CROSS DERIVATIVES
               if bDeformationCorrect==true && updateTripe==true            
                   v123=obj.derivatives.duds123(iMatNode,1:3,v);
                   Md3x = reshape(deformation.d3DX,3,3,3);
                   Md3y = reshape(deformation.d3DY,3,3,3);
                   Md3z = reshape(deformation.d3DZ,3,3,3);
                        % Tensor of products of derivatives:
                        Mv1v2v3=zeros(3,3,3);
                        for k=1:3
                            Mv1v2v3(:,:,k)=Mv1v2 * v3(k);
                        end
                        % Matrix with the products of simple and double
                        % cross derivatives
                        Mv2v=zeros(3,3);
                        for i=1:3
                            for j=1:3
                                Mv2v(i,j)=v12(i)*v3(j) + v13(i)*v2(j) + v23(i)*v1(j);
                            end
                        end
                        % Third summand in each case:
                        S123a=[sum(sum(Md2x.*Mv2v))    sum(sum(Md2y.*Mv2v))    sum(sum(Md2z.*Mv2v))];
                        S123b=[sum(sum(sum(Md3x.*Mv1v2v3))) sum(sum(sum(Md3y.*Mv1v2v3))) sum(sum(sum(Md3z.*Mv1v2v3)))];
                   obj.derivatives.duds123(iMatNode,1:3,v) = v123' + Md1*v123' + S123a' + S123b';
               end
           end

           % IMPORTANT: UPDATE FLAGS:
           obj.bWireframeBuilt = false;
           obj.bTetrahedralCanvasBuilt = false;
           obj.bQualityCalculated = false;
           obj.bQ1Calculated = false;
           obj.bQ2Calculated = false;
           obj.bQ3Calculated = false;
           obj.bQ4Calculated = false;
           obj.bQ5Calculated = false;
       end
       function obj         = AddCHDefornation(obj,CHd,bDebug)
           % Function to deform the CH mesh with the deformation values and
           % derivatives indicated in the coefficients xx, xy and xz. Each
           % of this coefficient vectors has (nNodes x 8) elements.
           % INPUT: 
           % - CHd = [xx;xy;xz], deformation of each coordinate
           if nargin<3
               bDebug=0;
           end
           if (bDebug), fprintf(1,'Debugging CubicMeshClass:AddCHDefornation\n'); end 
           if (bDebug), figure('Color',[1 1 1]); hold on; 
               for iCH=1:3
                   subplot(3,1,iCH), plot(CHd(:,iCH))
               end
           end
           [nDofs,foo] = size(CHd);
           nNods = nDofs/8;
           UsedNodes = obj.FindUsedNodes();
           nUsedNodes = numel(find(UsedNodes));
           if nNods ~= nUsedNodes
               fprintf('WARNING! deformation described with %i dofs, wheras the mesh has %i nodes used (of a total of %i)!\n',nDofs,nUsedNodes,obj.nNodes);
           end
           iUsedMatNode = 0;
           for iMatNode=1:obj.nNodes
               if UsedNodes(iMatNode)
                   iUsedMatNode = iUsedMatNode + 1;
                   for iCont=1:8 % Index of the nodal value (continuity enforced)
                       % All nodes have a first version of all values at least:
                       version = 1;
                       ibasis  = (iUsedMatNode-1)*8 + iCont;
                       Increment3DValue = CHd(ibasis,1:3);
                       obj = obj.IncrementNodeValue(iMatNode,iCont,version,Increment3DValue);
                       % Check if this should also be applied to other versions
                       if (iCont==1)
                           % Same deformation for the coordinate field values:
                           for iCoord=1:3
                               if obj.versions(iMatNode,iCoord)>1
                                   Increment1D = CHd(ibasis,iCoord);
                                   Increment3DValue = [0 0 0]; Increment3DValue(iCoord) = Increment1D;
                                   for v=2:obj.versions(iMatNode,iCoord)
                                       obj = obj.IncrementNodeValue(iMatNode,iCont,v,Increment3DValue);
                                   end
                               end
                           end
                       else
                           % But different story for the coordinate
                           % derivatives:
                           for version=2:3
                               for iCoord=1:3
                                   nValuesIntroduced = length(CHd(:,iCoord));
                                   % Index from 0 (no new basis) to nNewBasis:
                                   iNewBasis = obj.NewC1BasisIndex(iCoord,iMatNode,iCont,version);
                                   if (iNewBasis>0)
                                       % The index of the basis in the matrix must
                                       % be added to the last "regular" basis
                                       % index:
                                       iNewBasis = iNewBasis + 8*obj.nNodes;
                                       if iNewBasis<=nValuesIntroduced
                                           Increment1D = CHd(iNewBasis,iCoord);
                                           if (bDebug)
                                               Inc1stV = CHd(ibasis,iCoord);
                                               fprintf(1,'    ... (V%i=%1.2f)(V1=%1.2f)  Increment of (node%i, value%i, coord%i)\n',version,Increment1D,Inc1stV,iMatNode,iCont,iCoord);
                                           end
                                           Increment3DValue = [0 0 0]; Increment3DValue(iCoord) = Increment1D;
                                           obj = obj.IncrementNodeValue(iMatNode,iCont,version,Increment3DValue(iCoord),iCoord);
                                       else
        % Check that the additinal versions do not exist (if so, add the first
        % version as an alternative)
                                           if(bDebug),fprintf(1,'WARNING!!!  Node%i with second versions in coord%i, but values of the fitting from the first version added (CubicMeshClass:AddCHDefornation)!\n',iMatNode,iCoord);end
                                           Increment1D = CHd(ibasis,iCoord);
                                           Increment3DValue = [0 0 0]; Increment3DValue(iCoord) = Increment1D;
                                           obj = obj.IncrementNodeValue(iMatNode,iCont,version,Increment3DValue(iCoord),iCoord);
                                       end
                                   end
                               end
                           end
                       end
                   end
               else 
                   fprintf('WARNING! (CubicMeshClass:AddCHDefornation) Node %i is not used for the definition of elements.\n');
                   fprintf('         The indexing of dofs ignores it (this only works if the same convention has been adopted for the calculation of CHd)\n');
               end
           end
           obj = obj.Update();
       end

       function obj         = IncrementNodeValue(obj,iMatNode,iCont,version,IncrementValue,iCoord)
           % Function to update a node value:
           if (numel(IncrementValue)==3)
               Increment3DValue = IncrementValue;
           else
               if (iCoord<1)||(iCoord>3)
                   fprintf(1,'ERROR! CubicMeshClass:IncrementNodeValue, wrong specification of the coordinate field to update OR wrong size of the IncrementValue');
               end
               mask=zeros(1,3);
               mask(iCoord)=1;
               Increment3DValue = IncrementValue*mask;
           end
           switch iCont
               case 1
                   obj.coordinates(iMatNode,1:3,version) = obj.coordinates(iMatNode,1:3,version) + Increment3DValue;
               case 2
                   obj.derivatives.duds1(iMatNode,1:3,version)=obj.derivatives.duds1(iMatNode,1:3,version) + Increment3DValue;
               case 3
                   obj.derivatives.duds2(iMatNode,1:3,version)=obj.derivatives.duds2(iMatNode,1:3,version) + Increment3DValue;
               case 4 
                   obj.derivatives.duds3(iMatNode,1:3,version)=obj.derivatives.duds3(iMatNode,1:3,version) + Increment3DValue;
               case 5
                   obj.derivatives.duds12(iMatNode,1:3,version)=obj.derivatives.duds12(iMatNode,1:3,version) + Increment3DValue;
               case 6
                   obj.derivatives.duds13(iMatNode,1:3,version)=obj.derivatives.duds13(iMatNode,1:3,version) + Increment3DValue;
               case 7
                   obj.derivatives.duds23(iMatNode,1:3,version)=obj.derivatives.duds23(iMatNode,1:3,version) + Increment3DValue;
               case 8
                   obj.derivatives.duds123(iMatNode,1:3,version)=obj.derivatives.duds123(iMatNode,1:3,version) + Increment3DValue;
               otherwise
                   fprintf(1,'ERROR!!! In CubicMeshClass:IncrementNodeValue, wrong selection of nodal value index!!\n');
           end
       end
       function obj         = SetPoints(obj,points)
           [nPoints nCoords nVersions] = size(obj.coordinates);
           if nVersions==1
               obj.coordinates(:,:,1)=reshape(points,nPoints,nCoords);
           else % Only 2 versions per coordinate are expected!!!!
               obj.coordinates(:,:,1)=reshape(points(1:nPoints,:),nPoints,nCoords);
               obj.coordinates(:,:,2)=reshape(points(nPoints+1:2*nPoints,:),nPoints,nCoords);
           end
           obj = obj.Update();
       end  
       function obj         = PCAtransform(obj,PCAparameters)
          % CAUTION: this only updates coordinates, not any derivative!!!
          % Function to scale points in the directions of the PCA analysis
          % - points: 3D points
          % - PCAparameters:
          %   PCAparameters.Centre1
          %   PCAparameters.Centre2
          %   PCAparameters.V1
          %   PCAparameters.V2
          %   PCAparameters.Sc
          %   PCAparameters.Tx
          %   PCAparameters.Rt
          %
          % By Pablo Lamata, Oxford, June 2009
          
          fprintf('WARNING! FUNCTION DEPRECATED: use pcaTransformMesh instead!\n');

          % NOTE: shape1 is the fixed one, shape2 is the transformed one.
          if(max(obj.nNewVersionsBasis)>0)
              fprintf('ERROR! Function not prepared yet to transform a mesh with second versions!\n');
          end
          
          points2=GetPoints(obj);

          Centre1 = PCAparameters.Centre1;
          Centre2 = PCAparameters.Centre2;
          V1 = PCAparameters.V1;
          V2 = PCAparameters.V2;
          Sc = PCAparameters.Sc;
          Rt = PCAparameters.Rt;

          Points2WithoutMean = points2 - (ones(length(points2),1) * Centre2);
          MatrixOfScales = ones(length(points2),1) * Sc;
          Points2TranslatedRotatedScaled = MatrixOfScales .* (V2'*Points2WithoutMean')';
          Points2TranslatedRotatedScaled = V1*Points2TranslatedRotatedScaled';

          TransformedPoints = Points2TranslatedRotatedScaled' + (ones(length(points2),1) * Centre1);
          obj = obj.SetPoints(TransformedPoints);
          
          obj = obj.Update();

        % NOTE: the need to scale at the "intermediate rotation" prevents this kind
        % of implementation:
        % Points2TranslatedRotatedScaled = MatrixOfScales .* (Rt*Points2WithoutMean')';
        % for i=1:length(points)
        %    TransformedPoints(i,:) =  Rt*Points2WithoutMean(i,:)'
 
       end
       function obj         = MakeFlatbase(obj)
           % TODO: bring code from MakeFlatbase.m
       end
       function obj         = pcaTransformMesh(obj,pcaTransformation)
           bDebug=0;
          if(max(obj.nNewVersionsBasis)>0)
              fprintf('WARNING! Function not prepared yet to transform a mesh with second versions of the nodal coordinate values (but able to manage the derivatives)!\n');
          end

           %fprintf(1,' *** WARNING! *** This implementation of TransformMesh might not work with second versions!\n');
            u = obj.GetDofs();
            if(bDebug), figure; for i=1:3, subplot(3,1,i), plot(u(:,1)); end; end
            if(bDebug), fprintf(' Coordinate node 1 is %1.2f,%1.2f,%1.2f\n',u(1,:)); end
            u_corrected = zeros(size(u));
            [nN b c]= size(obj.coordinates);
            % Nodal coordinates: the first nN values
            iDOF = 1;
                is   = 1+(iDOF-1)*nN:(iDOF)*nN;
                u_corrected(is,1:3) = pcaTransformation.transform(u(is,1:3));
            % Nodal derivatives: the rest of values (including
            % second versions)
            iDOF = 2;
                is1   = 1+(iDOF-1)*nN;
                DOFsOption = 4; % Apply scale and rotation (no translation)
                u_corrected(is1:end,1:3) = pcaTransformation.transform(u(is1:end,1:3),1,DOFsOption);
            obj = obj.SetDofs(u_corrected(:,1:3));
            if(bDebug), fprintf(' Coordinate returned in node 1 is %1.2f,%1.2f,%1.2f\n',u_corrected(1,:)); end
            if(bDebug), fprintf(' Coordinate set in node 1 is %1.2f,%1.2f,%1.2f\n',obj.coordinates(1,1:3,1)); end            
       end
       function obj         = TransformMesh(obj,scale,rotation,centre)
           % Function to transform a mesh (both coords and derivs) by:
           % - Creating a PCAtransformation class 
           % - Aplying the transformation
           % 
           % Version control
           % - 2: Current:
           % - 1: DEPRECATED with a deformation field and
           % - A nodal warping of the mesh, with linear interpolation (it
           % is a rigid transformation, this is an accurate solution, and
           % much faster than a variational) DeformMeshByRegInterp_M3_v2
           
           Version = 2;
           bDebug=0;
            if nargin<3,         rotation = eye(3);   end
            if nargin<4, bCenter = 0; else bCenter=1; end
            if(bDebug), fprintf(' Coordinate in node 1 is %1.2f,%1.2f,%1.2f\n',obj.coordinates(1,1:3,1)); end
            if numel(scale)==1, scale(2)=scale(1); scale(3)=scale(1); end;
            Transformation = PCAtransformation();
            Transformation.Sc = scale;

            NR = numel(rotation);
            switch NR
                case 3
                    AngleX = rotation(1);
                    AngleY = rotation(2);
                    AngleZ = rotation(3);
                    ConcatenationOrder = 1;
                    Transformation = Transformation.SetRotationByAngles(AngleX,AngleY,AngleZ,ConcatenationOrder);
                case 9
                    Transformation = Transformation.SetRotationMatrixInV2(rotation);
            end
            if (bCenter)
                Transformation.Centre1 = centre;
                Transformation.Centre2 = centre;
            end
            
            switch Version
                case 1
                    % Define the region where the deformation map should be
                    % defined with the header of an image:
                    SamplingResolution = [2 2 2];
                    [image header] = obj.InitialiseBinaryImage(SamplingResolution);
                    % Add one voxel of size to this region (to avoid having points
                    % outside the region - rounding effects of image size):
                    header.dim = header.dim + [1 1 1];
                    DefMap         = Transformation.CreatePCAdeformationMap(header);
                    obj = DeformMeshByRegInterp_M3_v2(DefMap,obj,0.1,'central','linear');
                case 2
                    obj = obj.pcaTransformMesh(Transformation);
            end
            
            if(bDebug), fprintf(' Coordinate set in node 1 is %1.2f,%1.2f,%1.2f\n',obj.coordinates(1,1:3,1)); end
       end
       function obj         = DeformMeshNodes(obj,VTKdefSamplesFile)
           % Function to deform the mesh nodes (coordinates) accordingly to
           % the nodal deformation present in the input file (generated
           % accordingly to Dof2defSamples)
           [def] = io_VTKloadNodes(VTKdefSamplesFile);
           points = obj.GetNodeCoorValue(1:obj.nNodes);
           points = points + def;
           obj = obj.SetNodeCoorValue(points,1:obj.nNodes);
       end
           
       function obj         = DeformMesh(obj,DeformationFile)
           % Function to deform the mesh according to the deformation
           % field, which is defined as:
           % - DeformationFile, written accordingly to ReadGaussPoints.m,
           % DataAtGaussPoints(iElem(iPoint),xi(1),xi(2),xi(3),1:dim) is the
           % matrix that will be eventually loaded.
           %
           % TODO: enable the deformation with the DataAtGaussPoints fed
           % directly in this function FitField (and save the time to read
           % and write files)
           CHd = obj.FitField(DeformationFile);
           obj = obj.AddCHDefornation(CHd);
       end
       function [data]      = Dof2GPdef(obj,doffileIN,GPdeffileOUT,GaussOrder)
           fprintf('FUNCTION DEPRECATED! Use Dof2defSamples instead!\n');
       end
       function [data]      = Dof2defSamples(obj,doffileIN,defSamplesfileOUT,options)
           % Function to evaluate the deformation at a set of gauss points
           % coordinates.
           % 30/10/13: update from Dof2GPdef, now defining that the dof
           % file is interpolated at nodal coordinates, not Gauss Points,
           % for a nodal transformation of the mesh (c.Lagrange one). Note
           % that the file format will be different
           
           % Default options and parse options:
           GaussOrder = 4;
           SamplesType = 'GP';
           SamplesRange= [-100 100];
           DefOutputVersion = 1;
           if nargin >= 4
               if isfield(options,'GaussOrder'), GaussOrder = options.GaussOrder; end        
               if isfield(options,'SamplesRange'), SamplesRange = options.SamplesRange; end        
               if isfield(options,'SamplesType'), SamplesType = options.SamplesType; end               
               if isfield(options,'bChangeFromMetres2Milimeters'), bChangeFromMetres2Milimeters = options.bChangeFromMetres2Milimeters; end               
               if isfield(options,'iTime'), 
                   DefOutputVersion = 2;
                   iTime = options.iTime; 
               end
           end
           
           % Begin:
           [RootDir namefile] = obj.GetPath(doffileIN);
           VTKfileGP        = [RootDir 'VTKfileGP.vtk'];
           VTKfileTransGP   = [RootDir 'VTKfileTransGP.vtk'];
           % 1. Generate a VTK file with the Gauss Points coordinates:
           if exist(VTKfileGP,'file')==0
               switch SamplesType
                   case 'GP'
                        obj.WriteGaussPoints2VTK(VTKfileGP,GaussOrder);
                   case 'NODAL'
                        obj.WriteNodalCoords2VTK(VTKfileGP);
                   case 'EXHAUSTIVE'
                       % This is a debugging option: sometimes the
                       % alignment of the mesh is not correct with respect
                       % ot the dof file, and this is explored here:
                       nSamples = 50;
                       sampling = (SamplesRange(2) - SamplesRange(1)) / nSamples;
                       range = SamplesRange(1):sampling:SamplesRange(2);
                       [X Y Z] = meshgrid(range,range,range);
                       points = [X(:) Y(:) Z(:)];
                       opt.Poly = 1; % need to write as POLYDATA for ptransformation to work:
                       io_writeVTK(VTKfileGP,points,opt);
                   otherwise
                       fprintf('ERROR! Option of SamplesType (%s) not recognised\n',SamplesType);
               end
           end
           % 2. Transfor those coordiantes:
           if ~exist(doffileIN)
               fprintf('ERROR! dof file does not exist: %s\n',doffileIN);
               return;
           else
               switch DefOutputVersion
                   case 1
                       % a set of individual files, one per frame:
                       eval(['!ptransformation ' VTKfileGP ' ' VTKfileTransGP ' -dofin ' doffileIN])
                   case 2
                       % one single file, with a continuous interpolation
                       % in time (iTime belongs to [0 1])
                       eval(['!ptransformation ' VTKfileGP ' ' VTKfileTransGP ' -dofin ' doffileIN ' -time ' num2str(iTime)]);
               end
           end
           % 3. Read the transformed coordinates and calculate deformation:
           P1 = io_VTKloadNodes(VTKfileTransGP);
           P0 = io_VTKloadNodes(VTKfileGP);
           def= P1-P0;
           if bChangeFromMetres2Milimeters
               def = def * 1000;
           end
           switch SamplesType
               case 'GP'
                   % 4. Write the dof file:
                   % Make sure the indexing of the points is the same as done in 
                   % GetAllGaussPoints!
                   GaussPts = obj.GetGlobalGaussPoints(1,GaussOrder);
                   nPtsPerElem = GaussOrder^3;
                   localCoords = zeros(3,nPtsPerElem);
                   for iC=1:3
                       localCoords(iC,:) = reshape( GaussPts.LocalCoordinates(:,:,:,iC),1,nPtsPerElem);
                   end
                   WriteGaussPointsFile(defSamplesfileOUT,P0,localCoords,def);
               case 'NODAL'
                   opt.Poly = 1; % need to write as POLYDATA for ptransformation to work:
                   io_writeVTK(defSamplesfileOUT,def,opt);
               case 'EXHAUSTIVE'
                   I = find(def==max(def(:)));
                   [iP,iCoor] = ind2sub(size(def),I);
                   figure
                   range = 1:7:nSamples^3;
                   plot3(points(range,1),points(range,2),points(range,3),'.');
                   hold on
                   Magnif = 1000;
                   quiver3(points(range,1),points(range,2),points(range,3),Magnif*def(range,1),Magnif*def(range,2),Magnif*def(range,3),'LineWidth',3);
                   plot3(points(iP,1),points(iP,2),points(iP,3),'*r');
                   obj.plotWireframe();
                   axis equal
                   opt.Poly = 1; % need to write as POLYDATA for ptransformation to work:
                   
                   io_writeVTK(defSamplesfileOUT,def,opt);
           end
           data = def;
           % Remove temorary files:
           delete(VTKfileGP); 
           delete(VTKfileTransGP); 
       end
       
       function obj         = MoveCentre2Origin(obj)
           % Function to (1) approximate the centre of mass and (2) bring
           % the mesh to the origin of coordinates
           centre = obj.GetMeshCentre();
           obj = obj.translateMesh(-centre);
       end
       function obj         = DilateNodeCoordinate(obj,iNode2modify,iNodeReference)
           % Modify the coordinate of a node by addig the difference to
           % other coordinate from a reference node. used as a way to
           % "dilate" teh anatomy of the ventricle by a layer of a element
           P1 = obj.GetNodeCoorValue(iNode2modify);
           P2 = obj.GetNodeCoorValue(iNodeReference);
           obj = obj.SetNodeCoorValue(P1 + (P1-P2),iNode2modify);
       end
% Mesh topology changes:
       function obj         = DeleteElement(obj,iElems)
           %TODO: check if the numbering of elements should be also updated
           for i=1:length(iElems)
               iElem=iElems(i);
               obj.nNofElem(iElem)    = 0;
               obj.giNofElem(iElem,:) = 0;
               obj.mapping.ElemsOfNode(iElem,:)=0;
               obj.liNofElem(iElem,:) = 0;
               obj.valueIndices(iElem,:,:,:) = 0;
           end
       end
       function obj         = AddElement(obj,Shape,iElems)
           % Add the element(s) definition, which is
           % stored in the iElems(s) of the Shape. It is assumed that the
           % indexes of the nodes is congruent between Shape and obj
           nNewElems = length(iElems);
           for i=1:nNewElems;
               iElemInShape=iElems(i);
               iElem = obj.nElems + i;
               obj.nNofElem(iElem)              = Shape.nNofElem(iElemInShape);
               VI = 1:Shape.nNofElem(iElemInShape);
               obj.giNofElem(iElem,VI)        = Shape.giNofElem(iElemInShape,VI);
               % The num of max neigbours migh be different!
               N1 = length(obj.mapping.ElemsOfNode(obj.nElems,:));
               N2 = length(Shape.mapping.ElemsOfNode(iElemInShape,:));
               if N2>N1
                   obj.mapping.ElemsOfNode = [obj.mapping.ElemsOfNode zeros(obj.nNodes, N2-N1)];
               end
               obj.mapping.ElemsOfNode(iElem,1:N2) = Shape.mapping.ElemsOfNode(iElemInShape,1:N2);
               
               obj.liNofElem(iElem,:)           = Shape.liNofElem(iElemInShape,:);
               obj.valueIndices(iElem,:,:,:)    = Shape.valueIndices(iElemInShape,:,:,:);
           end
           obj.nElems = obj.nElems + nNewElems;
       end
       function obj         = ReorderElements(obj)
           ElementExists = true(1,obj.nElems);
           nElemsOld = obj.nElems;
           for iElem = 1:nElemsOld
               if obj.nNofElem(iElem)==0
                   ElementExists(iElem)=false;
               end
           end
           nNewElems = sum(ElementExists);
           NewElems = 1:nNewElems;
           OldElems = 1:obj.nElems;
           ListElems = OldElems(ElementExists);
           for iNewE = NewElems
               iOldE = ListElems(iNewE);
               obj.OLDGIE(iNewE) = iOldE;
               obj = obj.ChangeIndexElement(iNewE,iOldE);               
           end
           obj.nElems = nNewElems;
           fprintf('     Elements reordered, %i before, %i now\n',nElemsOld,nNewElems);
       end
       function obj         = ChangeIndexElement(obj,iNewE,IOldE)
           % It is supposed that iNewE is smaller than iOldE, and that
           % this function is called in a growing order of indexes (see
           % function AddElements as an example)
           % Most likely it won't be good to call this function from
           % anywhere else...
           nNofElem = obj.nNofElem(IOldE);
           obj.nNofElem(iNewE) = nNofElem;
           %obj.nNofElem(IOldE) = 0; % A definition of "empty element"
           obj.nNofElem(iNewE) = obj.nNofElem(IOldE);
           obj.giNofElem(iNewE,1:nNofElem) = obj.giNofElem(IOldE,1:nNofElem);
           obj.liNofElem(iNewE,1:8) = obj.liNofElem(IOldE,1:8);
           obj.valueIndices(iNewE,1:3,1:8,1:8) = obj.valueIndices(IOldE,1:3,1:8,1:8);% nElems x 3coordinates x 8nodes x 8values
       end
       function obj         = CopyNodeValues(obj,NodeIndexDestiny,ShapeSource,NodeIndexSource)
            obj.coordinates(NodeIndexDestiny,:,:)         = ShapeSource.coordinates(NodeIndexSource,:,:);
            if obj.InterpolationBasis == 1
                obj.derivatives.duds1(NodeIndexDestiny,:,:)   = ShapeSource.derivatives.duds1(NodeIndexSource,:,:);
                obj.derivatives.duds2(NodeIndexDestiny,:,:)   = ShapeSource.derivatives.duds2(NodeIndexSource,:,:);
                obj.derivatives.duds3(NodeIndexDestiny,:,:)   = ShapeSource.derivatives.duds3(NodeIndexSource,:,:);
                obj.derivatives.duds12(NodeIndexDestiny,:,:)  = ShapeSource.derivatives.duds12(NodeIndexSource,:,:);
                obj.derivatives.duds13(NodeIndexDestiny,:,:)  = ShapeSource.derivatives.duds13(NodeIndexSource,:,:);
                obj.derivatives.duds23(NodeIndexDestiny,:,:)  = ShapeSource.derivatives.duds23(NodeIndexSource,:,:);
                obj.derivatives.duds123(NodeIndexDestiny,:,:) = ShapeSource.derivatives.duds123(NodeIndexSource,:,:);                
            end
            obj.versions(NodeIndexDestiny,:)              = ShapeSource.versions(NodeIndexSource,:);
       end
       function [UsedNodes] = FindUsedNodes(obj)
            UsedNodes = false(1,obj.nNodes);
            %1. Build the list of used elements:
            for iElem=1:obj.nElems
                nNofiElem = obj.nNofElem(iElem);
                ListOfNodes(1:nNofiElem) = obj.giNofElem(iElem,1:nNofiElem);
                for iln=1:nNofiElem
                    UsedNodes(ListOfNodes(iln))=true;
                end
            end
       end
       function obj         = ReorderNodes(obj)
            % Function to reorder the nodes by looking at the element
            % definition and:
            % 1. Remove "unused" nodes, and save them into OLDGIN and
            % OLDnNodes
            % 2. Reassign a list of continuous nodes
            % 
            % Effect is reversed with function "RestoreOldGlobalNodeIndexes"

            UsedNodes = obj.FindUsedNodes();

            %2. Build the squeezed list of elements and its mapping with the previous
            %one
            AllNodes  = 1:obj.nNodes;
            OLDnNodes = obj.nNodes;
            %NewNodes  = 1:NEWnNodes;
            NodMapping= AllNodes(UsedNodes);
            % Change the elements definition:
            for iElem=1:obj.nElems
                nNofiElem = obj.nNofElem(iElem);
                ListOfNodes(1:nNofiElem) = obj.giNofElem(iElem,1:nNofiElem);    
                for iln=1:nNofiElem
                    OldGlobalNIndex = ListOfNodes(iln);
                    NewGlobalNIndex = find(NodMapping==OldGlobalNIndex);
                    obj.giNofElem(iElem,iln) = NewGlobalNIndex;
                end
            end

            NEWnNodes = numel(NodMapping);
            obj.nNodes = NEWnNodes;
            % Change the node numbering: CAUTION! for loop must be
            % 1:NEWnNodes in order not to overwrite node definitions 
            for iNode = 1:NEWnNodes
                NewGlobalNIndex   = iNode;
                OldGlobalNIndex   = NodMapping(iNode);
                obj.OLDGIN(iNode) = OldGlobalNIndex;
                [obj] = obj.CopyNodeValues(NewGlobalNIndex,obj,OldGlobalNIndex);
            end
            fprintf('     Nodes of the Cubic mesh reordered. nNodes is now %i (and was %i)\n',NEWnNodes,OLDnNodes);
            obj.nNodesUnused = OLDnNodes-NEWnNodes;
       end
       function obj         = RestoreOldGlobalNodeIndexes(obj)
           % COMPLEMENTARY FUNCTION TO ReorderNodes
           % Restore node values (right indexing):
           Temp = CubicMeshClass();
           for iNode = 1:obj.nNodes
               OldGlobalNIndex = obj.OLDGIN(iNode);
               Temp = Temp.CopyNodeValues(OldGlobalNIndex,obj,iNode);
           end
           for iNode = 1:obj.nNodes
               OldGlobalNIndex = obj.OLDGIN(iNode);
               obj = obj.CopyNodeValues(OldGlobalNIndex,Temp,OldGlobalNIndex);
           end
           % Restore elements definition (old node indexing)
            for iElem=1:obj.nElems
                nNofiElem = obj.nNofElem(iElem);
                ListOfNodes(1:nNofiElem) = obj.giNofElem(iElem,1:nNofiElem);    
                for iln=1:nNofiElem
                    NewGlobalNIndex = ListOfNodes(iln);
                    OldGlobalNIndex = obj.OLDGIN(NewGlobalNIndex);
                    obj.giNofElem(iElem,iln) = OldGlobalNIndex;
                end
            end
       end
       function [Subpart]   = ExtractSubpart(obj,iElms)
           % Function to extract a subpart of a mesh, indicated by the
           % elements that are taken:
           Subpart = obj;
           for iE = 1:obj.nElems
               I = find(iElms==iE);
               if numel(I)==0
                   Subpart = Subpart.DeleteElement(iE);
               end
           end
            Subpart = Subpart.ReorderElements();
            Subpart = Subpart.ReorderNodes();
            Subpart = Subpart.Update();
            Subpart = Subpart.UpdateDOFs();           
       end
       function [ShNoCollap,ShCOLLAP] = SplitMesh_CollapsedElems(obj)
           % The elements are divided in two meshes. 
           ShNoCollap = obj;
           ShCOLLAP = obj;
           for iElem = 1:obj.nElems
                % check if this is a collapsed element:
                if obj.isCollapsedElem(iElem)
                    % Delete this element in ShNoCollap
                    ShNoCollap = ShNoCollap.DeleteElement(iElem);
                else
                    % Delete this element in ShCOLLAP
                    ShCOLLAP = ShCOLLAP.DeleteElement(iElem);
                end
            end
            ShCOLLAP = ShCOLLAP.ReorderElements();
            ShCOLLAP = ShCOLLAP.ReorderNodes();
            ShCOLLAP = ShCOLLAP.Update();
            ShCOLLAP = ShCOLLAP.UpdateDOFs();

            ShNoCollap= ShNoCollap.ReorderElements();
            ShNoCollap= ShNoCollap.ReorderNodes();
            ShNoCollap= ShNoCollap.Update();
            ShNoCollap = ShNoCollap.UpdateDOFs();
            fprintf(1,'Mesh divided in two: (%i nodes, %i elems) and (%i nodes, %i elems)\n',ShNoCollap.nNodes,ShNoCollap.nElems,ShCOLLAP.nNodes,ShCOLLAP.nElems);
       end
       function obj         = MergeMesh_CollapsedElems(obj,ShCOLLAP)
       % It is supposed that this function is called from the NO
       % COLLAPSED MESH! (obj = ShNoCollap)
            bDebug=0;
            bRestoreOrder=1;
       % 1. Restore the Old Node Indexes in both meshes
            obj = obj.RestoreOldGlobalNodeIndexes();
            ShCOLLAP = ShCOLLAP.RestoreOldGlobalNodeIndexes();
            
            nElems1 = obj.nElems;
            nElems2 = ShCOLLAP.nElems;
       
       % 2. Copy the new definition of the collapsed nodes!
       % 2.a Find the collapsed elements
            CollapsedNodes = [];
            nCollapsed = 0;
            for iElem=1:ShCOLLAP.nElems
                if ShCOLLAP.isCollapsedElem(iElem)
                    if(bDebug),fprintf(1,'Element %i is collapsed!',iElem); end
                    % Identify which local node is collapsed:
                    ListOfLocalNodes = ShCOLLAP.liNofElem(iElem,:);
                    % Find which number is repeated:
                    for i=1:6
                        I = find(ListOfLocalNodes==i);
                        if numel(I)>1
                            iNode = ShCOLLAP.giNofElem(iElem,i);
                            if(bDebug),fprintf(1,'In element %i, node %i is collapsed!\n',iElem,iNode); end
                            % check if it was before in the list:
                            I = find(CollapsedNodes==iNode);
                            if numel(I)==0
                                nCollapsed = nCollapsed+1;
                                CollapsedNodes(nCollapsed) = iNode;
                            end
                        end
                    end
                end
            end
            fprintf(1,' == %i collapsed nodes found in the merging: (',nCollapsed);
        % 2.b Restore the collapsed node in its original index
        % (RestoreOldGlobalNodeIndexes has been called before):
            for i=1:nCollapsed
                iNode = CollapsedNodes(i);                
                fprintf(1,' %i,',iNode);
                obj = obj.CopyNodeValues(iNode,ShCOLLAP,iNode);
            end        
            % 
            fprintf(1,' ) ==\n',iNode);
            obj.nNodes = obj.nNodes + nCollapsed;
            
        % 3: restore the element indexes original order:
        if (bRestoreOrder)
            Temp = CubicMeshClass();
            % Add the elements in the right order from the two existing
            % meshes:
            bFinish = 0; bEnd1=0; bEnd2=0; i1=1; i2=1;
            while(~bFinish)
                if (i1<=nElems1), iElem1 = obj.OLDGIE(i1); else bEnd1=1; end
                if (i2<=nElems2), iElem2 = ShCOLLAP.OLDGIE(i2); else bEnd2=1; end
                if (~bEnd1)&&(bEnd2 || iElem1<iElem2)
                    Temp = Temp.AddElement(obj,i1);
                    if(bDebug), fprintf(1,'Element %i taken from 1\n',i1); end
                    i1=i1+1;
                else if (~bEnd2)
                        Temp = Temp.AddElement(ShCOLLAP,i2);
                        if(bDebug), fprintf(1,'Element %i taken from 2\n',i2); end
                        i2=i2+1;
                    end
                end
                if (bEnd1) && (bEnd2)
                    bFinish=1;
                end
            end
            obj.nElems = 0;
            for iElem=1:nElems1+nElems2
                obj = obj.AddElement(Temp,iElem);
            end
        else
            for iElem=1:nElems2
                obj = obj.AddElement(ShCOLLAP,iElem);
                if(bDebug), fprintf(1,'Element %i taken from Collapsed Shape added\n',iElem); end
            end
        end               
             obj.nElems = nElems1+nElems2;             
             obj = obj.Update();
       end
       function obj         = MergeMesh(obj,Mesh2)
            fprintf('merging %s and %s\n',obj.name,Mesh2.name);
            nElems1 = obj.nElems;
            nElems2 = Mesh2.nElems;
            
            % Add the node offset from Mesh2:
            nN1 = obj.nNodes;
            nN2 = Mesh2.nNodes;
            iii = nN1+1 : nN1+nN2;
            obj.versions(iii,:) = Mesh2.versions;
            obj.dofsUsed(iii,:) = Mesh2.dofsUsed;
            obj.coordinates(iii,:,:) = Mesh2.coordinates;
            obj.derivatives.duds1(iii,:,:) = Mesh2.derivatives.duds1;
            obj.derivatives.duds2(iii,:,:) = Mesh2.derivatives.duds2;
            obj.derivatives.duds3(iii,:,:) = Mesh2.derivatives.duds3;
            obj.derivatives.duds12(iii,:,:) = Mesh2.derivatives.duds12;
            obj.derivatives.duds13(iii,:,:) = Mesh2.derivatives.duds13;
            obj.derivatives.duds23(iii,:,:) = Mesh2.derivatives.duds23;
            obj.derivatives.duds123(iii,:,:) = Mesh2.derivatives.duds123;
%             if obj.MaxNeighbours < Mesh2.MaxNeighbours
%                 ii2 = obj.MaxNeighbours+1:Mesh2.MaxNeighbours;
%                 obj.mapping.ElemsOfNode(1:obj.nNodes, ii2) = 0;
%             end
%             iB1 = 1:Mesh2.MaxNeighbours;
%             obj.mapping.ElemsOfNode(iii,iB1) = Mesh2.mapping.ElemsOfNode + int16(obj.nElems * ones(Mesh2.nNodes,Mesh2.MaxNeighbours));
            
            obj.MaxNeighbours = max( obj.MaxNeighbours , Mesh2.MaxNeighbours );
                        
            Mesh2.giNofElem = Mesh2.giNofElem + int16(nN1 * double(ones([ size( Mesh2.giNofElem , 1 ) size( Mesh2.giNofElem , 2 )])));
            Mesh2.mapping.NodesOfElem = Mesh2.giNofElem;
            for iElem=1:nElems2
                obj = obj.AddElement(Mesh2,iElem);
            end
            obj.mapping.NodesOfElem = obj.giNofElem;
            obj.nNodes = obj.nNodes + Mesh2.nNodes;
            obj.nElems = nElems1+nElems2;             
            obj = obj.Update();
       end
       function obj         = LineariseTransmural(obj)
           obj = obj.LineariseOneElementThickWalls();
           obj = obj.LineariseInternalDerivatives();
       end
       function obj         = LineariseOneElementThickWalls(obj,options)
           % Function to change the degrees of freedom of the mesh in order
           % to linearise the edges, surfaces and volumes in betwen
           % nodes of an element that constitutes a wall (has two external
           % opposite surfaces)
           bBasalNodesAlso = 1;
           bWarningMade = 0;
           if obj.bExternalFacesFound==0
               obj = obj.FindExternalSurfaces();
           end         
           iNodes2Linearise = [];
           iElems = [];
           for iElem = 1:obj.nElems
               % Check if it has two external surfaces
               nExternalSurfaces = sum(obj.ExternalFaces(iElem,:));
               if nExternalSurfaces == 2
                    % Check if they are opposite
                    iSurfs = find(obj.ExternalFaces(iElem,:));
                    % In order to check if they are opposite, look at the
                    % definition of the six possibilities, in
                    % obj.mapping.Surfaces.Nodes:
                    % - Both surfaces are 1 and 2
                    % - Both surfaces are 3 and 4
                    % - Both surfaces are 5 and 6
                    iSurfs = sort(iSurfs);
                    if iSurfs(1)==1&&iSurfs(2)==2 || iSurfs(1)==3&&iSurfs(2)==4 || iSurfs(1)==5&&iSurfs(2)==6
                        iNodes2Linearise = [iNodes2Linearise obj.giNofElem(iElem,1:obj.nNofElem(iElem))];
                        iElems = [iElems iElem*ones(1,obj.nNofElem(iElem))];
                    end
               end
               if nExternalSurfaces == 3
                   if (~bWarningMade)
                        fprintf('WARNING! In linearization, assumption that any element with three external surfaces is the RV basal element!\n')
                        bWarningMade = 1;
                   end
                   iNodes2Linearise = [iNodes2Linearise obj.giNofElem(iElem,1:obj.nNofElem(iElem))];
                   iElems = [iElems iElem*ones(1,obj.nNofElem(iElem))];
               end
           end
           for iN = 1:numel(iNodes2Linearise)
               iNode = iNodes2Linearise(iN);
               iElem = iElems(iN);
               options.iElem = iElem;                   
               obj = obj.LineariseNode(iNode,options);                   
           end
       end
       function obj         = LineariseNode(obj,iNode,options)
           % Function to change the degrees of freedom of the mesh in order
           % to linearise the edges, surfaces and volumes in a node
           %
           % If we think in internal nodes, finding the elements
           % that have the node as local index 1 and 8 gives us all
           % possibilities for the neighbour nodes. This was the rationale
           % behind the first implementation (these indexes of elements are
           % provided as arguments)
           %
           %
           bDebug = 0;
           Xi2linearise = 3;
           % A flag to indicate that the nodes come from two adjacent
           % elements, so the derivative must be halved (set default to 0
           % 27/07/2014 after bug in ScriptAtlas).
           bLinearByTwoAdjacentElements = 0;
            b18 = 0; % flag to control if this is an internal node with elements 1 & 8 
           bLinearByNodesSingleElement  = 0;
           if nargin>=3
               if isfield(options,'Xi2linearise'), 
                   Xi2linearise = options.Xi2linearise; 
               end
               if isfield(options,'iElem'), 
                   iElem = options.iElem;
                   bLinearByNodesSingleElement = 1;
               end
               if isfield(options,'iElemNodeIsLocalNode1'), 
                   iElemNodeIsLocalNode1 = options.iElemNodeIsLocalNode1;
                   bLinearByTwoAdjacentElements = 1;
                   b18 = 1;
               end
               if isfield(options,'iElemNodeIsLocalNode8'), 
                   iElemNodeIsLocalNode8 = options.iElemNodeIsLocalNode8; 
                   bLinearByTwoAdjacentElements = 1;
                   b18 = 1;
               end 
%                if isfield(options,'bLinearByTwoAdjacentElements'), 
%                    bLinearByTwoAdjacentElements = options.bLinearByTwoAdjacentElements; 
%                end               
           end
           if(bLinearByNodesSingleElement)
               iLocal = find(obj.giNofElem(iElem,:)==iNode);
               % iLocal assumes an element definition without collapsed
               % surfaces (not repeated nodes). If iLocal has two values,
               % this is a collapsed node, and only the first is enough:
               if numel(iLocal)>1
                   iLocal = iLocal(1);
               end
               if numel(iLocal)>1 || numel(iLocal)==0
                   fprintf('WARNING (LineariseNode)! Element %i does not have node %i as expected\n',iElem,iNode);
                   return;
               end
           end
           
           if(bLinearByTwoAdjacentElements)
               biE1 = 0; biE8 = 0;
               % Check that the elems exist, otherwise get them:
               if ~exist('iElemNodeIsLocalNode1','var')
                   biE1 = 1;
               end
               if ~exist('iElemNodeIsLocalNode8','var')
                   biE8 = 1;
               end
               if biE1 || biE8
                   % Now the search of elements is simply guided by the xi
                   % direction. The 8 possible adjacent elements to a node in a
                   % structured mesh:
                   List8elements = obj.mapping.ElemsOfNode(iNode,:);
                   % The indexes of nodes that have xi = o and xi = 1:
                   switch Xi2linearise
                       case 1, iLocalNode0 = [1 3 5 7]; iLocalNode1 = [2 4 6 8];
                       case 2, iLocalNode0 = [1 2 5 6]; iLocalNode1 = [3 4 7 8];
                       case 3, iLocalNode0 = [1 2 3 4]; iLocalNode1 = [5 6 7 8];
                   end
                   % We now simply need to find a paired match between
                   % adjacent elements:
                   Candidates0 = List8elements(iLocalNode0);
                   Candidates1 = List8elements(iLocalNode1);
                   % A product will reveal which are non zero in both:
                   Valid = find(Candidates0 .* Candidates1 > 0);
                   % Now the two nodes: note that we want to point to the
                   % oposite iLocanNode1 and iLocalNode0
                   if numel(Valid)==0
                       fprintf('WARNING! No paired match between adjacent elements found, node = %i\n',iNode);
                   else
                       iElem0  = List8elements(iLocalNode1((Valid(1))));
                       iLocal0 = iLocalNode0(Valid(1));
                       iNode0  = obj.giNofElem(iElem0,obj.liNofElem(iElem0,iLocal0));
                       iElem2  = List8elements(iLocalNode0((Valid(1))));
                       iLocal2 = iLocalNode1(Valid(1));
                       iNode2  = obj.giNofElem(iElem2,obj.liNofElem(iElem2,iLocal2));
                   end
               end
           end
                       
           
          switch Xi2linearise
               case 1
                   iValue2update = 2;
                   iValues2reset = [5 6 8];
                   iLPaired2L8 = 6;
                   iLPaired2L1 = 2;
                   iLPairedSingle0 = [ 1 1 3 3 5 5 7 7];
                   iLPairedSingle1 = [ 2 2 4 4 6 6 8 8];
               case 2
                   iValue2update = 3;
                   iValues2reset = [5 7 8];
                   iLPaired2L8 = 7;
                   iLPaired2L1 = 3;
                   iLPairedSingle0 = [ 1 2 1 2 5 6 5 6];
                   iLPairedSingle1 = [ 3 4 3 4 7 8 7 8];
               case 3
                   iValue2update = 4;
                   iValues2reset = [6 7 8];
                   iLPairedSingle0 = [ 1 2 3 4 1 2 3 4];
                   iLPairedSingle1 = [ 5 6 7 8 5 6 7 8];
                   if(b18)
                       iLPaired2L8 = 4;
                       iLPaired2L1 = 5;
                   else
                       iLPaired2L8 = 4;
                       iLPaired2L1 = 5;
                   end
               otherwise
                   fprintf('ERROR! wrong selection of Xi2linearise!\n');
          end
           if(bLinearByTwoAdjacentElements)&&b18
               iNode0 = obj.giNofElem(iElemNodeIsLocalNode8,obj.liNofElem(iElemNodeIsLocalNode8,iLPaired2L8));
               iNode2 = obj.giNofElem(iElemNodeIsLocalNode1,obj.liNofElem(iElemNodeIsLocalNode1,iLPaired2L1));
           end
           if(bLinearByNodesSingleElement)
               iNode0 = obj.giNofElem(iElem,obj.liNofElem(iElem,iLPairedSingle0(iLocal)));
               iNode2 = obj.giNofElem(iElem,obj.liNofElem(iElem,iLPairedSingle1(iLocal)));
            end                  
           if ~exist('iNode0','var')
               ErrorMsg = sprintf(' Undefined function or variable "iNode0".\n');
               ErrorMsg = sprintf(' %s Options not defined the nodes to work with:\n',ErrorMsg);
               ErrorMsg = sprintf(' %s bLinearByTwoAdjacentElements=%i\n bLinearByNodesSingleElement=%i\n',ErrorMsg,bLinearByTwoAdjacentElements,bLinearByNodesSingleElement);               
               error(ErrorMsg);
           end
           
           % The new derivative is the average of the vector distance
           % between the node and the neighbours
           Point0 = obj.GetNodeCoorValue(iNode0);
           Point2 = obj.GetNodeCoorValue(iNode2);

           if(bDebug), fprintf('iNodes for linearization: %i and %i\n',iNode0,iNode2); end
           Derivative = (Point2 - Point0);
           if(bLinearByTwoAdjacentElements)
               Derivative = Derivative ./ 2;
           end
           obj = obj.SetNodeCoorValue(Derivative,iNode,1:3,iValue2update);
           for iv = 1:numel(iValues2reset)
               iValue2reset = iValues2reset(iv);
               obj = obj.SetNodeCoorValue([0 0 0],iNode,1:3,iValue2reset);
           end
           
       end
       function obj         = LineariseInternalDerivatives(obj,options)
           % Function to change the degrees of freedom of the mesh in order
           % to linearise the edges, surfaces and volumes in betwen
           % internal nodes
           Xi2linearise = 3;
           if nargin==2
               if isfield(options,'Xi2linearise'), Xi2linearise = options.Xi2linearise; end
           end
           % 1. Look for the internal nodes
           ListInternalNodes = obj.GetIndexesInternalNodes();
           
           % 2. Update the derivatives of these internal nodes
           iElemNodeIsLocalNode8 = 0;
           for iN = 1:numel(ListInternalNodes)
               iNode = ListInternalNodes(iN);
               % This is an internal node, at least 8 elements have it (in
               % case of collapsed elements in the apex, this might be a
               % bigger number).
               List8elements = obj.mapping.ElemsOfNode(iNode,:);
               % Search for the element where iNode is local node 1:
               ListLocalNode = zeros(1,8);
               for i = 1:numel(List8elements)
                   iEl = List8elements(i);
                   if iEl >0
                       iLocal = find(obj.giNofElem(iEl,:) == iNode);
                       ListLocalNode(i) = iLocal;
                       if iLocal == 1
                           iElemNodeIsLocalNode1 = iEl;
                       end
                       if iLocal == 8
                           iElemNodeIsLocalNode8 = iEl;
                       end
                   end
               end
               % In case collapsed elements, it might be that an internal
               % node is not ever a local node 8:
               if iElemNodeIsLocalNode8 ~= 0
                   % This looks not to be a collapsed node
                   options.iElemNodeIsLocalNode1 = iElemNodeIsLocalNode1;
                   options.iElemNodeIsLocalNode8 = iElemNodeIsLocalNode8;
                   obj = obj.LineariseNode(iNode,options);
               end
           end
       end
       
% Interpolation functions:
       function [CH]        = CubicHermite(obj,xhi)
           % Function that returns the values of the four basis Cubic Hermite
           % functions at the piont xhi. xhi can also be a vector of points, and then
           % the function returns the vector of values for each basis. 
           CBF01 = obj.CubicHermite1(xhi);
           CBF02 = obj.CubicHermite3(xhi);
           CBF11 = obj.CubicHermite2(xhi);
           CBF12 = obj.CubicHermite4(xhi);
           CH=[CBF01;CBF11;CBF02;CBF12];
       end
       function [DCH]       = derivCubicHermite(obj,xhi)
            % Function that returns the values of the derivatives of the four basis Cubic Hermite
            % functions at the piont xhi. xhi can also be a vector of points, and then
            % the function returns the vector of values for each basis. 
            DCBF01 = obj.derCubicHermite1(xhi);
            DCBF02 = obj.derCubicHermite3(xhi);
            DCBF11 = obj.derCubicHermite2(xhi);
            DCBF12 = obj.derCubicHermite4(xhi);
            DCH=[DCBF01;DCBF11;DCBF02;DCBF12];
       end
       function [CL]        = CubicLagrange(obj,xhi)
           % Function that returns the values of the Cubic Lagrange basis
           % sifted by 1/3, constituting the 4 basis functions along a line
           % that need to be evaluated at each xhi location.
           % xhi can also be a vector of points, and then
           % the function returns the vector of values for each basis.
            DCBF01 = obj.CubicLagrange1(xhi);
            DCBF02 = obj.CubicLagrange2(xhi);
            DCBF11 = obj.CubicLagrange3(xhi);
            DCBF12 = obj.CubicLagrange4(xhi);
            CL=[DCBF01;DCBF11;DCBF02;DCBF12];
       end
% Defintion of fibres and other fields:
       function obj         = SetFibreElevationAngle(obj,angleEpi,angleEndo)
            % Function to define the elevaiton angle of the fibres. Angle
            % is given in degrees, and converted to radiants (definition
            % used in cmGui for visualization).
            angleEpi =  pi * angleEpi / 180;
            angleEndo =  pi * angleEndo / 180;
            
            if ~obj.bExternalFacesFound
                obj = obj.FindExternalSurfaces();
            end
            iEndoNodes  = obj.FindEndoNodes();
            iEpiNodes   = obj.FindEpiNodes();
            iInnerNodes = 1:obj.nNodes;
            iInnerNodes([iEndoNodes iEpiNodes]) = [];
            InnerValue  = (angleEndo + angleEpi) / 2;
            
            % Set the elevations:            
            values(iEndoNodes,1)  = angleEndo;
            values(iEpiNodes,1)   = angleEpi;
            values(iInnerNodes,1) = InnerValue;
            % Derivatives: null in all but xi3 - radial (also for imbrications)
            dfds3(iEndoNodes,1)  = (InnerValue - angleEndo);
            dfds3(iEpiNodes,1)   = (angleEpi-InnerValue);
            dfds3(iInnerNodes,1) = (angleEpi-angleEndo)/2;
                dfds1 = zeros(obj.nNodes,2);
                dfds2 = zeros(obj.nNodes,2);
                dfds12  = zeros(obj.nNodes,2);
                dfds13  = zeros(obj.nNodes,2);
                dfds23  = zeros(obj.nNodes,2);
                dfds123 = zeros(obj.nNodes,2);
            
            % Set the imbrications:
            values(:,2) = 0;
            dfds3(:,2) = 0;
            
            % Save the data:
            obj.bFibres =1;                 % Flag to indicate fibre data is available
            obj.FibreDescriptionType = 2;   % Fibre data is anatomical (elevation and imbrication)
            obj.FibDim = 2;                 % There are two fields, elvation and imbrication
           obj.fibres.value = values;
           obj.fibres.dfds1 = dfds1;
           obj.fibres.dfds2 = dfds2;
           obj.fibres.dfds3 = dfds3;
           obj.fibres.dfds12 = dfds12;
           obj.fibres.dfds13 = dfds13;
           obj.fibres.dfds23 = dfds23;
           obj.fibres.dfds123 = dfds123;
       end
       function obj         = DefineElemLabels(obj,labels)
           % Definition of a constant field called "labels" with
           % interpolation per element
           obj.ElemValues = labels;        
           obj.bElemValues= true;
           % Get a new file ID:
           [obj,iF,bNewField]= GetFieldID(obj,'labels');
           obj.ListOfFields.field(iF).Name      = 'labels';
           obj.ListOfFields.field(iF).Type          = 'field';
           obj.ListOfFields.field(iF).SubType       = 'rectangular cartesian';
           obj.ListOfFields.field(iF).nComponents   = 1;
           iComp = 1;
           obj.ListOfFields.field(iF).component(iComp).Name = 'label';
           obj.ListOfFields.field(iF).component(iComp).ScaleFactorSet = 'constant*constant*constant';
           obj.ListOfFields.field(iF).component(iComp).InterpolationBase = 'grid based';
           obj.ListOfFields.field(iF).component(iComp).nValues = 0;
           obj.ListOfFields.field(iF).component(iComp).nVersions = 0;
       end
       
% Fitting a field in the finite element domain description:
    % a) General fitting functions:
       function [CHd]       = FitField(obj,data,coor,options)
           % Find the coefficients of the basis functions to represent a
           % field. The output is then incorporated calling SetFieldDofs
           % (see TestFitField)
           % 
           % INPUT:
           % - data: vector OR 3D(4D) matrix of data samples OR filename
           %    a) Vector of field values (nDimensions x nSamples);
           %    b) 3D matrix if only one field value. (nDimensions x
           %    nSamplesX x nSamplesY x nSamplesZ)
           % - coor: coordiantes where data samples are given. Three options:
           %    a) Vector of coordinate values (nSamplesx3) 
           %    b) Matrix of coordinate values (3x nX x nY x nZ). 
           %    c) 6 values to build the grid of 3D points from the origin
           %    and spacing (size coming from the matrix data)
           %    d) Image header to build the grid
           %
           % OUTPUT:
           % - CHd: Cubic Hermite description of the field (set of DOF
           % values). (nDofs x nK), nK = number of field dimensions.
           %
           % Revision History:
           % 30/01/2013 (PL): possibility of using the header of the
           % image to build the grid of points.
           % 17/11/10(PL): remove of the parameter fieldname, clean up, and update of
           % "SetFieldDofs" to check the field ID based on name.
           % 02/11/10(PL): returns only the dofs, which are later set in
           % right variable of the class (fibre, coordinate, field...)
           % 01/09/10(PL): update of this function in order to handle:
           % (1) Fitting of second versions
           % (2) Using sparse data (not in a regular grid, using the code
           % from matlabcentral NewtFit:
           % http://www.mathworks.com/matlabcentral/fileexchange/8970-3d-data-interpolation
           % 
           % TODO's:
           % 1) adapt to make a nodal fitting in collapsed nodes
           % (currently the variational solution does not work for collapsed
           % nodes)
           % 2) fit also second versions
            bExternalImplementation=1;
            bDebug=0;
            bSplitCollapsed=1;
            bFitWithSecondVersions = 1;
            bSaveDataAtGaussPoints = 0;
            FitFieldGaussOrder = 4;
            
            if nargin==4
                if isfield(options,'bFitWithSecondVersions');
                    bFitWithSecondVersions = options.bFitWithSecondVersions;
                end
                if isfield(options,'bSplitCollapsed');
                    bSplitCollapsed = options.bSplitCollapsed;
                end
                if isfield(options,'GaussOrder');
                    FitFieldGaussOrder = options.GaussOrder;
                end
                if isfield(options,'filenameDataGaussPoints')
                    filenameDataGaussPoints = options.filenameDataGaussPoints;
                    bSaveDataAtGaussPoints =1;
                end
            end            
            % Default parameters:
            datatype = 1; % A grid of samples
            nK = 1;       % Field of one single dimension
            if ischar(data)
                datatype = 3;
                coor = NaN;
            else
                switch ndims(data)
                    case 1
                        datatype = 2;
                        nSamples = length(data);                        
                    case 2
                        datatype = 2;
                        [nK,nSamples] = size(data);
                        if nK>nSamples % Permute in case is needed:
                            data = data';
                            [nK,nSamples] = size(data);
                        end
                    case 3
                        [nX,nY,nZ]=size(data);
                    case 4
                        [nK,nX,nY,nZ]=size(data);
                end
%                 if (nZ==1||nY==0)
%                     if(bDebug),fprintf(1,'     DEBUGGING ... CubicMeshClass.FitField - Data is not a 3D matrix (interp3 not used, whereas the NewtFit function)\n');end
%                     datatype = 2;
%                 end
            end
            
            if datatype==1
                if numel(coor)==6 % This is option c) for input coor (see above)
                    % Create a grid of 3D points
                    Spacing=[coor(1) coor(2) coor(3)];
                    Origin =[coor(4) coor(5) coor(6)];
                    coor=zeros(3,nX,nY,nZ);
                    for ix=1:nX
                        for iy=1:nY
                            for iz=1:nZ
                                coor(1,ix,iy,iz) = Origin(1) + (ix-1)*Spacing(1);
                                coor(2,ix,iy,iz) = Origin(2) + (iy-1)*Spacing(2);
                                coor(3,ix,iy,iz) = Origin(3) + (iz-1)*Spacing(3);
                            end
                        end
                    end
                end
                if(isstruct(coor))
                    % This is a header:
                    hd = coor;
                    clear coor;
                    nX  = hd.dim(1);
                    nY  = hd.dim(2);
                    nZ  = hd.dim(3);
                    for ix=1:nX
                        for iy=1:nY
                            for iz=1:nZ
                                voxCoor = [ix iy iz] - [1 1 1];
                                voxCoor(4) = 1;
                                point = hd.Mv2w * voxCoor';
                                for iCoor = 1:3
                                    coor(iCoor,ix,iy,iz) = point(iCoor);
                                end
                            end
                        end
                    end
                end
                    
            end
            bSplitted=0;
            if(bSplitCollapsed)
                [ShapeToFit,CollapsedElements] = obj.SplitMesh_CollapsedElems();
                if CollapsedElements.nElems>0
                    bSplitted = 1;
                end
            else
                ShapeToFit = obj;
                fprintf(1,'WARNING! CubicMeshClass:FitField Mesh is supposed not to have any collapsed element, but this has not been checked!\n');
            end
            if(bExternalImplementation)
                M2Interpolation='spline';
                fprintf(' Gauss Order chosen to be %i for M2 (construction of b)!\n',FitFieldGaussOrder);

                DATA.datatype = datatype;
                DATA.values = data;
                DATA.coor   = coor;
                optionsFit.GaussOrder =FitFieldGaussOrder;
                optionsFit.M2Interpolation = M2Interpolation;                
                optionsFit.bSplitted = bSplitted;
                optionsFit.ManageSecondaryVersions = bFitWithSecondVersions;
                if(bSaveDataAtGaussPoints)
                    optionsFit.filenameDataGaussPoints = filenameDataGaussPoints;
                end
                [CHd,foo,foo,nK] = FittingInto3DCubicHermiteMesh10(ShapeToFit,DATA,optionsFit);
                if( isnan(CHd))
                    error('found NAN in CHd');
                end
               
                % The total DoFs that the complete shape should have:
                nDofs = obj.nNodes * 8 + obj.nNewVersionsBasis(obj.SecondaryVersionsDefinitionOption);
                if(bSplitted)
                    % The fitting has been done in "non-collapsed" elements
                    % and the collapsed nodes should be given a nodal value
                    
                    NonCollapsedNodes = ShapeToFit.OLDGIN;
                    temp = CHd; clear CHd; CHd = zeros(nDofs,nK);
                    bCollapsed = ones(obj.nNodes,1);
                    for in = 1:ShapeToFit.nNodes
                        iNode = NonCollapsedNodes(in);
                        bCollapsed(iNode) = 0;
                        basisShapeNoCollapsed = [1:8]+(in-1)*8;
                        basisShapeComplete    = [1:8]+(iNode-1)*8;
                        if nK==1
                            CHd(basisShapeComplete) = temp(basisShapeNoCollapsed);
                        else
                            CHd(basisShapeComplete,:) = temp(basisShapeNoCollapsed,:);
                        end
                    end
                    % Now, the collapsed nodes:
                    iCollapsed = find(bCollapsed);
                    nColap = numel(iCollapsed);
                    basisUIndex  = zeros(nColap,1);
                    points       = zeros(nColap,3);
                    Coefficients = zeros(nColap,1);

                    switch datatype
                        case 3
                            [DataAtGaussPoints,coor,value,xiCoor,iElem] = ReadGaussPoints(DATA.values,obj.nElems);
                            dim = min(size(value));
                            for iC = 1:numel(iCollapsed);
                                iNode = iCollapsed(iC);
                                basisUIndex(iC) = 1 + (iNode-1)*8;
                                iElemsWithNode = obj.mapping.ElemsOfNode(iNode,:);
                                % Only the nonzero values:
                                iElemsWithNode = iElemsWithNode(find(iElemsWithNode));
                                % TODO: get the average value of the
                                % closest GaussPoints of every element: 
                                cnc = obj.coordinates(iNode,:,1);% CollapseNodeCoordinate
                                CandidateIndexes = [];
                                for j=1:length(iElemsWithNode)
                                    CandidateIndexes = find(iElem==iElemsWithNode(j));
                                    distancesX = coor(CandidateIndexes,1) - cnc(1);
                                    distancesY = coor(CandidateIndexes,2) - cnc(2);
                                    distancesZ = coor(CandidateIndexes,3) - cnc(2);
                                    distances = distancesX.^2 + distancesY.^2 + distancesZ.^2;
                                    WinnerIndexes = find(distances==min(distances));
                                    Indexes(j) = CandidateIndexes(WinnerIndexes(1));
                                end                                
                                Coefficients(iC,1:dim) = mean(value(Indexes,1:dim),1);
                                % OLD BIASED WAY:
                                %GaussPoints = squeeze(DataAtGaussPoints(iElemsWithNode(find(iElemsWithNode)),:,1,:));
                                %Coefficients(iC) = mean(GaussPoints(:));
                                % Version bugged not working:
                                %Coefficients = obj.Interpolate(DATA,points');
                            end
                            Coefficients = Coefficients';
                        otherwise
                            for iC = 1:numel(iCollapsed);
                                iNode = iCollapsed(iC);
                                basisUIndex(iC) = 1 + (iNode-1)*8;
                                points(iC,1:3) = obj.coordinates(iNode,:,1);
                            end
                            Coefficients = obj.Interpolate(DATA,points);
                    end
                    for iK=1:nK
                        CHd(basisUIndex,iK) = Coefficients(iK,:);                    
                    end
                end
                nBasis = max(size(CHd));
                fprintf('  Field is fitted, and represented with %i degrees of freedom. \n',nBasis)
            else
                %TODO: internal implementation is slower!
            end
       end
       %function obj = FitFieldLMS()
          %TODO: Robert to bring here the code to:
          %1. Calculate the xi coordinates of samples
          %2. Build and solve the LMS matrix system
       %end
    % b) Tailored fitting functions:
       function [obj]           = FitFibreTensorFromVtkFile(obj,directory,VtkFile,BinaryFileName)
% funciton to fit the data provided by N.Toussaint, a VTK filw with DT-MRI
% components, and a binary mask of the definition of the domain (to which
% the mesh must have been fitted before)
           [F,V,E] = VTK2cmGuiTetMesh(directory,VtkFile,0);   
           [Im,hd] = io_ReadMedicalImage([directory BinaryFileName]);
           Images  = NodalData2Images(V,hd,F);
           options.DataDir = directory;
           obj     = obj.FitFibreTensor(Images,hd,options);
       end
       function [obj]           = FitFibreTensor(obj,Images,header,options)
           % Funciton to fit the data captured by DR-MRI. The key here is
           % to know that tensors should be interpolated in the log space:
           % each component has to take its logarithm before fitting.
           %
           % Two ways of fitting data (flag "FittingOpiton")
           % (1) Project all components of the tensor into the basis
           % functions (in log space) and then get elevations/imbrications
           % to fit
           % (2) Get elevation/imbrication from data, and then project
           % these two into the basis functions.
           %
           % For two reasons, fitting is done in "world coordinates without
           % rotation":
           % - 1. Any use of interp3 needs the regular grid of samples
           % aligned with the cartesian grid
           % - 2. Generation of temporary images with cmGui is still not
           % feasible with arbitrary orientations, only with "slices"
           % aligned with the cartesian axes. 
           %
           % INPUT:
           % - images: a structure with the regular grid description of the
           % nine components of the tensor (from DT-MRI)
           % - header: of the images
           %
           % OUTPUT: mesh with fibres described as elevation and 
           % imbrication, and sheet angles, after interpolation of the 
           % tensor data at a set of Gauss Coordinates.
           %           
           % 30/01/2013
           
           
           % Flags:
            bDebug = 1;
            bDebugAlignment = 0;
            FittingOpiton = 2;
            DataDir = obj.DataDir;
            if nargin==4
                if isfield(options,'FittingOpiton'), FittingOpiton = options.FittingOpiton; end
                if isfield(options,'DataDir'), DataDir = options.DataDir; end
            end
            
           % Data quality checks:
           if numel(Images)~=9
               fprintf(' ERROR! CubicMeshClass.FitFibreTensor: There are not 9 expected images in first parameter introduced (but %i)!\n',numel(Images))
           end
           

           Rot = header.TransformMatrix; 
           CH2 = obj.rotateMesh(inv(Rot),header.origin);    
            % ... and update the header accordingly (so that the world
            % coordinates of the images correspond to the mesh as well)
           headerNoRot = header;
           headerNoRot.TransformMatrix = eye(3,3);
           options.bNotReloadHeader = 1;
           headerNoRot = ParseHeader(headerNoRot,options);
           if(bDebugAlignment)
                MeshName = 'MeshRotated';
                isoname  = 'IsoRotated';
                CH2 = CH2.SetName(MeshName);
                CH2.WriteExFiles(obj.DataDir);
                V = Build_Isosurface(logical(data),headerNoRot.Mv2w);
                WriteIsosurfaceExFormat(V,obj.DataDir,isoname);
                optView.isosurf = isoname;
                optView.CH2 = CH2;
                cmGuiViewMesh(obj.DataDir,obj,optView);
            end

           switch FittingOpiton
               case 1
                   for iDTc = 1:9 
                        % 1. Take the logarithm of components
                        data = Images(iDTc).data;
                        fieldname = sprintf('DT%i',iDTc);
                        io_WriteMedicalImage([obj.DataDir 'Image' fieldname header.Extension],data,header);
                        data2fit = log(data);

                        DOFs = CH2.FitField(data2fit,headerNoRot); 
                        if(bDebug)
                            fprintf('About to set a new field. nFields = %i\n',obj.nFields);
                            for iF=1:obj.nFields
                                fprintf('   ... Field %i: %s\n',iF,obj.GetFieldName(iF));
                            end
                        end
                        obj  = obj.SetFieldDofs(fieldname,DOFs);
                   end

                   % 3. Compute the fibre elevation and imbrication at all Gauss
                   % Points:

                   % 4. Compute the sheet angles at all Gauss points

               case 2
                   [imElevation,imImbrication] = CH2.GetImbricationAndElevationFromImages(Images,header,headerNoRot,DataDir);
                   DOFsElev = CH2.FitField(imElevation,headerNoRot);
                   DOFsImbr = CH2.FitField(imImbrication,headerNoRot);
                   fibCH(:,1) = DOFsElev;
                   fibCH(:,2) = DOFsImbr;
                   obj = obj.SetFibreDofs(fibCH);
                   obj.FibDim = 2;
                   obj.FibreDescriptionType=2;
                   obj.bFibres = 1;                   
           end
       end
       function [CHd]           = FitFibres(obj,imx,imy,imz,hIm,bFitWithSecondVersions)           
           % INPUT: fibres described as vectors (x,y,z) at a regular grid
           % of points (described as three images of the three components
           % and the header of the image with the origin and spacing). This
           % description MUST be smooth (otherwise the fitting won't be
           % good)
           %
           % OUTPUT: three sest of coefficients of the three fields, one for
           % each of the vectorial components, that needs to be retrieved
           % and loaded into the class by the function obj.RetrieveFibres
           
           
            obj.bFibres = 1;
            obj.FibreDescriptionType=1;
            obj.FibDim = 3;
            
           fprintf('*****************************************************************************************************************************************************************************\n');
           fprintf('WARNING! Function  FitFibres deprecated. Use FitFibresFromVectorialData instead, where the vectorial description of fibres is changed into a elevation and imbrication angles\n');
           fprintf('*****************************************************************************************************************************************************************************\n');
           if nargin<6
               bFitWithSecondVersions=0;
           end
           % Create a grid of 3D points
            Spacing= hIm.spacing;
            Origin = hIm.origin;
            [nX,nY,nZ]=size(imx);
            coor=zeros(3,nX,nY,nZ);
            for ix=1:nX
                for iy=1:nY
                    for iz=1:nZ
                        coor(1,ix,iy,iz) = Origin(1) + (ix-1)*Spacing(1);
                        coor(2,ix,iy,iz) = Origin(2) + (iy-1)*Spacing(2);
                        coor(3,ix,iy,iz) = Origin(3) + (iz-1)*Spacing(3);
                    end
                end
            end
            fib(1,:,:,:) = imx;
            fib(2,:,:,:) = imy;
            fib(3,:,:,:) = imz;
            
%             [ShapeNoCollapsedElements,CollapsedElements] = obj.SplitMesh_CollapsedElems();
%             if (CollapsedElements.nElems>1)
%                 % TODO:
%                 % CollapsedElements = DeformMeshByRegInterp_M3_v2(map,CollapsedElements);
%             else
%                 ShapeNoCollapsedElements = obj;
%                 fprintf(1,'WARNING! Mesh is supposed not to have any collapsed element, but this has not been checked!\n');
%             end

            tic();
            fprintf('  Fitting of fibres in shape FE... Image of fibres of size (%i,%i,%i)\n',size(imx))

    % Updated version with the choice of GaussOrder (08/01/10):
            GaussOrder = 4;
            fprintf(' Gauss Order chosen to be %i for M2 (construction of b)!\n',GaussOrder);            
            M2Interpolation = 'nearest';
            % TODO: update this fitting function to the new options!
            [CHd] = FittingInto3DCubicHermiteMesh10(fib,coor,obj,GaussOrder,M2Interpolation,bFitWithSecondVersions);
       end
       function [obj,fibCH]     = FitFibresFromVectorialData(obj,im1,im2,im3,hIm,bAnatomical,bOnlyProject)
           % INPUT: fibres described in two ways:
           % 1) as vectors (x,y,z) at a regular grid
           % of points (described as three images of the three components
           % and the header of the image with the origin and spacing)
           % 2) as three images of elevation, imbrication and sheet angle.
           if nargin<6
               % The default option is that data is given in cartesian
               bAnatomical = 0;
           end
           if nargin<7
               bOnlyProject = 0;
           end
           bSubsampling=0;
           bSaveTempImages=1;
           if(~bAnatomical)
               % Translate from cartesian to "anatomical":
               FileElevations = ['TempElevationsFor' obj.name '.vtk'];
               FileImbrications = ['TempImbricationsFor' obj.name '.vtk'];
               [imElevation,imImbrication] = obj.ProjectFibres(im1,im2,im3,hIm);
               write_image_vtk2(FileElevations,imElevation,hIm);
               write_image_vtk2(FileImbrications,imImbrication,hIm);
           else
               imElevation   = im1;
               imImbrication = im2;
               imSheetAngle  = im3;
               if numel(find(imSheetAngle))>0
                   fprintf('WARNING! code not prepared yet to fit the sheet angle\n');
               end
           end
            obj.bFibres = 1;
            obj.FibreDescriptionType=2;
            obj.FibDim = 2;
           if(bSaveTempImages)&(~bAnatomical)
               dir = obj.TempBinaryDir;
               write_image_vtk2([dir 'Elevation_temp.vtk'],imElevation,hIm,'binary','b');
               write_image_vtk2([dir 'Imbrication_temp.vtk'],imImbrication,hIm,'binary','b');
           end
           if(~bOnlyProject)
               if(bSubsampling)
                   ss=[3 3 1];
                   hIm.spacing = hIm.spacing .* ss;
                   temp = imElevation;
                   imEl = imElevation(1:ss(1):end,1:ss(2):end,1:ss(3):end);
                   imIm = imImbrication(1:ss(1):end,1:ss(2):end,1:ss(3):end);
               else
                   imEl = imElevation;
                   imIm = imImbrication;
               end
               clear imElevation imImbrication;


               bFitWithSecondVersions = 0;
               % Create a grid of 3D points
                Spacing= hIm.spacing;
                Origin = hIm.origin;
                [nX,nY,nZ]=size(imEl);
                coor=zeros(3,nX,nY,nZ);
                for ix=1:nX, for iy=1:nY, for iz=1:nZ
                    coor(1,ix,iy,iz) = Origin(1) + (ix-1)*Spacing(1);
                    coor(2,ix,iy,iz) = Origin(2) + (iy-1)*Spacing(2);
                    coor(3,ix,iy,iz) = Origin(3) + (iz-1)*Spacing(3);
                end; end; end
               GaussOrder = 4;
               M2Interpolation = 'spline';
               DATA.datatype = 1;
               DATA.values = imEl;
               DATA.coor = coor;
               [CHelev] = FittingInto3DCubicHermiteMesh10(obj,DATA);
               DATA.values = imIm;
               [CHimbr] = FittingInto3DCubicHermiteMesh10(obj,DATA);
               % Now retrieve this information:
               % ... assemble it in a single matrix:
               fibCH(:,1) = CHelev;
               fibCH(:,2) = CHimbr;
               %obj = obj.RetrieveFibres(fibCH,bFitWithSecondVersions);
               obj = obj.SetFibreDofs(fibCH);
           end
       end
       function obj             = FitFibresFromSparseTensorData(obj,TensorData,points)
           [elevations,imbrications] = obj.GetImbricationAndElevationFromSparseTensors(TensorData,points);
           obj = obj.FitImbricationAndElevationData(elevations,imbrications,points);
       end
       function [imElev,imImbr] = ProjectFibres(obj,imx,imy,imz,hIm)
           % Function that projects a vector of fibre direction
           % into the local coordinate system, determining the elevation
           % and imbrication angles.
           % Implementation options:
           % - 1: point by point, and finding the xi coordinates in each of
           % them
           % - 2: using cmgui to compute the local axis orientation, but
           % seems not to be working.
           % - 3: using cmgui to find the xi coordinates, but then
           % computation is still done point by point - the computational
           % gain in time is tiny!
           % - 4 (TODO): organise voxels in elements, group them, and find
           % the projection in elev,imbr in parallel in all of them using
           % fastCoordinateEvaluation
           bDebug = 0;
           bDebugAtan = 0;
           bDebugImbr = 0;

            % Create a list of 3D points
            Spacing= hIm.spacing;
            Origin = hIm.origin;
    
            if obj.beBBbuilt==0
                obj = obj.BuildElementBoundingBoxes();
            end
            implementationoption = 1; %2;
            [nX,nY,nZ]=size(imx);
            switch implementationoption
                case {1,3}                    
                    if implementationoption==3
                        % Precompute the xi coordinates:
                        imXi = zeros(nX,nY,nZ);
                        for iXiC=1:3
                            options.ImageKind = sprintf('xi%i',iXiC);
                            options.nVoxels = [nX,nY,nZ];
                            im = single(obj.GenerateIm_cmGUI(Spacing,Origin,options));
                            imXi(:,:,:,iXiC) = im;
                        end
                    end
                    imElev =  zeros(nX,nY,nZ);
                    imImbr =  zeros(nX,nY,nZ);
                    nPoints = nX*nY*nZ;
                    coor=zeros(6,nPoints);
                    index=0;
                    nVox = [nX nY nZ];
                    optionsGenIm.origin = Origin;
                    optionsGenIm.nVox = nVox;
                    binaryMask = obj.GenerateBinaryImage(Spacing,optionsGenIm);
                    for ix=1:nX, for iy=1:nY, for iz=1:nZ
                        if binaryMask(ix,iy,iz)>0
                            index=index+1;
                            coor(1,index) = Origin(1) + (ix-1)*Spacing(1);
                            coor(2,index) = Origin(2) + (iy-1)*Spacing(2);
                            coor(3,index) = Origin(3) + (iz-1)*Spacing(3);
                            coor(4,index) = ix;
                            coor(5,index) = iy;
                            coor(6,index) = iz;
                        end
                    end; end; end
                    nValidPoints=index;
                    points = coor(1:6,1:nValidPoints);
                    clear coor;
                    fprintf('About to project %i points...\n',nValidPoints);
                    tproj = tic();
                    for iPoint=1:nValidPoints
                        if rem(iPoint,10) == 0
                            fprintf('   ... Projecting point %i\n',iPoint);
                            toc(tproj)
                        end
                        % 1. Get the local material directions of this point:
                        CartesianCoordinate = [points(1,iPoint) points(2,iPoint) points(3,iPoint)];
                        ImCoor = [points(4,iPoint) points(5,iPoint) points(6,iPoint)];
                        Fibre = [imx(ImCoor(1),ImCoor(2),ImCoor(3)) imy(ImCoor(1),ImCoor(2),ImCoor(3)) imz(ImCoor(1),ImCoor(2),ImCoor(3))];                
                        switch implementationoption
                            case 1
                                [elevation,imbrication, iE,xiCoordinate, ~, dudxi1,dudxi2,dudxi3] = obj.GetElevationImbricationAngles(CartesianCoordinate,Fibre);
% AL 29.9.2014: Added iE,xiCoordinate, dudxi1,dudxi2,dudxi3 to output 
                                if ~isnan(dudxi1), 
                                    points(7:15, iPoint) = [dudxi1'; dudxi2'; dudxi3'];  % AL added 29.9.2014
                                    points(16:18, iPoint)= Fibre';   % AL added 02.10.2014
                                    points(19:20, iPoint)= [elevation; imbrication];  % AL added 02.10.2014
                                    points(21, iPoint)   = iE; % AL added on 4.11.2014
                                    points(22:24, iPoint)= xiCoordinate; % AL added on 4.11.2014
                                end 
                            case 3
                                XiCoor = zeros(1,3);
                                for iCC = 1:3,  XiCoor(iCC) = imXi(ImCoor(1),ImCoor(2),ImCoor(3),iCC); end
                                [elevation,imbrication]= obj.GetElevationImbricationAngles(CartesianCoordinate,Fibre,XiCoor);
                        end

                        imElev(ImCoor(1),ImCoor(2),ImCoor(3))=elevation;
                        imImbr(ImCoor(1),ImCoor(2),ImCoor(3))=imbrication;
                        
                                        disp(['Done ' num2str(iPoint)]), toc
                        
% AL 29.9.2014: save points array, which contains dudxi1,2,3 at each voxel.
%                         if mod(iPoint,200)==0, save('/home/al12/Data/20140718 Eric Caruth TAC/Pablo/MeshWithFibres_output/PointsXiData_AL_20141002.mat', 'points'), disp('SAVED'), end
%                         if mod(iPoint,200)==0, save('/home/al12/svnrepos/PabloCubicHermite/ExampleData/Alex/MeshWithFibres_output/PointsXiData_AL_20141006.mat', 'points'), disp('SAVED'), end
% ???? What's this?                        if mod(iPoint,200)==0, save('/home/al12/svnrepos/PabloCubicHermite/ExampleData/Alex/MeshWithFibres_output_20141029/PointsXiData_AL_20141029.mat', 'points'), disp('SAVED'), end
%                         if mod(iPoint,200)==0, save('/home/al12/svnrepos/PabloCubicHermite/ExampleData/Alex/MeshWithFibres_output/PointsXiData_AL_20141104.mat', 'points'), disp('SAVED'), end
                        if mod(iPoint,200)==0, save([obj.DataDir 'PointsXiData.mat'], 'points'), disp('SAVED'), end
        
                        
                    end
                case 2 
                    options.nVoxels = hIm.dim;
                    options.Derivative= 'xi1';                    
                    dudxi1 = obj.GenerateImageLocalOrientation(Spacing,Origin,options);
                    options.Derivative= 'xi2';                    
                    dudxi2 = obj.GenerateImageLocalOrientation(Spacing,Origin,options);
                    options.Derivative= 'xi3';                    
                    dudxi3 = obj.GenerateImageLocalOrientation(Spacing,Origin,options);
                if(bDebug)
                    Odudxi1 = dudxi1;
                    Odudxi2 = dudxi2;
                    Odudxi3 = dudxi3;
                    slices = 80:20:120;
                    for iS = 1:numel(slices)
                        figure('color',[1 1 1]); colormap(jet(256));
                        iSlice = slices(iS);
                        for iXi=1:3
                            for iC=1:3, 
                                iSub = iC + (iXi-1)*4;
                                switch iXi,
                                    case 1, data = Odudxi1;
                                    case 2, data = Odudxi2;                                        
                                    case 3, data = Odudxi3;
                                end
                                subplot(4,4,iSub), 
                                image(127.5*(1+data(:,:,iSlice,iC)));
                                title(sprintf('ORIGINAL dudxi%i, coord %i',iXi,iC)); axis equal;
                            end
                            iSub = iSub +1;
                            normVector = sqrt(sum(data.^2,4));
                            subplot(4,4,iSub), 
                            imagesc(normVector(:,:,iSlice)); colorbar;
                            title('Norm of components');  axis equal;
                        end
                    end
                end
                    % These directions are still not orthogonal, need to
                    % 4. Get the orthonormal coordinate system: find the vector
                    % perpendicular to dudxi1 and in the plane of dudxi1-dudxi2
                    dudxi3 = cross(dudxi1,dudxi2);
                    dudxi2 = cross(dudxi3,dudxi1);
                    dudxi1 = obj.Normalise(dudxi1);
                    dudxi2 = obj.Normalise(dudxi2);
                    dudxi3 = obj.Normalise(dudxi3); 
                    fibre(:,:,:,1) = imx;
                    fibre(:,:,:,2) = imy;
                    fibre(:,:,:,3) = imz;
                    fibre = obj.Normalise(fibre);
                    
                %A = imx .* Imxhi11 + imy .* Imxhi12 + imz * Imxhi13;
                A = imx .* dudxi1(:,:,:,1) + imy .* dudxi1(:,:,:,2) + imz .* dudxi1(:,:,:,3);
                %B = imx .* Imxhi21 + imy .* Imxhi22 + imz * Imxhi23;
                B = imx .* dudxi2(:,:,:,1) + imy .* dudxi2(:,:,:,2) + imz .* dudxi2(:,:,:,3);
                %C = imx .* Imxhi31 + imy .* Imxhi32 + imz * Imxhi33;
                C = imx .* dudxi3(:,:,:,1) + imy .* dudxi3(:,:,:,2) + imz .* dudxi3(:,:,:,3);
                imElev = atan(B./A);
                %imElev = asin(B);
                %imElev = acos(A);
                % As defined in Benson2010 ("Construction and validation of anisotropic and orthotropic ventricular geometries for quantitative predictive cardiac electrophysiology"): 
                
                % But as it should be (more robust in meaning):
                Diag = sign(A) .* squeeze(sqrt(A.^2 + B.^2));
                imImbr = atan(C./Diag);
                slice = 100;
                if(bDebugImbr)
                    image1 = atan(C./A); caption1 = 'imImbr = atan(C./A)';
                    image2 = Diag; caption2 = 'Diag = sign(A) * sqrt(A2 + B2)';
                    image3 = imImbr;     caption3 = 'imImbr = atan(C./ModDiag)';
                    clim = [-pi/8 pi/8];
                    clim2 = [0 1];
                end
                if(bDebugAtan)
                    image1 = imImbr;     
                    PlanarModule = sqrt(B.^2 + A.^2);
                    image2 = asin(B./PlanarModule);
                    image3 = acos(A./PlanarModule);                
                    caption1 = 'Imbrication with atan...';
                    caption2 = '... with asin,';
                    caption3 = '.. and with acos';
                    clim = [-pi/2 pi/2];
                    clim2= clim;
                end
                if(bDebugAtan)||(bDebugImbr)                    
                    figure('color',[1 1 1])
                    nRows = 3;
                    nCols = 4;
                    subplot(1,nCols,1), obj.plotExternalSurfaces();  
                        % Draw a plane:
                        voxCoor = [1 1 slice 1];
                        P0 = hIm.Mv2w * voxCoor';
                        for ix = 1:10:nX
                            for iy = 1:10:nY
                                voxCoor = [ix iy slice 1];
                                P1 = hIm.Mv2w * voxCoor';
                                plot3([P1(1) P0(1)],[P1(2) P0(2)],[P1(3) P0(3)],'r');
                                P0 = P1;
                            end
                        end
                        view(0,0); xlabel('X'); ylabel('Y'); zlabel('Z')
                        title(sprintf('Anatomy with image plane %i',slice))
                    subplot(nRows,nCols,2), imagesc(imx(:,:,slice)), title('Fx'), axis equal; colorbar;
                    subplot(nRows,nCols,3), imagesc(imy(:,:,slice)), title('Fy'), axis equal; colorbar;
                    subplot(nRows,nCols,4), imagesc(imz(:,:,slice)), title('Fz'), axis equal; colorbar;
                    subplot(nRows,nCols,6), imagesc(abs(A(:,:,slice))), title('abs(A)'), axis equal; colorbar;
                    subplot(nRows,nCols,7), imagesc(abs(B(:,:,slice))), title('abs(B)'), axis equal; colorbar;
                    subplot(nRows,nCols,8), imagesc((C(:,:,slice))), title('(C)'), axis equal; colorbar;
                    subplot(nRows,nCols,10), imagesc(image1(:,:,slice),clim), title(caption1), axis equal; colorbar;
                    subplot(nRows,nCols,11), imagesc(image2(:,:,slice),clim2), title(caption2), axis equal; colorbar;
                    subplot(nRows,nCols,12), imagesc(image3(:,:,slice),clim), title(caption3), axis equal; colorbar;                    
                end
                
                    
                if(bDebug)
                    slices = 100:25:175;
                    for iS = 1:numel(slices)
                        figure('color',[1 1 1]); colormap(jet(256));
                        iSlice = slices(iS);
                        for iXi=1:3
                            for iC=1:3, 
                                iSub = iC + (iXi-1)*4;
                                switch iXi,
                                    case 1, data = dudxi1;
                                    case 2, data = dudxi2;                                        
                                    case 3, data = dudxi3;
                                end
                                subplot(4,4,iSub), 
                                image(127.5*(1+data(:,:,iSlice,iC)));
                                title(sprintf('dudxi%i, coord %i',iXi,iC));axis equal;
                            end
                            iSub = iSub +1;
                            normVector = sum(data.^2,4);
                            subplot(4,4,iSub), image(normVector(:,:,iSlice)*255); title('Norm of components');  axis equal;
                        end
                        subplot(4,4,13), image((1+A(:,:,iSlice))*255/2); title('Component A'); axis equal;
                        subplot(4,4,14), image((1+imx(:,:,iSlice))*255/2); title('imx'); axis equal;
                        subplot(4,4,15), image(normVector(:,:,iSlice).*(1+imx(:,:,iSlice))*255/2); title('imx masked'); axis equal;
                        subplot(4,4,16), image((pi/2+imElev(:,:,iSlice))*255/(pi)); title('imElev'); axis equal;
                        %subplot(4,4,16), image(imImbr(:,:,iSlice)*255); title('imImbr'); axis equal;
                    end
                end
                if(bDebug)
                    figure('color',[1 1 1]); obj.plotExternalSurfaces(3); hold on; axis equal; 
                    I = find(A>-100);
                    FirstID = 3; % or 3
                    LastID = 3; % or 3
                    % One arbitrary point:
                    for iP = 1:77:numel(I)
                        iPoint = I(iP);
                        [ix,iy,iz] = ind2sub(size(A),iPoint);
                        voxCoor = [ix iy iz 1];
                        P = hIm.Mv2w * voxCoor';
    %                    plot3(P(1),P(2),P(3),'*r')
                        for iD = FirstID:LastID
                            switch iD
                                case 1, data2p = dudxi1; color = 'r';
                                case 2, data2p = dudxi2; color = 'g';
                                case 3, data2p = dudxi3; color = 'k';
                            end
                            dxi = squeeze(data2p(voxCoor(1),voxCoor(2),voxCoor(3),:));
                            dfib = squeeze(fibre(ix,iy,iz,:));
                            if (LastID - FirstID +1 )== 1
                                % only dudxi1 arrow, color code it
                                % accordingly to its Z component:
                                color = squeeze(ind2rgb(round(128*(1+dxi(3))),jet(256)));
                                color2= squeeze(ind2rgb(round(128*(1+dfib(3))),jet(256)));
                            end
                            P1= P + 10*dxi;
                            plot3([P(1) P1(1)],[P(2) P1(2)],[P(3) P1(3)],'color',color,'LineWidth',2);
                            P2 = P + 10*dfib;
                            %plot3([P(1) P2(1)],[P(2) P2(2)],[P(3) P2(3)],'color',color2,'LineWidth',3);
                        end
                    end
                end
            end
       end
       function [ImageLocOrient]= GenerateImageLocalOrientation(obj,Spacing,Origin,options)
            bNormalise = 0;
            if isfield(options,'bDebug'), bDebug = options.bDebug; end
            % It is an image generated with bNeedAccurateGrayscale!
            MaxGrayscale = 231;                      
            % Calling cmgui to generate images of the local material orientations   
            maxIm = 0;
            for iComp = 1:3
                options.ImageKind = sprintf('%s%i',options.Derivative,iComp);
                options.bDebug = 1;
                options.bNeedAccurateGrayscale = 1;
                im = single(obj.GenerateIm_cmGUI(Spacing,Origin,options));
                maxIm = max( max(im(:)), maxIm);
                % Correct mapping between (0-255) to (-1,1)
                im = 2*(im/MaxGrayscale - 0.5);
                ImageLocOrient(:,:,:,iComp) = im;                                                    
            end
            if(bNormalise)
                Norm = sqrt(sum(ImageLocOrient.^2,4));
                for iComp = 1:3
                    ImageLocOrient(:,:,:,iComp) = ImageLocOrient(:,:,:,iComp)./Norm;
                end
            end
        end
       function [elevation,imbrication,iE,xiCoordinate,error, dudxi1,dudxi2,dudxi3] = GetElevationImbricationAngles(obj,Point,Vector,XiCoor)
           % OUTPUT:
           % - error: metric of the distance between the Point and the
          % physical location of the point corresponding to xiCoordinates
          % (because of optimization resolution in the search of the
          % inverse coordinate, or because Point was outside the domain).
           bDebug = 0;
            elevation=NaN;
            imbrication=NaN;
           if nargin==4
               [dudxi1,dudxi2,dudxi3,iE,xiCoordinate,error] = obj.GetXiDirections(Point,XiCoor);
           else
               [dudxi1,dudxi2,dudxi3,iE,xiCoordinate,error] = obj.GetXiDirections(Point,[],1);
           end
            if isnan(dudxi1) 
            iE=NaN;
            xiCoordinate=[NaN NaN NaN];
                if(bDebug), fprintf('GetElevationImbricationAngles: NaN because out of the domain (point: %1.2f, %1.2f, %1.2f)\n',Point); end
                return;
            else
                if Vector == [0 0 0]
                    if(bDebug), fprintf('GetElevationImbricationAngles: NaN because of null input vector (point: %1.2f, %1.2f, %1.2f)\n',Point); end
                    return;
                else
                    if(bDebug), 
                        tolerance = 10^-6; % the one used in evaluate_inverse
                        if(error>tolerance), fprintf('WARNING! closest point at %1.3fmm found (original was out of the domain: %1.2f, %1.2f, %1.2f)\n',error,Point); end                        
                    end                        
                    A = Vector * dudxi1';
                    B = Vector * dudxi2';
                    C = Vector * dudxi3';
                    % As defined in Benson2010 ("Construction and validation of anisotropic and orthotropic ventricular geometries for quantitative predictive cardiac electrophysiology"): 
                    elevation = atan(B/A);
                    % imbrication = atan(C/A);
                    % But as it should be (more robust in meaning):
                    Diag = sign(A) .* squeeze(sqrt(A.^2 + B.^2));
                    imbrication = atan(C./Diag);
                end                
            end
       end
       function [obj]           = RetrieveFibres(obj,CHd,~)
           fprintf('WARNING! Function "RetrieveFibres" has been deprecated, new version obj.SetFibreDofs called\n');
           obj = obj.SetFibreDofs(CHd);
       end
       function [imElevation,imImbrication] = GetImbricationAndElevationFromImages(obj,Images,header,headerNoRot,dir)
           nDims = numel(Images);
           switch nDims
               case 3, fprintf('Getting elevation and imbrication from images of x,y,z components of fibre direction\n')
                   XYZimages = Images;
               case 9, 
                   fprintf('Getting elevation and imbrication from images of the nine components of a tensor (from DT-MRI)\n')
                   % The vectors need to be rotated accordingly to the
                   % rotation made to the mesh:                   
                   Rot = inv(header.TransformMatrix);
                   XYZimages = PrepareMainVector(Images,Rot);
               otherwise, fprintf('ERROR! the number of images does not make sense (CubicMeshClass.GetImbricationAndElevationFromImages)\n');
           end
           im1 =  XYZimages(1).data;
           im2 =  XYZimages(2).data;
           im3 =  XYZimages(3).data;
           [imE,imI] = obj.ProjectFibres(im1,im2,im3,headerNoRot);
           [imElevation,imImbrication] = obj.CorrectPhaseWrapping(imE,imI,headerNoRot);
           io_WriteMedicalImage([dir 'ImElevation' header.Extension],imElevation,header);
           io_WriteMedicalImage([dir 'ImImbrication' header.Extension],imImbrication,header);
       end
       function [imElevationOut,imImbricationOut] = CorrectPhaseWrapping(obj,imElevation,imImbrication,header,discretisation)
           % A function to correct phase wrapping, identified from
           % epicardial or endocardial locations (where the wrapping is
           % much more likely) and extended by fast marching
           
           bDebug = 0;
           ImbricationThreshold = 2 * pi / 8;
           ElevationThreshold   = pi/3;
           ImplementationOption = 2;
           bAllEpi = 1;
           % The region is 1.3 of the wall thickness:
           WT = obj.EstimateThickness();
           VOX= mean(header.spacing);
           ss = round(WT / (3 * VOX)); % size of the structural element 
           fprintf(' Phase wrapping correction. Estimated thickness = %1.2f; Epi layer of %i voxels\n',WT,ss);
           
           if(nargin<5)
               discretisation = 10;
           end
           % 1. Detect points with wrapping in epi and endo:
           if (~obj.bExternalFacesFound)
               obj = obj.FindExternalSurfaces();
           end
           [iElemsEpi,iFaceEpi] = obj.FindEpiElements();
           [iElemsEndo,iFaceEndo] = obj.FindEndoElements();
           if(bAllEpi)
               options = [];
           else
               % Only seeds to grow in "valid" voxels, those that have
               % phase wrapping already:
               options.imElevation = imElevation;
               options.condition = 1;
               options.ImbricationThreshold = ImbricationThreshold;
           end           
           [IvoxEpi] = obj.GetSurfaceVoxelIndexes(iElemsEpi,iFaceEpi,discretisation,header,options);
           fprintf('A total of %i epicardial voxels with phase wrapping: \n',numel(IvoxEpi));
           if(bDebug)               
               figure('color',[1 1 1]);
               show_segment_surface(imElevation,[0 0 0],[1 1 1],0.1);
               im = zeros(size(imElevation)); im(IvoxEpi) = 1;
               show_segment_surface(im,[0 0 0],[1 1 1],0.9);
               title('Epicardial nodes with phase wrapping');
           end
           if(~bAllEpi)
               imElevation(IvoxEpi) = imElevation(IvoxEpi) - pi;
               imImbrication(IvoxEpi) = imImbrication(IvoxEpi) - pi;
           end

%            options.condition = 2;
%            [IvoxEndo] = obj.GetSurfaceVoxelIndexes(iElemsEndo,iFaceEndo,discretisation,header,options);           
%            fprintf('A total of %i endocardial voxels with phase wrapping: \n',numel(IvoxEndo));
%            if(bDebug)               
%                figure('color',[1 1 1]);
%                show_segment_surface(imElevation,[0 0 0],[1 1 1],0.1);
%                im = zeros(size(imElevation)); im(IvoxEndo) = 1;
%                show_segment_surface(im,[0 0 0],[1 1 1],0.9);
%                title('Endocardial nodes with phase wrapping');
%            end
%            imElevation(IvoxEndo) = imElevation(IvoxEndo) + pi;
%            imImbrication(IvoxEndo) = imImbrication(IvoxEndo) + pi;

           switch ImplementationOption
               case 1, 
                   % Fast marching around these initial voxels:
                   % Find wrapping points: get the maximum value
                   if numel(IvoxEpi)>1 || numel(IvoxEndo)>1
                       [X Y Z] = ind2sub(size(imElevation),[IvoxEpi IvoxEndo]);
                       options.StartingVoxel = [X;Y;Z];
                   else
                       options = [];
                   end
                   [imElevationOut,imImbricationOut] = ReorientFibresAnatomical(imElevation,imImbrication,options);
               case 2,
                   % Dilate a region around these inital voxels, and flip
                   % any angle above 
                   imElevationOut       = imElevation;
                   imImbricationOut     = imImbrication;
                   im = zeros(size(imElevation)); im(IvoxEpi) = 1;
%                    im = boolean(imdilate(im,strel('disk',ss)));
                   im = logical(imdilate(im,strel('disk',ss))); %Trying to convert to boolean? G.Gonzalez 24/09/13
                   Icandidates = find(im);
                        i2 = find(imElevation(Icandidates) > ImbricationThreshold);
                        I2flipE = Icandidates(i2);
                        fprintf(' - %i voxels to flip Elevation\n',numel(I2flipE));
                        imElevationOut(I2flipE)  = imElevation(I2flipE) - pi;
                        i2 = find(imImbrication(Icandidates) > ElevationThreshold);
                        I2flipI = Icandidates(i2);
                        fprintf(' - %i voxels to flip Imbrication\n',numel(I2flipI));
                        imImbricationOut(I2flipI)= imImbrication(I2flipI) - pi;
                   if(bDebug)
                       [X Y Z] = ind2sub(size(imElevation),I2flip);
                       slice = median(Z);
                       subplot(121), imagesc(imElevation(:,:,slice)); title('Elevation before flipping');
                       subplot(122), imagesc(imElevationOut(:,:,slice)); title('Elevation after flipping');
                   end
           end
           
       end
       function [Ivox]          = GetSurfaceVoxelIndexes(obj,iElems,iFace,discretisation,header,options)
           % Funciton that computes the voxel coordinates of some
           % points in the surface of the mesh (surface of iFace of
           % iElems).
           % INPUT: additional options:
           % - condition: only return those voxels that satisfy a
           % certain condition
           % - imElevation: data to check a condition on fibre
           % elevation

           condition = 0;
           ImbricationThreshold = pi/2;
           if nargin==6
               if isfield(options,'condition'), condition = options.condition; end
               if isfield(options,'imElevation'), imElevation = options.imElevation; end
               if isfield(options,'ImbricationThreshold'), ImbricationThreshold = options.ImbricationThreshold; end               
           end
           Ivox = []; % linear index of voxels
           nPtsPerSur = discretisation^2;
           for iE = 1:numel(iElems)
               iElem = iElems(iE);
               [foo,P] = obj.tesselateElementFace(iElem,iFace,discretisation);               
               P = P';
               P(4,1:nPtsPerSur) = 1;
               voxels = round(header.Mw2v * P);
               Ineg = find(voxels<0);
               [Icoor INegPoint] = ind2sub(size(voxels),Ineg);
               bReportMw2v = 0;
               if numel(Ineg)>0
                   fprintf('ERROR! conversion of surface points to voxel coordinates led to negative values\n');
                   bReportMw2v = 1;
               end
               xOut = find(voxels(1,:)>header.dim(1)-1);
               if numel(xOut)>0
                   fprintf('ERROR! conversion of surface points to voxel coordinates led to X coordinates out of range (too big)\n');
                   bReportMw2v = 1;
               end
               yOut = find(voxels(2,:)>header.dim(2)-1);
               if numel(yOut)>0
                   fprintf('ERROR! conversion of surface points to voxel coordinates led to Y coordinates out of range (too big)\n');
                   bReportMw2v = 1;
               end
               zOut = find(voxels(3,:)>header.dim(3)-1);
               if numel(zOut)>0
                   fprintf('ERROR! conversion of surface points to voxel coordinates led to Z coordinates out of range (too big)\n');
                   bReportMw2v = 1;
               end
               if (bReportMw2v)
                   fprintf(' Element %i, face %i\n',iElem, iFace);
                   fprintf('       Mw2v = %1.1f %1.1f %1.1f %1.1f\n', header.Mw2v(1,:));
                   fprintf('              %1.1f %1.1f %1.1f %1.1f\n', header.Mw2v(2,:));
                   fprintf('              %1.1f %1.1f %1.1f %1.1f\n', header.Mw2v(3,:));
               end
               % Remove the voxels out of view:
               nPoints = numel(voxels)/3;
               Ivalid= 1:nPoints;
               if(bReportMw2v)
                   InotValid = [INegPoint xOut yOut zOut];
                   Ivalid(InotValid) = [];
                   fprintf(' A total of %i points were out of range (out of %i)\n',numel(InotValid),nPoints);
               end
               
               
               % Matlab indexing starts at [1 1 1]! Need to add this 1:
               iVox = sub2ind(header.dim,voxels(1,Ivalid)+1,voxels(2,Ivalid)+1,voxels(3,Ivalid)+1);
               iVox = unique(iVox);
               switch condition
                   case 0, NewI = 1:numel(iVox);
                   case 1, NewI = find(imElevation(iVox)>  ImbricationThreshold);
                   case 2, NewI = find(imElevation(iVox)< -ImbricationThreshold);
               end
               Ivox = [Ivox iVox(NewI)];
           end
           Ivox = unique(Ivox);
       end
       function [elevations,imbrications,iElements,xiCoordinates,iOut] = GetImbricationAndElevationFromSparseTensors(obj,TensorData,points,nameFileElevImbric,dir)
           % Function that prepares the raw data for the fitting:
           % 1) Makes the SVD analysis and gets the first eigenvector
           % (surrogate of fibre direction)
           % 2) Finds the elevation and imbrication angles, and writes a
           % file with all needed information for fitting and debug
           % purposes: elevation, imbrication, index of element, xi
           % coordinates of the point
           %
           % The objective is to make this once, since this is quite costly
           % in computational time.
                      
           iOut = NaN; % default output
           obj.TempcmGuiDir = obj.ReplaceSlash(obj.TempcmGuiDir);
           ImplementationOption = 1;
           bViewInitialAlignment = 1;
           bWriteRawFibreDirection=0;
           bWriteElevationImbricationFibreDirection=1;
                      
           if nargin<4
               nameFileElevImbric = 'FibresElevImbric';
           end
           if nargin<5
               dir = obj.TempcmGuiDir;
           end
           % --------------------------------------------------------------           
           nDimsTensor = TensorData.dimensions;
           switch nDimsTensor
               case 9
                   % Need to make the SVD analysis:
                   fprintf(1,'   PrepareFibreDataFromSparseTensors: (1) SVD analysis\n');
                   FibreVector = PrepareMainVector(TensorData); 
               case 3
                   % Only the fibre direction given: do nothing
                   fprintf(1,'   PrepareFibreDataFromSparseTensors: (1) No need of SVD analysis, fibre direction provided\n');
                   FibreVector = squeeze(TensorData.values);
               otherwise
                   fprintf('ERROR! The dimensions of the fibre data are not expected (in GetImbricationAndElevationFromSparseTensors)\n');
           end
                
           if(bViewInitialAlignment)
               bWriteRawFibreDirection = 1;
           end

           if(bWriteRawFibreDirection)
               FibreDirection.nFields=1;
               FibreDirection.name = 'Fibre_Direction';
               FibreDirection.dimensions = 3;
               FibreDirection.values(1,:,1:3) = FibreVector;
               nameFile = 'FibreDirectionData';
               WriteTetExNode(points,dir,nameFile,FibreDirection);
               fprintf(1,'   Writting the "Fibre direction raw data" after SVD of the tensor in %s',[obj.TempcmGuiDir nameFile]);
           end
           if(bViewInitialAlignment)
               optionsViewMesh.exdata = nameFile;
               cmGuiViewMesh(obj.DataDir,obj,optionsViewMesh);
           end
           % --------------------------------------------------------------
           fprintf(1,'   PrepareFibreDataFromSparseTensors: (2) Get imbrication and elevation\n');
           [nPoints b]      = size(FibreVector);

           switch ImplementationOption
               case 1 % Slow, inverse coordinate in matlab
                   elevations       = zeros(1,nPoints);
                   imbrications     = zeros(1,nPoints);
                   iElements        = zeros(1,nPoints);
                   xiCoordinates    = zeros(3,nPoints);
                   Errors           = zeros(1,nPoints);
                   a=tic();
                   if obj.beBBbuilt==0
                       obj = obj.BuildElementBoundingBoxes();
                   end
                   if obj.bExternalFacesFound==0
                       obj = obj.FindExternalSurfaces();
                   end
                   nPoints2Process=nPoints;%10
                   iPointIni = 1;%505;
                   for iPoint=iPointIni:iPointIni+nPoints2Process-1
                       if rem(iPoint,1000) == 0
                           % each point takes about 1.7 s!!! 
                           nNaNs = numel(find(isnan(elevations)));
                           tolerance = 10^-6; % from evaluate_inverse
                           iOut = (find(Errors>tolerance));
                           nOut = numel(iOut);
                           fprintf('   ... Projecting point %i (out of %i). \n',iPoint,nPoints)
                           fprintf('        - NaNs: %i (%1.2f %%)\n',nNaNs,100*nNaNs/nPoints);
                           fprintf('        - Out of domain: %i (%1.2f %%)\n',nOut,100*nOut/nPoints);
                           fprintf('          With an average distance to domain: %1.3f mm\n',mean(Errors(iOut)));
                       end
                       point = points(iPoint,1:3);
                       fibre = FibreVector(iPoint,1:3);
                       [elev,imbr,iE,xiCoordinate,dist2CP] = obj.GetElevationImbricationAngles(point,fibre);
                       elevations(iPoint)        = elev;
                       imbrications(iPoint)      = imbr;
                       iElements(iPoint)          = iE;
                       Errors(iPoint)             = dist2CP;
                       xiCoordinates(1:3,iPoint) = xiCoordinate;
                   end
                   iOut = (find(Errors>tolerance));
               case 2 % Fast, inverse coordinate through cmGui
                   [imElevation,imImbrication] = obj.ProjectFibres(im1,im2,im3,hIm);
                   
           end
           nNaNs = numel(find(isnan(elevations)));
           fprintf('   End of projection. Total NaNs %i (out of %i points processed)\n',nNaNs,nPoints2Process);
           if(bWriteElevationImbricationFibreDirection)
               FibresElevImbric.nFields=4;
               FibresElevImbric.dimensions(1) = 1;
               FibresElevImbric.dimNames(1).names = 'value';
               FibresElevImbric.name(1,:) = 'Elevation  ';
               FibresElevImbric.values(1,:) = elevations;
               FibresElevImbric.dimensions(2) = 1;
               FibresElevImbric.name(2,:) = 'Imbrication';
               FibresElevImbric.dimNames(2).names = 'value';
               FibresElevImbric.values(2,:) = imbrications;
               FibresElevImbric.dimensions(3) = 1;
               FibresElevImbric.name(3,:) = 'iElements  ';
               FibresElevImbric.dimNames(3).names = 'iE';
               FibresElevImbric.values(3,:) = iElements;
               FibresElevImbric.dimensions(4) = 3;
               FibresElevImbric.name(4,:) = 'xiCoordinat';               
               FibresElevImbric.dimNames(4).names = ['xi1';'xi2';'xi3'];
               FibresElevImbric.values(4,:,1:3) = xiCoordinates(1:3,:)';               
               WriteTetExNode(points,dir,nameFileElevImbric,FibresElevImbric);
               fprintf(1,'   Writting the "Fibre direction in elevation and imbrication format" in %s',[obj.TempcmGuiDir nameFileElevImbric]);
           end
           toc(a);
       end
       function obj             = FitImbricationAndElevationData(obj,elevations,imbrications,points)
           % --------------------------------------------------------------
           fprintf(1,'   FitImbricationAndElevationData: Fit imbrication and elevation\n');
           fieldname = 'elevation';
           DOFs = obj.FitField(elevations,points,fieldname);
           obj  = obj.SetFibreDofs(DOFs,1);
           fieldname = 'imbrication';
           DOFs = obj.FitField(imbrications,points,fieldname);
           obj  = obj.SetFibreDofs(DOFs,2);
           obj.FibDim = 2;
           obj.FibreDescriptionType=2;
           obj.bFibres = 1;
           if(0)
                % Codify a null sheet field:
                % This might be needed to have a consistent defintion of
                % fibres, but I am not sure it is really needed.               
                obj.nFields = obj.nFields+1;
                obj.fields.value(:,obj.nFields)=0;
                obj.fields.dfds1(:,obj.nFields)=0;
                obj.fields.dfds2(:,obj.nFields)=0;
                obj.fields.dfds3(:,obj.nFields)=0;
                obj.fields.dfds13(:,obj.nFields)=0;                
                obj.fields.dfds12(:,obj.nFields)=0;
                obj.fields.dfds123(:,obj.nFields)=0;
                obj.fields.dfds23(:,obj.nFields)=0;
                % A hack to avoid writting a new fiels in the definition of
                % files: copy the "imbrication" name!
                obj.fieldNames(:,obj.nFields)=obj.fieldNames(:,obj.nFields-1);
           end
       end
       function [obj,iField,bNewField]= GetFieldID(obj,fieldname)
           MaxNumberCharacters=100;
           % Check number of existing fields:
           if obj.nFields==0
               % Initialise the structure of names:
               obj.fieldNames=char(zeros(1,MaxNumberCharacters));               
           end
           bNewField=1;
           % Check if the fieldname is in the string
           nCaracters=numel(fieldname);               
           for iF=1:obj.nFields
               nCarField = obj.fieldNames(iF,1);
               % A quick way to check, and also avoid problems of too short
               % or long names with accesing outside the matrix:
               if nCarField==nCaracters
                   FN = obj.GetFieldName(iF);
                   if (strcmp(FN,fieldname))
                       bNewField=0;
                       iField=iF;
                   end
               end
           end
           if (bNewField)
               iField = obj.nFields + 1;
               obj.nFields = iField;
               obj = obj.SetFieldName(iField,fieldname);
           end
       end
       function [M,Mupdated]    = Build_M(obj)
            % Function to build the mass matrix. 
            
            % Integral of the 64localbasis x 64localbasis in a 3D element:            
            % ... first the 4x4 mass matrix of a 1D element:
            II = obj.GetMatrixOfPairedHermiteBasisIntegrals();
            % ... now to the mass matrix of a 3D element:
            II64=zeros(64,64);
            for i=1:64
                for j=1:64
                    multiplicands=zeros(1,3);
                    for k=1:3
                        multiplicands(k) = II(obj.mapping.IndexOf64CHBasis(k,i),obj.mapping.IndexOf64CHBasis(k,j));
                    end
                    % The volume is the product of what happens in each
                    % axis:
                    II64(i,j) = prod(multiplicands);
                end
            end

            nBasis=obj.nNodes*8;
            M=zeros(nBasis,nBasis);
            Mupdated=zeros(nBasis,nBasis);

            for iElem=1:obj.nElems
                NodesOfiElem = obj.mapping.NodesOfElem(iElem,:);
                if NodesOfiElem(7)==0
                    nNodesElement = 6;
                else
                    nNodesElement = 8;
                end
                for nli=1:nNodesElement
                    % Global index of the node:
                    n1=NodesOfiElem(nli);
            %                     if n1==34
            %                         fprintf('\nThe GlobalNode%i in element%i with nodes(%i,%i,%i,%i,%i,%i,%i,%i)\n',n1,iElem,NodesOfiElem(1:8));
            %                     end
                    % There are 8 basis per node (8 continuities per node)
                    for c1=1:8
                        % Global index of the basis:
                        Bi1 = obj.GlobalBasisIndex(n1,c1);
                        % We have a global node 'n1' which is a local node 'nli' in the
                        % element 'iElem'. 
                        % In this element, the basis 'Bi1' corresponds to the
                        % continuity 'c1' of the local node 'nli'. 
                        % Get the 8 basis indexes corresponding to local node nli:
                        The_8_ibasis_of_nli = find(obj.mapping.ContinuityOfNode==nli);
                        % Get the base index corresponding to local node nli and
                        % continuity c1:
                        Local_Bi1 = The_8_ibasis_of_nli(c1);
                        % This 'Local_Bi1' has a contribution to the mass matrix 
                        % with another 64 "local basis" (including itself) inside
                        % this element:

                        for nli2=1:nNodesElement
                            n2 = NodesOfiElem(nli2);
                            for c2=1:8
                                Bi2 = obj.GlobalBasisIndex(n2,c2);
                                The_8_mappingindexes_of_iElem = find(obj.mapping.ContinuityOfNode==nli2);
                                Local_Bi2 = The_8_mappingindexes_of_iElem(c2);
                                Mcontribution = II64(Local_Bi1,Local_Bi2);
            %                     if Bi2==Bi1
            %                         Mcontribution=Mcontribution/2;
            %                     end
                                M(Bi1,Bi2) = M(Bi1,Bi2) + Mcontribution;
                                Mupdated(Bi1,Bi2)=Mupdated(Bi1,Bi2)+1;
            %                     if n1==34 && c1==1 && c2==1
            %                         fprintf('                 has Basis %i and %i updated\n',Bi1,Bi2);
            %                     end                    
                            end
                        end
                    end
                end
            end

            % Check if the matrix is simetric before returning it!
            isSimetric=true;
            for i=1:nBasis
                for j=i:nBasis
                    if M(i,j)~=M(j,i)
                        isSimetric=false;
                        fprintf('ERROR! M is not symetric in (%i,%i)\n',i,j);
                    end
                end
            end

            if isSimetric==false
                M=zeros(nBasis,nBasis);
            end
       end
       function [b]             = Build_b(obj,data,coor)
            % Build b, integral of data*basis
            GaussIntOrder=5;
            nBasis=obj.nNodes*8;
            b = zeros(1,nBasis);
            BasisAtGauss     = obj.CHvaluesAtGaussPoints(GaussIntOrder);
            GaussCoordinates = obj.GetLocalGaussCoords1D(GaussIntOrder);
            GaussWeights     = GaussCoordinates.GaussWeights;

            % Calculate the interpolation of data at the gauss points:
            %fprintf('  1. Interpolating data at gauss points... ');
            dataGaus = zeros(obj.nElems,GaussIntOrder,GaussIntOrder,GaussIntOrder);
            grid     = obj.BuildGrid(coor);
            
            for iElem=1:obj.nElems
                GaussPoints = obj.GetGlobalGaussPoints(iElem,GaussIntOrder);
                points = reshape(GaussPoints.GlobalCoordinates,GaussIntOrder^3,3);
                values = obj.Interpolate(grid,data,points);
                clear points;
                values = reshape(values,GaussIntOrder,GaussIntOrder,GaussIntOrder);
                dataGaus(iElem,1:GaussIntOrder,1:GaussIntOrder,1:GaussIntOrder) = values;

                NodesOfiElem = obj.mapping.NodesOfElem(iElem,:);
                if NodesOfiElem(7)==0
                    nNodesElement = 6;
                else
                    nNodesElement = 8;
                end
                for nli=1:nNodesElement
                    % Global index of the node:
                    n1=NodesOfiElem(nli);
            %                     if n1==34
            %                         fprintf('\nThe GlobalNode%i in element%i with nodes(%i,%i,%i,%i,%i,%i,%i,%i)\n',n1,iElem,NodesOfiElem(1:8));
            %                     end
                    % There are 8 basis per node (8 continuities per node)
                    for c1=1:8
                        % Global index of the basis:
                            Bi1 = obj.GlobalBasisIndex(n1,c1);
                        % We have a global node 'n1' which is a local node 'nli' in the
                        % element 'iElem'. In this element, the basis 'Bi' corresponds 
                        % to the continuity 'c1' of the local node 'nli'. 
                            The_8_ibasis_of_nli = find(obj.mapping.ContinuityOfNode==nli);
                            Local_Bi1 = The_8_ibasis_of_nli(c1);
                            BasAtGauss(1:GaussIntOrder,1:GaussIntOrder,1:GaussIntOrder) = squeeze(BasisAtGauss(Local_Bi1,:,:,:));
                            DatAtGauss(1:GaussIntOrder,1:GaussIntOrder,1:GaussIntOrder) = squeeze(dataGaus(iElem,:,:,:));
                        % Build the tensor of Gaussian Weights:
                            Weights=zeros(GaussIntOrder,GaussIntOrder,GaussIntOrder);
                            for k=1:GaussIntOrder
                                Weights(k,:,:)=GaussWeights(k) * (GaussWeights'*GaussWeights);
                            end
                        bcontribution = sum(sum(sum(BasAtGauss.*DatAtGauss.*Weights)));
                        if isnan(bcontribution)
                            fprintf(' ERROR! NaN in the contribution of node %i, which belongs to element %i\n',n1,iElem);
                        end
                        b(Bi1) = b(Bi1) + bcontribution;
                    end
                end
            end
       end
       function [BasisAtGauss]  = CHvaluesAtGaussPoints(obj,order)
            BasisAtGauss = zeros(64,order,order,order);
            GaussCoordinates1D = obj.GetLocalGaussCoords1D(order);
            for i1=1:order
                for i2=1:order
                    for i3=1:order
                        xhi(1)=GaussCoordinates1D.GPxhi(i1);
                        xhi(2)=GaussCoordinates1D.GPxhi(i2);
                        xhi(3)=GaussCoordinates1D.GPxhi(i3);
                        for ib=1:64
                            CHfunctionIndexes = obj.mapping.IndexOf64CHBasis(:,ib);
                            multiplicands = zeros(1,3);
                            for k=1:3
                                CH = obj.CubicHermite(xhi(k));
                                multiplicands(k) = CH(CHfunctionIndexes(k),1);
                            end
                            BasisAtGauss(ib,i1,i2,i3) = prod(multiplicands);
                        end
                    end
                end
            end
       end
       function [M]             = GetMatrixOfPairedHermiteBasisIntegrals(obj)
           % Analyitical computation of the integral of paired basis
           % multiplications (speed up time)
           M11 = 13/35;
           M12 = 11/210;
           M13 = 9/70;
           M14 = -13/420;
           M22 = 1/105;
           M23 = 13/420;
           M24 = obj.IntegrateCubicHermiteBasis_X_CubicHermiteBasis(2,4);
           
           M = [    M11     M12     M13     M14;
                    M12     M22     M23     M24;
                    M13     M23     M11     -M12;
                    M14     M24     -M12    M22];
       end
       function [M]             = GetMatrixOf2DHermiteIntegrals(obj)
           mm = zeros(1,4);
           mm(1,1) = obj.IntegrateCubicHermiteBasis_X_CubicHermiteBasis(1,0);
           mm(1,2) = obj.IntegrateCubicHermiteBasis_X_CubicHermiteBasis(2,0);
           mm(1,3) = obj.IntegrateCubicHermiteBasis_X_CubicHermiteBasis(3,0);
           mm(1,4) = obj.IntegrateCubicHermiteBasis_X_CubicHermiteBasis(4,0);           
           M = mm' * mm;
       end
       function [value]         = IntegrateCubicHermiteBasis_X_CubicHermiteBasis(obj,BFi1,BFi2,xhi1,xhi2)
            % Function that calculates the lineal integral of the function result of
            % the product of two Cubic Hermite basis functions in the domain [0 1]. It 
            % is done with five gauss points, some are done analytically to
            % gain a tiny bit of accuracy.
            % 
            % BFi1: Basis Function Index 1
            % BFi2: Basis Function Index 2. If it is 0, this refers to the
            % constant function
            bDebug = 0;

            if BFi1<1 || BFi1 >4 || BFi2 <0 || BFi2 > 4
                fprintf(' ERROR: wrong BasisFunctionIndex!!\n');
            end
            if nargin<4
                xhi1=0;
                xhi2=1;
            end
            bComputed = 0;
            if xhi1==0 && xhi2==1
                % Analytical computation of some of these values:
                if (BFi1==1 && BFi2==1) || (BFi1==3 && BFi2==3)
                    value = 13/35;
                    bComputed = 1;
                end
                if (BFi1==2 && BFi2==2) || (BFi1==4 && BFi2==4)
                    value = 1/105;
                    bComputed = 1;
                end                    
                if (BFi1==1 && BFi2==2) || (BFi1==2 && BFi2==1)
                    value = 11/210; 
                    bComputed = 1;
                end                   
                if (BFi1==3 && BFi2==4) || (BFi1==4 && BFi2==3)
                    value = -11/210; 
                    bComputed = 1;
                end                   
                if (BFi1==1 && BFi2==3) || (BFi1==3 && BFi2==1)
                    value = 9/70;
                    bComputed = 1;
                end                  
                if (BFi1==1 && BFi2==4) || (BFi1==4 && BFi2==1)
                    value = -13/420;
                    bComputed = 1;
                end                 
                if (BFi1==2 && BFi2==3) || (BFi1==3 && BFi2==2)
                    value = 13/420;
                    bComputed = 1;
                end 
            end
            
            if bDebug
                bNumInt = 1;
            else
                if bComputed
                    bNumInt = 0;
                else
                    bNumInt = 1;
                end
            end
            if(bNumInt)
                % Numerical integration:
                GaussOrder = 5;
                LocalGaussPoints1D = obj.GetLocalGaussCoords1D(GaussOrder,xhi1,xhi2);
                [CH] = obj.CubicHermite(LocalGaussPoints1D.GPxhi);
                if BFi2==0
                    CH2 = ones(1,GaussOrder);
                else
                    CH2 = CH(BFi2,:);
                end
                IntValue = CH(BFi1,:).*CH2 * LocalGaussPoints1D.GaussWeights';
                if(bDebug)&&bComputed
                    fprintf('Error corrected: %f\n',value-IntValue);
                else
                    value = IntValue;
                end
            end
       end

% Quality functions:
       function obj         = CalculateQualityNoK(obj,xi)
           if nargin<2
               xi = 2;
           end
           options.bNotConditionNumber = 1;
           % calculate quality but not the condition number:
           obj = obj.CalculateQuality(xi,options);
       end
       function obj         = CalculateQuality(obj,xi,options)
           % Defualt options
           bNotConditionNumber = 1;
           if nargin<2
               xi = 2;
           end
           if nargin == 3
               if isfield(options,'bNotConditionNumber'), bNotConditionNumber = options.bNotConditionNumber; end
           end
                   
           tq = tic();
           fprintf('Calculating quality of mesh %s...\n',obj.name);
           fprintf('  ... Aspect Ratio\n');
           obj=obj.CalculateAspectRatio();
           fprintf('  ... Orthogonality\n');
           obj=obj.CalculateOrthogonality();
           fprintf('  ... Jacobian Ratio\n');
           obj=obj.CalculateJacobianRatio();
           fprintf('  ... Directional Jacobian Ratio (xi%i direction)\n',xi);
           obj=obj.CalculateDirecJacRatio(xi);
           if(~bNotConditionNumber)
               fprintf('  ... Condition Number\n');
               obj=obj.CalculateConditionNumber();
               obj.bQualityCalculated = true;
           end
           toc(tq)
           obj.bQualityCalculated = true;
       end
       function obj         = CalculateAspectRatio(obj)
          if obj.nElems==0
              fprintf(1,' WARNING: No elements in the mesh, not possible to calculate aspect ratio\n');
          else
              ne = obj.nElems;
              for i=1:ne
                  [ind,nn] = obj.GetNodeIndexesOfElement(i);
                  points = obj.coordinates(ind,:);
                  distances = obj.CalculeDistancesBetweenAllPoints(points);
                  ElementQuality = sqrt(3) * min(distances)/max(distances);
                  obj.Quality.AspectRatio(i,1) = ElementQuality;
              end
              obj.Quality.Q1 = mean(obj.Quality.AspectRatio);
          end
           obj.bQ1Calculated= true;
       end
       function obj         = CalculateOrthogonality(obj)
           if obj.nElems==0
               fprintf(1,' WARNING: No elements in the mesh, not possible to calculate aspect ratio\n');
           else
               if(obj.InterpolationBasis==1)
                   ne = obj.nElems;
                   nNan = 0;
                   % TODO: make the calculi per node, and after index the nodes
                   % of each element!
                   for iElem=1:ne
                       [ind,nn] = obj.GetNodeIndexesOfElement(iElem);
                       %preallocation:                  
                       Dot=zeros(1,3);
                       orthogonality=ones(1,nn);
                       switch obj.InterpolationBasis
                           case 1 % C.Hermite:
                               % Calculate the index in each node
                               for i=1:nn
                                   % Derivatives of vector U = (x,y,z) with respect to xhi1, xhi2 and xhi3
                                   Udxhi1 = obj.derivatives.duds1(ind(i),:);
                                   Udxhi2 = obj.derivatives.duds2(ind(i),:);
                                   Udxhi3 = obj.derivatives.duds3(ind(i),:);
                                   % Normalice vectors:
                                   Udxhi1 = obj.Normalise(Udxhi1);
                                   Udxhi2 = obj.Normalise(Udxhi2);
                                   Udxhi3 = obj.Normalise(Udxhi3);
                                   % Dot product between each couple of vectors:
                                   Dot(1)=abs(sum(Udxhi1*Udxhi2'));
                                   Dot(2)=abs(sum(Udxhi1*Udxhi3'));
                                   Dot(3)=abs(sum(Udxhi2*Udxhi3'));
                                   if isnan(Dot(1)) ||  isnan(Dot(2))  ||  isnan(Dot(3))
                                       fprintf(1,'WARNING! NaN in a dot product. Element number %i, node %i\n',iElem,ind(i));
                                       nNan = nNan + 1;
                                   end
                                   if isnan(Dot(1)), Dot(1) = 1; end
                                   if isnan(Dot(2)), Dot(2) = 1; end
                                   if isnan(Dot(3)), Dot(3) = 1; end
                                   % Adding 3 dot products, the maximum value is 3
                                   SumDots = sum(Dot);
                                   orthogonality(i)= 1 - SumDots/3;
                                   obj.Quality.OrthogonalityPerNode(ind(i))=orthogonality(i);
                               end
                           case {2,3,4} %c.Lagrange
                               delta = 0.0001;
                               % Calculate the index in each node
                               for i=1:nn
                                   % Get the three normalised directions by
                                   % numeric estimation
                                    % TODO!
                                    fprintf('WARNING! computation of Orthogonality not available yet for Lagrange meshes\n');
                                    obj.Quality.OrthogonalityPerNode(ind(i))=NaN;
                               end                           
                           otherwise
                               fprintf('WARNING! Interpolation basis option not recognise in the computation of Orthogonality\n');
                       end
                       obj.Quality.OrthogonalityPerNodeInElement(iElem,1:nn)=orthogonality;
                       obj.Quality.OrthogonalityPerElement(iElem,1) = sum(orthogonality)/nn;
                   end
                   if nNan>0
                       fprintf(1,'  WARNING! NaN in a dot product in a total of %i nodes!!\n',nNan);
                   end
                   obj.Quality.Q2 = mean(obj.Quality.OrthogonalityPerElement);
                   obj.bQ2Calculated= true;
               end
           end
           
       end
       function obj         = CalculateJacobianRatio(obj)
          GaussOrder = 4;
          bDebug=0;
          obj.Quality.JacobianRatio = zeros(1,obj.nElems);
          
          switch obj.InterpolationBasis
              case 1,
                  if obj.nElems==0
                      fprintf(1,' WARNING: No elements in the mesh, not possible to calculate aspect ratio\n');
                  else
                      ne = obj.nElems;
                      GaussPoints      = obj.GetGlobalGaussPoints(1,GaussOrder);
                      nPoints = GaussOrder*GaussOrder*GaussOrder;
          % 21/11/2011: BUG DETECTED! THIS DOES INTRODUCE QUITE DIFFERENT NUMBERS!
          % GaussLocalCoords = reshape(GaussPoints.LocalCoordinates,3,nPoints);  
                      GaussLocalCoords = reshape(GaussPoints.LocalCoordinates,nPoints,3)';
                      for iElem=1:ne
                          J = obj.GetJacobianDeterminant(iElem,GaussLocalCoords);    
                          if(bDebug)
                              if numel(find(J<0))>0
                                  plot(J);
                                  title('Negative determinant of jacobian found!')
                              end
                          end
        % P.Lamata (18/01/2013): the ratio can be negative as well!
                          %if (min(J)<0)
                          %    ElementJacobianRatio = 0;
                          %    if(bDebug), fprintf('Negative jacobian in element %i\n',iElem); end
                          %else
                              ElementJacobianRatio = min(J)/max(J);
                          %end
                          obj.Quality.JacobianRatio(iElem) = ElementJacobianRatio;
                      end
                      obj.Quality.Q3 = mean(obj.Quality.JacobianRatio);
                      obj.bQ3Calculated= true;
                  end
              otherwise
                  fprintf('WARNING! Computation of Jacobian Ratio not ready available yet for this interpolation basis\n');                  
          end
       end  
       function obj         = CalculateDirecJacRatio(obj,direction)
           % The idea behind this quality index is to explore the
           % homogeneity of jacobians, not in the entire element, but
           % in a given direction, which should be where the
           % deformation is expected. In this preliminary implementation,
           % only material directions are enabled.
           %
           % INPUT:
           % - direction: 1, 2 or 3, corresponding to the 3 local material
           % directions.
           % OUTPUT: updated class
           bDebug = 0;
           GaussOrder = 5;          
           obj.Quality.DirecJacRatio = zeros(1,obj.nElems);
           switch obj.InterpolationBasis
               case 1,
                  if obj.nElems==0
                      fprintf(1,' WARNING: No elements in the mesh, not possible to calculate aspect ratio\n');
                  else
                      ne = obj.nElems;
                      GaussPoints      = obj.GetGlobalGaussPoints(1,GaussOrder);
                      %GaussPoints      = obj.GetLocalGaussCoords1D(GaussOrder);
                      % The GPs are in GaussPoints.GPxhi;

                      nPoints = GaussOrder*GaussOrder*GaussOrder;
          % 21/11/2011: BUG DETECTED! THIS DOES INTRODUCE QUITE DIFFERENT NUMBERS!
          % GaussLocalCoords = reshape(GaussPoints.LocalCoordinates,3,nPoints);  
                      GaussLocalCoords = reshape(GaussPoints.LocalCoordinates,nPoints,3)';
                      for iElem=1:ne
                          % In each element, there are GaussOrder^2 lines whe
                          J = obj.GetJacobianDeterminant(iElem,GaussLocalCoords);   
                          if(bDebug)
                              if numel(find(J<0))>0
                                  plot(J);
                                  title('Negative determinant of jacobian found!')
                              end
                          end
        % P.Lamata (18/01/2013): the ratio can be negative as well!
        %                   if min(J)<0
        %                       ElementJacobianRatio = 0;
        %                   else
                              % Now, the comparison of min to max is done in different
                              % way: in only one dimension of this JM matrix: 
                              JM = reshape(J,GaussOrder,GaussOrder,GaussOrder);
                              switch direction
                                  case 1
                                      % Do nothing
                                  case 2
                                      JM = permute(JM,[2 1 3]);
                                  case 3
                                      JM = permute(JM,[3 2 1]);
                              end
                              JMsamples = zeros(GaussOrder,GaussOrder^2);
                              for iG=1:GaussOrder
                                  samples = JM(iG,:,:);
                                  JMsamples(iG,:) = samples(:);
                              end
                              % There are GaussOrder samples of this index, one per
                              % plane in which the element is sampled:
                              JacobianRatioSamples = min(JMsamples)./max(JMsamples);
                              % And we take the most restrictive plane:
                              ElementJacobianRatio = min(JacobianRatioSamples(:));
                          end
                          obj.Quality.DirecJacRatio(iElem) = ElementJacobianRatio;
        %               end
                      obj.Quality.Q4 = mean(obj.Quality.DirecJacRatio);
                      obj.bQ4Calculated= true;
                  end
              otherwise
                  fprintf('WARNING! Computation of Directional Jacobian Ratio not ready available yet for this interpolation basis\n');                  
           end
       end
           
       function obj         = CalculateConditionNumber(obj)
           % The idea behind this quality index is to explore the
           % condition nunber of the Jacobian matrix 
           % We will put in another version with an alternate definition as
           % well
           % 
           % OUTPUT: updated class
           
           ImplementationChoice = 2;%1: 'LinearisedCoarseConditionNumber'
                                    %2: first attempt to characterise the
                                  %continuum by just sampling the central
                                  %point of each element.
           adj_nodes = zeros(1,3);
           matrix_edgelen = zeros(3,3);
           Adjmatrix_edgelen = zeros(3,3);
           switch obj.InterpolationBasis
               case 1,
                   if ImplementationChoice ==2
                      GaussOrder = 4;
                      GaussPoints      = obj.GetGlobalGaussPoints(1,GaussOrder);
                      nGPts = GaussOrder*GaussOrder*GaussOrder;
                      GaussLocalCoords = reshape(GaussPoints.LocalCoordinates,nGPts,3)';
                   end
                   if obj.nElems==0
                      fprintf(1,' WARNING: No elements in the mesh, not possible to calculate aspect ratio\n');
                   else
                      ne = obj.nElems;
                      Jac_mat = zeros(3,3);
                      %t1= tic();
                      for iElem=1:ne
                          %t2 = tic();
                          switch ImplementationChoice
                              case 1
                                [ind,nn] = obj.GetNodeIndexesOfElement(iElem);                 
                                NodalCondNum = zeros(1,nn);
                                for iN = 1:nn;
                                    iNode = ind(iN);
                                    P0 = reshape(obj.coordinates(iNode,1:3),1,3);
                                    Nodes = obj.GetTheThreeNeighbourNodes(iElem,iNode,1);
                                    if numel(unique([iNode Nodes]))<4
                                        % This is a collapsed node:
                                        NodalCondNum(iN) = 10;
                                    else
                                        for i=1:3
                                            P1 = reshape(obj.coordinates(Nodes(i),1:3),1,3);
                                            edge = P1-P0;
                                            Jac_mat(i,1:3) = edge;
                                        end
                                        NodalCondNum(iN) = frobenius_norm(Jac_mat)*frobenius_norm(inv(Jac_mat));
                                    end
                                end
                                CondNum = max(NodalCondNum);
                              case 2
                                  % PL: Ishani, don't know really what you want to do
                                  % here. If you want the Jacobian matrix, you can
                                  % directly evaluate the degrees of freedom of the
                                  % Hermite mesh, get du/dxi1, du/dxi2 and du/dxi3:
                                  GPCondNum = zeros(1,nGPts);
                                  for iGaussCoord=1:nGPts
                                      xiCoord = GaussLocalCoords(1:3,iGaussCoord);
                                      %[0.5 0.5 0.5]; % The central piont of the element!
                                      Jac_mat = obj.GetJacobianMatrix(iElem,xiCoord);
                                      GPCondNum(iGaussCoord) = frobenius_norm(Jac_mat)*frobenius_norm(inv(Jac_mat));
                                  end
                                  CondNum = max(GPCondNum);
                          end
                          %fprintf('Element processed, %i out of %i\n',iElem,obj.nElems);
                          %toc(t2);
                          obj.Quality.ConditionNumber(iElem,1) = CondNum;
                          %For the central node in the element
                          %adj_nodes = GetTheThreeNeighbourNodes(obj,i,j,0);
                          %coords = obj.coordinates(adj_nodes,:);
                          %matrix_edgelen = [coords(1)-nn(1);coords(2)-nn(2);coords(2)-nn(2)];
                          %Jac_mat = det(matrix_edgelen);   %The Jacobian, the first new index 
                          %Adjmatrix_edgelen = norm(Jac_mat*inv(matrix_edgelen),'fro')
                      end
                      %fprintf('Calculation of condition number finished!\n');
                      %toc(t1)
                          % Print out distances
                          %norm(matrix_edgelen,'fro')*Adjmatrix_edgelen/abs(Jac_mat
                          %); %The cond num, 2nd new index
                      obj.Quality.Q5 = mean(obj.Quality.ConditionNumber);
                      obj.bQ5Calculated= true;
                   end                   
               otherwise
                  fprintf('WARNING! Computation of Condition Number not ready available yet for this interpolation basis\n');                  
           end 
           
       end 
       function [Q,nQ,dQ,mindQ,iEmindQ,QperE] = CalculateQ1indexes(obj,CHtemplate,bReportInCommandLine)
           parameters.bReportInCommandLine = bReportInCommandLine;
           [Q,nN,nQ,dQ,mindQ,iEmindQ,QperE] = CalculateQindexes(obj,CHtemplate,1,parameters);
       end
       function [Q,nQ,dQ,mindQ,iEmindQ,QperE] = CalculateQ2indexes(obj,CHtemplate,bReportInCommandLine)
           parameters.bReportInCommandLine = bReportInCommandLine;
           [Q,nN,nQ,dQ,mindQ,iEmindQ,QperE] = CalculateQindexes(obj,CHtemplate,2,parameters);
       end
       function [Q3,nN,nQ,dJ,mindJ,iEmindJ,QperE]          = CalculateQ3indexes(obj,CHtemplate,bReportInCommandLine,bPlotQ3)
           parameters.bReportInCommandLine = bReportInCommandLine;
           % Function to analyse the Jacobian ratio:
           % - Report elements with negatie jacobian
           % - compare the Jacobian ratio to that of a template
           % mesh (CHtemplate)
           if nargin<4
               bPlotQ3=0;
           end
           [Q3,nN,nQ,dJ,mindJ,iEmindJ,QperE] = CalculateQindexes(obj,CHtemplate,3,parameters);           
           if(bPlotQ3)
                figure('Color',[1 1 1]); hold on;
                obj.plotMeshQ3();
                view(60,30);
                title(sprintf('Ratio of jacobians of mesh %s',obj.name));
           end           
       end  
       function [Q,nN,nQ,dJ,mindJ,iEmindJ,QperE]           = CalculateQ4indexes(obj,CHtemplate,direction,bReportInCommandLine)
           parameters.bReportInCommandLine = bReportInCommandLine;
           parameters.direction = direction;
           [Q,nN,nQ,dJ,mindJ,iEmindJ,QperE] = CalculateQindexes(obj,CHtemplate,4,parameters);                     
       end  
       function [Q,nN,nQ,dJ,mindJ,iEmindJ,QperE]           = CalculateQ5indexes(obj,CHtemplate,bReportInCommandLine)
           parameters.bReportInCommandLine = bReportInCommandLine;
           [Q,nN,nQ,dJ,mindJ,iEmindJ,QperE] = CalculateQindexes(obj,CHtemplate,5,parameters);                     
       end       
       function [Q,nN,nQ,dQ,mindQ,iEmindQ,QperE] = CalculateQindexes(obj,CHtemplate,WhichQuality,parameters)
           % OUTPUT:
           % - Q: average quality in the mesh 
           % - nN: number of elements with negative Q
           % - nQ: number of elements with a drop of Q compared to a
           % template greater than 0.5
           % - dQ: average degradation = average quality / average quality of template
           % - mindQ: minimum quality (maximum degradation)
           % - iEmindQ: element with maximum degradation (only one
           % returned)
           if isfield(parameters,'bReportInCommandLine')
               bReportInCommandLine = parameters.bReportInCommandLine;
           else
               bReportInCommandLine = 0;
           end
           if isfield(parameters,'direction')
               direction = parameters.direction;
           else
               direction = 3;
           end
           
           bMin = 1;
           switch WhichQuality
               case 1
                   if ~CHtemplate.bQ1Calculated
                       CHtemplate = CHtemplate.CalculateAspectRatio();
                   end
                   if ~obj.bQ1Calculated
                       obj = obj.CalculateAspectRatio();
                   end
                   ratio=(obj.Quality.AspectRatio./CHtemplate.Quality.AspectRatio);
                   Q = obj.Quality.Q1;
                   nNeg = numel(find(obj.Quality.AspectRatio<0));
               case 2
                   if ~CHtemplate.bQ2Calculated
                       CHtemplate = CHtemplate.CalculateOrthogonality();
                   end
                   if ~obj.bQ2Calculated
                       obj = obj.CalculateOrthogonality();
                   end
                   ratio=(obj.Quality.OrthogonalityPerElement./CHtemplate.Quality.OrthogonalityPerElement);
                   Q = obj.Quality.Q2;
                   nNeg = numel(find(obj.Quality.OrthogonalityPerElement<0));                   
               case 3
                   if ~CHtemplate.bQ3Calculated
                       CHtemplate = CHtemplate.CalculateJacobianRatio();
                   end
                   if ~obj.bQ3Calculated
                       obj = obj.CalculateJacobianRatio();
                   end
                   nNeg = numel(find(obj.Quality.JacobianRatio<0));
                   ratio=(obj.Quality.JacobianRatio./CHtemplate.Quality.JacobianRatio);           
                   Q = obj.Quality.Q3;                  
               case 4
                   if ~CHtemplate.bQ4Calculated
                       CHtemplate = CHtemplate.CalculateDirecJacRatio(direction);
                   end
                   if ~obj.bQ4Calculated
                       obj = obj.CalculateDirecJacRatio(direction);
                   end
                   nNeg = numel(find(obj.Quality.DirecJacRatio<0));
                   ratio=(obj.Quality.DirecJacRatio./CHtemplate.Quality.DirecJacRatio);           
                   Q = obj.Quality.Q4;
               case 5
                   bMin = 0;
                   if ~CHtemplate.bQ5Calculated
                       CHtemplate = CHtemplate.CalculateConditionNumber();
                   end
                   if ~obj.bQ5Calculated
                       obj = obj.CalculateConditionNumber();
                   end
                   nNeg = numel(find(obj.Quality.ConditionNumber<0));
                   ratio=(obj.Quality.ConditionNumber./CHtemplate.Quality.ConditionNumber);           
                   Q = obj.Quality.Q5;
           end
           nN = nNeg;
           nQualityDropGreater05  = numel(find(ratio<0.5));                     
           nQ = nQualityDropGreater05;
           dQ = mean(ratio);
           if(bMin)
               mindQ = min(ratio);
           else
               %In Q5, the worst case is the maximum:
               mindQ = max(ratio);
           end
           iEmindQ = find(ratio==mindQ);
           QperE = ratio;
           if numel(iEmindQ)>1
               fprintf('WARNING! There were more than one element with mindQ%i, only the first returned\n',WhichQuality)
               temp = iEmindQ;
               clear iEmindQ;
               iEmindQ = temp(1);
           end
           if numel(iEmindQ)==0
               iEmindQ = NaN;
           end
           if(bReportInCommandLine)
               fprintf('----- Q%i analysis of mesh %s -----\n',WhichQuality,obj.name);
               fprintf('   Average Q%i  = %1.3f\n',WhichQuality,Q);
               fprintf('   Elements negative Q%i  = %i\n',WhichQuality,nN);
               fprintf('   Average Q%iratio  = %1.3f\n',WhichQuality,dQ);
               fprintf('   Min Q%iratio  = %1.3f, in element %i\n',WhichQuality,mindQ,iEmindQ);
               fprintf('   Elements Q%iratio<0.5 = %i\n',WhichQuality,nQ);
           end
       end
       
% Sizing and distance functions
       function obj         = BuildTetrahedralCanvas(obj)
           ne = obj.nElems;
           version = 1; % The second versions should be the same!
           for iElem=1:ne
               [ind,nn] = obj.GetNodeIndexesOfElement(iElem);
               points = obj.coordinates(ind,:,version);
               x=points(:,1);
               y=points(:,2);
               z=points(:,3);
               dt = DelaunayTri(x,y,z);
               Tes = dt(:,:);
               [s1 s2] = size(Tes);
               obj.TetrahedralCanvas.nDel(iElem) = s1; % Number of tetrahedra produced in DelanuyTri
               obj.TetrahedralCanvas.nNod(iElem) = nn; % Number of nodes in the element
               obj.TetrahedralCanvas.Tes(iElem,1:s1,:) = Tes;
               obj.TetrahedralCanvas.X(iElem,1:nn,:) = [x(:) y(:) z(:)];
           end
           obj.bTetrahedralCanvasBuilt=true;
       end
       function obj         = BuildWireframe(obj)
           ne = obj.nElems;
           bError = 0;
           for iElem=1:ne
               if(~bError)
                   [ind,nn] = obj.GetNodeIndexesOfElement(iElem);               
                   points = obj.coordinates(ind,:);  
                   switch nn
                       case 8, Order = obj.OrderVisit8Nodes;
                       case 6, Order = obj.OrderVisit6Nodes;
                       case 4, Order = obj.OrderVisit4Nodes;
                       case 27, %q.Lagrange:
                           Order = obj.OrderVisit27Nodes;
                       case 64, %c.Lagrange:
                           Order = obj.OrderVisit64NodesEX;
                           switch obj.FormatOrder
                               case 'EXformat'
                                   % do nothing more 
                               case 'CHeart'
                                   Order = obj.OrderVisit64NodesCHeart;
                               otherwise
                                   fprintf('WARNING! FormatOrder not defined in CubicClass - construction of Wireframe likely to be bugged\n');
                           end
                       case 3, Order = 1:3; % trivial case of a triangle
                       otherwise, 
                           fprintf('  ERROR: element with %i number of nodes not implemented in CubicMeshClass.BuildWireframe\n',nn);
                           Order = [];
                           bError = 1;
                   end
                   for iVisitNode = 1:length(Order)
                       obj.Wireframe.Point(iElem,iVisitNode,1:3)=points(Order(iVisitNode),1:3);
                   end
               end
           end
           if(~bError)
               obj.bWireframeBuilt = true;
           end
       end
       function obj         = BuildBoundingBox(obj,margin)
           % Updated version (03/11/2010): only first versions are taken
           % into account!
           Option = 2;
           if nargin<2
               % A default value of a margin around each direction and 
               % dimension of the BB, expressed as a percentage of the
               % maximum side
               margin=obj.DefaultBBmargin;
           end
           if obj.nNodes>0
               switch Option
                   case 1 % Old DEPRECATED OPTION
                       % Initialize the BB with the coordinates of the first node:
                       obj.BB(1) = obj.coordinates(1,1,1);
                       obj.BB(2) = obj.coordinates(1,1,1);
                       obj.BB(3) = obj.coordinates(1,2,1);
                       obj.BB(4) = obj.coordinates(1,2,1);
                       obj.BB(5) = obj.coordinates(1,3,1);
                       obj.BB(6) = obj.coordinates(1,3,1);
                       for iMatNode=1:obj.nNodes
                           v(1:3) = obj.versions(iMatNode,:);
                           for j=1:3
                               for k=1:v(j)                       
                                   c=obj.coordinates(iMatNode,j,k);
                                   if c<obj.BB(2*(j-1) +1)
                                       obj.BB(2*(j-1) +1)=c;
                                   end
                                   if c>obj.BB(2*(j-1) +2)
                                       obj.BB(2*(j-1) +2)=c;
                                   end
                               end
                           end
                       end                   
                   case 2
                       obj.BB(1) = min(obj.coordinates(:,1,1));
                       obj.BB(2) = max(obj.coordinates(:,1,1));
                       obj.BB(3) = min(obj.coordinates(:,2,1));
                       obj.BB(4) = max(obj.coordinates(:,2,1));
                       obj.BB(5) = min(obj.coordinates(:,3,1));
                       obj.BB(6) = max(obj.coordinates(:,3,1));
               end
           end
           maxside = max([obj.BB(2)-obj.BB(1),obj.BB(4)-obj.BB(3),obj.BB(6)-obj.BB(5)]);
           margin = maxside*margin/100;
           obj.BB(1:6)=obj.BB(1:6)+[-margin margin -margin margin -margin margin];
           obj.BB(7)  =margin;
       end
       function obj         = BuildElementBoundingBoxes(obj)
           obj.eBB = zeros(2,3,obj.nElems);
            for i=1:obj.nElems
                [points, xiC] = obj.ReconstructSurface(i,0,10);
                obj.eBB(:,:,i) = [min(points'); max(points')]; %2 by 3
            end
            obj.beBBbuilt=1;
       end

       function [ElemsIndex,obj] = FindClosestElements(obj,Point,RelativeCloseDefinitionInPercentage)
           % Get the closest element centre to the point, and then get all
           % other elements whose centres are also "relatively" close. The
           % definition of "relatively" close is an increase of distance in
           % a given percentage (parameter defined here)
           % 
           % ATENTION! a obj = obj.PreCalculateCentres() is adviced to
           % speed up if this function is to be called several times!!
           bDebug=0;
           if nargin<3
               RelativeCloseDefinitionInPercentage = 200;
           end
           if (~obj.bCentreElementsCalculated)
               obj = obj.PreCalculateCentres();
           end
           if obj.nElems==0
               fprintf(1,'ERROR, the class has no elements initialised! (likely problem in the reading of the mesh)\n');
           else
               ElementCentre = obj.ElemCentre';
               Distances = NaN * ones(1,obj.nElems);
               if(bDebug),fprintf(1,' DEBUGGING: CubicMeshClass:FindClosestElements - Measuring distance to the centre of %i elements',obj.nElems); end
               if numel(ElementCentre)>9
                   Distances = sum( (ElementCentre-repmat(Point',1,length(ElementCentre))).^2 , 1);
               else 
                   [a,b] = size(Point); if a>b, Point = Point'; end
                   for iElem=1:obj.nElems
                       if obj.nElems==1
                           centre = ElementCentre;
                       else
                           centre = ElementCentre(iElem,1:3);
                       end
                       [a,b] = size(centre); if a>b, centre = centre'; end
                       Distances(iElem) = sum((centre - Point).^2);
                   end
               end

               %iClosestElem = find(Distances==min(Distances));
               ElemsIndex = find(Distances < min(Distances)*(1+RelativeCloseDefinitionInPercentage/100));           
           end
       end
       function [ListFaces,FacesIndex] = FindClosetFaces(obj,Point,Elements,RelativeCloseDefinitionInPercentage)
           bDebug = 0;
           ListFaces=[0 0]; nF=0;
           for iE=1:length(Elements)
               iElem = Elements(iE);
               for iF=1:6
                   if obj.ExternalFaces(iElem,iF)
                       nF=nF+1;
                       ListFaces(nF,1) = iElem;
                       ListFaces(nF,2) = iF;
                       CentreFace = obj.ReconstructSurface(iElem,iF,1); %centre of the face
                       Distances(nF) = obj.DistanceBetweenTwoPoints(Point,CentreFace);
                       if(bDebug), fprintf('   ... Calculate centre of face %i of element %i: (%1.1f,%1.1f,%1.1f)\n',iF,iElem,CentreFace); end
                   end
               end
           end
           iClosestFaceCandidates = find(Distances==min(Distances));
           iClosestFace = iClosestFaceCandidates(1);
           DistThreshold = min(Distances)*(1+RelativeCloseDefinitionInPercentage/100);
           iCloseFaces = find(Distances <= DistThreshold);
           FacesIndex = iCloseFaces; % This already includes the closest one
           if(bDebug), fprintf('A close face is in element %i, face %i, at a distance of %1.1f.\n',ListFaces(iClosestFace,1),ListFaces(iClosestFace,2),min(Distances));
               fprintf('Other %i faces included in the search. Threshold Distance = %1.1f.\n',length(iCloseFaces)-1,DistThreshold); end
       end
       function [obj]       = PreCalculateCentres(obj)
           ElementCentre = zeros(3,obj.nElems);
           for iElem=1:obj.nElems
               % Calculate element centre:
               XiCentre = [0.5,0.5,0.5];
               ElementCentre(1:3,iElem) = obj.evaluate(iElem,XiCentre);
           end
           obj.ElemCentre = ElementCentre';
           obj.bCentreElementsCalculated = 1;
       end
       function [dist CP xiCoordsCP]   = AproxDistancePointToSurface(obj,Point,iElem,iFace,Discretization)
           % Find the xi coordinates of the closest point
       % 1. Find the point in a given discretization of the surface:
            bDebug=0;
            if nargin<5
                Discretization = 5;
            end
            % Get the list of candidate points:
            [CanPts,xiCoords] = obj.ReconstructSurface(iElem,iFace,Discretization);
            [a,b]=size(CanPts);
            if a==3
                CanPts=CanPts';
                xiCoords=xiCoords';
            end
%            CanPts = reshape(CanPts,Discretization^2,3);
            %Distances = sqrt( (CanPts(:,1) - Point(1)).^2 + (CanPts(:,2) - Point(2)).^2 + (CanPts(:,3) - Point(3)).^2);
            % sqrt removed for speed-up reasons:
            Distances = ( (CanPts(:,1) - Point(1)).^2 + (CanPts(:,2) - Point(2)).^2 + (CanPts(:,3) - Point(3)).^2);
            dist       = (min(Distances));
            I          = Distances==dist;
            % It might be that we have several points, we just take the first one:
            CPs         = CanPts(I,:);
            xiCoordsCPs = xiCoords(I,:);
            CP = CPs(1,:);
            xiCoordsCP = xiCoordsCPs(1,:);
            if (bDebug), 
                fprintf('The approximate closest point to P=(%1.2f,%1.2f,%1.2f)',Point);
                fprintf(' in surface %i of element %i, is (%1.1f,%1.1f,%1.1f), at a distance of %1.1f.\n',iFace,iElem,CP,sqrt(dist)); 
            end
       end
       function [dist CP iElemCP xiCP] = CalculateDistancePoint2Mesh(obj,Point)
           % ATENTION! a obj = obj.PreCalculateCentres() is adviced to
           % speed up if this function is to be called several times!!
           bDebug = 0;
           bDebugTiming=0;
           if (~obj.bExternalFacesFound)
               obj = obj.FindExternalSurfaces();
               fprintf('  ... ADVICE: call FindExternalSurfaces before to save computational time in multiple calls to GetMeshSurface() and similar\n');               
           end
           
           if(bDebug),
               fprintf(' === BEGINNING (FIND CLOSEST POINT to (%1.1f,%1.1f,%1.1f) ===\n',Point);
           end
if (bDebugTiming), t1=tic; end    
       %---------------------------------------------
       %1. Calculate which are the closest elements:
       %---------------------------------------------
           RelativeCloseDefinitionInPercentage = 150;
           Elements = obj.FindClosestElements(Point,RelativeCloseDefinitionInPercentage);
           nE = length(Elements);
           if(bDebug), fprintf('Closest element is %i. Other %i added in the search\n',Elements(1),nE-1); end
           
       %---------------------------------------------
       %2. Calculate which are the closest faces:
       %---------------------------------------------
           [ListFaces,FacesIndex] = obj.FindClosetFaces(Point,Elements,RelativeCloseDefinitionInPercentage);
           
       %---------------------------------------------
       %3. Calculate distance between point and CubicHermite surfaces:
       % minimise face candidates (TODO: clean this code, it's quite the
       % same as the point 2)
       %---------------------------------------------
           d = zeros(1,length(FacesIndex));
           closestPoint =  zeros(length(FacesIndex),3);
           XiCoordsCP =  zeros(length(FacesIndex),2);
           Discret1 = 11;
           for iF=1:length(FacesIndex)
               iFaceCandidate = FacesIndex(iF);
               iElem = ListFaces(iFaceCandidate,1);
               iFace = ListFaces(iFaceCandidate,2);
               if(bDebug), fprintf('iElem %i, face %i: ',iElem,iFace); end
               [d(iF) closestPoint(iF,:) XiCoordsCP(iF,:)] = obj.AproxDistancePointToSurface(Point,iElem,iFace,Discret1);
               if(bDebug), fprintf('CP=(%1.1f,%1.1f,%1.1f) , at dist=%1.1f\n',closestPoint(iF,:),d(iF)); end
           end
           % Current best solution:
           I    = d==min(d);
           dist = min(d);
           CP   = closestPoint(I,:);
           xiCP = XiCoordsCP(I,:);
           % For this choice, we want preferrably one only candidate! We
           % therefore decrease the definition of "relatively close". We
           % are save enough after taking "Discret1" samples in each xi
           % direction. 
           RelativeCloseDefinitionInPercentage = 1;
           iCandidateFaces = find( d <= min(dist)*(1+RelativeCloseDefinitionInPercentage/100));

    if (bDebugTiming), 
    time1=toc(t1);
    t2=tic; end           

       %---------------------------------------------
       % 4. Calculate the closest point at a high resolution in the
       % selected face candidates:
       %---------------------------------------------
           dis   = zeros(1,length(iCandidateFaces));
           CPc   = zeros(length(iCandidateFaces),3);
           xiCPc = zeros(length(iCandidateFaces),2);
           for iCPperFace=1:length(iCandidateFaces)
               iF = iCandidateFaces(iCPperFace);
               iFaceCandidate = FacesIndex(iF);
               iElem = ListFaces(iFaceCandidate,1);
               iFace = ListFaces(iFaceCandidate,2);
               [trash CP xiCP] = obj.AproxDistancePointToSurface(Point,iElem,iFace,Discret1);
               if(bDebug), fprintf('Closest face is in element %i, face %i, at a distance of %1.1f. \n Other %i faces included in the search. \n',iElem,iFace,dist,length(iCandidateFaces)-1); end
           
               Option = 'SteppestDescent';
               switch Option
                   case 'SteppestDescent'
                       if(bDebug), fprintf(' ... Optimisation by Steppest Descent\n'); end
                       [d,C,xi] = obj.OptimiseDistancePoint2Face(Point,iElem,iFace,CP,xiCP);
                       dis(iCPperFace) = d;
                       CPc(iCPperFace,:) = C;
                       xiCPc(iCPperFace,:) = xi;

                   case 'BruteForceComparingNpoints'
                       if(bDebug), fprintf(' ... Optimisation by Brute force\n'); end
                       d = NaN(1,length(FacesIndex));
                       closestPoint =  zeros(length(FacesIndex),3);
                       Discret1 = 100;
                       for iF2=1:length(iCandidateFaces)
                           iF = iCandidateFaces(iF2);
                           iFaceCandidate = FacesIndex(iF);
                           iElem = ListFaces(iFaceCandidate,1);
                           iFace = ListFaces(iFaceCandidate,2);
                           [d(iF) closestPoint(iF,:)] = obj.AproxDistancePointToSurface(Point,iElem,iFace,Discret1);
                           if(bDebug), fprintf('iElem %i, face %i: CP=(%1.1f,%1.1f,%1.1f) , at dist=%1.1f\n',iElem,iFace,closestPoint(iF,:),d(iF)); end
                       end
                       I = d==min(d);
                       dis(iCPperFace) = min(d);
                       CPc(iCPperFace,:) = closestPoint(I,:);
               end
           end
           I = find(dis==min(dis));
           if (bDebug)
           if numel(I)>1
               fprintf(' Warning, two faces had the same closest point!\n');
           end
           end
           dist = dis(I(1));
           CP   = CPc(I(1),:);
           xiCP2D = xiCPc(I(1),:);
               iF = iCandidateFaces(I(1));
               iFaceCandidate = FacesIndex(iF);
           iFace = ListFaces(iFaceCandidate,2);
           iElemCP = ListFaces(iFaceCandidate,1);
           % - iFace: which surface:
           %        5: xhi1=0
           %        6: xhi1=1
           %        3: xhi2=0
           %        4: xhi2=1
           %        1: xhi3=0
           %        2: xhi3=1

           switch iFace
               case 1, xiCP = [xiCP2D 0];
               case 2, xiCP = [xiCP2D 1];
               case 3, xiCP = [xiCP2D(1) 0 xiCP2D(2)];
               case 4, xiCP = [xiCP2D(1) 1 xiCP2D(2)];
               case 5, xiCP = [0 xiCP2D];
               case 6, xiCP = [1 xiCP2D];
           end
           if(bDebug),
               fprintf(' === END (FIND CLOSEST POINT to (%1.1f,%1.1f,%1.1f) ===\n',Point);
               fprintf(' Solution: iElem %i, face %i: CP=(%1.1f,%1.1f,%1.1f) , at dist=%1.1f\n\n',iElem,iFace,CP,dist); 
           end
if (bDebugTiming), 
    time2=toc(t2);
    if time1<1000 && time2<1000
        fprintf('************ Timing: %1.2f(%2.0f%%) pre-search, and %1.2f(%2.0f%%) final optimisation ************ \n',time1,100*time1/(time1+time2),time2,100*time2/(time1+time2));
    else
        if time1<1000
            fprintf('************ PARTIAL Timing: %1.2f pre-search \n',time1);
        else
            if time2<1000
                fprintf('************ PARTIAL Timing: %1.2f final optimisation \n',time2);
            end
        end
    end
end
            
       end         
       function [points]    = GenerateListSurfacePoints(obj,file,GaussOrder,bWriteFile)
           % Function to generate the list of 3D coordinates of the surface 
           % gauss points of the external surfaces, and to store them in a
           % file. This is done for the calculi of the distances to the
           % closest point later with cmiss. (example in
           % http://cmiss.bioeng.auckland.ac.nz/development/examples/2/21/21g/index.html)
           % The format of the data file (3D points) is given like:
           %  data information 
           %   1   -1.010800e+01   -4.990500e+00   -3.321200e+01  1.0  1.0  1.0 
           %   2   ...
           bDebug=0;
           bGraphicalDebug=0;
           if nargin<3
               % This is the default order used for the calculi of surface
               % errors:
               GaussOrder = 5;
           end
           if nargin<4
               bWriteFile = 1;
           end
           if (~obj.bExternalFacesFound)
               obj = obj.FindExternalSurfaces();              
           end           
           points = zeros(obj.nExternalFaces * GaussOrder^2,3);
           iES = 0;
           nPs = GaussOrder^2;
           for iElem=1:obj.nElems
               for iFace=1:6
                   if obj.ExternalFaces(iElem,iFace)
                       iES = iES + 1;
                       GPs   = obj.GetSurfaceGaussPoints(iElem,iFace,GaussOrder);
                       points( (iES-1) * nPs +1 : iES*nPs,1:3) = GPs.GlobalCoordinates';
                   end
               end
           end 
           % Now, write the file:
           if(bWriteFile)
               fid = fopen(file,'w');
               fprintf(fid,' data information\n');
               if (bDebug), fprintf(1,' Writting %i points of %i external surfaces\n',nPs,obj.nExternalFaces); end;
               for iES=1:obj.nExternalFaces
                   for iP=1:nPs
                       index = (iES-1) * nPs + iP;
                       fprintf(fid,' %i  %1.10d %1.10d %1.10d   1.0 1.0 1.0\n',index,points(index,1:3));
                   end
               end
               fclose(fid);
           end
           if (bGraphicalDebug)
               figure('Color',[1 1 1]); hold on;
               obj.plotWireframe();
               for iES=1:obj.nExternalFaces
                   for iP=1:nPs
                        index = (iES-1) * nPs + iP;
                        P = points(index,1:3);
                        plot3(P(1),P(2),P(3),'*');
                   end
               end
           end
       end
       function [V,F]       = TesselateExternalSurfaces(obj,discretisation,options)
           % Function used in ex2vtk.m for a conversion to VTK
           if nargin<2
               discretisation = 5;
           end
           bEpi = 0;
           bEndo = 0;
           iElems = 1:obj.nElems;
           if nargin ==3
               if isfield(options,'bEpi'), bEpi = options.bEpi; end
               if isfield(options,'bEndo'), bEndo = options.bEndo; end
               if isfield(options,'iElems'), iElems = options.iElems; end
           end
           if (~obj.bExternalFacesFound)
               obj = obj.FindExternalSurfaces();
           end
           nNodsPerSurf =discretisation^2;
           iFaces2Include = 1:6;
           if bEndo, iFaces2Include = 1;  end % xhi3=0
           if bEpi,  iFaces2Include = 2;  end % xhi3=1 
           nFacesPerSurf =((discretisation-1)^2)*2;
           if(~bEndo) && (~bEpi)
               nNodsTotal = obj.nExternalFaces * nNodsPerSurf;               
               nFacesTotal = obj.nExternalFaces * nFacesPerSurf;
               V = zeros(nNodsTotal,3);
               F = zeros(nFacesTotal,3);
           else
               V = [];
               F = [];
           end
           iExtSurface = 0;          
           for iElem=iElems
               for iFace = iFaces2Include
                   if obj.ExternalFaces(iElem,iFace)
                       iExtSurface = iExtSurface + 1;
                       if isempty(F), nodeOffset = 0;
                       else           nodeOffset = max(F(:)); end
                       [Fnew,Vnew] = obj.tesselateElementFace(iElem,iFace,discretisation);
                       n0 = 1 + (iExtSurface-1)*nNodsPerSurf;
                       n1 = iExtSurface*nNodsPerSurf;
                       V(n0:n1,:) = Vnew;
                       Fnew = Fnew + nodeOffset;
                       f0 = 1 + (iExtSurface-1)*nFacesPerSurf;
                       f1 =iExtSurface*nFacesPerSurf;
                       F(f0:f1,:) = Fnew;
                   end
               end
           end           
           
       end
       function [F,V]       = tesselateElementFace(obj,iElem,iFace,discretisation)
           if nargin<4
               discretisation = 5;
           end
           [points]   = obj.ReconstructSurface(iElem,iFace,discretisation);
           points     = points';
           iF = 0;
           F = zeros(2*((discretisation-1)^2),3);
           for i=1:discretisation-1
               I=(i-1)*discretisation;
               indexes = 1+I:discretisation+I;
               for j=1:discretisation-1     
                   %indexes2= i:discretisation:discretisation^2;
                   indexes2= indexes + discretisation;
                   iF = iF + 1;
                   F(iF,1) = indexes(j);
                   F(iF,3) = indexes2(j);
                   F(iF,2) = indexes2(j+1);
                   iF = iF + 1;
                   F(iF,1) = indexes(j);
                   F(iF,3) = indexes2(j+1);
                   F(iF,2) = indexes(j+1);
               end                   
           end
           V = points;
       end
       function [ERROR,STD,MAXERROR,err]  = CalculateMeshFittingError(obj,SurfacePoints,options)
           % Function to calculate the distance between meshes, as the
           % average distance from a set of SurfacePoints to their closest
           % point in the CubicHermite mesh. 
           % 
           % Version control:
           % - 19/04/12: cmGui possibility implemented from this example:
           % http://cmiss.bioeng.auckland.ac.nz/development/examples/a/optimisation/smooth_volume_fitting/index.html
           bDebug=0;
           fprintf('Calculating Fitting Error to mesh %s ...\n',obj.name);
           nP = numel(SurfacePoints)/3;
           SubsampleFactor = 1;
           bWriteErrorFile = 0;
           obj.TempcmGuiDir = obj.ReplaceSlash(obj.TempcmGuiDir);
           if ~exist(obj.TempcmGuiDir), mkdir(obj.TempcmGuiDir); end
           Dir = obj.TempcmGuiDir;
           CodeOption = 'cmGui';
           if nargin==3
               if isfield(options,'SubsampleFactor')
                   SubsampleFactor = options.SubsampleFactor;
               end
               if isfield(options,'bWriteErrorFile')
                   bWriteErrorFile = options.bWriteErrorFile;
               end
               if isfield(options,'DirectoryErrorFile')
                   Dir = options.DirectoryErrorFile;
                   bWriteErrorFile=1;
               end
               if isfield(options,'CodeOption')
                   CodeOption = options.CodeOption;
               end
           end
           nPoints = floor(nP*SubsampleFactor);
           % Calculate the distance from each point to the mesh:
           err    = zeros(1,nPoints);
           Errors = zeros(nPoints,3);
           CPs    = zeros(nPoints,3);

           SurfacePoints = reshape(SurfacePoints,nP,3);
           % Aleatorize and subsample the set of points:
           order  = randperm(nP);
           SurfacePoints = SurfacePoints(order,1:3);
           temp = SurfacePoints; clear SurfacePoints;
           SurfacePoints = temp(1:nPoints,1:3); clear temp;
           fprintf('  Number of samples for error calculation: %i ...\n',nPoints);
           
           if strcmp(CodeOption,'cmGui')               
               fprintf('Use of cmGui to measure distances to closest point in mesh\n');
               NameExPoints = 'Points';
               NameErrorField = 'Distance';
               A = clock;
               NameErrorFile  = ['Distances2ClosestPoint' obj.name sprintf('%i',int8(A))];
               options.GroupName = NameExPoints;
               options.Field1Name = 'data_coordinates';
               options.ScalarField = err;
               options.ScalarFieldName = NameErrorField;
               
               %SurfacePoints2(1,:) = [0 0 0]';
               %SurfacePoints2(2,:) = [50 50 50]';
               WriteExnode(fullfile(Dir, [ NameExPoints '.exnode']),SurfacePoints,options);
               NameMesh = 'Mesh';
               obj.name = NameMesh;
               obj.GroupName = NameMesh;
               obj.WriteExFiles(Dir);
               
                command = [];
                command{end+1}={sprintf('${PointsEXdata}="%s"',obj.ReplaceSlash(NameExPoints))};
                command{end+1}={'gfx r n "${dirEx}/${PointsEXdata}.exnode" node_offset 1000'};
                % removed 13/08/14 (duplicated): command{end+1}={'gfx r n "${dirEx}/${PointsEXdata}.exnode" node_offset 1000'};
               % create a group containing the outside faces for finding data point projections on
                command{end+1}={'gfx create egroup outside;'};
               % TODO: A WAY TO AUTOMATICALLY SELECT THE EXTERNAL SURFACES!!gfx sel faces group Mesh
                command{end+1}={'gfx modify egroup outside add faces all;'};
               % create a field which dynamically finds the nearest location to the scaled_data_coordinates on the 1-D mesh 
               command{end+1}={'gfx define field found_location find_mesh_location find_nearest mesh outside.cmiss_mesh_2d mesh_field coordinates source_field data_coordinates;'};
               
               % define a field giving the coordinates at the stored_location on the mesh:
               command{end+1}={'gfx define field projected_coordinates embedded element_xi found_location field coordinates;'};
               % define a field which calculates the error vector between the data point and its element project:
               command{end+1}={'gfx define field error_vector add fields projected_coordinates data_coordinates scale_factors 1 -1;'};
               % get the magnitude for visualisation
               command{end+1}={'gfx define field error magnitude field error_vector;'};
               % visualise error bars on the boxpoints:
               command{end+1}={'gfx create spectrum Distance linear range 0 5 extend_above rainbow reverse'};
               command{end+1}={sprintf('gfx mod g_e %s node_points coordinate data_coordinates LOCAL glyph line general size "0*0.1*0.1" centre 0,0,0 font default orientation error_vector scale_factors "1*0*0" select_on material green data error spectrum Distance;\n',NameExPoints)};               
               command{end+1}={sprintf('gfx mod g_e %s node_points coordinate data_coordinates LOCAL glyph sphere general size "0.8*0.8*0.8" centre 0,0,0 font default data error spectrum Distance;\n',NameExPoints)};

               command{end+1}={sprintf('gfx eval ngroup %s source error destination %s',NameExPoints,NameErrorField)};
               command{end+1}={sprintf('gfx write node group %s "${dirEx}/%s.exnode"',NameExPoints,NameErrorFile)};
               
                com = cells_sum(command);
                commands='# Commands to compute and view fitting error vectors';
                commands(end+1:end+2) = sprintf('\n');
                for i=1:length(command)
                    commands(end+1:end+length(com{i})+1)= sprintf('%s\n', com{i});
                end
               
               optionsView.ExtraCMGUIcommands = commands;
               % ONLY CMGUI 2.9 MAKES A CORRECT COMPUTATION OF DISTANCES!!
               optionsView.cmGuiVersion = '2.9';
               optionsView.bOrthographic = 1;
               optionsView.bPrintCaption = 1;
               optionsView.CaptionName = NameErrorFile;
               optionsView.bAutomaticExit = 1;
               optionsView.HeartVisualizationStyle = 'Semitransparent';
               optionsView.iTransparency = 2;
               optionsView.CommandFileName = 'CalculateFittingAccuracy';
               optionsView.bRemakeComfile2LoadFromSameDir = 1;
               
               if(exist([Dir NameErrorFile '.exnode'],'file'))
                   delete([Dir NameErrorFile '.exnode']);
               end
               cmGuiViewMesh(Dir,obj,optionsView);
               
               % NEED TO WAIT UNTIL NODES ARE WRITTEN!!
               iWait = 0;
               tcmgui = tic();
               while ~exist(fullfile(Dir,[ NameErrorFile '.exnode']),'file')
                   if rem(iWait,100) == 0
                        fprintf('Waiting to cmGui to finish the computation of fitting residual... %1.0f seconts of wait already\n',toc(tcmgui));
                   end
                   pause(2);
                   iWait = iWait + 1;
                   if iWait==1000
                       fprintf('ERROR! Too long wait for cmGui to produce the error metric!\n;');
                       ERROR = NaN; STD = NaN; MAXERROR = NaN; err = NaN;
                       return;
                   end
               end
               % It still crashes, maybe needs some further time to finish
               % writting:
               pause(1);
               fprintf('Fitting residual calculated: it took %1.0f seconts !\n;',toc(tcmgui));
               exData = ReadExNode(fullfile(Dir , [NameErrorFile '.exnode']));
               for iField = 1:exData.ListOfFields.nFields
                   FieldName = exData.ListOfFields.field(iField).Name;
                   if strcmp(FieldName,NameErrorField);
                       % Retrieve the distance error values:
                       err = cell2mat({exData.FieldValues(iField,:).values});
                   end
               end
               
           else
               fprintf('Use of matlab to measure distances to closest point in mesh (slow)\n');
               if(~obj.bExternalFacesFound)
                   fprintf('  Speed-up suggestion (if repeated calls to CalculateMeshFittingError): precalculate the External surfaces before calling it, by obj = obj.FindExternalSurfaces()\n');
                   obj = obj.FindExternalSurfaces();
               end


               nSamples = nPoints;
               iBlock = 0; nBlocks = 10; BlockSize = floor(nSamples/nBlocks);
               tSam = tic();
                for ipoint = 1:nPoints
                    if ipoint/BlockSize > iBlock
                        iBlock = iBlock + 1;
                        tSample = toc(tSam) / (ipoint-1);
                        fprintf('  ... %i%% of samples already processed (time per sample = %f)\n',100*iBlock/nBlocks,tSample);
                    end
                    point = SurfacePoints(ipoint,1:3);
                    [err(ipoint) CP] = obj.CalculateDistancePoint2Mesh(point);
                    Errors(ipoint,1:3) = CP-point;
                    CPs(ipoint,1:3) = CP;
                    if(bDebug)
                        CurrentMean = mean(err(find(err>0)));
                        CurrentStd  = std(err(find(err>0)));
                        CurrentMax  = max(err);
                        fprintf('Distance = %1.1f (node %i out of %i). Error = %1.2f +/- %1.2f. Max = %1.2f\n',err(ipoint),i,nPoints,CurrentMean,CurrentStd,CurrentMax);
                    end
                end
                err = sqrt(sum(Errors.^2,2));
                if(bWriteErrorFile)
                    nameForErrorFile = ['Error_' obj.name];
                    WriteErrorExData(Dir,nameForErrorFile,SurfacePoints,Errors,CPs);
                end
           end
            ERROR = mean(err);
            STD   = std(err);
            MAXERROR = max(err);            
            fprintf('Fitting error calculated (with subsample factor = %f)! Error = %1.2f +/- %1.2f. Max = %1.2f\n',SubsampleFactor,ERROR,STD,MAXERROR);
       end
       
       function []          = ViewMeshFittingError(obj,options)
           fprintf('WARNING!  obj.CalculateMeshFittingError must have been called before!\n');
           obj.TempcmGuiDir = obj.ReplaceSlash(obj.TempcmGuiDir);
           DIR = obj.TempcmGuiDir;
           OptionsViewMeshes = options;
           if isfield(options,'DirectoryErrorFile')
               DIR = options.DirectoryErrorFile;
           else
               fprintf('WARNING!  Data (exdata file) is supposed to be in %s (obj.TempcmGuiDir) \n',DIR);
           end           
           nameForErrorFile = ['Error_' obj.name];
           
           DirComFiles = obj.TempcmGuiDir;
           ComFile = [DirComFiles 'ViewMeshFittingError.com'];
                      
           % Call the external function to visualise the mesh alignment
           OptionsViewMeshes.finalMesh = obj.name;
           OptionsViewMeshes.bOnlyGenerateComFile = 1;           
           ComFileViewMeshes = ViewFittingAccuracyInCmGui(DIR,OptionsViewMeshes);
           fid = fopen(ComFile,'w');
           fid2 = fopen(ComFileViewMeshes,'r');
            while 1
                tline = fgetl(fid2);
                if ~ischar(tline), break, end
                fprintf(fid,'%s\n',tline);
            end
            fclose(fid2); 
           % Now add the necessary commands to visualise also the lines
           % joining each point of the isosurface to the mesh:
           fprintf(fid,'${dir}="%s"\n',obj.ReplaceSlash(DIR));
           fprintf(fid,'${ErrorEXdata}="%s"\n',obj.ReplaceSlash(nameForErrorFile));
           fprintf(fid,'${region}="%s"\n',nameForErrorFile);
           fprintf(fid,'gfx read data "${dir}${ErrorEXdata}.exdata"\n');
	       fprintf(fid,'# Calculate the module of the vector:\n');
	       fprintf(fid,'gfx def field ModErr2 dot_product fields  error error\n');
	       fprintf(fid,'gfx def field ModErr sqrt field ModErr2\n');
	       fprintf(fid,'gfx def field direction normalise field error\n');	
%	       fprintf(fid,'gfx mod g_e "${region}" data_points glyph line orientation direction scale ModErr material blue\n');
%	       fprintf(fid,'gfx mod g_e "${region}" data_points glyph sphere material blue size 0.2\n');
           fprintf(fid,'gfx mod g_e "${region}" data_points glyph cylinder general size "1*1*1" centre 0,0,0 font default orientation direction variable_scale ModErr scale_factors "0*0*0" select_on material blue selected_material default_selected;\n');
           fprintf(fid,'gfx mod g_e "${region}" data_points glyph sphere general size "2*2*2" centre 0,0,0 font default select_on material blue selected_material default_selected;\n');
           fclose(fid);
           
           CallcmGui(ComFile);

       end
           
       function [centre]    = GetMeshCentre(obj,option)
           if nargin<2
               option = 2;
           end
           switch option
               case 1
                   % Quick and approximate option
                   centre = zeros(1,3);
                   for iC = 1:3
                       centre(iC) = obj.BB(2*iC - 1) + (obj.BB(2*iC) - obj.BB(2*iC - 1) )/2;
                   end                       
                       % old bugged code (corrected 03/04/12):
%                    centre(1) = obj.BB(1) + obj.BB(2) /2;
%                    centre(2) = obj.BB(3) + obj.BB(4) /2;
%                    centre(3) = obj.BB(5) + obj.BB(6) /2;
               case 2
                   % A bit more of calculation, but closer to the centre of
                   % mass: get the average coordinate from all nodes
                   centre = mean(obj.GetPoints());
               case 3
                   % Sample the continuum, creating a binary image,
                   % and get the centre of mass of it
                   nSamplesPerDimension = 20;
                   spacing = zeros(1,3);
                   for iC=1:3
                        spacing(iC) = (obj.BB(2*iC) - obj.BB(2*iC - 1) ) / nSamplesPerDimension;
                   end
                   % Make the same spacing in x and y, in order to be able
                   % to call cmGui:
                   spacing(1:2) = mean(spacing(1:2));
                   [BinIm,hd] = obj.GenerateBinaryImage(spacing);
                   points = getPoints_fromBinary(BinIm,hd.origin,hd.spacing);
                   [a b] = size(points);
                   if a<b, points = points'; end
                   centre = mean(points,1);
           end
       end
       function [SS]        = GetAverageScale(obj)
           % function that returns the average length of the bounding box
           % of the mesh:
           obj = obj.BuildBoundingBox();
           for iD=1:3
               sidelength = obj.BB(2*iD) - obj.BB((2*iD) -1);
           end
           SS = mean(sidelength);
       end
       
       function [dist,CP,xi2DCP] = OptimiseDistancePoint2Face(obj,Point,iElem,iFace,CP,xi2DCP)
           % Function to find the closest point from a given Point to a
           % face of an element, from an initial guess
           % INPUT:
           % - iElem: index of the element
           % - iFace: index of the face (1 to 6)
           % - CP: global coordinates of the initial guess
           % - xi2DCP: 2D local coordinates of the initial guess
          
           bDebug = 0;
           if nargin<4
               xi2DCP = [0.5,0.5];
               CP = obj.evaluateFace(obj,iElem,iFace,xi2DCP);
           end
           % PARAMETERS:
           epsilon = 1e-15;
           % The search in the face previously was done with a
           % discretization of 10!
           InitialStepSize = 0.01;
           StepDecreaseFactor = 20;
           
           % 0. Initial minimum:
           dist = obj.DistanceBetweenTwoPoints(Point,CP);
           if (bDebug), fprintf('Initial CP=(%1.1f,%1.1f,%1.1f), dist = %1.1f\n',CP,dist); end;
           
           ss = InitialStepSize;
           while (ss>epsilon)
               % 1. Evaluate the eight "neighbour" positions:
               % xiPointsCandidates = repmat(xi2DCP,8,1) + [ss,0;0,ss;-ss,0;0,-ss;ss,ss;ss,-ss;-ss,ss;-ss,-ss];
               % A bigger (faster evaluation) search in 25 points at once!
               neigh = 11; 
               v1 = ones(1,neigh); v2=-(neigh-1)/2:1:(neigh-1)/2;
               V1 = [];
               for in=1:neigh                   
                   V1 = [V1 v2(in)*v1];
               end
               V2 = repmat(v2,1,neigh);
               xiPointsCandidates = repmat(xi2DCP,neigh^2,1) + ss*[V1;V2]';
               % Constrain the search to the 0-1 range:
               I = xiPointsCandidates>1;
               xiPointsCandidates(I)=1;
               I = xiPointsCandidates<0;
               xiPointsCandidates(I)=0;
               xiPointsCandidates = xiPointsCandidates';
               Points = obj.evaluateFace(iElem,iFace,xiPointsCandidates);
               Points = Points';
               % Remove the sqrt for optimization reasons
               %Distances = sqrt( (Points(:,1) - Point(1)).^2 + (Points(:,2) - Point(2)).^2 + (Points(:,3) - Point(3)).^2);
               Distances = ( (Points(:,1) - Point(1)).^2 + (Points(:,2) - Point(2)).^2 + (Points(:,3) - Point(3)).^2);
               % 2. Compare them with the current minimum:
               if min(Distances)<dist
                   dist = min(Distances);
                   I = Distances==dist;
                   if numel(find(I==1))==1
                       % New minimum found
                       CP = Points(I,:);
                       xi2DCP = xiPointsCandidates(:,I)';
                       if (bDebug), fprintf('Updated! CP=(%1.1f,%1.1f,%1.1f), dist = %1.1f (step=%1.10f)\n',CP,dist,ss); end;
                       % If this index is INSIDE the neighbourhood area,
                       % decrease the step size already!
                       [i1,i2] = ind2sub(size(xiPointsCandidates),I);
                       if ~(i1==1|i2==1|i1==neigh|i2==neigh)
                           ss = ss / StepDecreaseFactor;
                       end
                   else
                       ss = 0;
                       if (bDebug), fprintf('  Debugging info: search finished because two points were at the same distance while searching with a step size of %d\n',ss); end
                   end
               else
                   ss = ss / StepDecreaseFactor;
               end
           end
           dist = sqrt(dist);
       end
           
% Plotting functions:  
       function []          = cmGuiViewMeshConstantField(obj,values,FieldName)
           obj.TempcmGuiDir = obj.ReplaceSlash(obj.TempcmGuiDir);
           directory = obj.TempcmGuiDir;
           obj.WriteExElemFileWithConstantField([directory FieldName '.exelem'],obj.name,FieldName,values);
           obj.WriteExFiles(directory);
           optionscmGui.ConstantFieldName = FieldName;
           cmGuiViewMesh(directory,obj,optionscmGui);  
        end
       function []          = cmGuiViewMeshQuality(obj,WhichQuality)
           switch WhichQuality
               case 1
                   if(~obj.bQ1Calculated)
                       obj = obj.CalculateAspectRatio();
                   end
                   values = obj.Quality.AspectRatio;
                   FieldName = 'AspectRatio';
               case 2
                   if(~obj.bQ2Calculated)
                       obj = obj.CalculateOrthogonality();
                   end
                   values = obj.Quality.OrthogonalityPerElement;
                   FieldName = 'Orthogonality';
               case 3
                   if(~obj.bQ3Calculated)
                       obj = obj.CalculateJacobianRatio();
                   end
                   values = obj.Quality.JacobianRatio;
                   FieldName = 'JacobianRatio';
               case 4
                   if(~obj.bQ4Calculated)
                       obj = obj.CalculateDirecJacRatio();
                   end
                   values = obj.Quality.DirecJacRatio;
                   FieldName = 'DirecJacRatio';
               otherwise
                   fprintf('Wrong selection of which quality in cmGuiViewMeshQuality!\n')
           end        
           obj.cmGuiViewMeshConstantField(values,FieldName)
       end
       function []          = plotMinumumDistancePoint2Mesh(obj,Point)
           [dist CP] = obj.CalculateDistancePoint2Mesh(Point);
           hold on;
           plot3([CP(1) Point(1)],[CP(2) Point(2)],[CP(3) Point(3)], 'r');
           plot3([Point(1)],[Point(2)],[Point(3)], 'ro');
           plot3([CP(1)   ],[CP(2)   ],[CP(3)   ], 'r*');
       end
       function []          = plotMesh(obj,color,alpha)
           % Plot the mesh elements with the same color and a transparency.
           % Color is a value between 0 and 1.
           if nargin<2
               color=1;
           end
           if nargin<3
               alpha=1;
           end
           obj.plotMeshFieldperElement(color,alpha);
       end
       function []          = plotMeshQ1(obj)
           if obj.bQualityCalculated==false
               obj = obj.CalculateQuality();
           end
           obj.plotMeshFieldperElement(obj.Quality.AspectRatio)
       end
       function []          = plotMeshQ2(obj)       
           if obj.bQualityCalculated==false
               obj = obj.CalculateQuality();
           end
           %obj.plotQ2perelement();
           obj.plotWireframe();
           obj.plotQ2pernode();
       end
       function []          = plotMeshQ3(obj)
           if obj.bQ3Calculated==false
               obj = obj.CalculateJacobianRatio();
           end
           obj.plotMeshFieldperElement(obj.Quality.JacobianRatio)
       end
       function []          = plotWireframe(obj,color,alpha)
           if obj.bWireframeBuilt== false
               obj = obj.BuildWireframe();
           end
           if nargin<2
               color='k';
           end
           if nargin<3
               alpha=1;
           end
           for iElem=1:obj.nElems
               obj.plotWireframeElement(iElem,color,alpha);              
           end
           axis equal
           view(-38,30) 
           xlabel('X'); ylabel('Y'); zlabel('Z')
       end
       function []          = plotBB(obj)
           % BB = [xmin, xmax, ymin, ymax, zmin, zmax, margin]
           obj = obj.BuildBoundingBox();
           % Points of the BB:
           P1 = [obj.BB(1) obj.BB(3) obj.BB(5)];
           P2 = [obj.BB(1) obj.BB(3) obj.BB(6)];
           P3 = [obj.BB(1) obj.BB(4) obj.BB(5)];
           P4 = [obj.BB(1) obj.BB(4) obj.BB(6)];
           P5 = [obj.BB(2) obj.BB(3) obj.BB(5)];
           P6 = [obj.BB(2) obj.BB(3) obj.BB(6)];
           P7 = [obj.BB(2) obj.BB(4) obj.BB(5)];
           P8 = [obj.BB(2) obj.BB(4) obj.BB(6)];
           obj.plotLineBetweenTwoPoints(P1,P2);
           obj.plotLineBetweenTwoPoints(P1,P3);
           obj.plotLineBetweenTwoPoints(P1,P5);
           obj.plotLineBetweenTwoPoints(P2,P4);
           obj.plotLineBetweenTwoPoints(P2,P6);
           obj.plotLineBetweenTwoPoints(P3,P4);
           obj.plotLineBetweenTwoPoints(P3,P7);
           obj.plotLineBetweenTwoPoints(P4,P8);
           obj.plotLineBetweenTwoPoints(P5,P6);
           obj.plotLineBetweenTwoPoints(P5,P7);
           obj.plotLineBetweenTwoPoints(P6,P8);
           obj.plotLineBetweenTwoPoints(P7,P8);           
       end
       function []          = plotExternalSurfaces(obj,options)
           if nargin<2
               
           end
           % default options:
           discretisation = 5;
           iFaces = 1:6;
           color = 'k';
           LW =1;
           if nargin>=2
               if isfield(options,'discretisation'), discretisation= options.discretisation ; end
               if isfield(options,'iFaces'),        iFaces= options.iFaces ; end
               if isfield(options,'color'),         color= options.color ; end
               if isfield(options,'LW'),            LW= options.LW ; end
           end
           if (~obj.bExternalFacesFound)
               obj = obj.FindExternalSurfaces();
           end
           for iElem=1:obj.nElems
               for iFace=iFaces
                   if obj.ExternalFaces(iElem,iFace)
                       obj.plotElementFace(iElem,iFace,discretisation,color,LW);
                   end
               end
           end           
       end
       function []          = plotElementFace(obj,iElem,iFace,discretisation,color,LW)
           if nargin<4
               discretisation = 5;
           end
           if nargin<5, color='b';  end
           if nargin<6, LW = 1;     end
           [points]   = obj.ReconstructSurface(iElem,iFace,discretisation);
           points     = points';
           for i=1:discretisation
               hold on
               I=(i-1)*discretisation;
               indexes = 1+I:discretisation+I;
               indexes2= i:discretisation:discretisation^2;
               plot3(points(indexes,1),points(indexes,2),points(indexes,3),color,'LineWidth',LW);
               plot3(points(indexes2,1),points(indexes2,2),points(indexes2,3),color,'LineWidth',LW);
           end
           axis equal;
       end
       function []          = plotNodeNumbers(obj)
           for iNode=1:obj.nNodes
               x = obj.GetNodeCoorValue(iNode,1,1,1);
               y = obj.GetNodeCoorValue(iNode,2,1,1);
               z = obj.GetNodeCoorValue(iNode,3,1,1);
               text(x,y,z,sprintf('%i',iNode));
           end
       end
       function []          = plotQ2perelement(obj)
           if obj.bQualityCalculated==false
               obj = obj.CalculateQuality();
           end
           obj.plotMeshFieldperElement(obj.Quality.OrthogonalityPerElement)
       end
       function []          = plotQ2pernode(obj)
           if obj.bQualityCalculated==false
               obj = obj.CalculateQuality();
           end
           for i=1:obj.nNodes         
               ColorNodes = obj.Quality.OrthogonalityPerNode(i);              
               obj.plotNodeCoordinates(i,ColorNodes);  
               obj.plotNodeFirstDerivatives(i,ColorNodes);               
           end
%            for i=1:obj.nElem
%                [ind,nn] = obj.GetNodeIndexesOfElement(i);           
%                ColorNodes = obj.Quality.OrthogonalityPerNodeInElement(i,1:nn);              
%                obj.plotElementCoordinates(i,ColorNodes);  
%                for j=1:nn
%                    obj.plotNodeFirstDerivatives(ind(j),ColorNodes(j));
%                end
%            end
%            for i=1:obj.nNodes
%                obj.plotNodeFirstDerivatives(i,0);
%            end
           axis equal
       end
       function []          = plotElementQ2(obj,iElem)
           if obj.bQualityCalculated==false
               obj = obj.CalculateQuality();
           end
           [ind,nn] = obj.GetNodeIndexesOfElement(iElem);
           ColorNodes = obj.Quality.OrthogonalityPerNodeInElement(iElem,1:nn);
           obj.plotElementCoordinates(iElem,ColorNodes);
           obj.plotElementFirstDerivatives(iElem,ColorNodes);
           obj.plotElement(iElem,obj.Quality.OrthogonalityPerElement(iElem));
       end
       function []          = plotWireframeElement(obj,iElem,colorEdge,alpha,bPlotNodeGlobalIndex)
           if obj.bWireframeBuilt== false
               obj = obj.BuildWireframe();
           end
           [ind,nn] = obj.GetNodeIndexesOfElement(iElem);
           switch nn
               case 8, np=length(obj.OrderVisit8Nodes);
               case 6, np=length(obj.OrderVisit6Nodes);
               case 4, np=length(obj.OrderVisit4Nodes);
               case 64
                   % Both OrderVisit64NodesEX and OrderVisit64NodesCHeart
                   % have the same length:
                   np=length(obj.OrderVisit64NodesEX);
               case 3, np = 3; % trivial case of a triangle
               otherwise
                   fprintf(1,' WARNING: while ploting wireframe, element has a different number of nodes to 4, 6 or 8!');
                   np=0;               
           end
           if nargin<3
               colorEdge=[0 0 0];
           end
           if nargin<4
               alpha=1;
           end
           if nargin<5
               bPlotNodeGlobalIndex=0;
           end
           X=obj.Wireframe.Point(iElem,1:np,1);
           Y=obj.Wireframe.Point(iElem,1:np,2);
           Z=obj.Wireframe.Point(iElem,1:np,3);
           patch(X,Y,Z,0,'FaceColor',[1 0 0],'FaceAlpha',0.0,'EdgeAlpha',alpha,'EdgeColor',colorEdge);
           
           if (bPlotNodeGlobalIndex)
               [ind,nn] = obj.GetNodeIndexesOfElement(iElem);
               for i=1:nn
                   point = obj.coordinates(ind(i),:);
                   x=point(1);
                   y=point(2);
                   z=point(3);
                   tex=sprintf('G%i-L%i',ind(i),i);
                   text(x,y,z,['\leftarrow ' tex],'HorizontalAlignment','left');
               end
           end
       end
       function []          = plotMeshFieldperElement(obj,color,alpha)
           % color is a vector of values between 0 and 1 for each element
           if (obj.bTetrahedralCanvasBuilt==false)
               obj = obj.BuildTetrahedralCanvas();
           end
           if obj.bWireframeBuilt== false
               obj = obj.BuildWireframe();
           end
           if nargin<2, color = ones(1,obj.nElems); end
           if numel(color)==1, color = color*ones(1,obj.nElems);end
           if nargin<3, alpha=1;                  end
           for i=1:obj.nElems
               obj.plotElement(i,color(i),alpha);
           end
           obj.plotWireframe('k',alpha);
           axis equal
           view(-38,30)           
       end
       function []          = plotMaxMinQ1(obj)
           if obj.bQualityCalculated==false
               obj = obj.CalculateQuality();
           end
           ColorMin = min(obj.Quality.AspectRatio);
           ColorMax = max(obj.Quality.AspectRatio);
           Imin = find(obj.Quality.AspectRatio==ColorMin);
           Imax = find(obj.Quality.AspectRatio==ColorMax);  
           %obj.Quality.ImaxQ1 = Imax;
           %obj.Quality.IminQ1 = Imin;
           obj.plotElement(Imax,ColorMax);
           obj.plotElement(Imin,ColorMin);
           TitleText = sprintf('Element %i had AspectRatio = %f, and element %i had AspectRatio = %f\n',Imax,ColorMax,Imin,ColorMin);       
           title(TitleText);
       end
       function []          = plotMaxMinQ2(obj)
           if obj.bQualityCalculated==false
               obj = obj.CalculateQuality();
           end
           ColorMin = min(obj.Quality.OrthogonalityPerElement);
           ColorMax = max(obj.Quality.OrthogonalityPerElement);
           Imin = find(obj.Quality.OrthogonalityPerElement==ColorMin);
           Imax = find(obj.Quality.OrthogonalityPerElement==ColorMax);
           obj.plotElementQ2(Imin);
           obj.plotElementQ2(Imax);
           %[ind,nn] = obj.GetNodeIndexesOfElement(Imax);
           %ColorNodesMax = obj.Quality.OrthogonalityPerNodeInElement(Imax,1:nn);
           %[ind,nn] = obj.GetNodeIndexesOfElement(Imin);
           %ColorNodesMin = obj.Quality.OrthogonalityPerNodeInElement(Imin,1:nn);
           %obj.Quality.ImaxQ2 = Imax;
           %obj.Quality.IminQ2 = Imin;
           %obj.plotElement(Imax,ColorMax);
           %obj.plotElement(Imin,ColorMin);           
           %obj.plotElementCoordinates(Imax,ColorNodesMax)
           %bj.plotElementFirstDerivatives(Imax,ColorNodesMax)
           %obj.plotElementCoordinates(Imin,ColorNodesMin)
           %obj.plotElementFirstDerivatives(Imin,ColorNodesMin)
           TitleText = sprintf('Element %i had Orthogonality = %f, and element %i had Orthogonality = %f\n',Imax,ColorMax,Imin,ColorMin);       
           title(TitleText);
       end
       function []          = plotElement(obj,iElem,color,alpha)
           if (obj.bTetrahedralCanvasBuilt==false)
               obj = obj.BuildTetrahedralCanvas();
           end
           if nargin<3, color = 1; end
           if nargin<4, alpha=0.2; end           
           hold on
           RGBcolor = ind2rgb(round(256*color),jet(256));
           nn = obj.TetrahedralCanvas.nNod(iElem);
           nD = obj.TetrahedralCanvas.nDel(iElem);
           Tes(1:nD,:) = obj.TetrahedralCanvas.Tes(iElem,1:nD,:);
           X(1:nn,:) = obj.TetrahedralCanvas.X(  iElem,1:nn,:);      
           tetramesh(Tes,X,'FaceColor',RGBcolor,'FaceAlpha', alpha,'EdgeAlpha',0);
       end
       function []          = plotElementCoordinates(obj,iElem,ColorNodes)
           [ind,nn] = obj.GetNodeIndexesOfElement(iElem);
           if nargin<3
               ColorNodes = ones(1,nn);
           end
           if numel(ColorNodes) == 1
               ColorNodes = ones(1,nn) * ColorNodes;
           end
           for i=1:nn
               obj.plotNodeCoordinates(ind(i),ColorNodes(i))
           end
       end
       function []          = plotNodeCoordinates(obj,iMatNode,color)
           hold on
           if nargin<3
               color = 1;
           end
           for i=1:numel(iMatNode)
               iNode = iMatNode(i);
               x = obj.coordinates(iNode,1);
               y = obj.coordinates(iNode,2);
               z = obj.coordinates(iNode,3);
               RGBcolor = ind2rgb(round(256*color),jet(256));
               plot3(x,y,z,'o','MarkerFaceColor',RGBcolor,'MarkerEdgeColor',[0 0 0]);
           end
       end
       function []          = plotNodes(obj,color)
           hold on
           if nargin<3
               color = 1;
           end
           for iN = 1:obj.nNodes
               obj.plotNodeCoordinates(iN,color);
           end
       end
       function []          = plotElementFirstDerivatives(obj,iElem,ColorNodes)
           [ind,nn] = obj.GetNodeIndexesOfElement(iElem);
           for i=1:nn
               obj.plotNodeFirstDerivatives(ind(i),ColorNodes(i))
           end
       end
       function []          = plotNodeFirstDerivatives(obj,iMatNode,color)
           scale = 5;
           widthLine = 2.5;
           RGBcolor = ind2rgb(round(256*color),jet(256));
           centre = obj.coordinates(iMatNode,:);
           % Normalice vectors:
           direction1 = obj.Normalise(obj.derivatives.duds1(iMatNode,:));
           direction2 = obj.Normalise(obj.derivatives.duds2(iMatNode,:));
           direction3 = obj.Normalise(obj.derivatives.duds3(iMatNode,:));
           
           hold on
           [x y z] = obj.BuildVector(centre,direction1,scale);
           plot3(x,y,z,'Color',RGBcolor,'LineWidth',widthLine);
           [x y z] = obj.BuildVector(centre,direction2,scale);
           plot3(x,y,z,'Color',RGBcolor,'LineWidth',widthLine);
           [x y z] = obj.BuildVector(centre,direction3,scale);
           plot3(x,y,z,'Color',RGBcolor,'LineWidth',widthLine);  
       end

% Testing/debugging functions
       function []         = ViewBasisFunction(obj,whichbasis)
           % Function to plot the basis funciton in the [0,1] domain
           if nargin<2
               whichbasis = 'CL'
           end
           t = 0:0.001:1;
           switch whichbasis
               case 'CH'
                   values = obj.CubicHermite(t);
               case 'CL'
                   values = obj.CubicLagrange(t);
           end
           figure('color',[1 1 1])
           plot(t,values);
           title(sprintf('%s Basis functions',whichbasis));
           legend('1','2','3','4')
       end
       function []          = TestGenBinary(obj)
           % Parameters adapted for heartMedIA mesh:
           spacing = [1.9 1.9 2];
           origin  = [-70 -70 -120];
           nVox    = [75 85 70];
           [binaryA hImA] = obj.GenerateBinaryImage(spacing);
           options.origin = origin;
           [binaryB hImB] = obj.GenerateBinaryImage(spacing,options);
           options.nVox = nVox;
           [binaryC hImC] = obj.GenerateBinaryImage(spacing,options);
           figure('Color',[1 1 1]); hold on;
           subplot(131)
           obj.plotWireframe();
           show_segment_surface(binaryA,hImA.origin,hImA.spacing);
           subplot(132)
           obj.plotWireframe();
           show_segment_surface(binaryB,hImB.origin,hImB.spacing);
           subplot(133)
           obj.plotWireframe();
           show_segment_surface(binaryC,hImC.origin,hImC.spacing);
       end
       function []          = visualizeVolumes(obj)
           volume = zeros(1,obj.nElems);
           for iElem=1:obj.nElems
               fprintf('Calculating volume of element %i... ',iElem);
               volume(iElem) = obj.GetElementVolume(iElem);
               fprintf('Finished. Volume = %d \n ',volume(iElem));
           end
           volume = volume/max(volume);
           obj.plotMeshFieldperElement(volume);
       end
       function []          = plotGaussPoints(obj,iElem,GaussOrder)
           if nargin<3
               GaussOrder=3;
           end
           nPoints = GaussOrder^3;
           obj.plotElement(iElem);
           GaussPoints = obj.GetGlobalGaussPoints(iElem,GaussOrder);
           Coords = reshape(GaussPoints.GlobalCoordinates,nPoints,3);
           for i=1:nPoints
               plot3(Coords(i,1),Coords(i,2),Coords(i,3),'o');
           end
       end
   end
  
   methods (Static = true)
        
   % Testing functions
       function [testresult] = TestVolumeCalculation()
           testresult=true;
           bCylinder=1;
           epsilon=1e-20;
           
           %First, a cube of side 1mm
           shape='cube';
           side = 1;
           Rin = 1; Rout = side; Length = 1; Margin = 1;
           VolumeGT=side^3;
           nElemsA = [1 10 1];
           dimensions = [Rin Rout Length Margin nElemsA(1) nElemsA(2) nElemsA(3) ];
           Shape1 = CreateExDeformedShape(shape,'0',dimensions,0);
           vol = zeros(Shape1.nElems,1);
           for iE=1:Shape1.nElems
               vol(iE)=Shape1.GetElementVolume(iE);
           end
           TotalVol = sum(vol);
           error=abs(TotalVol-VolumeGT);
           if (error>epsilon)
               fprintf(1,'Test failed!! Volume calculation is wrong. Error in volume of a cube of 1mm of side = %d\n',error);
               testresult=false;
           end
           
           if (bCylinder)
               %Second, a cylinder:
               shape='cylinder';
               nElemsA = [2 6 2];
               Rin = 1; Rout = 2; Length = 1; Margin = 25;
               VolumeGT = pi*(Rout^2 - Rin^2)*Length;
               dimensions = [Rin Rout Length Margin nElemsA(1) nElemsA(2) nElemsA(3) ];
               Shape1 = CreateExDeformedShape(shape,'0',dimensions,0);
               vol = zeros(Shape1.nElems,1);
               for iE=1:Shape1.nElems
                   vol(iE)=Shape1.GetElementVolume(iE);
               end
               TotalVol = sum(vol);
               error=abs(TotalVol-VolumeGT);
               if (error>epsilon)
                   fprintf(1,'Test failed!! Volume calculation is wrong. Error in cylinder volume = %d, (GT=%f)\n',error,VolumeGT);
                   testresult=false;
               end
           end
       end
       function [testresult] = TestSurfaceCalculation()
           testresult=true;
           epsilon=1e-20;
           for iShape=1:2
               switch iShape
                   case 1
                       shape = 'cube';
                       nElemsA = [ 1 1 1];
                       Rin = 1; Rout = 2; Length = 1; Margin = 25;
                       SurfaceGT = 6*Rout^2;
                   case 2
                       shape = 'cylinder';
                       nElemsA = [1 6 1];
                       Rin = 1; Rout = 2; Length = 1; Margin = 25;
                       SurfaceGT = 2*pi*(Rout^2 - Rin^2) + 2*pi*(Rout+Rin)*Length;
               end
               dimensions = [Rin Rout Length Margin nElemsA(1) nElemsA(2) nElemsA(3) ];
               Shape1 = CreateExDeformedShape(shape,'0',dimensions,0);
               Surface = Shape1.GetMeshSurface();
               error = abs(Surface - SurfaceGT);
               if (error>epsilon)
                   fprintf(1,'Test failed!! Surface calculation is wrong. Error in %s surface = %d, (GT=%f)\n',shape,error,SurfaceGT);
                   testresult=false;
               end   
           end
       end
       function [] = TestFitField()
           DIR = './ExampleData/';
           bTestDataType1=1;
           bTestDataType2=0;
           bTestDataType3=0;
           %==============================================================
           % DATATYPE 1: a regular grid of samples
           %==============================================================
        if(bTestDataType1)
           nameCH = 'VentriclesTime0_eD3_fitted2LV3_Initialization';
           nameDF = 'VentriclesTime0_eD3_fitted2LV3_ini3_DF';
           CHt2_init = CubicMeshClass([DIR nameCH '.exnode'],[DIR nameCH '.exelem']);
           load(nameDF,'-MAT');
           Shape2 = DeformMeshByShapeFEInterp_M2(mapPhys,CHt2_init,4,'spline',1,2);
           Shape2.name = 'DeformedMesh';
           Shape2.WriteExFiles(DIR);
           cmGuiViewMesh(DIR,Shape2);            
        end
           %==============================================================
           % DATATYPE 2: an irregular cloud of samples
           %==============================================================
        if(bTestDataType2)
           nameCH = 'domain_eD2_fitted2LV2b_byM2_Vfit0';
           CH = CubicMeshClass([DIR nameCH '.exnode'],[DIR nameCH '.exelem']);
           nameData= 'ToussaintTensorDataElevImbric';
           fieldname = 'Elevations';
           EXdata = ReadExNode([DIR nameData '.exnode']);
           
            nPoints2 = EXdata.nNodes;
            points       = zeros(3,nPoints2);
            elevations   = zeros(1,nPoints2);
            imbrications = zeros(1,nPoints2);
            iElements    = zeros(1,nPoints2);
            xiCoordinates= zeros(3,nPoints2);
            for ip=1:nPoints2
                points(1:3,ip)   = EXdata.FieldValues(1,ip).values;
                elevations(ip)   = EXdata.FieldValues(2,ip).values;
                imbrications(ip) = EXdata.FieldValues(3,ip).values;
                iElements(ip)    = EXdata.FieldValues(4,ip).values;
                xiCoordinates(:,ip)= EXdata.FieldValues(5,ip).values;
            end
            CHd = CH.FitField(elevations,points);
            CH = CH.SetFieldDofs(fieldname,CHd,1);
            CH.name = 'LVwithElevations';
            CH.WriteExFiles(DIR);
            parameters.fieldname = fieldname;
            parameters.Max = pi/2;
           cmGuiViewMesh(DIR,CH,parameters);
        end
           %==============================================================
           % DATATYPE 3: data at the gauss points
           %==============================================================
        if(bTestDataType3)
           % Mesh:
           nameCH= 'case15VentriclesClean_gD16_fitted2heartMedIA_ini2_byM2_Vfit1';
           CH = CubicMeshClass([DIR nameCH '.exnode'],[DIR nameCH '.exelem']);
           % Data:
           dataset=1;
           switch dataset
               case 1
                   datafile = [DIR 'case15_activationtimes_gauss'];
                   nameOut = 'Case15WithActivationTimesBase';
               case 2
                   datafile = [DIR 'case15_activationtimes_gauss_BiV'];
                   nameOut = 'Case15WithActivationTimesBiV';
           end
           
           bTryLMSfittingByJiahe=1;
           if(bTryLMSfittingByJiahe)
               [DataAtGaussPoints,coor,value,xiCoor,iElem] = ReadGaussPoints(datafile,CH.nElems);
               xiC_all = [ iElem xiCoor];
               %first build the shape matrix A
               %d = size(value,1);
               %nDof = CH.nNodes * 8;
               b = value;
               %A = zeros(d, nDof);

               %EmbbedMeshXiPointsShapeMatrix_postfex=strrep(EmbbedMeshXiPoints_postfex,'.mat','GlobalShapeMatrix.mat' );
               EmbbedMeshXiPointsShapeMatrix = 'shapeMatrix.mat';
                if(exist(EmbbedMeshXiPointsShapeMatrix,'file')==2)
                    %load GlobalShapeMatrix and p
                    disp('loading precomputed shape matrix ...')
                    load(EmbbedMeshXiPointsShapeMatrix);
                else
                    disp('computing shape matrix ...')
                    [GlobalShapeMatrix p] = globalShapeMatrixOfXiCoords(CH, xiC_all);
                    save(EmbbedMeshXiPointsShapeMatrix,'GlobalShapeMatrix','p');
                end
                [x r]=solve_lsq(GlobalShapeMatrix, b, [], []);
           end
           
           CHd = CH.FitField(datafile);
           fieldname = 'ActivationTime';
           CH = CH.SetFieldDofs(fieldname,CHd,1);
           CH.name = nameOut;
           CH.WriteExFiles(DIR);
           Tmax = 250;
           parameters.fieldname = fieldname;
           parameters.Max = Tmax;
           cmGuiViewMesh(DIR,CH,parameters);
        end
       end
        
       function []           = TestFibreFittingFromSparseData()
           % An example dataset (from ScriptFitFibresV2)
            dirCH = 'D:\EuHeart\data\HumanFibres\meshing\';
            nameCH = 'domain_eD2_fitted2LV2b_byM2_Vfit0';        
            dir =   'D:\EuHeart\data\HumanFibres\';
            nameVTKdataFile = 'gaussiantensors-prolate-optimal-b';
            CH = CubicMeshClass([dirCH nameCH '.exnode'],[dirCH nameCH '.exelem']);
            versionOut = 'ToussaintTensorData';
            
            % Make the fittign of elevation and imbrication
            [F,V,E] = VTK2cmGuiTetMesh(dir,nameVTKdataFile,0);
            TensorData = F;
            points = V;
            nameFileElevImbric = [versionOut 'ElevImbric'];
            bFirstFittingTry=0;
            if(bFirstFittingTry) 
                [elevations,imbrications,iElements,xiCoordinates] = CH.GetImbricationAndElevationFromSparseTensors(TensorData,points,nameFileElevImbric,dir);
                CH = CH.FitImbricationAndElevationData(elevations,imbrications,points);
                % Both things done here:
                % CH = CH.FitFibresFromSparseTensorData(F,V);
            else
                EXdata = ReadExNode([dir nameFileElevImbric]);
                elevations   = EXdata.FieldValues(2,:);
                imbrications = EXdata.FieldValues(3,:);
                iElements    = EXdata.FieldValues(4,:);
                xiCoordinates= EXdata.FieldValues(5,:);
                %[elevations,imbrications,iElements,xiCoordinates] = 
                CH = CH.FitImbricationAndElevationData(elevations,imbrications,points);
            end

            % Calculate the error 
            % ... between the original vector and 
       end
       
   % Auxiliary functions
   
       function [dofsEndo3DMesh,dofsEpi3DMesh] = GetLVEndoEpiNodes(topology,iFirstNode)
           if nargin<2
               iFirstNode = 1;
               Jumps = 1;
               bReorder = 0;
           else
               Jumps = 3;
               bReorder = 1;
           end
           nLayers = numel(topology.NodeLayer);
           dofsEndo3DMesh = [];
           dofsEpi3DMesh  = [];
           for iLayer = 1:nLayers-1
               dofsEndo3DMesh = [dofsEndo3DMesh topology.NodeLayer(iLayer).EndoNodes(iFirstNode:Jumps:end)];
               dofsEpi3DMesh  = [dofsEpi3DMesh topology.NodeLayer(iLayer).EpiNodes(iFirstNode:Jumps:end)];
           end 
           %Add the apical nodes:
               dofsEndo3DMesh = [dofsEndo3DMesh topology.NodeLayer(nLayers).EndoNodes(:)];
               dofsEpi3DMesh  = [dofsEpi3DMesh topology.NodeLayer(nLayers).EpiNodes(:)];
           % Need to reorder these indexes, not per layer, but start in one
           % end of the contour and finishing in the other. This means
           % taking the first dof, and then the third...:
           if(bReorder)
               nD = numel(dofsEndo3DMesh);
               RightOrder = [1:2:nD nD-1:-2:1]; 
               % Hack to get the mapping right:
               RightOrder = RightOrder(end:-1:1);
               dofsEndo3DMesh = dofsEndo3DMesh(RightOrder);
               dofsEpi3DMesh  = dofsEpi3DMesh(RightOrder);
           end
       end
       
       function corners     = LagrangeCorners()
           corners = [1,4,13,16,49,52,61,64];
       end
       function [index]     = GlobalBasisIndex(iNode,iContinuity,dofsUsed)
           if nargin==3
                % We remove some DOFS from the basis:
                if dofsUsed(iNode,iContinuity)==0
                    index=NaN;
                else
                    nDOFsUsed = sum(sum(dofsUsed(1:iNode-1,:)));
                    OffsetNotUsedInThisNode = iContinuity - sum(dofsUsed(iNode,1:iContinuity));
                    index = nDOFsUsed + iContinuity - OffsetNotUsedInThisNode;
                end
            else
                % Original indexing:
                index = (iNode-1)*8 + iContinuity;
           end
       end
       function [nNodesPerElement,nVariablesPerNode] = GetBasisCharacteristics(InterpolationBasis , element)
           % Some indexing basic numbers to choose among
           % 1. c.Hermite
           % 2. c.Lagrange
           % 3. q.Lagrange
           % 4. l.Lagrange
           % 5. l.simplex
           %
           % element 
           % 1. Cube (8 nodes)
           % 2. Tet (4 nodes)
           % 3. triangle (3 nodes)
           %
           % http://opencmiss.org/documentation/data_format/ex_file_format.html
           
           if nargin<3
               element = 1;
           end
           switch InterpolationBasis
                case 1
                    switch element
                        case 1, nNodesPerElement = 8;
                        case 2, nNodesPerElement = 4;
                        case 3, nNodesPerElement = 3;
                    end
                    nVariablesPerNode= 8;
                case 2
                    nNodesPerElement = 64;
                    nVariablesPerNode= 1;
               case 3
                    nNodesPerElement = 27;
                    nVariablesPerNode= 1;
               case 4
                    nNodesPerElement = 8;
                    nVariablesPerNode= 1;
               case 5
                    nNodesPerElement = 3;
                    nVariablesPerNode= 1;
           end
       end
       
       function [grid]      = BuildGrid(coor)
            % Function taken from DFinterpolation2 at 26th Nov 2009
                x=squeeze(unique(coor(1,:,:,:)));
                y=squeeze(unique(coor(2,:,:,:)));
                z=squeeze(unique(coor(3,:,:,:)));

                if (length(x)==1)||length(y)==1||length(z)==1
                    fprintf(1,'ERROR in DFinterpolation:BuildGridError!!! Second parameter, coordinates, leads to a grid of size(%i,%i,%i)\n',length(x),length(y),length(z));
                    return;
                else
                    [Y,X,Z] = meshgrid(y,x,z);
                    %[X,Y,Z] = ndgrid(x,y,z);
                    grid.X=X;
                    grid.Y=Y;
                    grid.Z=Z;
                end
       end
       function [f]         = Interpolate(DATA,points)
           if isfield(DATA,'datatype')
               datatype = DATA.datatype;
           else
               fprintf(' ERROR in CubicMeshClass:Interpolate: data structure does not have the datatype field!\n');
           end           
           if datatype==3
               % Read the gauss point info and create a cloud of
               % points:
               [DataAtGaussPoints,coor,values] = ReadGaussPoints(DATA.values);
               DATA.datatype = 2;
               DATA.values = values;
               DATA.coor = coor;
           end
           f = InterpolateData(DATA,points);
       end
       function [LocalGaussPoints1D] = GetLocalGaussCoords1D(order,xhi1,xhi2)
           % Function that gets the gauss coordinates in an interval [0 1]
           % INPUT:
           % - order: Gauss Integration Order
           % - xhi1,xhi2: definition of a different interval to [0 1]
           % OUTPUT:
           % - LocalGaussPoints1D.GPxhi = coordinates in local domain [0 1]
           % - LocalGaussPoints1D.GaussWeights = weight of each coordinate
           % 
           % For further reference:
           % http://en.wikipedia.org/wiki/Gaussian_quadrature
           if nargin<2
               xhi1=0;
               xhi2=1;
           end
           switch order
               case 2
                gp1 = sqrt(1/3);
                GaussDistancesFromCentreInUnitElement  = [-gp1 gp1];
                GaussWeightsInUnitElement = [1 1];
               case 3
                gp1 = sqrt(3/5);
                GaussDistancesFromCentreInUnitElement  = [-gp1 0 gp1];
                GaussWeightsInUnitElement = [5/9 8/9 5/9];
               case 4
                x1=sqrt((3-2*sqrt(6/5))/7);
                x2=sqrt((3+2*sqrt(6/5))/7);
                w1=(18+sqrt(30))/36;
                w2=(18-sqrt(30))/36;
                GaussDistancesFromCentreInUnitElement = [-x2 -x1 x1 x2];
                GaussWeightsInUnitElement             = [ w2  w1 w1 w2];
               case 5
                x0=0;
                x1=sqrt(5-2*sqrt(10/7))/3;
                x2=sqrt(5+2*sqrt(10/7))/3;
                w0=128/225;
                w1=(322+13*sqrt(70))/900;
                w2=(322-13*sqrt(70))/900;
                GaussDistancesFromCentreInUnitElement = [-x2 -x1 x0 x1 x2];
                GaussWeightsInUnitElement             = [ w2  w1 w0 w1 w2];
                case 6
                  GaussDistancesFromCentreInUnitElement = [-0.93246951 -0.66120939 -0.23861918 0.23861918 0.66120939 0.93246951];
                  GaussWeightsInUnitElement             =  [0.17132449 0.36076157 0.46791393 0.46791393 0.36076157 0.17132449];
               case 7
                    GaussWeightsInUnitElement = [0.12948497 0.27970539 0.38183005 0.41795918 0.38183005 0.27970539 0.12948497];
                    GaussDistancesFromCentreInUnitElement            =  [-0.94910791 -0.74153119 -0.40584515 0 0.40584515 0.74153119 0.94910791];  
               otherwise
                   error(' ERROR! Gauss order %i not implemented in CubicHermite4 class!\n',order);
            end
            LengthInterval=xhi2-xhi1;
            centre=(xhi1 + xhi2)/2;
            LocalGaussPoints1D.GPxhi = centre*ones(1,order) + GaussDistancesFromCentreInUnitElement*(LengthInterval/2);
            LocalGaussPoints1D.GaussWeights= GaussWeightsInUnitElement*(LengthInterval/2);
       end
       function []          = plotPoints(points,style)
           hold on;
           for i=1:length(points)
               plot3(points(1,i),points(2,i),points(3,i),style);
           end
       end
       function []          = plotLineBetweenTwoPoints(P1,P2)
           plot3([P1(1) P2(1)],[P1(2) P2(2)],[P1(3) P2(3)]);
       end

       function [coords]    = Build_Face_3DxiCoor_from2Dxicoor(XiCoor2D,iFace)
           % Function to create the correct expression of a 3D local
           % coordinate from a 2D local coordinate point of a face.
           % - iFace: which surface to reconstruct:
           %        0: all surfaces (6 of them)
           %        5: xhi1=0
           %        6: xhi1=1
           %        3: xhi2=0
           %        4: xhi2=1
           %        1: xhi3=0
           %        2: xhi3=1
           
           xhia  = XiCoor2D(1,:);
           xhib  = XiCoor2D(2,:);
           nPoints = length(xhia);
           switch iFace
               case 5,
                   coords=[zeros(1,nPoints); xhia; xhib];
               case 6,
                   coords=[ ones(1,nPoints); xhia; xhib];
               case 3,
                   coords=[xhia; zeros(1,nPoints); xhib];
               case 4,
                   coords=[xhia;  ones(1,nPoints); xhib];
               case 1,
                   coords=[xhia; xhib; zeros(1,nPoints)];
               case 2,
                   coords=[xhia; xhib;  ones(1,nPoints)];
               case 0,
                   coords1=[zeros(1,nPoints); xhia; xhib];
                   coords2=[ ones(1,nPoints); xhia; xhib];
                   coords3=[xhia; zeros(1,nPoints); xhib];
                   coords4=[xhia;  ones(1,nPoints); xhib];
                   coords5=[xhia; xhib; zeros(1,nPoints)];
                   coords6=[xhia; xhib;  ones(1,nPoints)];
                   coords=[coords1,coords2,coords3,coords4,coords5,coords6];
               otherwise
                   fprintf(1,'wrong selection of option in CubicMeshClass.ReconstructSurface!!\n');
                   coords=[0 0 0];
           end
       end
       function [xiCoords]  = BuildXiSamples(xi1Range,xi2Range,xi3Range)
           n1 = length(xi1Range);
           n2 = length(xi2Range);
           n3 = length(xi3Range);
           nSamples = n1*n2*n3;
           xhi1=repmat(xi1Range,1,n2*n3);
           xh2 = xi2Range;
           xh3 = xi3Range;
           xhi2=single(zeros(1,nSamples));
           xhi3=single(zeros(1,nSamples));
           for i=1:n2
               % The first nXhiSamples(1)*nXhiSamples(2) values of xhi2:
               xhi2(1+(i-1)*n1:i*n1)=repmat(xh2(i),1,n1);
           end
           for i=1:n3
               % Xhi3 is a repetition of each xhi a number of
               % nXhiBlok3 times:
               nXhiBlok3=n1*n2;
               xhi3(1+(i-1)*nXhiBlok3:i*nXhiBlok3)=repmat(xh3(i),1,nXhiBlok3);
               xhi2(1+(i-1)*nXhiBlok3:i*nXhiBlok3)=xhi2(1:nXhiBlok3);
           end
           xiCoords = [xhi1;xhi2;xhi3];
       end
       
       function []          = Print2FileWithoutScapes(fid,string2print)
           % Function to print to file without taking into consideration
           % any potential escape symbol, any '/' is just path:
           indexes = find(string2print=='\');
           switch numel(indexes)
               case 0, fprintf(fid,'%s',string2print);
               otherwise
                   for j=1:numel(indexes)
                       if j==1
                           i0 = 1;
                       else
                           i0 = indexes(j-1)+1;
                       end
                       i1 = indexes(j)-1;
                       fprintf(fid,'%s',string2print(i0:i1));
                       fprintf(fid,'/');
                   end
                   if indexes(end) < numel(string2print)
                       fprintf(fid,'%s',string2print(indexes(end):end));
                   end
           end
       end
           
       
       function []          = PrintValues(fid,values,basis)  
           % Update: "basis" must not influence what to write, simply the
           % number of values:
           I= isnan(values);  values(I) = 0;
           fprintf(fid,'    %1.16d ',values);
           fprintf(fid,'\n');
%            switch basis
%                case 'c.Hermite'
%                    fprintf(fid,'    %1.16d %1.16d  %1.16d  %1.16d  %1.16d  %1.16d  %1.16d  %1.16d\n',values);
%                case {'l.Lagrange','c.Lagrange'}
%                    fprintf(fid,'    %1.16d \n',values);
%            end
       end
       function []          = PrintValueAndScaleFactorIndices(f2,CaseBasis,LocalNodeIndex,ScaleFactorIndexes,valueIndicesEXELEMorder,iCoor)
           switch CaseBasis
               case -1
                   nNodesPerElement = 0;
                   nVariablesPerNode= 0;
               case 0
                   nNodesPerElement = 8;
                   nVariablesPerNode= 1;
               case 1 % Linear triangular mesh
                   nNodesPerElement = 3;
                   nVariablesPerNode= 1;
               case {3,7}
                   nNodesPerElement = 8;
                   nVariablesPerNode= 8;
               case 6
                   nNodesPerElement = 27;
                   nVariablesPerNode= 1;
               case 8
                   nNodesPerElement = 64;
                   nVariablesPerNode= 1;
           end

               for iLocalNode=1:nNodesPerElement
                   if nargin<4, 
                       ScaleIndices = 1:nVariablesPerNode;
                       ScaleIndices = ScaleIndices + (iLocalNode-1)*nVariablesPerNode;
                       else         ScaleIndices = ScaleFactorIndexes(iLocalNode,1:nVariablesPerNode); 
                   end
                   if nargin<5, ValueIndices = 1:nVariablesPerNode;
                       else     ValueIndices = valueIndicesEXELEMorder(iCoor,iLocalNode,1:nVariablesPerNode); 
                   end
                   switch CaseBasis %A strange way to codify which option of the combinations between l.lagrange and c.Hermite
                       case {8,6} % c.Lagrange and q.Lagrange
                           fprintf(f2,'      %i.  #Values= 1\n',LocalNodeIndex(iLocalNode));
                           fprintf(f2,'       Value indices: %i \n',ValueIndices);
                           fprintf(f2,'       Scale factor indices: %i \n',ScaleIndices);                           
                       case 7
                           fprintf(f2,'      %i.  #Values= 8\n',LocalNodeIndex(iLocalNode));
                           fprintf(f2,'       Value indices: %i %i %i %i %i %i %i %i \n',ValueIndices);
                           fprintf(f2,'       Scale factor indices: %i %i %i %i %i %i %i %i \n',ScaleIndices);
                       case 3
                           fprintf(f2,'      %i.  #Values= 4\n',LocalNodeIndex(iLocalNode));
                           fprintf(f2,'       Value indices: %i %i %i %i \n',ValueIndices(1:4));
                           fprintf(f2,'       Scale factor indices: %i %i %i %i \n',ScaleIndices(1:4));
                       case {1,0}
                           fprintf(f2,'      %i.  #Values= 1\n',LocalNodeIndex(iLocalNode));
                           fprintf(f2,'       Value indices: %i \n',ValueIndices(1));
                           fprintf(f2,'       Scale factor indices: %i \n',ScaleIndices);
                   end
               end
       end
       function b           = deblank2(a)
           b = deblank(a);
           b = b(end:-1:1);
           b = deblank(b);
           b = b(end:-1:1);
           %fprintf(1,'Line was %s, with %i characters. Now is %s, with %i characters.\n',a,length(a),b,length(b));
       end
       function textout     = ReplaceSlash(textin)
            % Function to replace the windows \ for the linux / in the defintion of a
            % directory
            I = textin=='\';
            textout=textin;
            textout(I)='/';
            % until % added by Marta, 07/10/2014
            a=strfind(textout,'//');
            if ~isempty(a)
                textout(a)=[];
            end
            a=strfind(textout,'/\');
            if ~isempty(a)
                textout(a)=[];
            end
            a=strfind(textout,'\/');
            if ~isempty(a)
                textout(a)=[];
            end
            %

       end
       function [DIR namefile] = GetPath(absolutepath)
            I1=find(absolutepath=='/');
            I2=find(absolutepath=='\');
            if numel(I1)==0 && numel(I2)==0
                fprintf('WARNING in GetPath! %s does not have the "/" or "\" characters as expected!\n',absolutepath);
                DIR =[];
                namefile = absolutepath;
                return;
            end
            LastDirChar = max([I1 I2]);    
            DIR = absolutepath(1:LastDirChar);
            namefile = absolutepath(LastDirChar+1:end);
       end
           
       function FieldCaseBasis = MapSSet2CaseBasis(SSet)
           % Map the definiton of the basis into the code used inside the
           % class:
           if ~ischar(SSet)
               SSet = toCharArray(SSet)';
           end
           switch SSet
               case 'constant*constant*constant'
                   FieldCaseBasis = -1;
               case 'l.Lagrange*l.Lagrange*l.Lagrange'
                   FieldCaseBasis = 0;
               case 'l.simplex(2)*l.simplex'
                   FieldCaseBasis = 1;
               case 'c.Hermite*c.Hermite*l.Lagrange'
                   FieldCaseBasis = 3;                   
               case 'q.Lagrange*q.Lagrange*q.Lagrange'
                   FieldCaseBasis = 6;
               case 'c.Hermite*c.Hermite*c.Hermite'
                   FieldCaseBasis = 7;
               case 'c.Lagrange*c.Lagrange*c.Lagrange'
                   FieldCaseBasis = 8;
               otherwise
                   fprintf(1,'    ... ERROR! MapSSet2CaseBasis, case %s of basis functions not recognised!!\n',SSet);
           end
       end
       function    [basis1,basis2,basis3,nScaleFactors] = GetBasisFromCase(CaseBasis)
           % Function to decode the basis functions of a 3D interpolation
           switch CaseBasis
               case 0
                   nScaleSets = 0; %fprintf(f2,'#Scale factor sets= 0 \n');
                   basis1='l.Lagrange';
                   basis2='l.Lagrange';
                   basis3='l.Lagrange';
                   nScaleFactors = 8;
               case 1 % Linear triangular mesh
                   nScaleSets = 0; %fprintf(f2,'#Scale factor sets= 0 \n');
                   basis1='l.simplex(2)';
                   basis2='l.simplex';
                   basis3='';
                   nScaleFactors = 3;
               case 3
                   nScaleSets = 1; %fprintf(f2,'#Scale factor sets= 1 \n');
                   basis1='c.Hermite';
                   basis2='c.Hermite';
                   basis3='l.Lagrange';
                   nScaleFactors = 32;
               case 6 
                   nScaleSets = 1; %fprintf(f2,'#Scale factor sets= 1 \n');
                   basis1='q.Lagrange';
                   basis2='q.Lagrange';
                   basis3='q.Lagrange';
                   nScaleFactors = 27;
               case 7
                   nScaleSets = 1; %fprintf(f2,'#Scale factor sets= 1 \n');
                   basis1='c.Hermite';
                   basis2='c.Hermite';
                   basis3='c.Hermite';
                   nScaleFactors = 64;
               case 8
                   nScaleSets = 1; %fprintf(f2,'#Scale factor sets= 1 \n');
                   basis1='c.Lagrange';
                   basis2='c.Lagrange';
                   basis3='c.Lagrange';
                   nScaleFactors = 64;
               otherwise
                   fprintf(1,'    ... ERROR! PrintElemDefinition, case %i of basis functions not recognised!!\n',CaseBasis);
           end
       end
       
       function [EXmesh,l]  = GetNodeCoordsAndDerivs(EXmesh,n,f,l,FieldDefinition)
            %EXAMPLES OF VERSIONS:
            % if (v1==1 && v2==1 && v3 ==1)
            % Each node has 24 values, 3 coordinates and 21 derivatives, the field definition is:
            %    1) coordinates, coordinate, rectangular cartesian, #Components=3
            %    x.  Value index= 1, #Derivatives= 7 (d/ds1,d/ds2,d2/ds1ds2,d/ds3,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3)
            %    y.  Value index= 9, #Derivatives= 7 (d/ds1,d/ds2,d2/ds1ds2,d/ds3,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3)
            %    z.  Value index=17, #Derivatives= 7 (d/ds1,d/ds2,d2/ds1ds2,d/ds3,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3)
            %    if (v1==1 && v2==1 && v3 ==2)
                    % Each node has 29 values, the usual 3 + 21 and 8 more, the new
                    % version of Z coordinate and 7 derivatives. The coordinate will be
                    % the same though! This simply means to have to read 2 additional
                    % lines at the end.
            %    1) coordinates, coordinate, rectangular cartesian, #Components=3
            %    x.  Value index= 1, #Derivatives= 7 (d/ds1,d/ds2,d2/ds1ds2,d/ds3,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3)
            %    y.  Value index= 9, #Derivatives= 7 (d/ds1,d/ds2,d2/ds1ds2,d/ds3,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3)
            %    z.  Value index=17, #Derivatives= 7 (d/ds1,d/ds2,d2/ds1ds2,d/ds3,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3), #Versions= 2

            % Order the information about the versions:
                v1=FieldDefinition.versions(1);
                v2=FieldDefinition.versions(2);
                v3=FieldDefinition.versions(3);
                vi=[v1 v2 v3];
            % And about the indexes:
                indexValue1 = FieldDefinition.indexes(1);
                indexDeriv1 = FieldDefinition.indexes(2);
                indexValue2 = FieldDefinition.indexes(3);
                indexDeriv2 = FieldDefinition.indexes(4);
                indexValue3 = FieldDefinition.indexes(5);
                indexDeriv3 = FieldDefinition.indexes(6);
                indval = [indexValue1 indexValue2 indexValue3];
                indDer = [indexDeriv1 indexDeriv2 indexDeriv3];
            % PREALLOCATION:
                nv=2;   % Number of versions
                NodeCoordinates=zeros(3,nv);
                % Variable to store the derivative values read:
                % - 3 dimensions
                % - 7 derivatives (d/ds1,d/ds2,d2/ds1ds2,d/ds3,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3)
                % - nv versions
                derivatives=zeros(3,7,nv);
                
        %for iField=1:FieldDefinition.nFields
            nComponents=3;
            for i=1:nComponents
                for v=1:nv
                    if vi(i)>=v
                        %fprintf('Reading n=%i, v=%i, i=%i\n',n,v,i);
                        NodeCoordinates(i,v)=fscanf(f,'%f',1); 
                        if indDer(i)>0 %Only if the file has derivatives
                            for j=1:7
                                derivatives(i,j,v) = fscanf(f,'%f',1);
                            end
                        end
                        % Each version is written in two lines in the original file:
                        l=l+2;
                    end
                end
            end
        %end
            tline = fgetl(f);
            % DATA IN EXNODE WAS STORED LIKE:
            %    x.  Value index= 1, #Derivatives= 7 (d/ds1,d/ds2,d2/ds1ds2,d/ds3,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3)
            %    y.  Value index= 9, #Derivatives= 7 (d/ds1,d/ds2,d2/ds1ds2,d/ds3,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3)
            %    z.  Value index=17, #Derivatives= 7 (d/ds1,d/ds2,d2/ds1ds2,d/ds3,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3)
            % The first version:
            EXmesh.versions(n,1:3)    = vi;
            EXmesh.duds1(n,1:3)       = derivatives(:,1,1);
            EXmesh.duds2(n,1:3)       = derivatives(:,2,1);
            EXmesh.duds3(n,1:3)       = derivatives(:,4,1);
            EXmesh.duds12(n,1:3)      = derivatives(:,3,1);
            EXmesh.duds13(n,1:3)      = derivatives(:,5,1);
            EXmesh.duds23(n,1:3)      = derivatives(:,6,1);
            EXmesh.duds123(n,1:3)     = derivatives(:,7,1);
            EXmesh.coordinates(n,1:3) = NodeCoordinates(:,1);
            for i=1:3
                if vi(i)==2
                    EXmesh.duds1(n,i,2)       = derivatives(i,1,2);
                    EXmesh.duds2(n,i,2)       = derivatives(i,2,2);
                    EXmesh.duds3(n,i,2)       = derivatives(i,4,2);
                    EXmesh.duds12(n,i,2)      = derivatives(i,3,2);
                    EXmesh.duds13(n,i,2)      = derivatives(i,5,2);
                    EXmesh.duds23(n,i,2)      = derivatives(i,6,2);
                    EXmesh.duds123(n,i,2)     = derivatives(i,7,2);
                    EXmesh.coordinates(n,i,2) = NodeCoordinates(i,2);
                end
            end
            % CAUTION!!! the "empty versions" of the node fields should be filled in
            % order to have a congruent representation. Duplicates of the first version
            % are introduced:
            for i=1:3
                if vi(i)==2
                    for j=1:3
                        if vi(i)>vi(j)
                            EXmesh.duds1(n,j,2)       = derivatives(j,1,1);
                            EXmesh.duds2(n,j,2)       = derivatives(j,2,1);
                            EXmesh.duds3(n,j,2)       = derivatives(j,4,1);
                            EXmesh.duds12(n,j,2)      = derivatives(j,3,1);
                            EXmesh.duds13(n,j,2)      = derivatives(j,5,1);
                            EXmesh.duds23(n,j,2)      = derivatives(j,6,1);
                            EXmesh.duds123(n,j,2)     = derivatives(j,7,1);
                            EXmesh.coordinates(n,j,2) = NodeCoordinates(j,1);
                        end
                    end
                end
            end
       end
       function [FieldDefinition,l] = GetFieldDefinition(f,tline,l)
            % Get the number of fields:
            bEqualSignFound=0; iPosition=8;
            while(~bEqualSignFound)
                if tline(iPosition)=='='
                    bEqualSignFound=1;
                else
                    iPosition=iPosition+1;
                end
            end
            nFields = str2double(tline(iPosition+1:end));
            nCharForNames = [];
            Names = [];
            for iField=1:nFields
                tline = fgetl(f); l=l+1;           % get   1) coordinates, coordinate, rectangular cartesian, #Components=3
                % TODO: It is supposed that the coordinate field is the first one!
                if iField>1
                    % Get the name of the field:
                    index1 = find(tline==')');
                    index2 = find(tline==',');
                    name   = CubicMeshClass.deblank2(tline(index1(1)+1:index2(1)));
                    Names = [Names name];
                    nCharForNames = [nCharForNames length(name)];
                else % TODO: The same definition is supposed for all fields:
                    tline = fgetl(f); l=l+1;           % get     x.  Value index= 1, #Derivatives= 7 (d/ds1,d/ds2,d2/ds1ds2,d/ds3,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3)
                    Xindexes = CubicMeshClass.GetIndexes(tline);
                    Xversions = CubicMeshClass.GetVersions(tline);
                    tline = fgetl(f); l=l+1;           % get     y.  Value index= 9, #Derivatives= 7 (d/ds1,d/ds2,d2/ds1ds2,d/ds3,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3)
                    Yindexes = CubicMeshClass.GetIndexes(tline);
                    Yversions = CubicMeshClass.GetVersions(tline);
                    tline = fgetl(f); l=l+1;           % get     z.  Value index= 17, #Derivatives= 7 (d/ds1,d/ds2,d2/ds1ds2,d/ds3,d2/ds1ds3,d2/ds2ds3,d3/ds1ds2ds3)
                    Zindexes = CubicMeshClass.GetIndexes(tline);
                    Zversions = CubicMeshClass.GetVersions(tline);
                    FieldDefinition.versions = [Xversions Yversions Zversions];
                    FieldDefinition.indexes = [Xindexes Yindexes Zindexes];
                end
            end
            FieldDefinition.nFields = nFields;
            FieldDefinition.Names   = Names;
            FieldDefinition.nCharForNames   = nCharForNames;
       end
       function [Indexes]   = GetIndexes(tline)
           keyword = 'index=';
           I1= CubicMeshClass.FindString(tline,keyword);
           I2=find(tline==',');
           LineChar1 = I1(1)+length(keyword);
           LineChar2 = I2(1)-1;
           ValueIndex = int8(str2double(tline(LineChar1:LineChar2)));
           keyword = 'Derivatives=';
           I=CubicMeshClass.FindString(tline,keyword);
           I2=find(tline=='(');
           DerivativesIndex = int8(str2double(tline(I+length(keyword):I2(1)-1)));
           Indexes = [ValueIndex DerivativesIndex];
       end
       function [index]     = FindString(tline,string)
           nChar = length(tline);
           nCst  = length(string);
           nI=0;
           index=NaN;
           for i=1:nChar-nCst
               if strcmp(tline(i:i+nCst-1),string)
                   nI=nI+1;
                   index(nI)=i;
               end
           end
           if isnan(index(1)) % Marta
               fprintf(1,'WARNING! String not found!\n');
           end
       end
       function [NumerOfVersions] = GetVersions(tline)
           index = find(tline=='o');   % The letter 'o' is unique to the word 'version', and is the criteria defined to identify it!
           if (index~=0)               % We have more versions!
               NumerOfVersions = str2num(tline(index+4:end));                              
           else
               NumerOfVersions = 1;
           end
       end
       function [voxel]     = Point2Voxel(point,Image2PhysicalTransformation)
           % Change of coordinates, but without getting the integer value
           % of the voxel index!!
           sampling = resize(Image2PhysicalTransformation.sampling,1,3);
           origin   = resize(Image2PhysicalTransformation.origin  ,1,3);
           point    = resize(point, 1,3);
           voxel = (point-origin)./sampling;
       end
       function [point]     = Voxel2Point(voxel,Image2PhysicalTransformation)
           sampling = resize(Image2PhysicalTransformation.sampling,1,3);
           origin   = resize(Image2PhysicalTransformation.origin  ,1,3);
           voxel    = resize(voxel, 1,3);
           point = (voxel.*sampling + origin);
       end
       function [distances] = CalculeSquaredDistancesBetweenAllPoints(points)
          % Number of nodes:
          np=length(points);
          % index of distances
          nd=0;
          % Initialize distances:
          tnd=sum(1:np-1); %Total number of distances between pairs of points
          distances(tnd)=0;
          for i=1:np
              for j=i+1:np
                  nd=nd+1;
                  n1=points(i,:);
                  n2=points(j,:);
                  distances(nd)=(n1(1) - n2(1))^2 + (n1(2) - n2(2))^2 + (n1(3) - n2(3))^2;
                  %distances(nd)=CalculeSquaredDistanceBetween2Points(points(i,:),points(j,:));
              end
          end
          if (nd~=tnd), fprintf(1,' ERROR: not all distances were calcualted as expected\n'); end
       end
       function [distances] = CalculeDistancesBetweenAllPoints(points)
          % Number of nodes:
          np=length(points);
          % index of distances
          nd=0;
          % Initialize distances:
          tnd=sum(1:np-1); %Total number of distances between pairs of points
          distances(tnd)=0;
          for i=1:np
              for j=i+1:np
                  nd=nd+1;
                  n1=points(i,:);
                  n2=points(j,:);
                  distances(nd)=sqrt((n1(1) - n2(1))^2 + (n1(2) - n2(2))^2 + (n1(3) - n2(3))^2);
                  %distances(nd)=CalculeSquaredDistanceBetween2Points(points(i,:),points(j,:));
              end
          end
          if (nd~=tnd), fprintf(1,' ERROR: not all distances were calcualted as expected\n'); end
       end
       function [NormalisedMatrix] = Normalise(matrix)
           % The assumption taken is that the vector components are indexed
           % by the last dimension of the matrix
           N = ndims(matrix);
           Module = sqrt(sum(matrix.^2,N));
           NormalisedMatrix = matrix;
           % Avoid the NaNs: (needed for the computation of orthogonality
           % for example, where you don't want NaNs)
           Module(Module==0) = 1;
           
               nComponents = size(matrix,N);               
               switch N
                   case 1, NormalisedMatrix = matrix/Module;
                   case 2, for iC=1:nComponents, NormalisedMatrix(:,iC) = matrix(:,iC)./Module; end
                   case 3, for iC=1:nComponents, NormalisedMatrix(:,:,iC) = matrix(:,:,iC)./Module; end
                   case 4, for iC=1:nComponents, NormalisedMatrix(:,:,:,iC) = matrix(:,:,:,iC)./Module; end
                   case 5, for iC=1:nComponents, NormalisedMatrix(:,:,:,:,iC) = matrix(:,:,:,:,iC)./Module; end
                   case 6, for iC=1:nComponents, NormalisedMatrix(:,:,:,:,:,iC) = matrix(:,:,:,:,:,iC)./Module; end
                   case 7, for iC=1:nComponents, NormalisedMatrix(:,:,:,:,:,:,iC) = matrix(:,:,:,:,:,:,iC)./Module; end
                   case 8, for iC=1:nComponents, NormalisedMatrix(:,:,:,:,:,:,:,iC) = matrix(:,:,:,:,:,:,:,iC)./Module; end
                   otherwise
                       fprintf('ERROR in Normalise: number of dimensions not coded yet (maximum is 8)\n')
                       fprintf('                    matrix dimension  = %i\n',N);
               
               end
           
       end
       function [distance]  = DistanceBetweenTwoPoints(P1,P2)
           distance = sqrt( (P1(1)-P2(1))^2 + (P1(2)-P2(2))^2 + (P1(3)-P2(3))^2 );
       end
       function [x y z]     = BuildVector(centre,direction,scale)
           x(1) = centre(1);
           y(1) = centre(2);
           z(1) = centre(3);
           x(2) = centre(1) + direction(1) * scale;
           y(2) = centre(2) + direction(2) * scale;
           z(2) = centre(3) + direction(3) * scale;
       end
       
       function tureOrFalse = inRange(x,range, tol)
            if(nargin<3)
                tol=0;
            end
            tureOrFalse=1;
            for i=1:length(x)
                if(x(i)<range(1,i)-tol || x(i)>range(2,i)+tol)
                    tureOrFalse = 0;
                    break;
                end    
            end
        end

        function [SlicePlane] = ChooseSlicePlaneForCMGUI(spacing)
               % In cmGui, an image can be generated provided that the
               % pixel spacing in each image plane is the same in both
               % vertical and horizontal directions. The choice of the
               % SlicePlane is done here accordingly:
               
               epsilon = 0.001;
               if abs(spacing(1)-spacing(2))<epsilon
                   % It might be the case that it is isotropic in any of
                   % other two pairs of dimensions:
                   SlicePlane = 'Z';
               else
                   if abs(spacing(1)-spacing(3))<epsilon
                       SlicePlane = 'Y';
                   else
                       if abs(spacing(2)-spacing(3))<epsilon
                           SlicePlane = 'X';
                       else
                           fprintf(1,'WARNING! Not possible to generate binary with cmGui since the spacing is not the same in TWO directions. \n');
                           fprintf(1,'         Spacing = (%1.5f,%1.5f,%1.5f) \n',spacing);
                           SlicePlane = 'E';
                       end
                   end
               end
        end
       
        function [] = CheckDir(Dir)
            if ~exist(Dir,'dir'), mkdir(Dir); end
        end
        
   % Hermite Basis functions
       function [CL1]     = CubicLagrange1(xhi)
           % DENOMINATOR: ((0-1/3)*(0-2/3)*(0-1)) = -2/9
           CL1 = ((xhi - 1/3).*(xhi-2/3).*(xhi-1)) / (-2/9);
       end
       function [CL2]     = CubicLagrange2(xhi)
           % DENOMINATOR: ((2/3 - 0)*(2/3-1/3)*(2/3-1)) = -2/27
           CL2 = (xhi.*(xhi - 1/3).*(xhi-1)) / (-2/27);          
       end
       function [CL3]     = CubicLagrange3(xhi)
           % DENOMINATOR: ((1/3-0)*(1/3-2/3)*(1/3-1)) = 2/27
           CL3 = (xhi.*(xhi-2/3).*(xhi-1)) / (2/27);
       end
       function [CL4]     = CubicLagrange4(xhi)
           % DENOMINATOR: ((1-0)*(1-1/3)*(1-2/3)) = 2/9
           CL4 = (xhi.*(xhi - 1/3).*(xhi-2/3)) / (2/9);
       end
       function [CBF01]     = CubicHermite1(xhi)
           CBF01 = 1 - 3*xhi.^2 + 2*xhi.^3;
       end
       function [CBF02]     = CubicHermite3(xhi)
           CBF02 = xhi.^2 .* (3 - 2*xhi);
       end
       function [CBF11]     = CubicHermite2(xhi)
           CBF11 = xhi.*(xhi - 1).^2;
       end
       function [CBF12]     = CubicHermite4(xhi)
           CBF12 = xhi.^2 .* (xhi-1);
       end

        function [DCBF01]   = derCubicHermite1(xhi)
            %CBF01 = 1 - 3*xhi.^2 + 2*xhi.^3;
            DCBF01 =   - 6*xhi    + 6*xhi.^2;
        end
        function [DCBF02]   = derCubicHermite3(xhi)
            %CBF02 =   xhi.^2 .* (3 - 2*xhi);
            DCBF02 =          6*xhi - 6*xhi.^2;
        end
        function [DCBF11]   = derCubicHermite2(xhi)
            %CBF11 = xhi.*(xhi - 1).^2 = xhi.^3 - 2*xhi.^2 +xhi
            DCBF11 =                   3*xhi.^2 - 4*xhi +1;
        end
        function [DCBF12]   = derCubicHermite4(xhi)
            %CBF12 = xhi.^2 .* (xhi-1);
            DCBF12 = 3*xhi.^2 - 2*xhi;
        end
   end
end

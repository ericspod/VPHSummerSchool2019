function [CHmesh,TransformationToMakeBaseHorizontal] = MakeFlatBase(CHmeshIN,options)
% Function to make a flat base in the heart:
% 1. Fit base nodes in a plane
% 2. Project node coordinates to that plane
% 3. Project the corresponding cross derivatives in the plane
%
% Option:
% 1: Find the best plane fit of the base nodes and reorient the whole shape
% to align with Z axis
% 2: Find the best plane fit of the base, but do not reorient the shape
% 3: Do not find the best plane, which is suppossed as [0 0 -1], simply
% correct the base nodes to be in this plane.
% 
% 20/01/12: no need to define the templateID, it is automatically detected
% after an analysis of the topology with GetCardiacMeshTopology.m. This
% parameter is removed from the list of optional parameters.
% 18/01/11: option of making the base circular (for D.Nordsletten's need of
% the inpunt inflow and outflow of valve planes)
% 05/08/10: output the transformation parameters used to make the base
% horizontal (will be needed to relate simulation results to the original
% image space)
% 22/04/10: choose the right derivatives to be flatened! duds1 is not
% longer the one to be flatened, but duds2 (after the redefinition of local
% coordinates in the generated ellipsoids and hearts). Therefore, it's
% duds13 and not duds23 the double cross derivative to make flat...
% 14/04/10: introduce flatenning options

% Two fitting options are tried, the first one is bugged...
fittingOption=2;
CHmesh = CHmeshIN;

% Default options:
bVisualizeFitting = 0;
FlatOption=1;
bMakeLVaCircle=0;
% A flag statin that, so far, shape is not oriented in the vertical
% direction:
bShapeNotReoriented = 1;

if nargin>=2
    if isfield(options,'bMakeLVaCircle'), bMakeLVaCircle = options.bMakeLVaCircle; end
    if isfield(options,'FlatOption'), FlatOption = options.FlatOption; end
    if isfield(options,'bVisualizeFitting'), bVisualizeFitting = options.bVisualizeFitting; end
end
% if nargin<3
%     templateID=1;
% end

meshTopology = GetCardiacMeshTopology(CHmeshIN);
ListOfBaseNodes = meshTopology.basalNodes;
if bMakeLVaCircle > 1
    fprintf('WARNING! looks as if user introduced TemplateID, but this is a parameter not needed any more for making a flat surface, parameter ignored\n');
    bMakeLVaCircle=0;    
end
if(bMakeLVaCircle)
    fprintf('WARNING! Function not prepared to make a circular base of a LV of different thickness than 2 elements\n');        
    allbasalnodes = sort(ListOfBaseNodes);
    ListOfBaseNodesPerLayer(1,:) = allbasalnodes(1):3:allbasalnodes(end); %endo
    ListOfBaseNodesPerLayer(2,:) = allbasalnodes(2):3:allbasalnodes(end);
    ListOfBaseNodesPerLayer(3,:) = allbasalnodes(3):3:allbasalnodes(end); % epi
end

TransformationToMakeBaseHorizontal.scale = NaN;
TransformationToMakeBaseHorizontal.rotation = NaN;
TransformationToMakeBaseHorizontal.centre = NaN;
%% Parameters 
switch FlatOption
    case 1
        bFindFittingPlane = 1;
        bCorrectBaseNodes = 1;
        bReorientShape    = 1;
    case 2
        bFindFittingPlane = 1;
        bCorrectBaseNodes = 1;
        bReorientShape    = 0;
    case 3
        bFindFittingPlane = 0;
        bCorrectBaseNodes = 1;
        bReorientShape    = 0;
        normal = [0 0 -1];
end
if (bMakeLVaCircle)
    bCorrectBaseNodes = 1;
end
% The list is obtained through a cmGUI visualization of the mesh:
% switch templateID
%     case 1
%         ListOfBaseNodes = [26:33,62:72,98:105];
%     case 2  % For meshes with other indexes for the base nodes:
%         ListOfGIN = [26:33,62:72,98:105];
%         nNodes = length(ListOfGIN);
%         ListOfBaseNodes = zeros(1,nNodes);
%         for i=1:nNodes
%             ListOfBaseNodes(i) = find(CHmeshIN.GIN==ListOfGIN(i));
%         end
%     case 3 % ellipsoid of 7 9 2 elements
%         % ListOfBaseNodes = [190:216]; used when the nodes were not
%         % reordered!
%         ListOfBaseNodes = 166:192;
%     case 4 % ellipsoid of 3 4 1 elements
%         ListOfBaseNodes = 19:26;
%     case 5  % Prototype V,VI,VII with 9 elements in circumferential
%         ListOfBaseNodes = [160:183 199:204];        
%     case 6 % ellipsoid of 7 8 2 elements
%         % ListOfBaseNodes = [190:216]; used when the nodes were not
%         % reordered!
%         ListOfBaseNodes = 148:171;
%     case 7 % heart with 7 12 2 elements, and Level_RVjoint = 6
%         ListOfBaseNodes = [220:252 254 255 257 258 260 261];
%     case 8 % heartMedIA
%         ListOfBaseNodes = [163:186 196:201];
%     case 9 % LV882
%         ListOfBaseNodes = 172:195;
%         nNodesRadial=3;
%         nNodesCircunf=8;
%         ListOfBaseNodesPerLayer(1,:) = 172:3:193; %endo
%         ListOfBaseNodesPerLayer(2,:) = 173:3:194;
%         ListOfBaseNodesPerLayer(3,:) = 174:3:195; % epi
%     case 10 %BiV892, 231 nodes
%         ListOfBaseNodes = [191:216 228:231];
%     case 11 %BiV892, 234 nodes
%         ListOfBaseNodes = [190:215 231:234];
% 
%     case 12 % ellipsoid of 8 9 2 elements
%         % ListOfBaseNodes = [190:216]; used when the nodes were not
%         % reordered!
%         ListOfBaseNodes = 193:219;
%     case 13 % ellipsoid of 8 8 2 elements:
%         ListOfBaseNodes = 172:195;
%     case 14 %BiV892, 237 nodes
%         ListOfBaseNodes = [189:214 234:237];
%     case 15 %BiV892, 240 nodes
%         ListOfBaseNodes = [188:213 237:240];
% end

nPoints = numel(ListOfBaseNodes);
if (bFindFittingPlane)
    [plane bShapeNotReoriented] = GetBasalPlane(CHmeshIN,ListOfBaseNodes);
    normal = plane(1:3);
end


%% 2. Correct nodes and derivatives:
if (bCorrectBaseNodes)
    CHmesh = CHmeshIN;
    fprintf(1,'    *** Need to correct the base nodes of the shape, normal to base =  (%1.1f,%1.1f,%1.1f) ***\n',normal);
    fprintf(1,'    *** Orientation convention %i in the mesh! ***\n',CHmesh.OrientationOption);
    x2 = zeros(1,nPoints);
    y2 = zeros(1,nPoints);
    z2 = zeros(1,nPoints);
    for i=1:nPoints
        iNode=ListOfBaseNodes(i);
        nVersions = max(CHmeshIN.versions(iNode,:));
    %     if nVersions>1
    %         bDebug=1;
    %     else
            bDebug=1;
    %    end
        for v=1:nVersions
            if (bDebug)
                if iNode==164
                    fprintf('      Before             After  in node %i version %i\n',iNode,v);
                end
            end
            % 2.1 Place nodes in the projection to the plane:
            %(iNode,iCoor,iNodeValue,version)
            point = CHmeshIN.GetNodeCoorValue(iNode,1:3,1,v); %coordinates(iNode,1:3,v);
            PointInPlane = ProjectPoint2Plane(point,plane);
            CHmesh = CHmesh.SetNodeCoorValue(PointInPlane,iNode,1:3,1,v); %CHmesh.coordinates(iNode,1:3,v)=PointInPlane;
            x2(i) = PointInPlane(1);
            y2(i) = PointInPlane(2);
            z2(i) = PointInPlane(3);

            % 2.2 In the case of the heart, it depends on the orientation of xi coordinates.
            % change the duds1 and duds3, the
            % derivatives that must be paralell to the base plane:            
            switch CHmesh.OrientationOption
                case 2                    
                    Der2Flat(1,:) = 'duds2 '; dofindex(1) = 3;
                    Der2Flat(2,:) = 'duds3 '; dofindex(2) = 4;
                    Der2Flat(3,:) = 'duds23'; dofindex(3) = 7;
                case 3
                    Der2Flat(1,:) = 'duds1 '; dofindex(1) = 2;
                    Der2Flat(2,:) = 'duds3 '; dofindex(2) = 4;
                    Der2Flat(3,:) = 'duds13'; dofindex(3) = 6;
            end
            for iDer=1:3
                dof2flat = dofindex(iDer);
                vector = CHmeshIN.GetNodeCoorValue(iNode,1:3,dof2flat,v); %derivatives.duds2(iNode,1:3,v);
                vectorInPlane = ProjectVector2Plane(PointInPlane,vector,plane);
                CHmesh = CHmesh.SetNodeCoorValue(vectorInPlane,iNode,1:3,dof2flat,v);
                %CHmesh.derivatives.duds2(iNode,1:3,v)=vectorInPlane;
                if (bDebug), 
                    if iNode==164, fprintf('%s (%1.1f,%1.1f,%1.1f) (%1.1f,%1.1f,%1.1f) \n',Der2Flat(iDer,:),vector,vectorInPlane); end
                end
            end
        end
    end
    CHmesh = CHmesh.Update();
    % Check the fitting visually
    if (bVisualizeFitting)
        figure('Color',[1 1 1]); hold on;
        plot3(x,y,z,'*b');
        plot3(x2,y2,z2,'or');
        CHmesh.plotWireframe();
        axis equal;
        title('Surface made flat, with points before and after the process')
        %cmGuiViewMesh(CHmesh.DataDir,CHmesh);
    end
end

%% 3. Orient the shape to have the normal to this flat surface pointing in +Z
if bReorientShape && bShapeNotReoriented
    fprintf(1,'    *** Need to reorient the shape ***\n');
    scale=[1 1 1];
    % Normal to the plane is:
    rotation = MakeRotationFromTwoNormalVectors([0 0 -1],normal);
    centre = mean(CHmeshIN.GetNodeCoorValue(1:CHmeshIN.nNodes,1:3,1,1),1);  % (nNodes x 3 x versions)
    CHmesh = CHmesh.TransformMesh(scale,rotation,centre);
    TransformationToMakeBaseHorizontal.scale = scale;
    TransformationToMakeBaseHorizontal.rotation = rotation;
    TransformationToMakeBaseHorizontal.centre = centre;
    CHmesh = CHmesh.Update();
end


if (bMakeLVaCircle)
    BaseCoords = squeeze(CHmesh.GetNodeCoorValue(ListOfBaseNodes,1:3,1,1));%coordinates(ListOfBaseNodes,1:3,1));
    CircleCentre = mean(BaseCoords,1);
    % First, make an approximate circle
    radius = zeros(1,nNodesRadial);
    for iLayer=1:nNodesRadial
        points = CHmesh.GetNodeCoorValue(ListOfBaseNodesPerLayer(iLayer,:),1:3,1,1);
        radius(iLayer) = FitCircle(CircleCentre,points);
        for iN = 1:nNodesCircunf
            iNode = ListOfBaseNodesPerLayer(iLayer,iN);
            CHmesh = AdjustNodeValuesToCircle(iNode,CHmesh,CircleCentre,radius(iLayer),normal);
        end
    end    
    % Now, make the most perfect circle, by moving the coordinates to make
    % them evenly spaced in circumferential direction, and by setting the
    % tangent derivatives to have a module = arc-length
    for iLayer=1:nNodesRadial
        iNodes = ListOfBaseNodesPerLayer(iLayer,:);
        CHmesh = MakeBaseCircular(CHmesh,iNodes,CircleCentre,radius(iLayer),normal);
    end
    CHmesh = CHmesh.Update();
end


if (bVisualizeFitting)
    figure('Color',[1 1 1]); hold on;
    CHmesh.plotWireframe();
    CHmeshIN.plotWireframe('r');
    title('Surface made flat and oriented in +Z (before rotation in red)')
    axis equal;
    optView.CH2 = CHmeshIN;
    CHmesh = CHmesh.SetName([CHmeshIN.name 'flat']);
    CHmesh.WriteExFiles(CHmesh.DataDir);
    cmGuiViewMesh(CHmesh.DataDir,CHmesh,optView);
end
  
function [CHmesh] = MakeBaseCircular(CHmesh,iNodes,CircleCentre,radius,normal)
    points = squeeze(CHmesh.GetNodeCoorValue(iNodes,1:3,1,1)); %coordinates(iNodes,1:3,1);
    % Take a reference of 0� at first point, and then calculate the average
    % rotation in degrees of the "grid of evenly spaced nodes":
    nPoints = length(iNodes);
    RotationOffset = zeros(1,nPoints);
    AngularPosition= zeros(1,nPoints);
    RotationAngle  = zeros(1,nPoints);
    DeltaAngleEachElement = 2*pi/nPoints;
    for iP=1:nPoints
        p = points(iP,1:3);
        c = CircleCentre;
        RadialVector = p-c;
        UnitaryRadialVector = NormaliseVector(RadialVector);
        if iP==1
            ReferenceUnitaryVectorForCos = UnitaryRadialVector;
            ReferenceUnitaryVectorForSin = cross(UnitaryRadialVector,normal);
            RotationOffset(iP) = 0;
            AngularPosition(iP)= 0;
        else
            SinAngle = dot(UnitaryRadialVector,ReferenceUnitaryVectorForSin);
            CosAngle = dot(UnitaryRadialVector,ReferenceUnitaryVectorForCos);            
            RotationAngle(iP) = atan(SinAngle/CosAngle);
            if CosAngle<0
                RotationAngle(iP) =  RotationAngle(iP) + pi;
            end
            AngularPosition(iP) = round(RotationAngle(iP)/DeltaAngleEachElement);
            RotationOffsetA = rem(RotationAngle(iP),DeltaAngleEachElement);
            RotationOffsetB = rem(2*pi-RotationAngle(iP),DeltaAngleEachElement);
            if abs(RotationOffsetA)<abs(RotationOffsetB)
                RotationOffset(iP) = RotationOffsetA;
            else
                RotationOffset(iP) = -RotationOffsetB;
            end
        end
    end
    RotationOff = mean(RotationOffset);
    switch CHmesh.OrientationOption
        case 2         
            xiCircunferential=2;
            xiRadial=3;
        case 3
            xiCircunferential=1;
            xiRadial=3;
    end
    DofDerCircumf = xiCircunferential+1;
    for iP=1:nPoints
        Position = AngularPosition(iP);
        Angle = Position * DeltaAngleEachElement + RotationOff; 
        RadialUnitaryVector = sin(Angle)*ReferenceUnitaryVectorForSin + cos(Angle)*ReferenceUnitaryVectorForCos;
        NewCoor = CircleCentre + radius*RadialUnitaryVector;
        iNode = iNodes(iP);
        CHmesh = CHmesh.SetNodeCoorValue(NewCoor,iNode,1:3,1,1);
        % The derivative must be:
        CircumfUnitaryVector = cross(RadialUnitaryVector,normal);
        CircumfModule = DeltaAngleEachElement*radius;
        NewDerCircumf = CircumfModule*CircumfUnitaryVector;
        CHmesh = CHmesh.SetNodeCoorValue(NewDerCircumf,iNode,1:3,DofDerCircumf,1);
    end

function [radius] = FitCircle(CircleCentre,points)
    % Equation of a circle:
% 1. Let N be a unit normal vector for the plane.
% 2. Let C be the circle center, and let R be the radius.
% 3. Let U be a unit vector from C toward a point on the circle.
% 4. Let V = N x U.
% 5. Let A be the paramter.
% 6. A point P is on the circle if...
% P = C + R cos(A) U + R sin(A) V

    % So, we already know the centre and the normal. The average radius is
    % just the average distance from the points to the centre!
    nPoints = numel(points)/3;
    points = reshape(points,nPoints,3);
    distances=zeros(1,nPoints);
    for iP=1:nPoints
        p=points(iP,1:3);
        c=CircleCentre;
        disVector = c-p;
        distances(iP) = Module(disVector);
    end
    radius = mean(distances);

function [CHmesh] = AdjustNodeValuesToCircle(iNode,CHmesh,CircleCentre,radius,normal)
    % The coordinate point
    nodeCoord = CHmesh.GetNodeCoorValue(iNode,1:3,1,1);
        d = (nodeCoord-CircleCentre);
        d = NormaliseVector(d);
        NewCoor = CircleCentre + d*radius;
    CHmesh = CHmesh.SetNodeCoorValue(NewCoor,iNode,1:3,1,1);
    % Now, the derivatives:
    % The different orientation options conventions:
    switch CHmesh.OrientationOption
        case 2         
            xiCircunferential=2;
            xiRadial=3;
        case 3
            xiCircunferential=1;
            xiRadial=3;
    end
    iDInCircDir=xiCircunferential+1;
    iDInRadiDir = xiRadial+1;
    % Fix the derivative in circumferential direction:
    DerivCircum = CHmesh.GetNodeCoorValue(iNode,1:3,iDInCircDir,1);
        % We want to project it to the tangent to the circle laying in the
        % plane of the base:
        RadialDirectionTowardsCentre = d;
        Normal2Plane = normal;
        TangentDirection = cross(RadialDirectionTowardsCentre,Normal2Plane);
        TangentDirectionUnitary = NormaliseVector(TangentDirection);
        ModuleNewDerivCircum = dot(DerivCircum,TangentDirectionUnitary);
        NewDerivCircum = TangentDirectionUnitary * ModuleNewDerivCircum;
    CHmesh = CHmesh.SetNodeCoorValue(NewDerivCircum,iNode,1:3,iDInCircDir,1);  
   
function [module] = Module(vector)
    module = sqrt(vector(1)^2 + vector(2)^2 + vector(3)^2);

function [VectorInPlane] = ProjectVector2Plane(PointInPlane,vector,plane)
Point1 = PointInPlane;
Point2 = ProjectPoint2Plane(PointInPlane+vector,plane);
VectorInPlane = Point2-Point1;

function [PointInPlane] = ProjectPoint2Plane(point,plane)
% Implementation of http://www.9math.com/book/projection-point-plane
u = point(1); v = point(2); w = point(3);
a = plane(1); b = plane(2); c = plane(3); d = plane(4);

D = (a*u + b*v + c*w +d)/(a^2 + b^2 + c^2);
x0 = u - a*D; y0 = v - b*D; z0 = w - c*D;

PointInPlane = [x0 y0 z0];

function [Rt] = MakeRotationFromTwoNormalVectors(v1,v2)
        % - V1, V2: Orientation matrices of each eigenanalysis. They will be needed
        % if the points want to be transformed after the PCA alignment (needed to
        % apply the right scaling). Rt = V1*V2';
        v1=reshape(v1,1,3);
        v2=reshape(v2,1,3);
        v1 = NormaliseVector(v1);
        v2 = NormaliseVector(v2);
%(1) calculate the angle from the first vector to the second as in (v dot w) / (||v|| * ||w||), 
        a = acos(sum(v1.*v2));
% (2) then build an axis perpendicular to both vectors as in (v cross w), 
        u = cross(v1,v2);
        u = NormaliseVector(u);
% (3) then build a rotation matrix from the given axis and the given angle
% see http://en.wikipedia.org/wiki/Rotation_matrix
        ux=u(1); uy=u(2); uz=u(3);
        c=cos(a);
        s=sin(a);
        Rt = [ux^2+(1-ux^2)*c     ux*uy*(1-c)-uz*s   ux*uz*(1-c)+uy*s;
              ux*uy*(1-c)+uz*s    uy^2+(1-uy^2)*c    uy*uz*(1-c)-ux*s;
              ux*uz*(1-c)-uy*s    uy*uz*(1-c)+ux*s   uz^2+(1-uz^2)*c];
        
function [v] = NormaliseVector(v)
v = v / Module(v);


function [ coordsOut ] = NeglectMeshDerivatives(coords, derivativesList, NumOfDerivatives)
    %Remove the selected derivatives from a matrix of coordinates
    %(typically of size [1168x3]) corresponding to a mesh model.

    %A mesh model has the shape of nodes coordinates + (7) derivatives
    %in the form: [coordinates duds1 duds2 duds3 duds12 duds13 duds23 duds123]

    %derivList is the list of derivatives indices in the form of:
    %derivList = [duds1 duds2 duds3 duds12 duds13 duds23 duds123]

    derivativeSize = 146; %default number of elements for each derivative
    derivList = [1 1 0 1 0 0 0]; %default keep only duds1, duds2 and duds12

    if(exist('NumOfDerivatives','var'))
        derivativeSize = NumOfDerivatives;
    end
    if(exist('derivativesList','var'))
        derivList = derivativesList;
    end

    [~,n] = size(derivList);
    j = 1;

    for i = 1:n
        if(derivList(i) == 0) %if derivative index is off, add its id to a list
            idList(j) = i;
            j=j+1;
        end
    end

    %for each derivative that needs to be neglected assign zeros to
    %correponding coordinates (in batches of 'derivativeSize', e.g. 146 elements)
    [~,n] = size(idList);
    for k=1:n 
        rangeStart = derivativeSize * idList(k);
        rangeEnd = rangeStart + derivativeSize;
        idZeros = (rangeStart)+1 : rangeEnd;
        coords(idZeros,:) = 0; %set this range to zero
    end

    coordsOut = coords;
end

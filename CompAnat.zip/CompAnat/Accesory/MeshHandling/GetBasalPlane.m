function [plane bShapeNotReoriented centre] = GetBasalPlane(CHmeshIN,ListOfBaseNodes)


nPoints = numel(ListOfBaseNodes);
x=zeros(nPoints,1);
y=zeros(nPoints,1);
z=zeros(nPoints,1);
for i=1:nPoints
    iNode=ListOfBaseNodes(i);
    % the second version of coordinates is not needed, it must be the same
    x(i)=CHmeshIN.GetNodeCoorValue(iNode,1,1,1); %coordinates(iNode,1,1);
    y(i)=CHmeshIN.GetNodeCoorValue(iNode,2,1,1); %coordinates(iNode,2,1);
    z(i)=CHmeshIN.GetNodeCoorValue(iNode,3,1,1); %coordinates(iNode,3,1);
end
X = [x y z];

%% 1. Fit in a plane:
fprintf(1,'    *** Need to find the plane fitting the base nodes ***\n');
%     switch fittingOption
%         case 1
%             % data (x(i),y(i),z(i))
%             % model a*x+b*y+c*z+d=0, a^2+b^2+c^2=1
%             % THIS OPTION IS BUGGED!
%             A=[x,y,z,ones(nPoints,1)];
%             [U,S,V]=svd(A);
%             ss=diag(S);
%             i=find(ss==min(ss)); % find position of minimal singular value
%             coeff=V(:,min(i)); % this may be multiple
%             plane=coeff/norm(coeff(1:3),2);
%         case 2
            [coeff] = pca(X);
            basis = coeff(:,1:2);
             normal = coeff(:,3);
             plane(1:3)= normal;
             centre = mean(X,1);
             plane(4) = -plane(1:3)*centre';
%     end
% end

% CONVENTION: the base is realigned into -Z, and, in order to solve the
% ambiguity of the sense of the normal vector to the plane fitting the base
% nodes, we suppose that the initial orientation of this normal vector has
% its Z component negative, or we correct it:
normal = reshape(normal,1,3);
if normal(3)>0
    normal = - normal;
end
plane(1:3)= normal;
centre = mean(X,1);
plane(4) = -plane(1:3)*centre';
bShapeNotReoriented = 1;
if (abs(normal)==[0 0 1])
    bShapeNotReoriented = 0;
end
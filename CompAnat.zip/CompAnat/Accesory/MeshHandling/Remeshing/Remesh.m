%function [NameGoodCH] = Remesh(dirCH,NameBadCH,template,NameInitialMesh)
% Function to refit a mesh to an already existing one, with the aim to
% improve the regularity of its elements.
% 
% INPUT:
% - dirCH: directory where the "old bad mesh" is.
% - NameBadCH: name of the file of the mesh of "bad quality"
% - template: to use for the refitting.

dirCH = '../../../HotData/Remeshing/';
TempDir = [dirCH '/temp/'];
NameBadCH = 'inflation_step_5';
template = 'HeartTemplate/HeartMedIA';
NameInitialMesh = 'case8VentriclesClean2_g4D4_ss444_fitted2heartMedIA_ini3_byM2_Vfit1_ForSim';
tempBinary = [dirCH 'TempBinary.vtk'];
NameGoodCH = 'TempBinary_mesh';
NameNewInitialMesh = 'NewInitialMesh';
DeformationFileName = 'Deformation';

bRebuildMesh = 1;
bCalculateDF = 1;
bResultsCheck= 1;
bWarpBack    = 1;
    bDebugDilation=1;



CHinit  = CubicHermiteMesh4([dirCH NameInitialMesh]);
if(bRebuildMesh)
    fprintf('=================================================\n');
    fprintf('1. Creating a binary image of existing "bad mesh"\n');
    fprintf('=================================================\n');
    CH = CubicHermiteMesh4([dirCH NameBadCH]);
    CH.TempcmGuiDir = TempDir;
    CH.TempBinaryDir= TempDir;
    % A high resolution of the binary image:
    VoxSpacing = [1 1 1];
    bCheckRewritting=1;
    if(bCheckRewritting)
        CH.name = 'Rewritten';
        CH.GroupName = 'Rewritten';
        CH.WriteExFiles(dirCH);
        cmGuiViewMesh(dirCH,CH);
        %figure; CH.plotExternalSurfaces();
        % Bug was in 
    end
    % TODO: check the I/O functionality, there is an error reading the ex files
    % coming from a simulation!!!

    CH.CreateBinImageVTK(tempBinary,VoxSpacing);

    fprintf('=================================================\n');
    fprintf('2. Warping the template %s\n',template);
    fprintf('=================================================\n');
    params.InputTemplate = template;
    params.InputBinary   = tempBinary;
    params.OutputDir     = dirCH;
    params.TempDir       = TempDir;
    params.bBATCHPROCESSING=0;
    params.bPrintCaptionFinalResult = 1;
    params.WhichNamingConvention = 'simple';
    params.bForceCreation_vFit0 = 1;
    params.InitOption = 3;
    params.rotZ = 45;
    % This might be needed, but first try with an increase of binary image resolution from 5 to 1:
    % A detailed registration is wanted here!
    % params.ShIRTNodeSpacing = 2;
    OutputShapes = HermitePersonalization(params);
    GoodCH = OutputShapes.Shape2vFit0;
    GoodCH.name = NameGoodCH;
    GoodCH.GroupName = NameGoodCH;
    fprintf('=================================================\n');
    fprintf('3. Saving the new "good mesh": %s\n',NameGoodCH);
    fprintf('=================================================\n');
    GoodCH.WriteExFiles(dirCH);
else
    CH      = CubicHermiteMesh4([dirCH NameBadCH]);
    GoodCH  = CubicHermiteMesh4([dirCH NameGoodCH]);
end
if(bResultsCheck)
    % Check the alignment between the "bad mesh" and the new "good mesh",
    % at the simulation point before crashing:
    ViewOptions.CH2 = GoodCH;
    cmGuiViewMesh(dirCH,CH,ViewOptions);
end
if(bCalculateDF)
    fprintf('=================================================\n');
    fprintf('4. Calculation of warping from inital config.\n');
    fprintf('  (given by mesh %s)\n',NameInitialMesh);
    fprintf('=================================================\n');
    % TODO: CHECK WHY THE DOFS HAVE DIFFERENT LENGHTS!
    % dofsBAD has 1680
    % dofsINI has 1644
    % - Hint: simulation fills secondary versions in all nodes for x,y,z,
    % regardless only x,y had secondary...??
    % HACK SOLUTION: change the mapping of dofsBAD:
    CH.valueIndices = CHinit.valueIndices;
    CH.nNewVersionsBasis = CHinit.nNewVersionsBasis;
    CH.NewBasisIndex = CHinit.NewBasisIndex;
    dofsINI     = CHinit.GetDofs();
    dofsBAD     = CH.GetDofs();
    deformation = dofsBAD-dofsINI;
    % HACK SOLUTION to define a vectorial field:
    CH.FibreDescriptionType =1;
    CH = CH.SetFibreDofs(deformation);
    CH = CH.BuildElementBoundingBoxes();
    fprintf('4.1 Writing a deformation field:\n');
    hdr = CH.ExportFieldDescription(dirCH,DeformationFileName);
    save([dirCH DeformationFileName '.mat'],'-append','hdr');
    delete(tempBinary);
else    
    GoodCH  = CubicHermiteMesh4([dirCH NameGoodCH]);
end
if(bResultsCheck)
    ViewOptions.ExtraCMGUIcommands = 'gfx read data Deformation.exdata\n gfx modify g_element points data_points glyph arrow_line\n';
    cmGuiViewMesh(dirCH,CHinit,ViewOptions);
end
if(bWarpBack)
    fprintf('=================================================\n');
    fprintf('5. "Good mesh" back to initial configuration\n');
    fprintf('=================================================\n');
    load([dirCH 'Deformation.mat']); 
    %loads 'Points' and 'Values' and 'hdr', the header during the export of
    %the deformation field:
    origin = hdr.origin;
    spacing= hdr.spacing;
    % Build the map:
    [na nb] = size(Values);
    nP = nb;
    map = [];
    for iP=1:nP
        CurrentPoint = Points(1:3,iP);
        ix = (CurrentPoint(1)-origin(1))/spacing(1) + 1;
        iy = (CurrentPoint(2)-origin(2))/spacing(2) + 1;
        iz = (CurrentPoint(3)-origin(3))/spacing(3) + 1;
        if ix<0
            fpritnf('error\n');
        end
        map.x(ix,iy,iz) = Points(1,iP);
        map.y(ix,iy,iz) = Points(2,iP);
        map.z(ix,iy,iz) = Points(3,iP);
        map.u(ix,iy,iz) = Values(1,iP);
        map.v(ix,iy,iz) = Values(2,iP);
        map.w(ix,iy,iz) = Values(3,iP);
    end
    % "Dilate the map": deformation was only defined in terms of nodes
    % inside the domain, and the interpolation needs the external ones
    % also: a dilation operation is needed in eaxh component.
    if(bDebugDilation), figure; subplot(211), imagesc((map.u(:,:,5))); end
    NewMap = map;
    for iP=1:nP
        CurrentPoint = Points(1:3,iP);
        ix = (CurrentPoint(1)-origin(1))/spacing(1) + 1;
        iy = (CurrentPoint(2)-origin(2))/spacing(2) + 1;
        iz = (CurrentPoint(3)-origin(3))/spacing(3) + 1;
        
        if map.u(ix,iy,iz)==0 && map.v(ix,iy,iz)==0 && map.w(ix,iy,iz)==0
            NewMap.u(ix,iy,iz) = AverageNonceroNeighbours(map.u,ix,iy,iz);
            NewMap.v(ix,iy,iz) = AverageNonceroNeighbours(map.v,ix,iy,iz);
            NewMap.w(ix,iy,iz) = AverageNonceroNeighbours(map.w,ix,iy,iz);
        end
    end
    map = NewMap;
    if(bDebugDilation), subplot(212), imagesc((map.u(:,:,5))); end
    
    NewInitialMesh = DeformMeshByShapeFEInterp_M2(map,GoodCH);
    NewInitialMesh.name = NameNewInitialMesh;
    NewInitialMesh.GroupName = NameNewInitialMesh;
    NewInitialMesh.WriteExFiles(dirCH);
else
    NewInitialMesh = CubicHermiteMesh4([dirCH NameNewInitialMesh]);
end
if(bResultsCheck)
    % Check the alignment between the original and the new initial mesh:
    ViewOptions.CH2 = NewInitialMesh;
    ViewOptions.ExtraCMGUIcommands = 'gfx read data Deformation.exdata\n gfx modify g_element points data_points glyph arrow_line\n';
    cmGuiViewMesh(dirCH,CHinit,ViewOptions);
end
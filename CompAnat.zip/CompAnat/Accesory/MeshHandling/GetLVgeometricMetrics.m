function [metrics,OrientationMatrix] = GetLVgeometricMetrics(MeshOrPath,options)
% Function to compute the geometrical metrics in a left ventricle of:
% - MyoVol: Myocardial volume
% - BPVol: Blood pool volume
% - Length: apex to base distance (robust to topology, detecting the most
% distant point to the base)
% - Thickn average thickness in the ventricle
%
% INPUT: an instance of the CubicMeshClass, or the path to the EX data.
%
% OUTPUT: structure with the metrics.
%
% By Pablo Lamata

% Default options
bWriteMetrics = 0;
optionsGenBin = [];

if nargin>=2
    if isfield(options,'fileOut'),  fileOut = options.fileOut; bWriteMetrics = 1; end
    if isfield(options,'SlicePlane'),  optionsGenBin.SlicePlane = options.SlicePlane; end
end

% Default output:
MyoVol = NaN;
BPVol  = NaN;
Length = NaN;
Thickn = NaN;
ThSTD  = NaN;


if ischar(MeshOrPath)
    % Load the data:
    Mesh = CubicMeshClass(MeshOrPath);
else
    if isa(MeshOrPath,'CubicMeshClass')
        Mesh = MeshOrPath;
    else
        error('GetLVgeometricMetrics:argChk','Input not recognised (neither a path to EX data, nor a CubicMeshClass)');
    end
end

fprintf('Computing myocardial volume... \n');    
    MyoVol = Mesh.GetMeshVolume();

fprintf('Computing Blood Pool volume... \n');
    BPmesh = Create_LV_BloodPool(Mesh);
    BPVol  = BPmesh.GetMeshVolume();

fprintf('Computing length... \n');

% Need to identify the nodes of the mesh that point to the right ventricle
% from the LV centre. The convention in the generation of templates is that
% the septum is towards the +Y axis, and therefore a template mesh will
% have the "septal node" defined as the one with the largest Y component.
% Nevertheless, this is only feasible for a template, not any mesh!

    iRVnodes = 130;
    [OrientMatrix,Length] = GetLVmeshOrientation(Mesh,iRVnodes);

fprintf('Computing epi and endo max diameters... \n');
    % Images perpendicular to the main axis of inertia (estimated in
    % previous step) are generated, and the internal and external diameters
    % are estimated from them:
    VoxSize = Length / 100;  % In mm
    Centre = Mesh.GetMeshCentre();
    MeshR  = Mesh.rotateMesh(inv(OrientMatrix),Centre);
    SamplingResolution = [VoxSize VoxSize VoxSize];    
    [Bin,Hd] = MeshR.GenerateBinaryImage(SamplingResolution,optionsGenBin);
    % Start the search of the maximum diameters by the middle. The shape is
    % now aligned with the X axis, after "de-rotating" it:
    iStart = round(Hd.dim(1)/2);
    % initialise the search of maximums:
    BinImag = squeeze(Bin(iStart,:,:));
    [WallT,RadiusInVoxs] = EstimateWallThicknessFromSA(BinImag,'LV',eye(3));
    MaxRadiusInVoxs = NaN * ones(2,2);
    for iLayer = 1:2
        for iInc = 1:2
            increment = -1 + (iInc-1)*2;
            MaxRadiusInVoxs(iLayer,iInc) = GetMaxDiam(RadiusInVoxs(iLayer),iStart,increment,Bin,iLayer);
        end
    end
    EndoDiam = 2* max(MaxRadiusInVoxs(1,:)) * VoxSize;
    EpiDiam  = 2* max(MaxRadiusInVoxs(2,:)) * VoxSize;
    
fprintf('Computing thickness of wall... \n');
    [Thickn, ThSTD] = Mesh.EstimateThickness();
    
% Prepare output
density = 1.055; % https://www.physiology.org/doi/full/10.1152/ajpheart.00478.2003: a sedentary mammal such as the rat, cattle, or human, all of which have heart weight-to-body weight ratios of ?3�5 g/kg. The density of myocardium in these mammals is around 1.055 g/ml (35)
metrics.MyoVol = MyoVol;
metrics.BPVol  = BPVol;
metrics.Length = Length;
metrics.EndoDiam = EndoDiam;
metrics.EpiDiam = EpiDiam;
metrics.Thickn = Thickn;
metrics.ThSTD  = ThSTD;
metrics.Spher  = EpiDiam/Length;
metrics.LVM2vol= MyoVol*density/BPVol;

if(bWriteMetrics)
    fid = fopen(fileOut,'w');
    if fid~=-1
        fprintf('Writting geometrical metrics to %s\n',fileOut);
        fprintf(fid,'MyoVol(l)   = %1.5f\n',metrics.MyoVol/1000);
        fprintf(fid,'BPVol(l)    = %1.5f\n',metrics.BPVol/1000); 
        fprintf(fid,'Length(mm)   = %1.5f\n',metrics.Length); 
        fprintf(fid,'EndoDiam(mm) = %1.5f\n',metrics.EndoDiam); 
        fprintf(fid,'EpiDiam(mm)  = %1.5f\n',metrics.EpiDiam); 
        fprintf(fid,'Thickn(mm)   = %1.5f\n',metrics.Thickn); 
        fprintf(fid,'ThSTD(mm)    = %1.5f\n',metrics.ThSTD); 
        fprintf(fid,'Sphericity   = %1.5f\n',metrics.Spher);
        fprintf(fid,'LVM2vol(mg/ml) = %1.5f\n',metrics.LVM2vol);
        
        
        fclose(fid);
    else
        error('GetLVgeometricMetrics:fileNotFound',sprintf('not possible to open file %s',fileOut));
    end
end


function NewMax = GetMaxDiam(Max,iStart,increment,Bin,iLayer)
    CurrentMax = 0;
    iSlice = iStart;
    while CurrentMax < Max
        CurrentMax = Max;
        iSlice = iSlice + increment;
        BinImag = squeeze(Bin(iSlice,:,:));
        [WallT,Radius] = EstimateWallThicknessFromSA(BinImag,'LV',eye(3));
        Max = Radius(iLayer);
    end
    NewMax = CurrentMax;

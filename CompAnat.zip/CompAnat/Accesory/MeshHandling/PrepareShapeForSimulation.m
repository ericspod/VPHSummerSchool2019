function [ShapeForSim] = PrepareShapeForSimulation(Shape,dirOut,nameOut,FlatenningOption,bMakeCircularBase)
%
% Version control
% - 01/07/2013: realization no need of templateID any more (it was the
% fifth parameter in), since long time ago it was coded the automatic
% characterization of element and node layers.

    if ischar(Shape)
        Shape = CubicMeshClass(Shape);
    end
    bIPfiles=0;   
    bViewFlatteningResult=0;
    if nargin<5
        bMakeCircularBase=0;
    end
    fprintf(1,'  == Preparing shape for simulation: base flat, fibers. ==\n');
    
    % No need of templateID any more (21/01/2013):
    %[ShapeForSim,TransformationToMakeBaseHorizontal] = MakeFlatBase(Shape,FlatenningOption,templateID,bMakeCircularBase);
    opt.FlatenningOption = FlatenningOption;
    opt.bMakeCircularBase= bMakeCircularBase;
    [ShapeForSim,TransformationToMakeBaseHorizontal] = MakeFlatBase(Shape,opt);

    save(sprintf('%s%sTransf2BaseHoriz.mat',dirOut,nameOut),'TransformationToMakeBaseHorizontal');
    ShapeForSim = ShapeForSim.SetName(nameOut);
    ShapeForSim.WriteExFiles(dirOut);
    if(bIPfiles)
        ShapeForSim.WriteTrinilearIPELFB([dirOut nameOut '.ipelfb']);
        ShapeForSim.WriteIpFiles(nameOut,dirOut,dirOut);    
    end
    if(bViewFlatteningResult)
        cmguiparameters.CH2 = ShapeForSim;
        cmGuiViewMesh(dirOut,Shape,cmguiparameters);
    end
end
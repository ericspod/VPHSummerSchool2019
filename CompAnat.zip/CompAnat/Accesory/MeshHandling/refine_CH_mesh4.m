%% Written by Matthew Sinclair
% Last modified: 8/03/11
%--------------------------------------------------------------------------
% =============================
% Before running this function
% =============================
%
% - Ensure the directory 'PabloCubicHermite' is in your Matlab path.
% - Ensure that the exelem and exnode files you are loading in are in your
% Matlab path.
%--------------------------------------------------------------------------
% =============================
% Description
% =============================
%
% - This function refines a cubic hermite mesh.
% - exelem and exnode files are handled by Pablo's CubicHermiteMesh4 class.
% - Refinement is carried out in user-selected Xi directions.
% - Refinement is currently done in powers of 2 - i.e. elements are halved
% along Xi directions.
%
% -------------------------------------------------------------------------
% =============================
% Instructions
% =============================
%
% INPUTS:
%   (1) root name of exelem and exnode file (i.e. the part that precedes
%   the suffix). Referred to as the 'exfile' name.
%   (2) an array containing the Xi directions you want to refine in. This
%   restricts you to numbers between 1 and 3, with a max length of 3 (i.e.
%   for just Xi1: [1]. For all Xi directions: [1 2 3]).
%   (3) an array with the number of times you wish to halve elements in the
%   chosen Xi directions.
%   (4) output directory path for refined mesh and com viewing file for CMGUI.
%   (This will default to the current directory if there is no input).
%
% OUTPUTS:
%   (1) new exelem and exnode files, whose name is based on the
%   refinement options and the original 'exfile' name.
%   (2) The mesh structure object created by Pablo's 'CubicHermiteMesh4'
%   class in your workspace.
%
%--------------------------------------------------------------------------
% =============================
% Example
% =============================
%
% new_heart_template = refine_CH_mesh4('heart_template',[1 2], [3])
%
% This takes the files 'heart_template.exnode' and
% 'heart_template.exelem' for refinement.
%
% [1 2] will then refine elements into 2, first refining in
% the Xi1, and then in the Xi2 direction. [3] carries this out 3 times.

% Therefore, there will be (2*2)^(3) = 64 times the number of elements
% in the new mesh compared to the original.
%
% The mesh object 'new_heart_template' appears in the Matlab workspace.
%
% The output 'exfile' name will be:
%   'refined_heart_template_xi12_refinements3'
%--------------------------------------------------------------------------
% =============================
% Notes/To Do's
% =============================
%
% The function is coded such that refinements can only be performed on
% elements in divisions of two.
%
% The function is hard-coded to only handle 1 type of collapsed element,
% which are those found in the apex of Pablo's template meshes.
%
% The function is also coded only to handle nodes with a maximum of 2
% versions.
%
%--------------------------------------------------------------------------

function [obj] = refine_CH_mesh4(exfile, xi_list, refine_level, outdir)
%% ------------------------------------------------------------------------
tic

%outdir ='/home/Matt/Meshing/cm2carp/PabloCubicHermite/refinement_script/refined_meshes/';

% DEFAULT INITIALISATION
if nargin < 3
    xi_list = 1;
    refine_level = 1;
    disp('=================================================================')
    disp('Default: Refining by two in the Xi1 direction')
    disp('=================================================================')
end

% DEFAULT INITIALISATION
if nargin < 4
    outdir = [pwd '/'];
    disp('=================================================================')
    disp('Unspecificed output directory.')
    disp(['Using current directory for outputs: ' outdir])
    disp('=================================================================')
end

% Currently elements can only be refined by 2
n_xi_list = [2 2 2];

% Using Pablo's class CubicHermiteMesh
exnodefile = [exfile '.exnode'];
exelemfile = [exfile '.exelem'];
obj = CubicHermiteMesh4(exnodefile,exelemfile);
obj.MaxNeighbours = 240;


% Display total new number of elements
refinement_factor=(2^(length(xi_list)))^(refine_level);
new_number_of_elements = refinement_factor*obj.nElems;
disp('=================================================================')
disp(['Number of elements in the original mesh: ' num2str(obj.nElems)]);
disp(['Number of elements in the refined mesh: ' num2str(new_number_of_elements)]);
disp('=================================================================')

% New object name for output
xi_nums = regexprep(num2str(xi_list),' ','');
nxi_nums =  regexprep(num2str(n_xi_list),' ','');
obj.name = ['refined_' obj.name '_xi' xi_nums '_refinements' num2str(refine_level)];

%% ------------------------------------------------------------------------

% Loop over number of refinements (powers of 2)
for refine_i = 1:refine_level
    
    % Loop over Xi directions selected for refinement
    for xi_i = 1:length(xi_list)
        xi = xi_list(xi_i);
        n_xi = n_xi_list(xi_i);
        update_nN = obj.nNodes;
        original_nNodes = obj.nNodes;
        update_nE = obj.nElems;
        el_count = 0;
        used_nodes = [];
        new_N_list = [];
        vnodes= [];
        newNvalIndices = [];
        list_temp_versions = [obj.versions; int8(zeros(4*length(obj.versions),3))];
        
        % Initialising valueIndices
        NEWvalueIndices = zeros(update_nE*2,3,8,8);
        %TEMPvalueIndices = [obj.valueIndices; obj.valueIndices];
        for i = 1:8
            for j = 1:8
                NEWvalueIndices(:,:,i,j) = int8(j);
            end
        end
        
        % Loop over elements in mesh
        for i_el= 1:obj.nElems
            
            if i_el == 1
                disp(['Refining in Xi' num2str(xi) ' direction'])
            end
            disp(['Current Element: ' num2str(i_el)])
            
            nN = obj.nNofElem(i_el);
            giN = zeros(1,8);
            if length(obj.giNofElem(i_el,:))==6
                giN(1:6) = obj.giNofElem(i_el,:);
            else
                giN = obj.giNofElem(i_el,:);
            end
            liN = obj.liNofElem(i_el,:);
            count = 0;
            new_node_values = [];
            new_node_matrix = [];
            repeat_index = [];
            repeat_index2 = [];
            non_repeat_index = [];
            list_new_gNodes = [];
            
            if n_xi>1
                
                % loop over divisions in selected xi direction
                %for l = 0:1:n_xi
                for l = 1:(n_xi-1)
                    
                    % loop over xi directions in which there are no divisions
                    for i = 0:1
                        for j = 0:1
                            
                            % loop for NEW node values and derivatives
                            for k = 1:8
                                count = count+1;
                                if xi == 1
                                    new_node_values(count,1:3) = obj.evaluate(i_el,[l*(1/n_xi) j i],k);
                                elseif xi == 2
                                    new_node_values(count,1:3) = obj.evaluate(i_el,[j l*(1/n_xi) i],k);
                                elseif xi == 3
                                    new_node_values(count,1:3) = obj.evaluate(i_el,[j i l*(1/n_xi)],k);
                                end
                            end
                        end
                    end
                end
            end
            
            %% Nodes which have already been used to define a new node.
            % For collapsed elements - HARD CODED for Pablo templates.
            if xi == 1
                el_nodes_used = [giN(liN([1 2]));giN(liN([3 4]));giN(liN([5 6]));giN(liN([7 8]))];
                if nN == 6
                    new_node_values = new_node_values([9:16 25:32],:);
                    temp_el_nodes_used(1,:) = el_nodes_used(2,:);
                    temp_el_nodes_used(2,:) = el_nodes_used(4,:);
                    el_nodes_used = temp_el_nodes_used;
                end
            elseif xi == 2
                el_nodes_used = [giN(liN([1 3]));giN(liN([2 4]));giN(liN([5 7]));giN(liN([6 8]))];
            elseif xi == 3
                el_nodes_used = [giN(liN([1 5]));giN(liN([2 6]));giN(liN([3 7]));giN(liN([4 8]))];
                if nN == 6
                    new_node_values = new_node_values([9:32],:);
                    temp_el_nodes_used(1,:) = el_nodes_used(2,:);
                    temp_el_nodes_used(2,:) = el_nodes_used(3,:);
                    temp_el_nodes_used(3,:) = el_nodes_used(4,:);
                    el_nodes_used = temp_el_nodes_used;
                    
                end
            end
            
            %% Find nodes which have already been used
            if i_el>1
                for i = 1:length(el_nodes_used)
                    temp_nodes = el_nodes_used(i,:);
                    temp_rows = find(used_nodes(:,1)==temp_nodes(1));
                    if ~isempty(temp_rows)
                        temp_rows2 = find(used_nodes(temp_rows,2)==temp_nodes(2));
                        if ~isempty(temp_rows2)
                            % index for (4) current new nodes
                            repeat_index = [repeat_index i];
                            % index for position in (all) used nodes
                            repeat_index2 = [repeat_index2 temp_rows(temp_rows2)];
                        else
                            non_repeat_index = [non_repeat_index i];
                        end
                    else
                        non_repeat_index = [non_repeat_index i];
                    end
                end
                el_nodes_old = el_nodes_used(repeat_index,:);
                el_nodes_new = el_nodes_used(non_repeat_index,:);
            else
                el_nodes_new = el_nodes_used;
            end
            
            used_nodes = [used_nodes; el_nodes_new];
            
            if ~isempty(non_repeat_index)
                for i = 1:length(non_repeat_index)
                    new_node_matrix = [new_node_matrix; new_node_values((non_repeat_index(i)*8-7:non_repeat_index(i)*8),:)];
                end
            elseif isempty(non_repeat_index)
                new_node_matrix = [];
                if i_el ==1
                    new_node_matrix = [new_node_values];
                end
            end
            
            %% Check if current element nodes have been used already
            
            % new number of nodes, and index of new nodes in current element
            n = length(new_node_matrix)/8;
            n2 = length(new_node_values)/8;
            
            new_N_nums = ((update_nN+1):(update_nN+n2));
            
            % Adjustment to new_N_nums for nodes already used previously
            if ~isempty(repeat_index)
                new_N_nums(repeat_index) = new_N_list(repeat_index2);
                if ~isempty(non_repeat_index)
                    for i = 1:length(non_repeat_index);
                        new_N_nums(non_repeat_index(i)) = max(new_N_list)+i;
                    end
                end
            end
            
            if n>0
                update_nodes = ((update_nN+1):(update_nN+n));
            else
                update_nodes = [];
            end
            new_N_list = [new_N_list update_nodes];
            
            % total number of nodes and elements
            update_nN = update_nN+n;
            update_nE = update_nE + n_xi-1;
            el_count_old = el_count;
            
            % Case where a collapsed element is split into 1 collapsed and
            % one non-collapsed element
            new_nNofElem = [nN; nN];
            if nN == 6
                if xi == 2
                    new_nNofElem = [nN; (nN+2)];
                end
            end
            
            %% Defining new local and global node index list for current element
            % NOTE: ONLY WORKS WHEN n_xi = 2
            for i = 1:n_xi
                el_count = el_count+1;
                new_liN(i,:) = liN;
                % If refinement is in xi1 direction
                if xi == 1
                    if i == 1
                        if nN == 6
                            new_giN(i,:) = giN;
                            new_giN(i,[3 6]) = new_N_nums;
                        else
                            new_giN(i,:) = giN;
                            new_giN(i,[2 4 6 8]) = new_N_nums;
                        end
                    elseif i == n_xi
                        if nN == 6
                            new_giN(i,:) = giN;
                            new_giN(i,[2 5]) = new_N_nums;
                        else
                            new_giN(i,:) = giN;
                            new_giN(i,[1 3 5 7]) = new_N_nums;
                        end
                    end
                    % If refinement is in xi2 direction
                elseif xi == 2
                    if i == 1
                        if nN == 6
                            new_giN(i,:) = giN;
                            new_giN(i,[2 3 5 6]) = new_N_nums;
                        else
                            new_giN(i,:) = giN;
                            new_giN(i,[3 4 7 8]) = new_N_nums;
                        end
                    elseif i == n_xi
                        if nN == 6
                            new_liN(i,:) = [1 2 3 4 5 6 7 8];
                            new_giN(i,[3 4 7 8]) = giN([2 3 5 6]);
                            new_giN(i,[1 2 5 6]) = new_N_nums;
                        else
                            new_giN(i,:) = giN;
                            new_giN(i,[1 2 5 6]) = new_N_nums;
                        end
                    end
                    % If refinement is in xi3 direction
                elseif xi == 3
                    if i == 1
                        if nN == 6
                            new_giN(i,:) = giN;
                            new_giN(i,[4 5 6]) = new_N_nums;
                        else
                            new_giN(i,:) = giN;
                            new_giN(i,[5 6 7 8]) = new_N_nums;
                        end
                    elseif i == n_xi
                        if nN == 6
                            new_giN(i,:) = giN;
                            new_giN(i,[1 2 3]) = new_N_nums;
                        else
                            new_giN(i,:) = giN;
                            new_giN(i,[1 2 3 4]) = new_N_nums;
                        end
                    end
                end
            end
            g_new_giN(el_count_old+1:el_count,:)=new_giN;
            g_new_liN(el_count_old+1:el_count,:)=new_liN;
            nNofElem(el_count_old+1:el_count,:)=new_nNofElem;
            
            
            %% Dealing with Versions
            
            % Create list of nodes/node pairs used to define new nodes that
            % have versions
            if ~isempty(el_nodes_new)
                if length(obj.coordinates(el_nodes_new(1,1),:))>3
                    for i = 1:length(el_nodes_new(:,1))
                        if obj.coordinates(el_nodes_new(i,:),1:3)==obj.coordinates(el_nodes_new(i,:),4:6)
                            vnodes = [vnodes; el_nodes_new(i,:) 0];
                        elseif obj.coordinates(el_nodes_new(i,1),1:3)==obj.coordinates(el_nodes_new(i,1),4:6)
                            if max(obj.coordinates(el_nodes_new(i,2),1:3)~=obj.coordinates(el_nodes_new(i,2),4:6))
                                vnodes = [vnodes; el_nodes_new(i,1) 0 0];
                            end
                        elseif obj.coordinates(el_nodes_new(i,2),1:3)==obj.coordinates(el_nodes_new(i,2),4:6)
                            if  obj.coordinates(el_nodes_new(i,1),1:3)~=obj.coordinates(el_nodes_new(i,1),4:6)
                                vnodes = [vnodes; el_nodes_new(i,2) 0 0];
                            end
                        end
                    end
                end
            end
            
            vnodes = unique(vnodes,'rows');
            
            % Adding global index of new nodes with versions to vnodes list
            if ~isempty(vnodes)
                for i_vnodes = 1:length(el_nodes_used)
                    temp_nodes = el_nodes_used(i_vnodes,:);
                    temp_rows = find(vnodes(:,1)==temp_nodes(1));
                    if ~isempty(temp_rows)
                        temp_rows2 = find(vnodes(temp_rows,2)==temp_nodes(2));
                        if ~isempty(temp_rows2)
                            vnodes(temp_rows(temp_rows2),3) = new_N_nums(i_vnodes)
                        end
                    end
                end
            end
            
            % NEWValueIndices are all set to 1:8 - if versions are needed,
            % the necessary indices are taken from previous nodes with
            % versions used to define the new node.
            NodesExtraVersions = [];
            
            for i_new_el = el_count_old+1:el_count
                for i_node = 1:8
                    global_node = g_new_giN(i_new_el,i_node);
                    local_node = g_new_liN(i_new_el,i_node);
                    if ~isempty(find(vnodes(:)==global_node)) && global_node>0
                        if global_node<(original_nNodes+1)
                            original_lN = find(obj.giNofElem(i_el,:)==global_node);
                            newNvalIndices=obj.valueIndices(i_el,:,original_lN,:);
                            NEWvalueIndices(i_new_el,:,local_node,:)=newNvalIndices;
                        else
                            
                            original_gN=vnodes(find(vnodes(:,3)==global_node),1);
                            original_lN = find(obj.giNofElem(i_el,:)==original_gN);
                            newNvalIndices=obj.valueIndices(i_el,:,original_lN,:);
                            NEWvalueIndices(i_new_el,:,local_node,:)=newNvalIndices;
                            check = ceil(max(max((newNvalIndices)))/8);
                            NodesExtraVersions = [NodesExtraVersions; [global_node check]];
                        end
                    end
                end
            end
            
            NodesExtraVersions = unique(NodesExtraVersions,'rows');
            %--------------------------------------------------------------------------
            %% Update obj. fields
            %--------------------------------------------------------------------------
            % Update Coordinates and derivatives
            for i = 1:length(new_N_nums)
                iN = new_N_nums(i);
                
                % If new node is formed from two nodes with versions, then
                % it requires versions with the same derivatives.
                % NOTE: Coded for nodes with a maximum of 2 versions.
                j = 1;
                
                if ~isempty(NodesExtraVersions)
                    version_row = find(NodesExtraVersions(:,1) == iN);
                    if ~isempty(version_row)
                        % expected to be maximum of 2 in Pablo templates.
                        j = (NodesExtraVersions(version_row,2));
                    end
                end
                
                obj.GIN(iN) = iN;
                obj.coordinates(iN,:,j) = new_node_values(i*8-7,:);
                obj.derivatives.duds1(iN,:,j) = new_node_values(i*8-6,:);
                obj.derivatives.duds2(iN,:,j) = new_node_values(i*8-5,:);
                obj.derivatives.duds3(iN,:,j) = new_node_values(i*8-4,:);
                obj.derivatives.duds12(iN,:,j) = new_node_values(i*8-3,:);
                obj.derivatives.duds13(iN,:,j) = new_node_values(i*8-2,:);
                obj.derivatives.duds23(iN,:,j) = new_node_values(i*8-1,:);
                obj.derivatives.duds123(iN,:,j) = new_node_values(i*8,:);
                
                if (list_temp_versions(iN,1))>0
                    if list_temp_versions(iN,1) < j
                        list_temp_versions(iN,:) = j;
                    end
                else
                    list_temp_versions(iN,:) = j;
                end
            end
            
            obj.nNodes = update_nN;
            
        end
        
        % Adjust derivatives depending on the current refinement direction
        for i = 1:obj.nNodes
            % Check for 2nd versions
            if(numel(size(obj.derivatives.duds1))==3)
                j_index = [1:2];
            else
                j_index = 1;
            end
            for j = j_index
                if xi == 1
                    obj.derivatives.duds1(i,:,j) = obj.derivatives.duds1(i,:,j)/n_xi;
                    obj.derivatives.duds12(i,:,j) = obj.derivatives.duds12(i,:,j)/n_xi;
                    obj.derivatives.duds13(i,:,j) = obj.derivatives.duds13(i,:,j)/n_xi;
                    obj.derivatives.duds123(i,:,j) = obj.derivatives.duds123(i,:,j)/n_xi;
                elseif xi == 2
                    obj.derivatives.duds2(i,:,j) = obj.derivatives.duds2(i,:,j)/n_xi;
                    obj.derivatives.duds12(i,:,j) = obj.derivatives.duds12(i,:,j)/n_xi;
                    obj.derivatives.duds23(i,:,j) = obj.derivatives.duds23(i,:,j)/n_xi;
                    obj.derivatives.duds123(i,:,j) = obj.derivatives.duds123(i,:,j)/n_xi;
                elseif xi == 3
                    obj.derivatives.duds3(i,:,j) = obj.derivatives.duds3(i,:,j)/n_xi;
                    obj.derivatives.duds23(i,:,j) = obj.derivatives.duds23(i,:,j)/n_xi;
                    obj.derivatives.duds13(i,:,j) = obj.derivatives.duds13(i,:,j)/n_xi;
                    obj.derivatives.duds123(i,:,j) = obj.derivatives.duds123(i,:,j)/n_xi;
                end
            end
        end
        
        % Update version-related arrays
        obj.valueIndices = NEWvalueIndices;
        obj.versions = list_temp_versions(1:obj.nNodes,:);
        obj.dofsUsed = ones(obj.nNodes, 8);
        
        % Update element numbering
        obj.nElems = update_nE;
        
        % Update Nodes of Elements mapping
        obj.giNofElem = g_new_giN;
        obj.liNofElem = g_new_liN;
        obj.nNofElem = nNofElem;
        
        % Pre-allocating space for BuildMapping
        obj.MaxNeighbours = 240;
        
        %obj = obj.FindSecondVersionBasis();
        obj = obj.Update();
    end
end

toc

%--------------------------------------------------------------------------
% Writing updated mesh to exnode and exelem files
%obj.WriteExFiles(obj,exNodeFileNameORdir,exElemFileName,GroupName,options)
WriteExFiles(obj,outdir)
%--------------------------------------------------------------------------
%% Create com file for visualisation
%cmGuiViewMesh(outdir,obj)


end


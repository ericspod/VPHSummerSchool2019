function [Tff] = ComputeStressFromStrain(EXfileStrain,GuccParams,HPvalues)
% Code to compute stress from the strain, according to a Guccione material
% law:
% Tij = C1 * E_ij * C_ij * e^Q

bDebug = 1;
bEngineeringShearStrain = 0;

C1 = GuccParams(1);
C2 = GuccParams(2);
C3 = GuccParams(3);
C4 = GuccParams(4);

EXdata = ReadExNode(EXfileStrain);

nNodes = EXdata.nNodes;
Eff = zeros(1,nNodes);
Ess = zeros(1,nNodes);
Enn = zeros(1,nNodes);
Esn = zeros(1,nNodes);
Efn = zeros(1,nNodes);
Efs = zeros(1,nNodes);

for iF = 1:EXdata.ListOfFields.nFields
    fieldname = EXdata.ListOfFields.field(iF).Name;
    switch fieldname(1:3)
        % it was not E, but lambda what was computed in cmGui:
        % Eff = 0.5(lambda^2 - 1)
        case 'Eff', Eff = 0.5*(cell2mat({EXdata.FieldValues(iF,:).values}).^2 - 1);
        case 'Enn', Enn = 0.5*(cell2mat({EXdata.FieldValues(iF,:).values}).^2 - 1);
        case 'Ess', Ess = 0.5*(cell2mat({EXdata.FieldValues(iF,:).values}).^2 - 1);
        % the other three shear strains are not computed yet in cmGui!
    end
    if strcmp(fieldname,'fibre_axes_xi')
        RefAx = cell2mat({EXdata.FieldValues(iF,:).values});
    end
    if strcmp(fieldname,'deformed_fibre_axes_xi')
        DefAx = cell2mat({EXdata.FieldValues(iF,:).values});
    end
    if strcmp(fieldname,'Efsn_xi')
        Efsn = cell2mat({EXdata.FieldValues(iF,:).values});
    end
    if strcmp(fieldname,'Cfsn_xi')
        Cfsn = cell2mat({EXdata.FieldValues(iF,:).values});
    end
end


if exist('RefAx','var')
    RefFib = RefAx(1:3,:);
    RefShe = RefAx(4:6,:);
    RefNor = RefAx(7:9,:);

    % Check orthogonality:
    WorstCondition = max([dot(RefFib,RefShe,1) dot(RefFib,RefNor,1) dot(RefShe,RefNor)]);
    if WorstCondition > exp(-6)
        word2print = 'ERROR! Not meeting the';
    else
        word2print = 'Meeting the';
    end
    fprintf('%s orthogonality of reference axes (worst case had dot product = %1.9f\n',word2print,WorstCondition);

    if(bEngineeringShearStrain)
        if exist('DefAx','var')
            % Now project deformed vectors into each of the three shear planes:
            DefFib = DefAx(1:3,:);
            DefShe = DefAx(4:6,:);
            DefNor = DefAx(7:9,:);
            nRefFib = normalise(RefFib);
            nRefShe = normalise(RefShe);
            nRefNor = normalise(RefNor);
            nDefFib = normalise(DefFib);
            nDefShe = normalise(DefShe);
            nDefNor = normalise(DefNor);
            for iPlane = 1:3
                switch iPlane
                    case 1, Ax1 = nRefFib; Ax2 = nRefShe; Vn = nRefNor;   D1 = nDefFib; D2 = nDefShe; 
                    case 2, Ax1 = nRefFib; Ax2 = nRefNor; Vn = -nRefShe;  D1 = nDefFib; D2 = nDefNor; 
                    case 3, Ax1 = nRefShe; Ax2 = nRefNor; Vn = -nRefFib;  D1 = nDefShe; D2 = nDefNor; 
                end 
                % First, project D1 and D1 in the plane defined by Ax1 and Ax2:
                pD1 = projectVector2plane(Ax1,Ax2,D1);
                pD2 = projectVector2plane(Ax1,Ax2,D2);
                % Get the angle between each pair of refernce and deformed axes (both
                % axes have been normalised, not need to devide by module):
                Angle1 = GetAngles(Ax1,pD1,Vn);
                Angle2 = GetAngles(Ax2,pD2,Vn);
                Shear = Angle1 - Angle2;
                switch iPlane
                    case 1, Efs = Shear;
                    case 2, Efn = Shear;
                    case 3, Esn = Shear;
                end
            end
        end
    end
end

if exist('Efsn','var')
    fprintf('loading strain computed from cmGui\n');
    Eff = Efsn(1,:);
    Ess = Efsn(5,:);
    Enn = Efsn(9,:);
    Esn = Efsn(3,:);
    Efs = Efsn(2,:);
    Efn = Efsn(3,:);
end

Q = C2 * Eff.^2 + C3 * (Ess.^2 + Enn.^2 + 2*Esn.^2) + C4 * (2*Efn.^2 + 2*Efs.^2); 

if exist('Cfsn','var')
    Cscale = Cfsn(1,:);%NaN * ones(1,nPoints);
    % now computed in cmGui
%     for iP = 1:nPoints
%         Cmatrix(1,1:3) = C(1:3,iP);
%         Cmatrix(2,1:3) = C(4:6,iP);
%         Cmatrix(3,1:3) = C(7:9,iP);
%         % Rotate in fibre axes:
%         L(1,1:3) = RefAx(1:3,iP);
%         L(2,1:3) = RefAx(4:6,iP);
%         L(3,1:3) = RefAx(7:9,iP);
%         % by
%         Cfsn = L' * C * L;
%         Cfsn = inv(Cfsn);
%         Cscale(iP) = Cfsn(1,1);
%     end
    HPscaled = HPvalues' .* Cscale;
else
    HPscaled = NaN;
end

TGucc = C1 .* Eff .* C2 .* exp(Q);
Tff   = TGucc + HPscaled;

if(0)
    Q2= C2 * Eff.^2 + C3 * (Ess.^2 + Enn.^2);
    Tff2 = C1 .* Eff .* C2 .* exp(Q2);
end
if(bDebug)
    H = figure('color',[1 1 1],'units','normalized','outerposition',[0 0 1 1])
    for i=1:6
        switch i
            case 1, varname = 'Eff'; var=Eff; isp = i;
            case 2, varname = 'Ess'; var=Ess; isp = i;
            case 3, varname = 'Enn'; var=Enn; isp = i+1;
            case 4, varname = 'Efs'; var=Efs; isp = i+1;
            case 5, varname = 'Efn'; var=Efn; isp = i+2;
            case 6, varname = 'Esn'; var=Esn; isp = i+2;
        end
        subplot(3,3,isp), plot(var), title(sprintf('%s. median=%1.3f',varname,median(var)));
    end
    subplot(233)
    plot(TGucc), title(sprintf('TGucc, median=%1.3f',median(TGucc)));
    axis([0 nNodes -3*mean(TGucc) +5*mean(TGucc)])
    subplot(236)
    plot(HPscaled), title(sprintf('Hydrost.Press., median=%1.3f',median(HPscaled)));
    axis([0 nNodes -3 +5])
    export_fig(['StressComputations.bmp'],'-bmp',H);
end

function [angles] = GetAngles(Va,Vb,Vn)
% Vn is the reference normal to know whether this is a positive or negative
% angle:

    % The normal vector to Va and Vb:
    Nv = cross(Va,Vb,1);
    % The sin of the angle between Va and Vb (the module of the cross
    % product):
    sina = sqrt(sum(Nv.^2,1));
    % The cos is the dot product:
    cosa = dot(Va,Vb,1);

    angles = atan( sina./cosa );
    signes = sign(dot(Vn,Nv,1));
    angles = signes .* angles;

function pD = projectVector2plane(Ax1,Ax2,D)
    C1 = dot(Ax1,D,1);
    C2 = dot(Ax2,D,1);
    pD = NaN * ones(3,size(Ax1,2));
    for iC = 1:3
        pD(iC,:) = C1.*Ax1(iC,:) + C2.*Ax2(iC,:);
    end

    
function [v] = normalise(v)
    % v is a matrix 3xnPoints
    norms = sqrt(sum(v.^2,1));
    for ic = 1:3
        v(ic,:) = v(ic,:)./norms;
    end
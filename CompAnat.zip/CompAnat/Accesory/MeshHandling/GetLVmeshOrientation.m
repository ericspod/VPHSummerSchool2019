function [OrientMatrix,Length] = GetLVmeshOrientation(Cmesh,iRVnodes)
% Function to get the orientation matrix of a left ventricular mesh
%
% Orientation is defined by:
% - The apex to base direction. The mean basal point is first estimated,
% and then the most distant point to it.
% - The left to right direction, perpendicular to the former, and
% containing the average of the RVnodes introduced in parameters.
%
% By Pablo Lamata. Oxford, 16/01/2014

% Version control:
% - 31/08/14(PL): removal of third argument "options", it was useless.
% Addition of the output of length.

bDebug = 0;

%% Compute the apical to basal direction:
% Compute the MBP, Mean Basal Point:
topology = GetCardiacMeshTopology(Cmesh);
BasalNodes = topology.basalNodes;
MBP = mean(Cmesh.GetNodeCoorValue(BasalNodes),1);

% Compute the AP, Apical Point. Search in exteral surface of the apical
% elements (get the last two layers just in case):
nLayers = numel(topology.ElemLayer);
ApicalElems = [topology.ElemLayer(nLayers).elems topology.ElemLayer(nLayers-1).elems];
% Only the epicardium ones to reduce memory burden
AllEpiElems = topology.epiElems;
EpiApiElems = [];
for iE = 1:numel(ApicalElems)
    iApical = ApicalElems(iE);
    I = find(AllEpiElems == iApical);
    if numel(I)>0
        EpiApiElems = [EpiApiElems iApical];
    end
end
% The external surface of the elements is sampled:
options.bEpi   = 1;
options.iElems = EpiApiElems;
discretisation = 10;
[V,F]          = Cmesh.TesselateExternalSurfaces(discretisation,options);
SurfacePoints  = V;
% Find the largest distance:
Dist = sum((SurfacePoints - repmat(MBP,size(SurfacePoints,1),1)).^2,2);
iMax = find(Dist==max(Dist));
AP = SurfacePoints(iMax,:);
% In case several points in max distance:
AP = mean(AP,1);

ABdir = AP - MBP;
Length = sqrt(sum(ABdir.^2));

%% The rest: LRdirection
SeptumPoint = mean(Cmesh.GetNodeCoorValue(iRVnodes),1);
LRdir = SeptumPoint - MBP;
PCAt = PCAtransformation();
OrientMatrix = PCAt.BuildRotMatrixFromTwoVectors(ABdir,LRdir);

if(bDebug)
    figure; hold on;
    Cmesh.plotExternalSurfaces();
    plot3(MBP(1),MBP(2),MBP(3),'r*','LineWidth',4);
    plot3(AP(1),AP(2),AP(3),'r*','LineWidth',4);
    plot3([MBP(1) AP(1)],[MBP(2) AP(2)],[MBP(3) AP(3)],'k','LineWidth',4);
    %plot3(SurfacePoints(:,1),SurfacePoints(:,2),SurfacePoints(:,3),'+c');
    plot3(SeptumPoint(1),SeptumPoint(2),SeptumPoint(3),'*g','LineWidth',4);
    C = Cmesh.GetMeshCentre();
    colors = 'rgb';
    for iV = 1:3
        V = OrientMatrix(:,iV);
        ss= 10;
        plot3([C(1) C(1)+ss*V(1)],[C(2) C(2)+ss*V(2)],[C(3) C(3)+ss*V(3)],colors(iV),'LineWidth',4);
    end
    view(45,45);
end



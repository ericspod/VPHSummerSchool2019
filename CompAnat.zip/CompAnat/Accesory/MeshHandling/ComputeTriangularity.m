function [score] = ComputeTriangularity(template)
% Function to compute a triangularity score from the collection of 144
% meshes of the Bisbal cohort.
%
% INPUT:
% - template: mesh as read by CubicMeshClass

    bDebug = 0;
    ImplementationOption = 6;
    plane = 'XZ';

    switch ImplementationOption
        case 1
            % Idea that was abandoned half way...
            % Split the mesh into the upper and lower region:
            iElmsBelow = [];
            iElmsAbove = [];
            for iC = 1:6
                iElmsBelow = [iElmsBelow iC:12:144];
                iElmsAbove = [iElmsAbove iC+6:12:144];
            end
            
            MeshAbove = template.ExtractSubpart(iElmsAbove);
            MeshBelow = template.ExtractSubpart(iElmsBelow);
            if(1)
                figure('color',[1 1 1]);
                MeshAbove.plotWireframe('r');
                MeshBelow.plotWireframe('b');
            end
            % Compute the metrics of the two regions
            ...
        case {2,3,4,5}
        % 2D slice computations:
            switch plane
                case 'YZ'
                    % Approximate the silouette in the YZ plane:
                    P = template.coordinates(:,[2 3],1);
                case 'XZ'
                    P = template.coordinates(:,[1 3],1);
            end            
            c1 = P(:,1);
            c2 = P(:,2);
            k = convhull(c1,c2);
            if(bDebug)
                figure('color',[1 1 1]);
                subplot(1,3,1)
                template.plotWireframe('r');
                hold on
                switch plane
                    case 'YZ'
                        kx = zeros(1,numel(k));
                        x = zeros(1,numel(c1));
                        plot3(kx,c1(k),c2(k),'k-',x,c1,c2,'b*')
                    case 'XZ'
                        ky = zeros(1,numel(k));
                        y = zeros(1,numel(c1));
                        plot3(c1(k),ky,c2(k),'k-',c1,y,c2,'b*')
                end
            end
            
            switch ImplementationOption
                case 5
                    % Centre the mask in the top-down direction
                    MeanExtrems = ( max(c2) + min(c2) )/2;
                    c2 = c2 - MeanExtrems;                    
                otherwise
                    % Do nothing, keep "empty space" in edges of the
                    % silouette. 
            end
            % Set in a bounding box of size [1-,1]
            yn = c1(k)/ max(abs(c1(k)));
            zn = c2(k)/ max(abs(c2(k)));
            
            % Generate a binary image
            pointMatrix = [yn,zn];       %#  3-D points
            DTm = delaunayTriangulation(pointMatrix);  %# Create a Delaunay triangulation
            [Y,Z] = meshgrid(-1:0.02:1);   %# Create a mesh of coordinates for your volume
            simplexIndex = pointLocation(DTm,Y(:),Z(:));  %# Find index of simplex that
                                                  %#   each point is inside
            mask = ~isnan(simplexIndex);    %# Points outside the convex hull have a
                                %#   simplex index of NaN
            mask = reshape(mask,size(Y));   %# Reshape the mask to 101-by-101-by-101

            
            % Get the overlap with an upward and downward triangle:
            Pup = [-1 -1;1 -1; 0 1];
            DT = delaunayTriangulation(Pup); 
            simplexIndex = pointLocation(DT,Y(:),Z(:));
            TriangUp = ~isnan(simplexIndex); 
            TriangUp = reshape(TriangUp,size(Y));
            
            Pdw = [-1 1;1 1; 0 -1];
            DT = delaunayTriangulation(Pdw); 
            simplexIndex = pointLocation(DT,Y(:),Z(:));
            TriangDw = ~isnan(simplexIndex); 
            TriangDw = reshape(TriangDw,size(Y));
            
            switch ImplementationOption
                case 2 % overlap
                    UpScore = sum(mask .* TriangUp);
                    DwScore = sum(mask .* TriangDw);
                case 3 % line by line multiplication
                    pUp = zeros(1,size(Y,2));
                    pDw = pUp;
                    for ix = 1:size(Y,1)
                        mp = numel(find(mask(ix,:)));
                        pUp(ix) = mp * numel(find(TriangUp(ix,:)));
                        pDw(ix) = mp * numel(find(TriangDw(ix,:))); 
                    end
                    UpScore = sum(pUp);
                    DwScore = sum(pDw);
                case 4
                    % Dice coefficient
                    UpScore = dice(mask , TriangUp);
                    DwScore = dice(mask , TriangDw);
                case 5
                    % Areas above and below the mid point:
                    UpScore = numel(find(mask(51:end,:)));
                    DwScore = numel(find(mask(1:51,:)));
            end
            score = UpScore / DwScore;
            
            if(bDebug)
                subplot(1,3,2)
                triplot(DTm); axis equal;
                subplot(1,3,3)
                imagesc((mask + TriangDw + TriangUp)); axis equal;
                title(sprintf('Triangularity = %f',score));
            end
        case 6
            % 3D computations
            P = template.coordinates(:,[1:3],1);
            % Compute the convex hull of the mesh:
            k = convhull(P(:,1),P(:,2),P(:,3));
            % Scale the top/down direction:
            MeanExtrems = ( max(P(:,3)) + min(P(:,3)) )/2;
            P(:,3) = P(:,3) - MeanExtrems;     
            for iC = 1:3
                P(:,iC) = P(:,iC) / max(abs(P(:,iC)));
            end
            DTm = delaunayTriangulation(P);
            [X,Y,Z] = meshgrid(-1:0.02:1); 
            simplexIndex = pointLocation(DTm,Y(:),X(:),Z(:));
            mask = ~isnan(simplexIndex);
            mask = reshape(mask,size(Y));            
            UpScore = numel(find(mask(:,:,51:end)));
            DwScore = numel(find(mask(:,:,1:51)));    
            score = UpScore / DwScore;

    end

function [score] = dice(img1,img2)
    %The steps are:
    
    img1 = int16(img1);
    img2 = int16(img2);
    
%1. set one image non-zero values as 200
img1(img1>0)=200;

%2. set second image non-zero values as 300
img2(img2>0)=300;

%3. set overlap area 100
OverlapImage = img2-img1;

%4. count the overlap100 pixels
[r,c,v] = find(OverlapImage==100);
countOverlap100=size(r);

%5. count the image200 pixels
[r1,c1,v1] = find(img1==200);
img1_200=size(r1);

%6. count the image300 pixels
[r2,c2,v2] = find(img2==300);
img2_300=size(r2);

%7. calculate Dice Coef
score = 2*countOverlap100/(img1_200+img2_300);

%figure(1);image(OverlapImage);colormap(gray);title('Overlapping area used to calculate Dice Coef')

    
function [] = GenerateAtlasModesTexFigure(ResultsDir,options)
 
%==========================================================================
% Default options:
    modes = 1:5;
    nStd = 2;   % Number of stds that are plot
    bViewAxis = 0;
    AxesRootFileName = 'AxesMode';
    % Column with the axis showing the distribution of cases (box plot or
    % "star plot"):
    bNoMiddleColumn = 0;
    % Column with the title of Mode
    bNoFirstColumn = 0;
    % Include the variance description
    bVarPerMode = 0;
    versionstring = '';
    AtlasSurname = '';
    
% Parse options
    if nargin>=2
        if isfield(options,'modes'), modes = options.modes; end
        if isfield(options,'nStd'), nStd = options.nStd; end
        if isfield(options,'bViewAxis'), bViewAxis= options.bViewAxis; end
        if isfield(options,'AxesRootFileName'), AxesRootFileName = options.AxesRootFileName; end
        if isfield(options,'bNoMiddleColumn'), bNoMiddleColumn = options.bNoMiddleColumn; end
        if isfield(options,'bNoFirstColumn'), bNoFirstColumn = options.bNoFirstColumn; end
        if isfield(options,'bVarPerMode'), bVarPerMode = options.bVarPerMode; end
        if isfield(options,'AtlasSurname'), AtlasSurname = options.AtlasSurname; end
        if isfield(options,'versionstring'), versionstring = options.versionstring; end
    end
%==========================================================================
if bViewAxis
    bNoFirstColumn = 1;
end
    TexFile = fullfile(ResultsDir, ['AtlasModes' AtlasSurname '.tex']);
    fid = fopen(TexFile,'w');
    if fid==-1
        fprintf('Not possible to create TEX file %s\n',TexFile);
        return
    else
        fprintf('Generating tex file: %s\n',TexFile);
    end
    
    fprintf(fid,'\\documentclass[a4paper]{article}\n');
    fprintf(fid,'\\usepackage{graphicx}\n');
    fprintf(fid,'\\usepackage{morefloats}\n');
    if bViewAxis
        fprintf(fid,'\\usepackage{array}\n');
    end
    % to allow the use of spaces in the file path:
    fprintf(fid,'\\usepackage{graphicx}\n');
    fprintf(fid,'\\usepackage[space]{grffile}\n');
    
    fprintf(fid,'\\topmargin = -40pt\n');
    fprintf(fid,'\\oddsidemargin= 0pt\n');
    fprintf(fid,'\\textwidth = 400pt\n');
    fprintf(fid,'\\textheight = 700pt\n');
    fprintf(fid,'\\begin{document}\n');

    nColumns = 4 - bNoFirstColumn - bNoMiddleColumn;
    if bViewAxis
        textFLcol3 = ' & ';
        width1 = 0.30;
        width2 = 0.35;
        width3 = 0.30;
        nModesPerTable = 10;
        if bNoFirstColumn
            textalignmentintable = '';
        else
            textalignmentintable = ' >{\centering\arraybackslash}m{0.25in}';
        end
        widths = [width1 width2 width3];
        for iCol = 1:3            
            textalignmentintable = [textalignmentintable sprintf(' >{\\centering\\arraybackslash}m{%f\\textwidth} ',widths(iCol))];
        end
        textalignmentintable = ['{' textalignmentintable '}'];
    else
        textFLcol3 = 'Mean&';
        width1 = 0.3;
        width2 = 0.3;
        width3 = 0.3;
        nModesPerTable = 3;
        txcol = '';
        for iC = 1:nColumns, 
            txcol = sprintf('%sc|',txcol);
        end
        textalignmentintable = ['[t]{' txcol '}'];
    end
    nModes = numel(modes);
    nTables = ceil(nModes/nModesPerTable);
    if bNoFirstColumn
        textFLcol1 = '';
    else
        textFLcol1 = 'Mode&';
    end
    if bNoMiddleColumn
        textFLcol3 = '';
    end
    for iTable = 1:nTables
        iMode0 = 1 + (iTable-1)*nModesPerTable;
        iMode1 = iMode0 + nModesPerTable - 1;
        if iMode1>nModes, iMode1=nModes; end
        fprintf(fid,'\\begin{table}[ht]\n');
        fprintf(fid,'  \\centering\n');
        fprintf(fid,'  \\begin{tabular}%s\n',textalignmentintable);

        
        FirstLine = [textFLcol1 sprintf('-%istd &',nStd) textFLcol3 sprintf('+%istd ',nStd) '\\'];
        fprintf(fid,'%s\n',FirstLine);
        nameImageRoot= fullfile(ResultsDir,[ 'ImageAtlas' AtlasSurname 'Mode']);
        
        for iM = iMode0:iMode1   
            iMode = modes(iM);
            if ~bNoFirstColumn
                fprintf(fid,'%i&',iMode);
            end

            % In each mode, first the shape - 2std:        
            % Marta, 21/10/2014
%             nameImage = [ResultsDir sprintf('ImageAtlasMode%iNegativeMean.png',iMode)];
            
            nameImage = [nameImageRoot  num2str(iMode) 'Negative.png'];
            AlternativeRoot = fullfile(ResultsDir,sprintf('ImageAtlasMode%iNegative',iMode));
            IncludeGraphicsIfExist(fid,nameImage,width1,AlternativeRoot);
            fprintf(fid,' &');
            if ~bNoMiddleColumn
                if bViewAxis
                    nameImage = fullfile(ResultsDir, sprintf('%s%i.png',AxesRootFileName,iMode));
                    AlternativeRoot = NaN; % something that will not be found
                else      
                     % Marta, 21/10/2014
%                     nameImage = [ResultsDir sprintf('ImageAtlasMode%iMeanMean.png',iMode)];
                     nameImage = [nameImageRoot  num2str(iMode) 'Mean.png'];
                    AlternativeRoot = fullfile(ResultsDir,sprintf('ImageAtlasMode%iMean',iMode));
                end
                IncludeGraphicsIfExist(fid,nameImage,width2,AlternativeRoot);
                fprintf(fid,' &');            
            end
            % In each mode, first the shape - 2std:     
            % Marta, 21/10/2014
% %             nameImage = [ResultsDir sprintf('ImageAtlasMode%iPositiveMean.png',iMode)];
             nameImage = [nameImageRoot  num2str(iMode) 'Positive.png'];
            AlternativeRoot = fullfile(ResultsDir,sprintf('ImageAtlasMode%iPositive',iMode));
            IncludeGraphicsIfExist(fid,nameImage,width3,AlternativeRoot);
            fprintf(fid,' \\\\ \n');
        end
        fprintf(fid,'  \\end{tabular}\n');        
        fprintf(fid,'\\end{table}\n');
    end
    if(bVarPerMode)
        fprintf(fid,'  \\centering\n');
        % look for the variance image:
        RootName2Search = fullfile(ResultsDir,['VarianceStudy' versionstring]);
        width = 0.5;
        IncludeGraphicsIfExist(fid,'',width,RootName2Search);
    end
        
    fprintf(fid,'\\end{document}\n');
    fclose(fid);

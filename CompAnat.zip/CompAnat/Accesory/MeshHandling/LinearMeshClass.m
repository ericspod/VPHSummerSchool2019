classdef LinearMeshClass
    % Class implemented to handle a 1D cubic mesh 
    
    
    properties
        DataDir % Directory where the data was read/written to file
        name
        GroupName
        exNodeFileName
        exElemFileName
        
        % Choice of interpolation between elements
        basisfunction
        nBasisPerNode
        nNodesPerElem
        nNodes
        nElems
        giNofElem
        
        dofs
        
        % Structure with the mapping of elements and nodes:
        mapping
        
        % Some shape analysis tools
        Centre
        Orientation
      
    end
    methods
% Initialization, Update and mapping:
        function [obj]      = LinearMeshClass(basisfunction)
            if nargin==0
                basisfunction = 'c.Hermite';
            end
                % Default initialization:
                obj.basisfunction = basisfunction;
                [nBasisPerNod nNodesPerElemt ContinuityOfNode IndexOfBasis] = obj.GetBasisCharacteristics();
                obj.nNodesPerElem = nNodesPerElemt;
                obj.nBasisPerNode = nBasisPerNod;
                obj.mapping.ContinuityOfNode = ContinuityOfNode;
                obj.mapping.IndexOfBasis     = IndexOfBasis;
                obj.nNodes = 0;
        end        
        function [nBasisPerNode nNodesPerElem ContinuityOfNode IndexOfBasis] = GetBasisCharacteristics(obj)
            switch obj.basisfunction
                case 'c.Hermite'
                    IndexOfBasis = [1 2 3 4];            
                    ContinuityOfNode = [1 1 2 2];
                    nBasisPerNode = 2;         
                    nNodesPerElem = 2;
            end
        end    
        function id         = GlobalBasisIndex1D(obj,n1,c1)
            % Function to map which is the index of the global basis corresponding to
            % the global node n1, and continuity (local basis) c1
            switch obj.basisfunction
                case 'c.Hermite'
                    id = 1 + (c1-1) + (n1-1) * 2;
            end
        end
        function [n1,c1]    = GetDofMeaning(obj,iDof)
            % Inverse function of GlobalBasisIndex1D
            switch obj.basisfunction
                case 'c.Hermite'
                    n1 = ceil(iDof/2);
                    c1 = iDof - (n1-1)*2;
            end
        end            
        function [obj]      = SetTopology(obj,nElems)
            % Initialize topology by just the number of elements:
            obj.nElems = nElems;
            obj.nNodes = nElems + 1;
            for iEl = 1:nElems
                % Each element has two nodes, with a simple ordering:
                obj.giNofElem(iEl,:) = [iEl,iEl+1];
            end
        end
        
% Set or get dofs:
        function [u]        = GetNodalDofs(obj,iNode,iBase)
            if nargin>=2
                options.Nodes = iNode;
            end
            if nargin>=3
                options.iBase = iBase;
            end
            u = obj.GetDofs(options);
        end
        function [u]        = GetElemDofs(obj,iElem)
            options.Nodes = obj.giNofElem(iElem,:);
            u = obj.GetDofs(options);
        end
        function [u]        = GetDofs(obj,options)
           OrderOption = 1; 
           iGlobalNodes = 1:obj.nNodes;
           iB = 1:obj.nBasisPerNode;
           if nargin==2
               if isfield(options,'Nodes'), iGlobalNodes = options.Nodes; end
               if isfield(options,'OrderOption'), OrderOption = options.OrderOption; end
               if isfield(options,'iBase'), iB = options.iBase; end
           end
           idofs = obj.GetIndexDofs(iGlobalNodes,OrderOption,iB);            
           u = obj.dofs(idofs,:);
        end
        function [obj]      = SetDofs(obj,u,options)
           OrderOption = 1; 
           iGlobalNodes = 1:obj.nNodes;
           iB = 1:obj.nBasisPerNode;
           if nargin==3
               if isfield(options,'Nodes'), iGlobalNodes = options.Nodes; end
               if isfield(options,'OrderOption'), OrderOption = options.OrderOption; end
               if isfield(options,'iBase'), iB = options.iBase; end
           end
           if isempty(iGlobalNodes)
               % Need to allocate, this seems the first time dofs are set:
               obj.nNodes = max(size(u))/obj.nBasisPerNode;               
               iGlobalNodes = 1:obj.nNodes;
           end
           idofs = obj.GetIndexDofs(iGlobalNodes,OrderOption,iB);           
           if numel(idofs) ~= size(u,1)
               if numel(idofs) == size(u,2)
                   u = u';
               else
                   fprintf('ERROR! dofs do not match with the size expected\n')
                   fprintf('       number of dofs provided: %i,%i\n',size(u,1),size(u,2));
                   fprintf('       number of dofs in mesh: %i (corresponding to %i nodes)\n',numel(idofs),numel(iGlobalNodes));
               end
           end
           obj.dofs(idofs,:) = u;
           obj = obj.UpdateCentre();
        end
        function idofs      = GetIndexDofs(obj,iGlobalNodes,OrderOption,iB)
           % iB: choice of the basis (1 = coordinate; 2 = derivative in
           % caes of c.Hermite)
           idofs = zeros(1,numel(iGlobalNodes));
           if nargin<4
               iB = 1:obj.nBasisPerNode;
           end
           
           for iN = 1:numel(iGlobalNodes)
               iNode = iGlobalNodes(iN);
               for iBase = iB
                   dofID = obj.GlobalBasisIndex1D(iNode,iBase);
                   switch OrderOption
                        case 1
                            iLocalBasis = iBase + (iN-1)*obj.nBasisPerNode;
                        case 2
                            iLocalBasis = iN + (iBase-1)*obj.nNodesPerElem;
                   end
                   idofs(iLocalBasis) = dofID;
               end
           end
           % Since we allow for not filling all indexes:
           idofs = idofs(idofs~=0);
        end

% Fit the dofs corresponding to a list of points (of the line)
        function [obj]      = FitLinearMesh2Points(obj,P)
            bViewCubicFitting = 0;
            
            options.nElements = obj.nElems;
            [nP,nC] = size(P);
            if nP<nC, P = P';  [nP,nC] = size(P);end             
            for iCoor = 1:nC
                Mesh1D = Fitting1D(P(:,iCoor),options);
                if(bViewCubicFitting)
                    InterpP(:,iCoor) = Mesh1D.LineEvaluation();
                end                
                dofs(:,iCoor) = Mesh1D.GetDofs();
            end
            if(bViewCubicFitting)
                %H = figure('color',[1 1 1]);  
                hold on; 
                switch nC
                    case 2,
                        plot(P(:,1),P(:,2));
                        plot(InterpP(:,1),InterpP(:,2),'r');
                    case 3,
                        plot3(P(:,1),P(:,2),P(:,3));
                        plot3(InterpP(:,1),InterpP(:,2),InterpP(:,3),'r');
                end
            end
        
            obj = obj.SetDofs(dofs);
        end
        function [dofs]     = FitDofsFromSparseSamplesCloseToLine(obj,Points,Values)
            % Function to fit a continuous function using the FE basis,
            % from the data sampled in a sparse set of 3D points near the
            % geometry of the line.
            
            % Check if there are enough constraints:
            if numel(obj.dofs) > numel(Points)
                fprintf('ERROR! Not enough points to constrain the fitting\n');
                return;
            else
                % 1) Find the local coordinate of the data:
                nP = numel(Points)/3;
                ListElems = NaN * ones(1,nP);
                ListLocXi = NaN * ones(1,nP);                
                for iP = 1:nP
                    P = Points(iP,:);
                    [P2,iE,iLoc]   = obj.FindClosestPoint(P);
                    ListElems(iP) = iE;
                    ListLocXi(iP) = iLoc;
                end
                % Assume there is only one element, all in element 1
                if min(ListElems)<1 || max(ListElems)>1
                    fprintf('ERROR! need to code a more elaborated fitting function!\n');
                else
                    % 2) Build the overdetermined system of equations: 
                    for iCoor = 1:3
                        y = Values(:,iCoor);
                        B = obj.CubicHermite(ListLocXi)';
                        c = B\y;
                        dofs(:,iCoor) = c;
                    end
                end
            end
        end
        
% Evaluation:        
        function [value]    = Evaluate1D(obj,iElem,localCoor)
            % 1. Get the value of the basis function in this coordinate:
                switch obj.basisfunction
                    case 'c.Hermite'
                        BasisValues = obj.CubicHermite(localCoor);
                end

            % 2. Get the dofs inside this element
                [u] = obj.GetElemDofs(iElem);

                nDimensions = size(u,2);
                BasisV = repmat(BasisValues,1,nDimensions);
            % 3. Multiply coefficients and basis:
                value=sum(BasisV.*u);
        end
        function [values]   = LineEvaluation(obj,t)
            if nargin<2
                t = 0:0.1:obj.nElems;
            end
            for it = 1:numel(t)
                tt = t(it);
                iElem = ceil(tt);
                if iElem == 0, iElem = 1; end
                localCoor = tt + 1 - iElem;
                values(it,:) = obj.Evaluate1D(iElem,localCoor);
            end
        end
        function [values]   = GaussEvaluation(obj,order)
            if nargin<2
                order = 4;
            end
            localCoor = obj.GetLocalGaussCoords1D(order);
            for iElem = 1:obj.nElems   
                itoffset = (iElem-1)*order;
                for ilocal = 1:order
                    it = ilocal + itoffset;                
                    values(it,:) = obj.Evaluate1D(iElem,localCoor.GPxhi(ilocal));
                end
            end
        end
        function [D,GC]     = Distance2point(obj,globalCoordinate,Point)
            nD = numel(Point);
            iElement = ceil(globalCoordinate);
            localCoor= 1 + globalCoordinate - iElement;
            MeshPoint = obj.Evaluate1D(iElement,localCoor);
            switch nD
                case 2, 
                    P1 = reshape(Point,1,2);
                    P2 = reshape(MeshPoint,1,2);
                case 3
                    P1 = reshape(Point,1,3);
                    P2 = reshape(MeshPoint,1,3);
            end
            D = sqrt(sum(( P1 - P2).^2));
            GC = globalCoordinate;
        end     
        function obj        = UpdateCentre(obj)
            % Get the coordinates:
            opt.iBase = 1;
            u = obj.GetDofs(opt);
            obj.Centre = mean(u,1);
        end
        
% Change shape:
        function [obj]      = Rotate(obj,RotationMatrix,C)
            nDims = numel(C);
            center = reshape(C,1,nDims);
            u = obj.GetDofs();
            nDofs = obj.nNodes * obj.nBasisPerNode;
            % Build a matrix that only "centers" the nodal coordinates, not
            % the derivatives:
            center_matrix = zeros(nDofs,nDims);
            for iDof = 1:nDofs
                [iN,iCont] = obj.GetDofMeaning(iDof);
                if iCont == 1
                    center_matrix(iDof,:) = center;
                end
            end
            u_corrected = (u - center_matrix)* RotationMatrix' + center_matrix;
            obj=obj.SetDofs(u_corrected);
        end
        function [P2,iE,iLoc]   = FindClosestPoint(obj,point)            
            bDebug = 0;
            
            % Search the closest point to P:
            nE = obj.nElems;
            x0 = 0; %nE/2 - 1;
            x1 = nE; %nE/2 + 1;
            Xmin = fminbnd(@(GC) Distance2point(obj,GC,point),x0,x1);
            iE = ceil(Xmin);
            iLoc= 1 + Xmin - iE;
            P2 = obj.Evaluate1D(iE,iLoc);
            if(bDebug)
                figure
                obj.plot();
                hold on; 
                plot(P(1),P(2),'r*');                
                plot(P2(1),P2(2),'b*');
                axis equal;
            end
        end
        function [obj]      = AdjustApex(obj,P)
            % Adjust the degrees of freedom so that the mid node has its
            % coordinates as close as possible to P
            bDebug = 0;
            % New Apex is at:
            [P2,Xmin]   = obj.FindClosestPoint(P);
            
            % Create a list of data samples for a new fitting, evenly
            % spaced, since this is the requirement for the Fitting1D
            % function:
            GCapex = Xmin;
            nSamp = 10*obj.nElems/2;
            ss1 = GCapex/(nSamp-1);
            ss2 = (obj.nElems - GCapex)/(nSamp-1);
            iSamples1 = 0:ss1:GCapex;
            iSamples2 = GCapex:ss2:obj.nElems;
            if numel(iSamples1)~=numel(iSamples2)
                fprintf('ERROR! not an even sampling at both sides of new apex\n');
                pause();
            end
            points1 = obj.LineEvaluation(iSamples1);
            % In order not to repeat the new apex point:
            points2 = obj.LineEvaluation(iSamples2(2:end));
            points = [points1 ;points2];
            
            options.nElements = obj.nElems;
            for iCoor = 1:2
                Mesh1D = Fitting1D(points(:,iCoor),options);
                dofs(:,iCoor) = Mesh1D.GetDofs();
            end
            if(bDebug)
                oldobj = obj;
            end
            obj = obj.SetDofs(dofs);           
            if(bDebug)
                figure;
                obj.plot();
                oldobj.plot('r');
            end
            
        end
        function [obj]      = Move2centre(obj)
            opt.iBase = 1;
            u = obj.GetDofs(opt);
            nPoints = size(u,1);
            nDims = size(u,2);
            u = u - repmat(reshape(obj.Centre,1,nDims),nPoints,1);
            obj = obj.SetDofs(u,opt);
            obj.Centre = zeros(1,nDims);
        end
% Plotting
        function []         = plotDofs(obj,bDerivatives,color)
            if nargin<2
                bDerivatives = 1;
            end
            if nargin<3
                color = 'r';
            end
            hold on
            % Get the coordinates:
            opt.iBase = 1;
            u = obj.GetDofs(opt);
            plot(u(:,1),u(:,2),['o' color]);
            if(bDerivatives)
                % Get the derivatives:
                opt.iBase = 2;
                du = obj.GetDofs(opt);
                % plot them:
                quiver(u(:,1),u(:,2),du(:,1),du(:,2),color)
            end       
            % Plot centre:
            plot(obj.Centre(1),obj.Centre(2),['x' color]);
        end
        function []         = plot(obj,color,LineWidth,bPoints)
            values = obj.LineEvaluation();
            nDims = size(values,2);
            if nargin<2, 
                color = [0 0 1];  
            else
                if numel(color)==1
                    switch color
                        case 'r', color =[1 0 0];
                        case 'g', color =[0 1 0];
                        case 'b', color =[0 0 1];
                    end
                end
            end
            if nargin<3, LineWidth = 1;  end
            if nargin<4, bPoints = 0; end
            switch nDims
                case 1, plot(values,'color',color,'LineWidth',LineWidth);
                case 2, plot(values(:,1),values(:,2),'color',color,'LineWidth',LineWidth);
                        plot(obj.Centre(1),obj.Centre(2),'x','color',color);
                case 3, plot3(values(:,1),values(:,2),values(:,3),'color',color,'LineWidth',LineWidth);
            end
            if bPoints
                t = 0:1:obj.nElems;
                values = obj.LineEvaluation(t);
                switch nDims
                    case 1, plot(values,'o','color',color,'LineWidth',LineWidth);
                    case 2, plot(values(:,1),values(:,2),'o','color',color,'LineWidth',LineWidth);
                    case 3, plot3(values(:,1),values(:,2),values(:,3),'o','color',color,'LineWidth',LineWidth);
                end
            end
        end
     
% Basis functions:
        function [CH]        = CubicHermite(obj,xhi)
           % Function that returns the values of the four basis Cubic Hermite
           % functions at the piont xhi. xhi can also be a vector of points, and then
           % the function returns the vector of values for each basis. 
           CBF01 = obj.CubicHermite1(xhi);
           CBF02 = obj.CubicHermite3(xhi);
           CBF11 = obj.CubicHermite2(xhi);
           CBF12 = obj.CubicHermite4(xhi);
           CH=[CBF01;CBF11;CBF02;CBF12];
       end
    end
    
   methods (Static = true)    
       % Hermite Basis functions
       function [CBF01]     = CubicHermite1(xhi)
           CBF01 = 1 - 3*xhi.^2 + 2*xhi.^3;
       end
       function [CBF02]     = CubicHermite3(xhi)
           CBF02 = xhi.^2 .* (3 - 2*xhi);
       end
       function [CBF11]     = CubicHermite2(xhi)
           CBF11 = xhi.*(xhi - 1).^2;
       end
       function [CBF12]     = CubicHermite4(xhi)
           CBF12 = xhi.^2 .* (xhi-1);
       end
       function [LocalGaussPoints1D] = GetLocalGaussCoords1D(order,xhi1,xhi2)
           % Function that gets the gauss coordinates in an interval [0 1]
           % INPUT:
           % - order: Gauss Integration Order
           % - xhi1,xhi2: definition of a different interval to [0 1]
           % OUTPUT:
           % - LocalGaussPoints1D.GPxhi = coordinates in local domain [0 1]
           % - LocalGaussPoints1D.GaussWeights = weight of each coordinate
           % 
           % For further reference:
           % http://en.wikipedia.org/wiki/Gaussian_quadrature
           if nargin<2
               xhi1=0;
               xhi2=1;
           end
           switch order
               case 2
                gp1 = sqrt(1/3);
                GaussDistancesFromCentreInUnitElement  = [-gp1 gp1];
                GaussWeightsInUnitElement = [1 1];
               case 3
                gp1 = sqrt(3/5);
                GaussDistancesFromCentreInUnitElement  = [-gp1 0 gp1];
                GaussWeightsInUnitElement = [5/9 8/9 5/9];
               case 4
                x1=sqrt((3-2*sqrt(6/5))/7);
                x2=sqrt((3+2*sqrt(6/5))/7);
                w1=(18+sqrt(30))/36;
                w2=(18-sqrt(30))/36;
                GaussDistancesFromCentreInUnitElement = [-x2 -x1 x1 x2];
                GaussWeightsInUnitElement             = [ w2  w1 w1 w2];
               case 5
                x0=0;
                x1=sqrt(5-2*sqrt(10/7))/3;
                x2=sqrt(5+2*sqrt(10/7))/3;
                w0=128/225;
                w1=(322+13*sqrt(70))/900;
                w2=(322-13*sqrt(70))/900;
                GaussDistancesFromCentreInUnitElement = [-x2 -x1 x0 x1 x2];
                GaussWeightsInUnitElement             = [ w2  w1 w0 w1 w2];
                case 6
                  GaussDistancesFromCentreInUnitElement = [-0.93246951 -0.66120939 -0.23861918 0.23861918 0.66120939 0.93246951];
                  GaussWeightsInUnitElement             =  [0.17132449 0.36076157 0.46791393 0.46791393 0.36076157 0.17132449];
               case 7
                    GaussWeightsInUnitElement = [0.12948497 0.27970539 0.38183005 0.41795918 0.38183005 0.27970539 0.12948497];
                    GaussDistancesFromCentreInUnitElement            =  [-0.94910791 -0.74153119 -0.40584515 0 0.40584515 0.74153119 0.94910791];  
               otherwise
                   error(' ERROR! Gauss order %i not implemented in CubicHermite4 class!\n',order);
            end
            LengthInterval=xhi2-xhi1;
            centre=(xhi1 + xhi2)/2;
            LocalGaussPoints1D.GPxhi = centre*ones(1,order) + GaussDistancesFromCentreInUnitElement*(LengthInterval/2);
            LocalGaussPoints1D.GaussWeights= GaussWeightsInUnitElement*(LengthInterval/2);
       end
   end
end
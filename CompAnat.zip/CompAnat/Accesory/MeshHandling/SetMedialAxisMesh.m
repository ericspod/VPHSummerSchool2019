function [ CHMeanMR ] = SetMedialAxisMesh( MRMesh, MeanMedialDofs )
%Create a CH mesh from medial axis data by copying medial axis into 
%a CH mesh with the same node coordinates in epi and endo

MRTopology      = GetCardiacMeshTopology(MRMesh);
MRNodeLayers    = MRTopology.NodeLayer;    

%copy current mesh and flatten it out to no derivatives
CH = MRMesh;    
derivativesList = [0 0 0 0 0 0 0]; %keep no derivatives
model = NeglectMeshDerivatives(CH.GetDofs(), derivativesList, CH.nNodes);                    
CH = CH.SetDofs(model);
MeshDofs = CH.GetDofs();

lastIdx = 1;

for iL = 1:numel(MRNodeLayers)

    nNodes      = length(MRNodeLayers(iL).EndoNodes);

    EpiNodeIdx  = MRNodeLayers(iL).EpiNodes;
    EndoNodeIdx = MRNodeLayers(iL).EndoNodes;

    %get subarray from mean medial axis array
    leapIdx = (lastIdx + nNodes) - 1;
    MeanPos = MeanMedialDofs(lastIdx:leapIdx,1:3);
    lastIdx = lastIdx + nNodes;

    %set epi and endo with same medial axis coordinates
    MeshDofs(EpiNodeIdx,:) = MeanPos;
    MeshDofs(EndoNodeIdx,:) = MeanPos;

end

CHMeanMR = MRMesh.SetDofs(MeshDofs);

end


function [EXdata2] = RemoveRedundantPoints(EXdata)
% Function that gets into the structure EXdata, read by the function
% ReadExNode.m, and removes redundant nodes. 
%
% Redundant nodes are for example found in the linear hexahedral mesh
% generated for the visualization of isochrones.
%
% The structure of EXdata is:
% - EXdata.name
% - EXdata.nNodes
% - EXdata.GIN = Global Index of Node (the index written in the file)
% - EXdata.ListOfFields.nFields
% - EXdata.ListOfFields.field(iField): a set of fields with:
%     field(iField).Name
%     field(iField).nComponents
%     field(iField).component(iComp): a set of components with:
%        component(iComp).Indexes
%        component(iComp).nVersions
%        component(iComp).nValues
% - EXdata.FieldValues(iField,iNode).values: matrix of size (nComponents x nFieldValues x nVersions)
%
% By Pablo Lamata. Oxford, 31/01/2011

bDebug=1;

bDuplicated = zeros(1,EXdata.nNodes);
fprintf('WARNING! compatibility to load the EXdata into a CubicHermiteMesh class is lost (not coded in this RemoveRedundantPoints.m()\n');


name1 = EXdata.ListOfFields.field(1).Name(1:11);
if strcmp(name1,'coordinates')||strcmp(name1,'Coordinates')
    CField=1;
else
    fprintf('Coordinate field not found where expected! It has %s instead!\n',name1);
end
DuplicateNodes = [];
for iNode1 = 1:(EXdata.nNodes-1)
    if numel(find(DuplicateNodes==iNode1))==0 % If the node has not been labelled as repeated already
        % Find the closest points among the remaining ones:
        Iequal = [];
        P1 = EXdata.FieldValues(CField,iNode1).values(1:3,1,1);
        iNode2 = iNode1+1:EXdata.nNodes;
        P1 = repmat(P1',numel(iNode2),1);
        P2 = zeros(numel(iNode2),3);
        for i=1:numel(iNode2)
            iN = iNode2(i);
            P2(i,1:3) = squeeze(EXdata.FieldValues(CField,iN).values(1:3,1,1));
        end
        P2 = squeeze(P2);
        dist = sum((P2-P1).^2,2);
        Iequal = find(dist==0);
        Iequal = Iequal + iNode1;
        if(bDebug), 
            if numel(Iequal)>0, fprintf('Duplicates found (n=%i)! node %i is the same as node %i\n',numel(Iequal),Iequal(1),iNode1); end
        end

        if numel(Iequal)>0
            DuplicateNodes = [DuplicateNodes Iequal'];
        end
    end
end

DuplicateNodes = unique(DuplicateNodes);
nNodes2 = EXdata.nNodes - numel(DuplicateNodes);
EXdata2.name   = EXdata.name;
EXdata2.nNodes = nNodes2;
EXdata2.ListOfFields = EXdata.ListOfFields;

iNode2=0;
for iNode1=1:EXdata.nNodes
    if numel(find(DuplicateNodes==iNode1))==0    
        iNode2 = iNode2+1;
        for iField = 1:EXdata.ListOfFields.nFields
            EXdata2.FieldValues(iField,iNode2).values = EXdata.FieldValues(iField,iNode1).values;            
        end
        EXdata2.GIN(iNode2) = EXdata.GIN(iNode1); 
    end
end
            
if iNode2~=nNodes2
    fprintf('ERROR  in removing redundant nodes. The final number of points copied into EXdata is %i, whereas %i were expected\n',iNode2,nNodes2)
end
        
            
    

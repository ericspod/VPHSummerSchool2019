function [ CH1 ] = CreateAndPlotMesh( CH, CurrMartrixDof, OutputDirectory )

%This function accepts a CH model and overwrites its coordinates in order
%to create a new independent mesh. If desired, the new mesh can be
%visualised via cmgui.

%accepts 1168x3 coordinate matrix (DOFs)
plotOutput = 1;

[k,m,n] = size(CurrMartrixDof);
singleModel = reshape(CurrMartrixDof, 1168, 3); %copy current model
   
%display single mesh: for testing only
if(plotOutput)
    %overwrtite last CH model
    S1 = 1;
    CH1 = CH.SetDofs(singleModel);
    iV = 1;
    sig = '';
    AtlasSurname = '';
    iEig = 1;
    name = [CH1.name sprintf('MyCHModel')];
    CH1.name = name;
    CH1.GroupName = name;
    CH1.InterpolationBasis = 1; %GGG    
    CH1.WriteExFiles(OutputDirectory);

%     optionsFlat.FlatOption = 2;
%     [CHmeshCorrected] = MakeFlatBase(CH1,optionsFlat);
%     CHmeshCorrected.WriteExFiles(OutputDirectory);

    opt.bOrthographic = 1;
    opt.ViewAngle = 35;
    opt.bAutomaticExit = 1;
    opt.CaptionName = sprintf('Atlas%sMode%iTest',AtlasSurname,iEig);
    opt.bSmallCaption = 1;            
    opt.ColorCH1 = GetAtlasColor(1,2);
    opt.CaptionName = sprintf('Atlas%sMode%iTest',AtlasSurname,iEig);
    cmGuiViewMesh(OutputDirectory,CH1,opt);
end

end


% -------------------------------------------------------------------------
% Written by: Matthew Sinclair. Modified by: Pablo Lamata
% Last Update: 16/05/2013
% -------------------------------------------------------------------------
% DESCRIPTION:
% This function produces a truncated (bi)ventricular segmentation in order 
% to exclude the valves from the segmentation. Three possible methods:
% (1) Using the first Principal Component of the LV bloodpool (BP) pointing
% towards the base of the heart, and creates a clipping plane based on the 
% specified number of standard deviations from the centre of mass of the LVBP.
% (2) Using the basal plane introduced as the parameter, and creating the
% clipping plane a number of mm underneath the basal plane.
% (2) Using the basal plane introduced as the parameter, and cropping the
% RV and LV valves septum
% 
%
% -------------------------------------------------------------------------
% INPUTS:
%       (1) Myo_im = binary image of myocardium segmentation
%       (2) hd = header of segmentation
%       (3) options:
%        Needed for method 1:
%         - LVBP_im = binary image of LV bloodpool segmentation (same dimensions as Myo_im)
%         - SD_factor = Standard Deviations for clipping plane
%        Needed for method 2:
%         - BasalPlane: [a b c d] of the plane equation ax + by + cz + d = 0
%         - TruncationDistanceFromPlane
%        Needed for method 3:
%         - BasalPlane: [a b c d] of the plane equation ax + by + cz + d = 0
%         - BasalPoint: a point of the basal plane inside the image volume
%        Accesory:
%         - ss = subsampling factor for output binary image
%
% -------------------------------------------------------------------------
% OUTPUTS:
%       (1) fitting_heart_im = truncated segmentation for mesh fitting
%       (2) TruncationMethod: 
%
% -------------------------------------------------------------------------

function [fitting_heart_im] = truncate_segmentation(Myo_im,hd,options)

% Default options
SD_factor = 1.5;
TruncationDistanceFromPlane = 5; % in the same units of image headers, mm
ss = 1;
bViewTruncation = 1;
TruncationMethod = 2;

if nargin>=3
    if isfield(options,'bDebug'), bViewTruncation = options.bDebug; end
    if isfield(options,'SD_factor'), 
        SD_factor = options.SD_factor; 
        TruncationMethod = 1;
    end
    if isfield(options,'ss'), ss = options.ss; end
    if isfield(options,'BasalPlane'),  BasalPlane = options.BasalPlane; end
    if isfield(options,'BasalPoint'),  
        BasalPoint = options.BasalPoint; 
        TruncationMethod = 3;
    end
    if isfield(options,'TruncationDistanceFromPlane'), 
        TruncationDistanceFromPlane = options.TruncationDistanceFromPlane; 
    end
    if isfield(options,'LVBP_im'), 
        LVBP_im = options.LVBP_im; 
        TruncationMethod = 1;
    end
end

obj = PCAtransformation;

Myo_pts = getPoints_fromBinary(Myo_im,hd.origin,hd.spacing);

switch TruncationMethod
    case 1
        % Truncation based on PC1 of LVBP
        LVBP_pts = getPoints_fromBinary(LVBP_im,hd.origin,hd.spacing);
        % PCA on LVBP giving eigenvalues (S1), eigenvectors (V1) and COM (C1)
        [S1, V1, C1] = obj.PrincipalComponentAnalysisOfShape(LVBP_pts);

        % Define number of standard deviations  PC1
        SD = SD_factor*sqrt(S1(1,1));
        PC1 = V1(:,1);
    case {2,3}
        [S1, V1, C1] = obj.PrincipalComponentAnalysisOfShape(Myo_pts);
        % The trunkation 3mm underneath:
        PC1 = BasalPlane(1:3);
        V1 = BuildOrientationMatrixFromMainVector(PC1);
end

% Ensure PC1 points toward base
t_pts = transform_coords_z_align(Myo_pts,V1,C1);
[r] = transform_coords_cylindrical(t_pts);
PC1 = check_PC1_direction(r, t_pts, PC1);

% Truncate LV myocardium
switch TruncationMethod
    case 1
        c_SD = C1+(SD*PC1)';        % truncation point
        bTruncationPlane = 1;
    case 2
        % Any point in the plane will work:
        x = C1(1); y = C1(2);
        P = BasalPlane;
        z = - ( P(1)*x + P(2)*y + P(4) ) / P(3);
        PlanePoint = [x y z];
        % Now, a distance from it:
        c_SD = PlanePoint - TruncationDistanceFromPlane * PC1./sqrt(sum(PC1.^2));
        bTruncationPlane = 1;
    case 3
        bTruncationPlane = 0;
        % Get the intersection of the volume by the plane:
        IMnrrd = Build_nrrd(Myo_im,hd);
        InterpolationChoice = 'nn';
        slope = BasalPlane(1:3);
        Pxyz = BasalPoint;
        [im gx gy gz midx] = scinrrd_intersect_plane(IMnrrd,Pxyz,slope,InterpolationChoice); 
        figure('color',[1 1 1]);
        imagesc(im);
        a=1;
end

if(bTruncationPlane)
    cut_Myo_pts = zeros(size(Myo_pts));
    count = 0;
    for i = 1:ss:length(Myo_pts)
        below = dot(PC1,(Myo_pts(i,:) - c_SD));
        if below < 0
            count = count+1;
            cut_Myo_pts(count,:) = Myo_pts(i,:);
        end
    end
    cut_Myo_pts = cut_Myo_pts(1:count,:);
    fitting_heart_points = cut_Myo_pts;

    % percentage of myocardial segmentation remaining
    perc = length(find(cut_Myo_pts~=0))*ss/length(find(Myo_pts~=0))*100;
    disp(['Percentage of myocardium retained: ' num2str(perc)]);

    % Convert points to binary 
    fitting_heart_im = getBinary_fromPoints(fitting_heart_points,hd.dim, hd.origin, hd.spacing);
end
if(bViewTruncation)
    %figure('color',[1 1 1]); 
    hold on
    show_segment_surface(fitting_heart_im,hd.Mv2w,[],0,0.5);
    %show_segment_surface(Myo_im,hd.Mv2w,[],1,0.5);
    %show_segment_surface2(fitting_heart_im,1,0.5);
    %show_segment_surface2(Myo_im,1,0.5);
end
% pars.SD = SD; pars.PC1 = PC1; pars.centre = C1; pars.c_SD = c_SD;
% pars.myo = length(find(fitting_heart_im~=0));
% pars.perc = perc;
end

function t_pts = transform_coords_z_align(pts,V,C)
% Transform coordinates to be aligned in z with the long axis of the LVBP

% Use PC1 as z-axis.
R = [V(:,3) V(:,2) V(:,1)];
t_pts = pts;
for i = 1:length(pts)
    t_pts(i,:) = pts(i,:)-C;
    t_pts(i,:) = (R'*t_pts(i,:)')';
end
end

function [r,theta] = transform_coords_cylindrical(pts)
% Transform points to cylinderical coordinates

theta = zeros(length(pts),1); r = theta;

for i=1:length(pts)
    r(i) = norm(pts(i,1:2));
    theta(i)=atan2(pts(i,2), pts(i,1));
    % Theta not used here
end
end

function PC1 = check_PC1_direction(r,t_pts,PC1)
% Check PC1 points toward base
%  Criterion: Basal points have a greater mean radius than apical points
r_above_COM = r(t_pts(:,3)>0);
r_below_COM = r(t_pts(:,3)<0);
if mean(r_above_COM) < mean(r_below_COM)
    PC1 = -PC1;
end
end

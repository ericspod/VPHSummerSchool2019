function LV_V = BuildOrientationMatrixFromMainVector(vz_temp)
    % find a vector with null dot product
    x2 = 0; y2 = 0.1;
    z2 = -(vz_temp(1)*x2 + vz_temp(2)*y2) /vz_temp(3);
    v2 = [x2 y2 z2];
    % normalise this vector:
    v2 = v2./sqrt(sum(v2.^2));
    % and then the other is the result of the cross product:
    v3 = cross(vz_temp,v2);
    % normalise this vector:
    v3 = v3./sqrt(sum(v3.^2));
    % the orientation matrix:
    LV_V = [vz_temp' v2' v3'];
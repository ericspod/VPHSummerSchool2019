function [nrow,ncol] = ComputeRowColNumber(nSlices)
% Function to compute a number of rows and columns to divide the number of
% plots that needs to be used

f = factor(nSlices);

if numel(f) == 1
    nSlices = nSlices+1;
    f = factor(nSlices);
end

% Since factors are sorted...
nrow = prod(f(1:2:end));
ncol = prod(f(2:2:end));
    
function ID = GetCaseID_HCM(DicName,i0)
% Function to extract the ID robustly to '_', as in the HCM cohort
% Input
% - DicName: name of the file
% - i0: first character with a digit
    ID = sscanf(DicName(i0:end),'%f',1);
    I_ = find( DicName == '_');
    if numel(I_ > 0)
        SecondPart = sscanf(DicName(I_+1:end),'%f',1);
        ID = sscanf( sprintf( '%i%i',ID,SecondPart), '%f',1);
    end
% Code to compute the power to find a correlatin between two samples
% number of paired samples:
N = 100;

% Hypothesised correlation to be found:
CC = 0.2;

alpha = 0.05;

%% 
nsamples = 10000;
conf = 1-alpha;
r = zeros(1,nsamples);
for j = 1:nsamples
    xy = normrnd(0,1,N,2);
    r(j) = corr(xy(:,1),xy(:,2));
end
cutoff = quantile(r,conf);

nsamples = 1000;
mu = [0; 0];
sig = [1 CC; CC 1];
r = zeros(1,nsamples);
for j = 1:nsamples
    xy = mvnrnd(mu,sig,N);
    r(j) = corr(xy(:,1),xy(:,2));
end
[power,powerci] = binofit(sum(r>cutoff),nsamples)
function p=compAUCs(recnow,CVpost1,CVpost2)
% computes whether two AUCs are significantly different
% uses method in Hanley & McNeill, Radiology, 1983
% SE of AUCs from auc_marta.m, which is adapted from 
% http://www.mathworks.com/matlabcentral/fileexchange/48165...
% -confidence-intervals-for-area-under-the-receiver-operating-curve--auc-
% Marta, 31/12/2015

recnow=logical(recnow);

% compute AUCs and SE of AUC for each metric to be compared
[AUC1,CI1,SE1] = auc_marta(cat(2,recnow, CVpost1),0.05,'hanley',500);
[AUC2,CI2,SE2] = auc_marta(cat(2,recnow, CVpost2),0.05,'hanley',500);

disp(['AUC1: ' num2str(AUC1,'%.2f') ' +- ' num2str(abs(CI1(1)-AUC1),'%.2f')])
disp(['AUC2: ' num2str(AUC2,'%.2f') ' +- ' num2str(abs(CI2(1)-AUC2),'%.2f')])

% make sure metric1 has the higher AUC because test is one-sided
if AUC1<AUC2
    AUCtemp=AUC1;
    SEtemp=SE1;
    AUC1=AUC2;
    SE1=SE2;
    AUC2=AUCtemp;
    SE2=SEtemp;
end

% compute correlation between two metrics for recurrent and non-recurrent
% cases and average
rN=corr(CVpost1(~recnow),CVpost2(~recnow));
rA=corr(CVpost1(recnow),CVpost2(recnow));
rmean=(rN+rA)/2;
AUCmean=(AUC1+AUC2)/2;

% compute corrected r value using Table 1 from Henley, McNeill
% if AUCmean is high, go back to article to populate table
if AUCmean>0.73
    error(['Current program does not contemplate such high AUCs. ' ...
        'See table 1 of Hanley, McNeill for values of r.']);
else
    if rmean>0.84
        r=rmean-0.02;
    elseif rmean>0.30
        r=rmean-0.03;
    elseif rmean>0.16
        r=rmean-0.02;
    elseif rmean>0.06
        r=rmean-0.01;
    else
        r=rmean;
    end
end

% compute z-statistic for test (from Hanley, McNeill's paper) and
% corresponding p-value (one-sided, testing for 'AUC1 is bigger than AUC2' 
% rather than 'AUCs are different')
z=(AUC1-AUC2)/sqrt(SE1^2+SE2^2-2*r*SE1*SE2);
p=normcdf(-abs(z),0,1);

disp(['p: ' num2str(p,'%.2f')])
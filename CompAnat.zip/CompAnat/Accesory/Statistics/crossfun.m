
function yfit = crossfun(xtrain, ytrain, xtest, rbf_sigma, boxconstraint)
 %Train model on xtrain, ytrain and get predictions of class of xtest
 svmStr = svmtrain(xtrain,ytrain,'Kernel_Function','rbf','rbf_sigma',rbf_sigma,'boxconstraint',boxconstraint);
 yfit = svmclassify(svmStr, xtest);
end


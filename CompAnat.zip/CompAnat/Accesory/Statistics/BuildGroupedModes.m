function GroupedModes = BuildGroupedModes(modes,Ks)
% Build the combinations of modes taken K at a time, 

nGM = 0;

if numel(modes)==1
    % gradual incrase of groups:
    for iGm=1:modes
        GroupedModes{iGm} = [1:iGm];
    end
    return;
end

if numel(modes)==2
    % gradual incrase of groups, from m1 to m2
    m1 = min(modes);
    m2 = max(modes);
    nM = m2 - m1 + 1;
    for iGm=1:nM
        GroupedModes{iGm} = [m1:m1+iGm-1];
    end
    return;
end
        

if nargin<2
    Ks = 2:numel(modes);
end
for iK = 1:numel(Ks)
    C = combnk(modes,Ks(iK));
    for iC = 1:size(C,1)
        iGm = nGM + iC;
        GroupedModes{iGm} = C(iC,:);
    end
    nGM = iGm;
end
function [diff_mean,diff_SD,rho_mean_diff,rho_x_y,poly_diff_mean,poly_corr_x_y, xydata]=BlandAltmanAgreementDeg(x,y,PLOT,Xlabel,Ylabel,Norm_unit,TitleLabel,directory,outputname,postfix,axisarray)%,x1,y1,x2,y2)
%%
% this function calculates the agreement degree between two input vectors.
% it do Bland-Altman analysis of differences and correlation plot 
% Input  arguments :
%                   x        : 1st vector 
%                   y        : 2nd vector
%                   PLOT     : plot option, it can be 'yes' or 'no' default value is yes
%                   Norm_unit: plot scaling unit (optional input)
%                   Xlabel   : horizontal axis title (correlation plot)
%                   Ylabel   : vertical   axis title (correlation plot)
% note that x and y must have the same length and must be a row vector!

% Output arguments :
%                   diff_mean     : Mean difference between the two input vectors -- mean(x-y)
%                   diff_SD       : SD of the difference between the two input vectors -- std(x-y)
%                   rho_mean_diff : Correlation coef of the Mean vector and the differences vector
%                   rho_x_y       : Correlation coef of the two input vectors x&y
%                   poly_diff_mean: linear polynomical fitted curve of the Bland-Altman plot 
%                   poly_corr_x_y : linear polynomical fitted curve of the correlation plot
% example:
%         x=rand(1,20);
%         y=rand(1,20);
%         agreementDeg(x,y,'yes','Xlabel','Ylabel',5);

titlePlot = 'Analysis of Differences (Bland-Altman) Plot';
%titlePlot = 'Correlation Analysis Plot';
dir = '';
bSave = 0;
postFix = '';
name = '';
axisarr = [-100 100 -100 100];

if nargin==5
    Norm_unit=1;
end
if nargin==3
    Xlabel='Xlabel';
    Ylabel='Ylabel';
end
if nargin==2
    PLOT='yes';
end
if ~isempty(TitleLabel)
    titlePlot = TitleLabel;
end
if exist('directory','var')
    dir = directory;
    bSave = 1;
end
if exist('postfix','var')
    postFix = postfix;
end
if exist('outputname','var')
    name = outputname;
end
if exist('axisarray','var')
    axisarr = axisarray;
end

Diff=x-y;
Mean=(x+y)/2;
diff_mean=mean(Diff);
diff_SD=std(Diff);
rhoM=corrcoef(Mean,Diff);
rho_mean_diff=rhoM(1,2);

if strcmp(PLOT,'yes')
    %%%Bland-Alman Plot, uncomment the double % % to display the plot
    %% diff analysis
% %     figure;
% %     plot(Norm_unit*Mean,Norm_unit*Diff,'*');
% %     hold on;
    
    t=linspace(min(Norm_unit*Mean),max(Norm_unit*Mean),length(Mean));
    diff_mean_vec=zeros(size(t));
    diff_mean_vec(:)=Norm_unit*diff_mean;
    diff_SD_vec=zeros(size(t));
    diff_SD_vec(:)=Norm_unit*diff_SD;
% %     plot(t,diff_mean_vec,'g');
% %     plot(t,diff_mean_vec+2*diff_SD_vec,'k');
% %     plot(t,diff_mean_vec-2*diff_SD_vec,'k');
% %     grid on;
% %     legend('Difference','Mean','Mean+2SD','Mean-2SD');hold on
    poly_diff_mean=fit(Norm_unit*Mean',Norm_unit*Diff','poly1');
    %plot(poly_diff_mean,'r');
% %     title(titlePlot);
% % %     title = titlePlot;
% %     xlabel('Average (mm)');
% %     ylabel('Difference (mm)');
    %% correlation analysis
    %Linear Regression 
    clear rhoM;
    H = figure;
    rhoM=corrcoef(x,y);
    rho_x_y=rhoM(1,2);

    [rho,pval] = corr(x',y');
    
    bNumbersOnly = 0; 
    if(bNumbersOnly)
        for i=1:length(x)
            %if i == 77%195
            %    plot(x(i),y(i),'*','Color','g'); hold on;
            %else
                plot(x(i),y(i),'','Color','b'); hold on;
            %end
        text(x(i),y(i),num2str(i));
        end
    else
        plot(Norm_unit*x,Norm_unit*y,'*');grid on;hold on;
    end

%     plot(Norm_unit*x1,Norm_unit*y1,'*','Color','b');grid on;hold on;
%     plot(Norm_unit*x2,Norm_unit*y2,'*','Color','black');grid on;hold on;
    
    poly_corr_x_y=fit(Norm_unit*x',Norm_unit*y','poly1');
    xydata = [Norm_unit*x' Norm_unit*y'];
    plot(poly_corr_x_y,'r');
% %     plot(Norm_unit*x,Norm_unit*x,'g');
%     title('Correlation Plot');
    title1 = sprintf('%s (r=%.3f, p=%.3f)', titlePlot, rho_x_y, pval);
    title(title1);
    axis(axisarr);
    xlabel(Xlabel);ylabel(Ylabel);
    
    p = polyfit(x',y',1);
    yfit = polyval(p,x');
    ymean = mean(y);
    SSR = sum((yfit-ymean).^2);
    SST = sum((y'-ymean).^2);
    Rsquared = SSR/SST;
    
    legend('x data Vs. y data','Linear Fitted Curve');%,'y=x line');
    if(bSave)
        export_fig([dir 'CorrAnalysis' name sprintf('Eigen%i',postFix) '.png'],'-png','-m2',H);
    end
end

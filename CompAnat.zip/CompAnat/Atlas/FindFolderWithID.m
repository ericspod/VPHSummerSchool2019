function [ CaseFolderName, iDirect ]= FindFolderWithID(direct,iCase,postname)
% Function to find the folder with the name that ends in the digits of the
% iCase. The mapping can also have a "postname" after the digit

bCheckNameEnding = 0;
if nargin>=3
    bCheckNameEnding = 1;
end
    CaseFolderName = NaN;
    for iDirect = 3:numel(direct)
        bValid = 1;
        name = direct(iDirect).name;
        if (bCheckNameEnding)
            % Only the case with the name ending in postname can be
            % considered:
            if numel(name)>numel(postname)
                if ~strcmp(name(end-numel(postname)+1:end),postname)
                    bValid = 0;
                end
            else
                bValid = 0;
            end
        end
        if(bValid)
            %ID = GetIDfromName(name);
            ID = GetNumberFromName(name,2);
            if ID == iCase
                CaseFolderName = name;
                return;
            end
        end
    end
end
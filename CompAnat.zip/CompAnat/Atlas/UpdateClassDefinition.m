function NewClassDefinition = UpdateClassDefinition(ClassDefinition,GroupedClasses)
% Agreggate subclasses for further analysis

nNewClasses = numel(GroupedClasses);

for iC = 1:nNewClasses
    MergedOldClasses = GroupedClasses{iC};
    nGrouped = numel(MergedOldClasses);
    if nGrouped == 1
        NewClassDefinition(iC) = ClassDefinition(MergedOldClasses);
    else
        % Not a unique value to define here:
        NewClassDefinition(iC).TypeInFile = NaN;
        NewClassDefinition(iC).PatID = [];
        NewClassDefinition(iC).Indexes = [];
        NewClassDefinition(iC).FileID = [];
        for iOld = 1:nGrouped
            iO = MergedOldClasses(iOld);
            NewClassDefinition(iC).PatID = [NewClassDefinition(iC).PatID ClassDefinition(iO).PatID];
            NewClassDefinition(iC).Indexes = [NewClassDefinition(iC).Indexes ClassDefinition(iO).Indexes];
            NewClassDefinition(iC).FileID = [NewClassDefinition(iC).FileID ClassDefinition(iO).FileID];
        end
        NewClassDefinition(iC).nCases = numel(NewClassDefinition(iC).FileID);
    end
end

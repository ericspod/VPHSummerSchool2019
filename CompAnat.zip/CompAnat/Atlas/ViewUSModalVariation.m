function [Handle] = ViewUSModalVariation(directory,iEig,S,options)
% Function to visualise the modal variations from 2D US contours, generated
% with the CalculateUSAtlas.m function
%
% INPUT:
% - directory: where the output of CaculateUSAtlas has been saved. This is
% a file called "Atlas.mat" by default, or "Atlas*.mat", where * stands for
% any 'surname' given to the main name to differentiate studies. 
% - iEig: index(es) of the modes to visualise
% - S: number of standar deviations to choose for the extremes of the
% distribution of the population in this eigenvector.
%
% OUTPUT:
% - handle of the plot

bTogether = 1;

ss = [];
AtlasSurname = '';
AtlasFileName = 'Atlas.mat';
bMovie = 0;

if nargin==4
    if isfield(options,'AtlasSurname'), AtlasSurname = options.AtlasSurname;  end
    if isfield(options,'AtlasFileName'), AtlasFileName = options.AtlasFileName;  end    
    if isfield(options,'bMovie'), bMovie = options.bMovie;  end    
end

AtlasFile = fullfile(directory, AtlasFileName);
fprintf('Reading atlas %s\n',AtlasFile);
load(AtlasFile);
% This loads 'V','ss','MeanDofs'

nM = numel(iEig);
if bTogether, 
    posit = [50 50 nM*200 200];
else
    posit = [50 50 nM*200 300];
end
Handle = figure('color',[1 1 1],'Outerposition',posit);

for iM = 1:nM
    if bTogether, 
        subplot(1,nM,iM)
    end
    iV = iEig(iM);
    S1 = S*sqrt(ss(end-iV+1));
    hold on;
    nDofs = size(MeanDofs);
    eigenvector = GetVector(iV,V,nDofs);

    LineWidth = 3;
    if(bMovie)
        % plot an additional contour:
        PlotEchoContours(MeanDofs + S1 * eigenvector,GetAtlasColor(4,2,S),3);
        % And fix the other ones to +/- 2 std
        S1 = 2*sqrt(ss(end-iV+1));
        LineWidth = 0.5;
    end
    % plot the average:
    if~bTogether, subplot(2,nM,iM); hold on; end
    PlotEchoContours(MeanDofs,GetAtlasColor(1,2), LineWidth);
    % plot the extremes:
    PlotEchoContours(MeanDofs + S1 * eigenvector, GetAtlasColor(2,2), LineWidth);
    if~bTogether, 
        axis 'off';
        subplot(2,nM,iM+nM);
        hold on;
    end
    PlotEchoContours(MeanDofs - S1 * eigenvector, GetAtlasColor(3,2), LineWidth);
    if~bTogether, 
        PlotEchoContours(MeanDofs,GetAtlasColor(1,2), LineWidth);
    end
    %axis 'off';
    title(sprintf('Mode %i',iV));
end


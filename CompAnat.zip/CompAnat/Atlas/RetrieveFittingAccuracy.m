function [MeanAccuracy,MeanQuality,Accuracy,Quality,RegAcc] = RetrieveFittingAccuracy(DataDirectory , options )%SubDirectory,)
% 
% Version control
% - 05/06/18: removal of the fileVersion,SpecialListCases options (need to
% bring them back if needed to)


bPlot = 0;
[ListCases] = GetCasesInDirectory(DataDirectory);
nCases = numel(ListCases);
Accuracy = NaN*ones(1,nCases);
Quality = NaN*ones(1,nCases);
RegAcc = NaN*ones(1,nCases);

% Default options:
SubDirectory = '';
OutDir = 'Output_heartgen';


direc = dir(DataDirectory);

%Support for old and new file versions of PersonalizationReport.txt files
%given as a parameter. Useful for merging old and new PersonalizationReport
%file versions.
version = 'oldVersion';

if nargin>=2
    if isfield(options,'SubDirectory'), SubDirectory = options.SubDirectory; end
    if isfield(options,'OutDir'),       OutDir = options.OutDir; end
end
if(exist('fileVersion','var'))
    version = fileVersion;
end
if(exist('SpecialListCases','var'))
    ListOldCases = SpecialListCases; %user provided list of files with different PersonalizationReport*.txt version    
else
    ListOldCases = NaN;
end

iCase = 0;
for iDir = 3:numel(direc)
    CaseDir = direc(iDir).name;
    %ReportFile = [DataDirectory 'EVS' sprintf('%03i',iCase) '/zmask/Output_heartgen/PersonalizationReportBinaryMask.txt'];
    ReportFile = fullfile(DataDirectory,  CaseDir, SubDirectory, OutDir, '/PersonalizationReport*.txt');
    NameFile = ls(ReportFile);
    if numel(NameFile)>0
        iCase = iCase + 1;
        NameFile = deblank2(NameFile(end,:));
        ReportFile = fullfile(DataDirectory,  CaseDir, SubDirectory, OutDir, NameFile);
        if exist(ReportFile,'file')
            fprintf('Reading report of directory %i (file: %s)\n',iCase,ReportFile);
            
            %Set specific file version for the cases provided
            lastversion = version;
            if(~isnan(ListOldCases))
                caseid = str2num(direc(iDir).name(end-2:end));            
                FileIndex = find(caseid == ListOldCases);
                if(FileIndex > 0)
                    version = 'oldVersion';
                else
                    version = 'newVersion';
                end            
            end
            Report = ReadPersonalizationReport(ReportFile,version);
            version = lastversion;
            
            RegAcc(iCase) = Report.RegAcc;
            Accuracy(iCase) = Report.MeanEuclDist;
            Quality(iCase) = Report.MeshQ_JacobianRatio(1);
        else
            fprintf('WARNING! Report of case %i not found (file: %s)\n',iCase,ReportFile);
        end
    end
end

MeanAccuracy(1) = mean(Accuracy(~isnan(Accuracy)));
MeanAccuracy(2) = std(Accuracy(~isnan(Accuracy)));
MeanQuality  = mean(Quality(~isnan(Quality)));

if(bPlot)
    figure('color',[1 1 1]);
    subplot(211), plot(Accuracy), title('Accuracy per case')
    subplot(212), plot(Quality), title('Quality per case')
end
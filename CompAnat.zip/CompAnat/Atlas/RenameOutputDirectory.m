function OutputDirectory = RenameOutputDirectory(OutputDirectory,AtlasAlignmentOption)
AlignmentOptionChar = '';
switch AtlasAlignmentOption
    case {-1}
        % do nothing: default option for cases where there was no study of
        % the different shape spaces
    case {0,'NA'}
        AlignmentOptionChar = 'NA';
    case {1,'C'}
        AlignmentOptionChar = 'C';
    case {2,'R'}
        AlignmentOptionChar = 'R';
    case {3,'S'}
        AlignmentOptionChar = 'S';
    case {4,'rv'}
        AlignmentOptionChar = 'rv';      
end
OutputDirectory = [OutputDirectory AlignmentOptionChar];

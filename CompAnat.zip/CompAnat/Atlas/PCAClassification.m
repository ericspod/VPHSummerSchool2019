function [clapLinear,clapQuad,clap1vs3,clap3vs4,clap1vs4 ] = PCAClassification(OutputDirectory, options)

    clapLinear = [];
    clapQuad = []; 
    clap1vs3 = []; 
    clap3vs4 = []; 
    clap1vs4 = []; 
    
    %LDA

    %OLD: load('E:\data\GG\TestsReconstruction\224cases\residualShapeCases\AllVariables_ResidualShapeCases.mat')


    %NEW: With ALL Derivatives
    %load('E:\data\GG\TestsReconstruction\224cases\residualShapeCases\AllVariables_ResidualShapeCases-WithDerivatives.mat')

    %with SOME Derivatives - duds1, duds2, duds12
    %load('E:\data\GG\TestsReconstruction\224cases\residualShapeCases\AllVariables_ResidualShapeCases-WithSomeDerivatives-coords_ds1_ds2_ds12.mat')

    %single variable (Len,Ext,Lum)
    % load('U:\ResultsTraditionalModels\224cases\LVMeasures2DLenExtLum.mat') 

    %separate variables (Len,Ext,Lum)
    % load('U:\ResultsTraditionalModels\224cases\LVMeasures2DByCase.mat') 

    %all variables (12) based on LVdimensions.xlsx
    % load('U:\ResultsTraditionalModels\224cases\LVAllMeasures2D.mat')

    ResultsDir = 'U:\ResultsTraditionalModels\224cases\';   
    OutputPath = 'Classification\cLagrangeFixedSurfaceCoords\';

    numberTrial = 1;
    

    b2DMeasurements = 0;    %length,epi,endo (3 dims)
    bOriginal3PCs = 0;      %first 3 original PCs
    b2DMeasurementsALL = 0; %all 12 measurements
    b2DMeasurements11 = 0;  %11 measurements
    b2DMeasurementsOnly5 = 0;  %5 measurements (length,vol,mass,epi,endo)
    b2DMeasurementsOnly6 = 0;  %6 measurements (length,vol,mass,epi,endo,avg)
    arr22DMeasurementsOnly6 = [2:6,13];
    b2DMeasurementsWallThickness = 0; %6 "wall" measurements
    bUse11coordsP = 0;      %3 a-priori + 8 PCs
    bOriginalALLPCs = 0;    %first N original PCs
    numOriginalCoordsP = 3;
    arrNumOrigiCoordsP = [2:(numOriginalCoordsP+1)];

    bCase1vs3vs4 = 1; 
    bCase1vs3 = 0;
    bCase3vs4 = 0;
    bCase1vs4 = 0;

    b2DMeasurementsMMOnly = 1; %(depends on b2DMeasurementsALL)  %mm-based measurements only (11 measurements but vol,mass)
    arr2DMeasurementsMMOnly = [2,5:12];
   
    bQuadratic = 1;    
    
    if nargin==2
       if isfield(options,'bCase1vs3vs4'),  bCase1vs3vs4 = options.bCase1vs3vs4;  end  
       if isfield(options,'bCase1vs3'),  bCase1vs3 = options.bCase1vs3;  end  
       if isfield(options,'bCase3vs4'),  bCase3vs4 = options.bCase3vs4;  end  
       if isfield(options,'bCase1vs4'),  bCase1vs4 = options.bCase1vs4;  end  
       
       if isfield(options,'bQuadratic'),  bQuadratic = options.bQuadratic;  end  
       if isfield(options,'numberTrial'),  numberTrial = options.numberTrial;  end  
       if isfield(options,'ResultsDir'),  ResultsDir = options.ResultsDir;  end  
       if isfield(options,'OutputPath'),  OutputPath = options.OutputPath;  end  
       
    end
    
    OutputDirClassification = [ResultsDir OutputPath];
    
    GetCases;
    
    %p-values (PCA coordinates arranged by case)
    coordsP = [LVMeasures3DByCase1; LVMeasures3DByCase3; LVMeasures3DByCase4];
    [m1,n] = size(LVMeasures3DByCase1);
    caseIDs1 = repmat(1, 1, m1);
    [m3,n] = size(LVMeasures3DByCase3);
    caseIDs3 = repmat(3, 1, m3);
    [m4,n] = size(LVMeasures3DByCase4);
    caseIDs4 = repmat(4, 1, m4);

    caseIDsInLine = [caseIDs1 caseIDs3 caseIDs4];
    caseIDsInLine = caseIDsInLine';
    
    %first 3 a-priori PCs (default)
    pLength = coordsP(:,2); 
    pEndo = coordsP(:,3); %Epi and endo columns are inverted in GetCases.m with respect to PCA coords variable 'p', swap them here
    pEpi = coordsP(:,4);
    
    
    bCase3and4together = 0;
    if(bCase3and4together) %cases 3 and 4 (adults) together
        m3and4 = m3 + m4;
        caseIDsInLine3and4 = repmat(34, 1, m3and4);  
        caseIDsInLine = [caseIDs1 caseIDsInLine3and4]; 
        caseIDsInLine = caseIDsInLine';
    end

    if(bCase1vs3vs4) %three way comparison
        caseIDsInLine = [caseIDs1 caseIDs3 caseIDs4];
        caseIDsInLine = caseIDsInLine';
        %Cases 1 vs 3
        caseIDs1and3 = [caseIDs1 caseIDs3];
        caseIDs1and3 = caseIDs1and3';
        [ids1vs3m,~] = size(caseIDs1and3);
        %Cases 3 vs 4
        caseIDs3and4 = [caseIDs3 caseIDs4];
        caseIDs3and4 = caseIDs3and4';
        [k,~] = size(caseIDsInLine);
        [l,~] = size(caseIDs3and4);
        ids3vs4n = (k-l)+1;
        %Cases 1 vs 4
        caseIDs1and4 = [caseIDs1 caseIDs4];
        caseIDs1and4 = caseIDs1and4';
        [~,ids1vs4m] = size(caseIDs1);
        [~,ids1vs4n] = size(caseIDs4);

        %default is coordsP, assign values (Case1vs3,3vs4,1vs4)    
        pLength1vs3 = coordsP(1:ids1vs3m,2);
        pEndo1vs3 = coordsP(1:ids1vs3m,3);
        pEpi1vs3 = coordsP(1:ids1vs3m,4);

        pLength3vs4 = coordsP(ids3vs4n:end,2); 
        pEndo3vs4 = coordsP(ids3vs4n:end,3);
        pEpi3vs4 = coordsP(ids3vs4n:end,4);    

        pLength1tmp = coordsP(1:ids1vs4m,2)'; 
        pLength4tmp = coordsP((end-ids1vs4n)+1:end,2)';  
        pLength1vs4 = [pLength1tmp pLength4tmp]';
        pEndo1tmp = coordsP(1:ids1vs4m,3)';
        pEndo4tmp = coordsP((end-ids1vs4n)+1:end,3)';  
        pEndo1vs4 = [pEndo1tmp pEndo4tmp]';
        pEpi1tmp = coordsP(1:ids1vs4m,4)';
        pEpi4tmp = coordsP((end-ids1vs4n)+1:end,4)'; 
        pEpi1vs4 = [pEpi1tmp pEpi4tmp]';

        cp1and3 = cvpartition(caseIDs1and3,'k',10); % Stratified cross-validation
        cp3and4 = cvpartition(caseIDs3and4,'k',10); % Stratified cross-validation
        cp1and4 = cvpartition(caseIDs1and4,'k',10); % Stratified cross-validation

        %cvpart = cvpartition(caseIDs1and3,'holdout',0.3);

        %save cross-validation partition on disk to load in future tests
        if ~exist([OutputDirClassification 'cvpartitionsCase1vs3vs4' '_Trial' num2str(numberTrial) '.mat'])
            save([OutputDirClassification 'cvpartitionsCase1vs3vs4' '_Trial' num2str(numberTrial) '.mat'],'cp1and3','cp3and4','cp1and4');
            fprintf('cvpartitionsCase1vs3vs4%s_Trial.mat Saved\n', num2str(numberTrial));
        else
            load([OutputDirClassification 'cvpartitionsCase1vs3vs4' '_Trial' num2str(numberTrial) '.mat']);    
            fprintf('cvpartitionsCase1vs3vs4_Trial%s.mat Loaded from disk\n', num2str(numberTrial));
        end


    end

    plotWindowSize = [-150 150 -60 60];

    if(b2DMeasurements)
        fprintf('2D - 3 dimensions\n');
        %2D manual measurements (originally obtained from LVdimensions.xlsx)
        %Length, Epi and Endo
        values2D = [LVMeasures2DByCase1; LVMeasures2DByCase3; LVMeasures2DByCase4];
        [m1,n] = size(LVMeasures2DByCase1);
        caseIDs1 = repmat(1, 1, m1);
        [m3,n] = size(LVMeasures2DByCase3);
        caseIDs3 = repmat(3, 1, m3);
        [m4,n] = size(LVMeasures2DByCase4);
        caseIDs4 = repmat(4, 1, m4);
        caseIDsInLine = [caseIDs1 caseIDs3 caseIDs4];
        caseIDsInLine = caseIDsInLine';

        if(bCase3and4together)
            m3and4 = m3 + m4;
            caseIDsInLine3and4 = repmat(34, 1, m3and4);  
            caseIDsInLine = [caseIDs1 caseIDsInLine3and4]; 
            caseIDsInLine = caseIDsInLine';
        end

        pLength = values2D(:,2); 
        pEndo = values2D(:,3);
        pEpi = values2D(:,4); 

        if(bCase1vs3vs4)    %three way comparison
            pLength1vs3 = values2D(1:ids1vs3m,2);
            pEndo1vs3 = values2D(1:ids1vs3m,3);
            pEpi1vs3 = values2D(1:ids1vs3m,4);   

            pLength3vs4 = values2D(ids3vs4n:end,2); 
            pEndo3vs4 = values2D(ids3vs4n:end,3);
            pEpi3vs4 = values2D(ids3vs4n:end,4); 

            pLength1tmp = values2D(1:ids1vs4m,2)'; 
            pLength4tmp = values2D((end-ids1vs4n)+1:end,2)';  
            pLength1vs4 = [pLength1tmp pLength4tmp]';
            pEndo1tmp = values2D(1:ids1vs4m,3)';
            pEndo4tmp = values2D((end-ids1vs4n)+1:end,3)';  
            pEndo1vs4 = [pEndo1tmp pEndo4tmp]';
            pEpi1tmp = values2D(1:ids1vs4m,4)';
            pEpi4tmp = values2D((end-ids1vs4n)+1:end,4)'; 
            pEpi1vs4 = [pEpi1tmp pEpi4tmp]';        
        end

        plotWindowSize = [-150 150 -150 150];
    end

    if(b2DMeasurementsALL || b2DMeasurementsWallThickness || b2DMeasurements11... 
        || b2DMeasurementsOnly5 || b2DMeasurementsOnly6)
        %2D manual measurements (originally obtained from LVdimensions.xlsx)
        %Length, Volume, Mass, Endo, Epi, Anterior, Anterolateral,
        % Inferolateral, Inferior, Inferoseptal, Anteroseptal, Average

        values2DALL = [LVAllMeasures2DByCase1; LVAllMeasures2DByCase3; LVAllMeasures2DByCase4];
        [m1,n] = size(LVAllMeasures2DByCase1);
        caseIDs1 = repmat(1, 1, m1);
        [m3,n] = size(LVAllMeasures2DByCase3);
        caseIDs3 = repmat(3, 1, m3);
        [m4,n] = size(LVAllMeasures2DByCase4);
        caseIDs4 = repmat(4, 1, m4);
        caseIDsInLine = [caseIDs1 caseIDs3 caseIDs4];
        caseIDsInLine = caseIDsInLine';

        if(bCase3and4together)
            m3and4 = m3 + m4;
            caseIDsInLine3and4 = repmat(34, 1, m3and4);  
            caseIDsInLine = [caseIDs1 caseIDsInLine3and4]; 
            caseIDsInLine = caseIDsInLine';
        end

        length2DTmp = values2DALL(:,2); 
        volume2DTmp = values2DALL(:,3);
        mass2DTmp = values2DALL(:,4);
        endo2DTmp = values2DALL(:,5);
        epi2DTmp = values2DALL(:,6);
        anterio2DTmp = values2DALL(:,7);
        anteroLat2DTmp = values2DALL(:,8);
        inferoLat2DTmp = values2DALL(:,9);
        inferior2DTmp = values2DALL(:,10);
        inferoSep2DTmp = values2DALL(:,11);
        anteroSep2DTmp = values2DALL(:,12);
        average2DTmp = values2DALL(:,13);  

        if(bCase1vs3vs4) %three way comparison
            %Case1vs3
            length2DTmp1vs3 = values2DALL(1:ids1vs3m,2);
            volume2DTmp1vs3 = values2DALL(1:ids1vs3m,3);
            mass2DTmp1vs3 = values2DALL(1:ids1vs3m,4); 
            endo2DTmp1vs3 = values2DALL(1:ids1vs3m,5); 
            epi2DTmp1vs3 = values2DALL(1:ids1vs3m,6); 
            anterio2DTmp1vs3 = values2DALL(1:ids1vs3m,7); 
            anteroLat2DTmp1vs3 = values2DALL(1:ids1vs3m,8); 
            inferoLat2DTmp1vs3 = values2DALL(1:ids1vs3m,9); 
            inferior2DTmp1vs3  = values2DALL(1:ids1vs3m,10); 
            inferoSep2DTmp1vs3 = values2DALL(1:ids1vs3m,11); 
            anteroSep2DTmp1vs3 = values2DALL(1:ids1vs3m,12); 
            average2DTmp1vs3 = values2DALL(1:ids1vs3m,13); 
            %Case3vs4
            length2DTmp3vs4 = values2DALL(ids3vs4n:end,2);
            volume2DTmp3vs4 = values2DALL(ids3vs4n:end,3);
            mass2DTmp3vs4 = values2DALL(ids3vs4n:end,4); 
            endo2DTmp3vs4 = values2DALL(ids3vs4n:end,5); 
            epi2DTmp3vs4 = values2DALL(ids3vs4n:end,6); 
            anterio2DTmp3vs4 = values2DALL(ids3vs4n:end,7); 
            anteroLat2DTmp3vs4 = values2DALL(ids3vs4n:end,8); 
            inferoLat2DTmp3vs4 = values2DALL(ids3vs4n:end,9); 
            inferior2DTmp3vs4  = values2DALL(ids3vs4n:end,10); 
            inferoSep2DTmp3vs4 = values2DALL(ids3vs4n:end,11); 
            anteroSep2DTmp3vs4 = values2DALL(ids3vs4n:end,12); 
            average2DTmp3vs4 = values2DALL(ids3vs4n:end,13); 
            %Case1vs4        
            length2DTmp1vs4 = [values2DALL(1:ids1vs4m,2)' values2DALL((end-ids1vs4n)+1:end,2)']';
            volume2DTmp1vs4 = [values2DALL(1:ids1vs4m,3)' values2DALL((end-ids1vs4n)+1:end,3)']';
            mass2DTmp1vs4 = [values2DALL(1:ids1vs4m,4)' values2DALL((end-ids1vs4n)+1:end,4)']';
            endo2DTmp1vs4 = [values2DALL(1:ids1vs4m,5)' values2DALL((end-ids1vs4n)+1:end,5)']';
            epi2DTmp1vs4 = [values2DALL(1:ids1vs4m,6)' values2DALL((end-ids1vs4n)+1:end,6)']';
            anterio2DTmp1vs4 = [values2DALL(1:ids1vs4m,7)' values2DALL((end-ids1vs4n)+1:end,7)']';
            anteroLat2DTmp1vs4 = [values2DALL(1:ids1vs4m,8)' values2DALL((end-ids1vs4n)+1:end,8)']';
            inferoLat2DTmp1vs4 = [values2DALL(1:ids1vs4m,9)' values2DALL((end-ids1vs4n)+1:end,9)']';
            inferior2DTmp1vs4 = [values2DALL(1:ids1vs4m,10)' values2DALL((end-ids1vs4n)+1:end,10)']';
            inferoSep2DTmp1vs4 = [values2DALL(1:ids1vs4m,11)' values2DALL((end-ids1vs4n)+1:end,11)']';
            anteroSep2DTmp1vs4 = [values2DALL(1:ids1vs4m,12)' values2DALL((end-ids1vs4n)+1:end,12)']';
            average2DTmp1vs4 = [values2DALL(1:ids1vs4m,13)' values2DALL((end-ids1vs4n)+1:end,13)']';        
        end

    end

    if(bUse11coordsP)
        %11 p-values [3 a-priori + 8 obtained thru SVD] (PCA coordinates arranged by case)    
        %Epi and endo columns are not inverted in GetCases.m with respect to PCA coords variable 'p'  
        coordsP11eigvecs = [p11coordsPByCase1; p11coordsPByCase3; p11coordsPByCase4];
        [m1,n] = size(p11coordsPByCase1);
        caseIDs1 = repmat(1, 1, m1);
        [m3,n] = size(p11coordsPByCase3);
        caseIDs3 = repmat(3, 1, m3);
        [m4,n] = size(p11coordsPByCase4);
        caseIDs4 = repmat(4, 1, m4);
        caseIDsInLine = [caseIDs1 caseIDs3 caseIDs4];
        caseIDsInLine = caseIDsInLine';

        if(bCase3and4together)
            m3and4 = m3 + m4;
            caseIDsInLine3and4 = repmat(34, 1, m3and4);  
            caseIDsInLine = [caseIDs1 caseIDsInLine3and4]; 
            caseIDsInLine = caseIDsInLine';
        end   

        if(bCase1vs3vs4)    %three way comparison
            coordsP11eigvecs1vs3 = coordsP11eigvecs(1:ids1vs3m,2:end);
            coordsP11eigvecs3vs4 = coordsP11eigvecs(ids3vs4n:end,2:end); 
            coordsP11eigvecs1tmp = coordsP11eigvecs(1:ids1vs4m,2:end)';
            coordsP11eigvecs4tmp = coordsP11eigvecs((end-ids1vs4n)+1:end,2:end)';
            coordsP11eigvecs1vs4 = [coordsP11eigvecs1tmp coordsP11eigvecs4tmp]';        
        end
    end

    if(bOriginal3PCs)
        fprintf('3 Original PCs\n');
        %p-values (original 3PCs - PCA coordinates arranged by case)
        originalPCs = [LVOriginalPCsByCase1; LVOriginalPCsByCase3; LVOriginalPCsByCase4];
        [m1,n] = size(LVOriginalPCsByCase1);
        caseIDs1 = repmat(1, 1, m1);
        [m3,n] = size(LVOriginalPCsByCase3);
        caseIDs3 = repmat(3, 1, m3);
        [m4,n] = size(LVOriginalPCsByCase4);
        caseIDs4 = repmat(4, 1, m4);
        caseIDsInLine = [caseIDs1 caseIDs3 caseIDs4];
        caseIDsInLine = caseIDsInLine';

        if(bCase3and4together)
            m3and4 = m3 + m4;
            caseIDsInLine3and4 = repmat(34, 1, m3and4);  
            caseIDsInLine = [caseIDs1 caseIDsInLine3and4]; 
            caseIDsInLine = caseIDsInLine';
        end

        pLength = originalPCs(:,2); 
        pEndo = originalPCs(:,3);
        pEpi = originalPCs(:,4);   

        if(bCase1vs3vs4) %three way comparison
            pLength1vs3 = originalPCs(1:ids1vs3m,2);
            pEndo1vs3 = originalPCs(1:ids1vs3m,3);
            pEpi1vs3 = originalPCs(1:ids1vs3m,4);

            pLength3vs4 = originalPCs(ids3vs4n:end,2); 
            pEndo3vs4 = originalPCs(ids3vs4n:end,3);
            pEpi3vs4 = originalPCs(ids3vs4n:end,4); 

            pLength1tmp = originalPCs(1:ids1vs4m,2)'; 
            pLength4tmp = originalPCs((end-ids1vs4n)+1:end,2)';  
            pLength1vs4 = [pLength1tmp pLength4tmp]';
            pEndo1tmp = originalPCs(1:ids1vs4m,3)';
            pEndo4tmp = originalPCs((end-ids1vs4n)+1:end,3)';  
            pEndo1vs4 = [pEndo1tmp pEndo4tmp]';
            pEpi1tmp = originalPCs(1:ids1vs4m,4)';
            pEpi4tmp = originalPCs((end-ids1vs4n)+1:end,4)'; 
            pEpi1vs4 = [pEpi1tmp pEpi4tmp]';        
        end
        plotWindowSize = [-250 250 -250 250];
    end

    if(bOriginalALLPCs)
        fprintf('%i Original PCs\n', numOriginalCoordsP);
        %N number of original P coordinates (take only N number of columns)
        originalPCsN = [pALLOrigCoordsPByCase1(:,arrNumOrigiCoordsP); ...
            pALLOrigCoordsPByCase3(:,arrNumOrigiCoordsP); pALLOrigCoordsPByCase4(:,arrNumOrigiCoordsP)];

        [m1,n] = size(pALLOrigCoordsPByCase1(:,arrNumOrigiCoordsP));
        caseIDs1 = repmat(1, 1, m1);
        [m3,n] = size(pALLOrigCoordsPByCase3(:,arrNumOrigiCoordsP));
        caseIDs3 = repmat(3, 1, m3);
        [m4,n] = size(pALLOrigCoordsPByCase4(:,arrNumOrigiCoordsP));
        caseIDs4 = repmat(4, 1, m4);
        caseIDsInLine = [caseIDs1 caseIDs3 caseIDs4];
        caseIDsInLine = caseIDsInLine';

        if(bCase3and4together)
            m3and4 = m3 + m4;
            caseIDsInLine3and4 = repmat(34, 1, m3and4);  
            caseIDsInLine = [caseIDs1 caseIDsInLine3and4]; 
            caseIDsInLine = caseIDsInLine';
        end   

        if(bCase1vs3vs4)    %three way comparison
            originalPCsNeigvecs1vs3 = originalPCsN(1:ids1vs3m,:);
            originalPCsNeigvecs3vs4 = originalPCsN(ids3vs4n:end,:); 
            originalPCsNeigvecs1tmp = originalPCsN(1:ids1vs4m,:)';
            originalPCsNeigvecs4tmp = originalPCsN((end-ids1vs4n)+1:end,:)';
            originalPCsNeigvecs1vs4 = [originalPCsNeigvecs1tmp originalPCsNeigvecs4tmp]';
        end
    end

    bPlot = 0;
    if(bPlot)
        %Plot between pLength and pEpi
        h1 = gscatter(pLength,pEpi,caseIDsInLine,'krb','ov^',[],'off');
        set(h1,'LineWidth',2)
        if(bCase3and4together == 0)
            legend('Case1','Case3','Case4','Location','best')
        else
            legend('Case1','Case3and4','Location','best')
        end

        hold on
        X = [pLength,pEpi];
        cls = ClassificationDiscriminant.fit(X,caseIDsInLine);
        if(bCase3and4together == 0)
            %first line % boundary between the second and third classes
            K = cls.Coeffs(2,3).Const;
            L = cls.Coeffs(2,3).Linear;
            f = @(x1,x2) K + L(1)*x1 + L(2)*x2;
            h2 = ezplot(f,plotWindowSize);
            set(h2,'Color','r','LineWidth',2)
        end
        %second line % boundary between the first and second classes
        K = cls.Coeffs(1,2).Const;
        L = cls.Coeffs(1,2).Linear;
        f = @(x1,x2) K + L(1)*x1 + L(2)*x2;
        h3 = ezplot(f,plotWindowSize);
        set(h3,'Color','k','LineWidth',2)
        % axis([.9 7.1 0 2.5])

        xlabel('Length')
        ylabel('Epi')
        title('{\bf Linear Classification with Fisher Training Data}')


        if(bQuadratic)
            cqs = ClassificationDiscriminant.fit(X,caseIDsInLine,'DiscrimType','quadratic');
            if(bCase3and4together == 0)
                delete(h2); 
            end

            delete(h3) % First, remove the linear boundaries from the plot.

            if(bCase3and4together == 0)
                % Now, retrieve the coefficients for the quadratic boundary between the
                % second and third classes.
                K = cqs.Coeffs(2,3).Const;
                L = cqs.Coeffs(2,3).Linear;
                Q = cqs.Coeffs(2,3).Quadratic;

                % Plot the curve K + [x1,x2]*L + [x1,x2]*Q*[x1,x2]' = 0.
                f = @(x1,x2) K + L(1)*x1 + L(2)*x2 + Q(1,1)*x1.^2 + ...
                    (Q(1,2)+Q(2,1))*x1.*x2 + Q(2,2)*x2.^2;
                h2 = ezplot(f,plotWindowSize);
                set(h2,'Color','r','LineWidth',2)
            end

            % Now, retrieve the coefficients for the quadratic boundary between the
            % first and second classes.
            K = cqs.Coeffs(1,2).Const;
            L = cqs.Coeffs(1,2).Linear;
            Q = cqs.Coeffs(1,2).Quadratic;

            % Plot the curve K + [x1,x2]*L + [x1,x2]*Q*[x1,x2]'=0:
            f = @(x1,x2) K + L(1)*x1 + L(2)*x2 + Q(1,1)*x1.^2 + ...
                (Q(1,2)+Q(2,1))*x1.*x2 + Q(2,2)*x2.^2;
            h3 = ezplot(f,plotWindowSize); % Plot the relevant portion of the curve.

            set(h3,'Color','k','LineWidth',2)
            %axis([-250 250 -250 250])
            xlabel('Length')
            ylabel('Epi')
            title('{\bf Quadratic Classification with Fisher Training Data}')
            hold off
        end

        %%%
        %Plot between pEpi and pEndo
        figure
        h4 = gscatter(pEndo,pEpi,caseIDsInLine,'krb','ov^',[],'off');
        set(h4,'LineWidth',2)
        if(bCase3and4together == 0)
            legend('Case1','Case3','Case4','Location','best')
        else
            legend('Case1','Case3and4','Location','best')
        end
        hold on
        X = [pEndo,pEpi];
        cls = ClassificationDiscriminant.fit(X,caseIDsInLine);
        if(bCase3and4together == 0)
            %first line % boundary between the second and third classes
            K = cls.Coeffs(2,3).Const;
            L = cls.Coeffs(2,3).Linear;
            f = @(x1,x2) K + L(1)*x1 + L(2)*x2;
            h5 = ezplot(f,plotWindowSize);
            set(h5,'Color','r','LineWidth',2)
        end
        %second line % boundary between the first and second classes
        K = cls.Coeffs(1,2).Const;
        L = cls.Coeffs(1,2).Linear;
        f = @(x1,x2) K + L(1)*x1 + L(2)*x2;
        h6 = ezplot(f,plotWindowSize);
        set(h6,'Color','k','LineWidth',2)
        % axis([.9 7.1 0 2.5])

        xlabel('Endo')
        ylabel('Epi')
        title('{\bf Linear Classification with Fisher Training Data}')

        if(bQuadratic)
            cqs = ClassificationDiscriminant.fit(X,caseIDsInLine,'DiscrimType','quadratic');
            if(bCase3and4together == 0)
                delete(h5); 
            end
            delete(h6) % First, remove the linear boundaries from the plot.
            if(bCase3and4together == 0)
                % Now, retrieve the coefficients for the quadratic boundary between the
                % second and third classes.
                K = cqs.Coeffs(2,3).Const;
                L = cqs.Coeffs(2,3).Linear;
                Q = cqs.Coeffs(2,3).Quadratic;

                % Plot the curve K + [x1,x2]*L + [x1,x2]*Q*[x1,x2]' = 0.
                f = @(x1,x2) K + L(1)*x1 + L(2)*x2 + Q(1,1)*x1.^2 + ...
                    (Q(1,2)+Q(2,1))*x1.*x2 + Q(2,2)*x2.^2;
                h5 = ezplot(f,plotWindowSize);
                set(h5,'Color','r','LineWidth',2)
            end

            % Now, retrieve the coefficients for the quadratic boundary between the
            % first and second classes.
            K = cqs.Coeffs(1,2).Const;
            L = cqs.Coeffs(1,2).Linear;
            Q = cqs.Coeffs(1,2).Quadratic;

            % Plot the curve K + [x1,x2]*L + [x1,x2]*Q*[x1,x2]'=0:
            f = @(x1,x2) K + L(1)*x1 + L(2)*x2 + Q(1,1)*x1.^2 + ...
                (Q(1,2)+Q(2,1))*x1.*x2 + Q(2,2)*x2.^2;
            h6 = ezplot(f,plotWindowSize); % Plot the relevant portion of the curve.

            set(h6,'Color','k','LineWidth',2)
            %axis([-250 250 -250 250])
            xlabel('Endo')
            ylabel('Epi')
            title('{\bf Quadratic Classification with Fisher Training Data}')
            hold off
        end

    end

    %confusion matrices
    X2 = [pLength,pEpi,pEndo];

    if(bCase1vs3vs4) %default coordsP
        if(bCase1vs3)
            fprintf('Case1vs3');
            caseIDsInLine = caseIDs1and3;
            %cp1and3 = cvpartition(caseIDs1and3,'k',10); % Stratified cross-validation
            X2 = [pLength1vs3, pEpi1vs3, pEndo1vs3];
        elseif(bCase3vs4)
            fprintf('Case3vs4');
            caseIDsInLine = caseIDs3and4;
            %cp3and4 = cvpartition(caseIDs3and4,'k',10); % Stratified cross-validation
            X2 = [pLength3vs4, pEpi3vs4, pEndo3vs4];
        elseif(bCase1vs4)
            fprintf('Case1vs4');
            caseIDsInLine = caseIDs1and4;
            %cp1and4 = cvpartition(caseIDs1and4,'k',10); % Stratified cross-validation
            X2 = [pLength1vs4, pEpi1vs4, pEndo1vs4];
        end
    end

    if(b2DMeasurementsALL)
        fprintf('2D - All dimensions\n');
        if(b2DMeasurementsMMOnly == 1)
            fprintf('\n 2D - 9 dimensions \n');
        end
        X2 = [length2DTmp volume2DTmp mass2DTmp endo2DTmp epi2DTmp anterio2DTmp...
            anteroLat2DTmp inferoLat2DTmp inferior2DTmp inferoSep2DTmp anteroSep2DTmp average2DTmp];
        if(bCase1vs3vs4)
            if(bCase1vs3)
                caseIDsInLine = caseIDs1and3;
                X2 = [length2DTmp1vs3 volume2DTmp1vs3 mass2DTmp1vs3 endo2DTmp1vs3 epi2DTmp1vs3 anterio2DTmp1vs3...
                        anteroLat2DTmp1vs3 inferoLat2DTmp1vs3 inferior2DTmp1vs3 inferoSep2DTmp1vs3 anteroSep2DTmp1vs3 average2DTmp1vs3];
                    if (b2DMeasurementsMMOnly == 1)
                        X2 = [length2DTmp1vs3 endo2DTmp1vs3 epi2DTmp1vs3 anterio2DTmp1vs3...
                            anteroLat2DTmp1vs3 inferoLat2DTmp1vs3 inferior2DTmp1vs3 inferoSep2DTmp1vs3 anteroSep2DTmp1vs3];
                    end
            elseif(bCase3vs4)
                caseIDsInLine = caseIDs3and4;
                X2 = [length2DTmp3vs4 volume2DTmp3vs4 mass2DTmp3vs4 endo2DTmp3vs4 epi2DTmp3vs4 anterio2DTmp3vs4...
                        anteroLat2DTmp3vs4 inferoLat2DTmp3vs4 inferior2DTmp3vs4 inferoSep2DTmp3vs4 anteroSep2DTmp3vs4 average2DTmp3vs4];
                    if (b2DMeasurementsMMOnly == 1)
                        X2 = [length2DTmp3vs4 endo2DTmp3vs4 epi2DTmp3vs4 anterio2DTmp3vs4...
                            anteroLat2DTmp3vs4 inferoLat2DTmp3vs4 inferior2DTmp3vs4 inferoSep2DTmp3vs4 anteroSep2DTmp3vs4];
                    end
            elseif(bCase1vs4)
                caseIDsInLine = caseIDs1and4;
                X2 = [length2DTmp1vs4 volume2DTmp1vs4 mass2DTmp1vs4 endo2DTmp1vs4 epi2DTmp1vs4 anterio2DTmp1vs4...
                        anteroLat2DTmp1vs4 inferoLat2DTmp1vs4 inferior2DTmp1vs4 inferoSep2DTmp1vs4 anteroSep2DTmp1vs4 average2DTmp1vs4];
                    if (b2DMeasurementsMMOnly == 1)
                        X2 = [length2DTmp1vs4 endo2DTmp1vs4 epi2DTmp1vs4 anterio2DTmp1vs4...
                            anteroLat2DTmp1vs4 inferoLat2DTmp1vs4 inferior2DTmp1vs4 inferoSep2DTmp1vs4 anteroSep2DTmp1vs4];
                    end
            end
        end
    elseif(b2DMeasurementsWallThickness)
        fprintf('2D - 6 "Wall" dimensions\n');
        X2 = [anterio2DTmp anteroLat2DTmp inferoLat2DTmp inferior2DTmp inferoSep2DTmp anteroSep2DTmp];
        if(bCase1vs3vs4)
            if(bCase1vs3)
                caseIDsInLine = caseIDs1and3;
                X2 = [anterio2DTmp1vs3 anteroLat2DTmp1vs3 inferoLat2DTmp1vs3 inferior2DTmp1vs3 inferoSep2DTmp1vs3 anteroSep2DTmp1vs3];
            elseif(bCase3vs4)
                caseIDsInLine = caseIDs3and4;
                X2 = [anterio2DTmp3vs4 anteroLat2DTmp3vs4 inferoLat2DTmp3vs4 inferior2DTmp3vs4 inferoSep2DTmp3vs4 anteroSep2DTmp3vs4];
            elseif(bCase1vs4)
                caseIDsInLine = caseIDs1and4;
                X2 = [anterio2DTmp1vs4 anteroLat2DTmp1vs4 inferoLat2DTmp1vs4 inferior2DTmp1vs4 inferoSep2DTmp1vs4 anteroSep2DTmp1vs4];
            end
        end
    elseif(b2DMeasurements11)
        fprintf('2D - 11 dimensions\n');
        X2 = [length2DTmp volume2DTmp mass2DTmp endo2DTmp epi2DTmp anterio2DTmp...
            anteroLat2DTmp inferoLat2DTmp inferior2DTmp inferoSep2DTmp anteroSep2DTmp];
        if(bCase1vs3vs4)
            if(bCase1vs3)
                caseIDsInLine = caseIDs1and3;
                X2 = [length2DTmp1vs3 volume2DTmp1vs3 mass2DTmp1vs3 endo2DTmp1vs3 epi2DTmp1vs3 anterio2DTmp1vs3...
                        anteroLat2DTmp1vs3 inferoLat2DTmp1vs3 inferior2DTmp1vs3 inferoSep2DTmp1vs3 anteroSep2DTmp1vs3];
            elseif(bCase3vs4)
                caseIDsInLine = caseIDs3and4;
                X2 = [length2DTmp3vs4 volume2DTmp3vs4 mass2DTmp3vs4 endo2DTmp3vs4 epi2DTmp3vs4 anterio2DTmp3vs4...
                        anteroLat2DTmp3vs4 inferoLat2DTmp3vs4 inferior2DTmp3vs4 inferoSep2DTmp3vs4 anteroSep2DTmp3vs4];
            elseif(bCase1vs4)
                caseIDsInLine = caseIDs1and4;
                X2 = [length2DTmp1vs4 volume2DTmp1vs4 mass2DTmp1vs4 endo2DTmp1vs4 epi2DTmp1vs4 anterio2DTmp1vs4...
                        anteroLat2DTmp1vs4 inferoLat2DTmp1vs4 inferior2DTmp1vs4 inferoSep2DTmp1vs4 anteroSep2DTmp1vs4];
            end
        end
    elseif(b2DMeasurementsOnly5)
        fprintf('2D - 5 dimensions only\n');
        X2 = [length2DTmp volume2DTmp mass2DTmp endo2DTmp epi2DTmp];
        if(bCase1vs3vs4)
            if(bCase1vs3)
                caseIDsInLine = caseIDs1and3;
                X2 = [length2DTmp1vs3 volume2DTmp1vs3 mass2DTmp1vs3 endo2DTmp1vs3 epi2DTmp1vs3];
            elseif(bCase3vs4)
                caseIDsInLine = caseIDs3and4;   
                X2 = [length2DTmp3vs4 volume2DTmp3vs4 mass2DTmp3vs4 endo2DTmp3vs4 epi2DTmp3vs4];
            elseif(bCase1vs4)
                caseIDsInLine = caseIDs1and4;
                X2 = [length2DTmp1vs4 volume2DTmp1vs4 mass2DTmp1vs4 endo2DTmp1vs4 epi2DTmp1vs4];
            end
        end
    elseif(b2DMeasurementsOnly6)
        fprintf('2D - 6 dimensions only (5+avg)\n');
        X2 = [length2DTmp volume2DTmp mass2DTmp endo2DTmp epi2DTmp average2DTmp];
        if(bCase1vs3vs4)
            if(bCase1vs3)
                caseIDsInLine = caseIDs1and3;
                X2 = [length2DTmp1vs3 volume2DTmp1vs3 mass2DTmp1vs3 endo2DTmp1vs3 epi2DTmp1vs3 average2DTmp1vs3];
            elseif(bCase3vs4)   
                caseIDsInLine = caseIDs3and4; 
                X2 = [length2DTmp3vs4 volume2DTmp3vs4 mass2DTmp3vs4 endo2DTmp3vs4 epi2DTmp3vs4 average2DTmp3vs4];
            elseif(bCase1vs4)   
                caseIDsInLine = caseIDs1and4;
                X2 = [length2DTmp1vs4 volume2DTmp1vs4 mass2DTmp1vs4 endo2DTmp1vs4 epi2DTmp1vs4 average2DTmp1vs4];
            end  
        end
    end
    if(bUse11coordsP)
        fprintf('11 (a_priori+rest) PCs \n');
        X2 = coordsP11eigvecs(:, 2:end);
        if(bCase1vs3vs4)
            if(bCase1vs3)
                caseIDsInLine = caseIDs1and3;            
                X2 = coordsP11eigvecs1vs3;
            elseif(bCase3vs4)
                caseIDsInLine = caseIDs3and4;            
                X2 = coordsP11eigvecs3vs4;
            elseif(bCase1vs4)
                caseIDsInLine = caseIDs1and4;            
                X2 = coordsP11eigvecs1vs4;
            end
        end
    end

    if(bOriginalALLPCs)
        fprintf('%i Original PCs\n', numOriginalCoordsP);
        X2 = originalPCsN;
        if(bCase1vs3vs4)
            if(bCase1vs3)
                caseIDsInLine = caseIDs1and3; 
                X2 = originalPCsNeigvecs1vs3;
            elseif(bCase3vs4)
                caseIDsInLine = caseIDs3and4;  
                X2 = originalPCsNeigvecs3vs4;
            elseif(bCase1vs4)
                caseIDsInLine = caseIDs1and4;  
                X2 = originalPCsNeigvecs1vs4;
            end
        end
    end
    if(bQuadratic)
        cls2 = ClassificationDiscriminant.fit(X2,caseIDsInLine,'DiscrimType','quadratic');
    else
        cls2 = ClassificationDiscriminant.fit(X2,caseIDsInLine);    
    end
    %N.B. ClassificationDiscriminant.fit is not being used any further in this 
    %script, it has been superseded by classify and confusion matrix


    typeOfClassification = 'linear';
    % if(bQuadratic)
    %     typeOfClassification = 'quadratic';
    % end

    typeOfClassification %display which type

    %Compute the confusion matrix using stratified 10-fold cross validation:
    order = unique(caseIDsInLine); % Order of the group labels
    cp = cvpartition(caseIDsInLine,'k',10); % Stratified cross-validation
    if(bCase1vs3)
        cp = cp1and3;        
    elseif(bCase3vs4)
        cp = cp3and4; 
    elseif(bCase1vs4)
        cp = cp1and4;
    end
    f = @(xtr,ytr,xte,yte)confusionmat(yte,...
        classify(xte,xtr,ytr,typeOfClassification),'order',order);
    cfMat = crossval(f,X2,caseIDsInLine,'partition',cp);

    %Specificity/Sensitivity (with cross validation data subsets)
    clapLinear = classperf(caseIDsInLine);
    for i = 1:cp.NumTestSets
            trIdx = cp.training(i);
            teIdx = cp.test(i);
            ytest = classify(X2(teIdx,:),X2(trIdx,:),caseIDsInLine(trIdx,:),typeOfClassification);
    %            err(i) = sum(~strcmp(ytest,species(teIdx)));
            classperf(clapLinear, ytest, teIdx);
    end

    sens = clapLinear.Sensitivity
    spec = clapLinear.Specificity
    clapLinear.DiagnosticTable'

    if(bCase3and4together)
        numElem = 2;
    else
        numElem = 3;
    end

    if(bCase1vs3vs4)
        numElem = 2;
    end

    % fprintf('confusion matrix (cross-validation) ');
    % cfMat = reshape(sum(cfMat),numElem,numElem)

    if(bQuadratic) %Repeat for QDA classification
        typeOfClassification = 'quadratic';
        typeOfClassification %display which type
        clapQuad = classperf(caseIDsInLine);
        for i = 1:cp.NumTestSets
                trIdx = cp.training(i);
                teIdx = cp.test(i);
                ytest = classify(X2(teIdx,:),X2(trIdx,:),caseIDsInLine(trIdx,:),typeOfClassification);
        %            err(i) = sum(~strcmp(ytest,species(teIdx)));
                classperf(clapQuad, ytest, teIdx);
        end

        sensQuad = clapQuad.Sensitivity
        specQuad = clapQuad.Specificity
        clapQuad.DiagnosticTable'
    end
    % fprintf('standard confusion matrix (no cross-validation) ');
    % %standard confusion matrix (no cross-validation)
    % R2 = confusionmat(cls2.Y,resubPredict(cls2))
    % % cls2.ClassNames


    % subset = X2(216:end,:); % take four rows (from Case4) as an example of misclassification
    % [label] = predict(cls2,subset)

    %%%Support Vector Machine

    fprintf('SVM \n');

    if(bCase3and4together == 0)
        fprintf('Case1 vs Case3 vs Case4\n');
        %Cases 1 vs 3
        if(bCase1vs3vs4 && bCase1vs3)
            caseIDs1and3 = [caseIDs1 caseIDs3];
            caseIDs1and3 = caseIDs1and3';

            [m,~] = size(caseIDs1and3);
            pLength = coordsP(1:m,2); 
            pEndo = coordsP(1:m,3);
            pEpi = coordsP(1:m,4); 

            if(b2DMeasurements)
                fprintf('2D - 3 dimensions\n');
                pLength = values2D(1:m,2); 
                pEndo = values2D(1:m,3);
                pEpi = values2D(1:m,4); 
            end
            if(bOriginal3PCs)
                fprintf('3 Original PCs\n');
                pLength = originalPCs(1:m,2); 
                pEndo = originalPCs(1:m,3);
                pEpi = originalPCs(1:m,4); 
            end
            if(b2DMeasurementsALL)
                fprintf('2D - All dimensions\n');
                all2Ds = values2DALL(1:m, 2:13);
                if (b2DMeasurementsMMOnly == 1)
                    fprintf(' 2D - 9 dimensions (mm-based only)\n');
                    all2Ds = values2DALL(1:m, arr2DMeasurementsMMOnly);
                end                
            end
            if(b2DMeasurementsWallThickness)      
                fprintf('2D - 6 "Wall" dimensions\n');
                wallTickness2Ds = values2DALL(1:m,7:12);
            end
            if(b2DMeasurements11)
                fprintf('2D - 11 dimensions\n');
                elevenDims2Ds = values2DALL(1:m, 2:12);        
            end
            if(b2DMeasurementsOnly5)
                fprintf('2D - 5 dimensions only\n');
                fiveDims2Ds = values2DALL(1:m, 2:6); 
            end
            if(b2DMeasurementsOnly6)
                fprintf('2D - 6 dimensions only (5+avg)\n');
                sixDims2Ds = values2DALL(1:m, arr22DMeasurementsOnly6);
            end
            if(bUse11coordsP)
                fprintf('11 (a_priori+rest) PCs \n');
                p11PCs = coordsP11eigvecs(1:m, 2:end);
            end
            if(bOriginalALLPCs)
                fprintf('%i Original PCs\n', numOriginalCoordsP);
                pNOrigPCs = originalPCsN(1:m,:);
            end

        %     X = [pLength,pEpi];
        %     Y = [pEndo,pEpi];
        % 
        %     success = false;
        % 
        %     %no cross-validation 
        %     if(bQuadratic) %actually RBF
        %         figure, svmStructX = svmtrain(X, caseIDs1and3, 'kernel_function','rbf','showplot', true); %length/epi
        %         hold on
        %         xlabel('Length')
        %         ylabel('Epi')
        %         title('{\bf SVM Classes 1 vs 3}')
        %         hold off
        % 
        %         figure, svmStructY = svmtrain(Y, caseIDs1and3, 'kernel_function','rbf','showplot', true); %endo/epi
        %         hold on
        %         xlabel('Endo')
        %         ylabel('Epi')
        %         title('{\bf SVM Classes 1 vs 3}')
        %         hold off
        % 
        %         success = true;
        %     else
        %         figure, svmStructX = svmtrain(X, caseIDs1and3, 'showplot', true);
        %         hold on
        %         xlabel('Length')
        %         ylabel('Epi')
        %         title('{\bf SVM Classes 1 vs 3}')
        %         hold off
        % 
        %         figure, svmStructY = svmtrain(Y, caseIDs1and3, 'showplot', true);
        %         hold on
        %         xlabel('Endo')
        %         ylabel('Epi')
        %         title('{\bf SVM Classes 1 vs 3}')
        %         hold off
        % 
        %         success = true;
        %     end
        % 
        %     %SVM confusion matrices
        %     if(success)
        %         %no cross-validation 
        %         vX = svmclassify(svmStructX,X);
        %         fprintf('SVM Length-Epi Classes 1 vs 3 (no-cross)\n');
        %         confMatrixSVM1vs3X = confusionmat(caseIDs1and3, vX)
        % 
        %         vY = svmclassify(svmStructY,Y);
        %         fprintf('SVM Endo-Epi Classes 1 vs 3 (no-cross)\n');
        %         confMatrixSVM1vs3Y = confusionmat(caseIDs1and3, vY)      
        %     end

        %     %new classifier (cross-validation) %RBF
        %     [k,~] = size(X);
        %     c = cvpartition(k,'kfold',10);    
        %     order = unique(caseIDs1and3); % Order of the group labels
        %     cp = cvpartition(caseIDs1and3,'k',10); % Stratified cross-validation
        % 
        %     minfnX = @(z)crossval('mcr', X, caseIDs1and3, 'Predfun', ...
        %         @(xtrain,ytrain,xtest)crossfun(xtrain,ytrain,...
        %         xtest,exp(z(1)),exp(z(2))),'partition',cp);
        %     opts = optimset('TolX',5e-4,'TolFun',5e-4);
        %     [searchmin fval] = fminsearch(minfnX, rand(2,1),opts);
        %     z = exp(searchmin);
        %     figure, svmStruct2X = svmtrain(X, caseIDs1and3, 'kernel_function','rbf',...
        %         'rbf_sigma',z(1),'boxconstraint',z(2),'showplot',true);
        %     hold on
        %     xlabel('Length')
        %     ylabel('Epi')
        %     title('{\bf SVM Classes 1 vs 3}')
        %     hold off   
        %     vX = svmclassify(svmStruct2X,X);
        %     fprintf('SVM Length-Epi Classes 1 vs 3 (crossval)\n');
        %     confMatrixSVM1vs3X_CrossVal = confusionmat(caseIDs1and3, vX)
        % 
        %     minfnY = @(z)crossval('mcr', Y, caseIDs1and3, 'Predfun', ...
        %         @(xtrain,ytrain,xtest)crossfun(xtrain,ytrain,...
        %         xtest,exp(z(1)),exp(z(2))),'partition',cp);
        %     opts = optimset('TolX',5e-4,'TolFun',5e-4);
        %     [searchmin fval] = fminsearch(minfnY, rand(2,1),opts);
        %     z = exp(searchmin);
        %     figure, svmStruct2Y = svmtrain(Y, caseIDs1and3, 'kernel_function','rbf',...
        %         'rbf_sigma',z(1),'boxconstraint',z(2),'showplot',true);
        %     hold on
        %     xlabel('Endo')
        %     ylabel('Epi')
        %     title('{\bf SVM Classes 1 vs 3}')
        %     hold off
        %     vY = svmclassify(svmStruct2Y,Y);
        %     fprintf('SVM Endo-Epi Classes 1 vs 3 (crossval)\n');
        %     confMatrixSVM1vs3Y_CrossVal = confusionmat(caseIDs1and3, vY)

            X2 = [pLength,pEpi,pEndo]; 

            if(b2DMeasurementsALL)
                X2 = all2Ds;
            elseif(b2DMeasurementsWallThickness)        
                X2 = wallTickness2Ds;
            elseif(b2DMeasurements11)        
                X2 = elevenDims2Ds;     
            elseif(b2DMeasurementsOnly5)
                X2 = fiveDims2Ds;   
            elseif(b2DMeasurementsOnly6)
                X2 = sixDims2Ds; 
            end
            if(bUse11coordsP)
                X2 = p11PCs;
            end
            if(bOriginalALLPCs)            
                X2 = pNOrigPCs;
            end

            order = unique(caseIDs1and3); % Order of the group labels
            cp = cvpartition(caseIDs1and3,'k',10); % Stratified cross-validation
            if(bCase1vs3vs4 && bCase1vs3)
                   cp = cp1and3;        
            end
            minfnX = @(z)crossval('mcr', X2, caseIDs1and3, 'Predfun', ...
                @(xtrain,ytrain,xtest)crossfun(xtrain,ytrain,...
                xtest,exp(z(1)),exp(z(2))),'partition',cp);
            opts = optimset('TolX',5e-4,'TolFun',5e-4);
            [searchmin fval] = fminsearch(minfnX, rand(2,1),opts);
            z = exp(searchmin);

            %Specificity/Sensitivity (with cross validation data subsets)
            clap1vs3 = classperf(caseIDs1and3);
            for i = 1:cp.NumTestSets
                trIdx = cp.training(i);
                teIdx = cp.test(i);   
                svmStruct2X = svmtrain(X2(trIdx,:), caseIDs1and3(trIdx,:), 'kernel_function','rbf',...
                    'rbf_sigma',z(1),'boxconstraint',z(2),'showplot',false);
                ytest = svmclassify(svmStruct2X,X2(teIdx,:));
                classperf(clap1vs3, ytest, teIdx);
            end
            fprintf('caseIDs1and3\n');
            sens = clap1vs3.Sensitivity
            spec = clap1vs3.Specificity
            clap1vs3.DiagnosticTable'
        end
        %Cases 3 vs 4
        if(bCase1vs3vs4 && bCase3vs4)
            caseIDsInLine = [caseIDs1 caseIDs3 caseIDs4]';
            caseIDs3and4 = [caseIDs3 caseIDs4];
            caseIDs3and4 = caseIDs3and4';
            [k,~] = size(caseIDsInLine);
            [l,~] = size(caseIDs3and4);
            n = (k-l)+1;
            pLength = coordsP(n:end,2); 
            pEndo = coordsP(n:end,3);
            pEpi = coordsP(n:end,4); 

            if(b2DMeasurements)
                pLength = values2D(n:end,2); 
                pEndo = values2D(n:end,3);
                pEpi = values2D(n:end,4); 
            end
            if(bOriginal3PCs)
                pLength = originalPCs(n:end,2); 
                pEndo = originalPCs(n:end,3);
                pEpi = originalPCs(n:end,4);
            end

            X2 = [pLength,pEpi,pEndo];

            if(b2DMeasurementsALL)
                all2Ds = values2DALL(n:end, 2:13);  
                if (b2DMeasurementsMMOnly == 1)
                    all2Ds = values2DALL(n:end, arr2DMeasurementsMMOnly);  
                end
                X2 = all2Ds;
            end
            if(b2DMeasurementsWallThickness)        
                wallTickness2Ds = values2DALL(n:end,7:12);
                X2 = wallTickness2Ds;
            end
            if(b2DMeasurements11)        
                elevenDims2Ds = values2DALL(n:end, 2:12); 
                X2 = elevenDims2Ds;
            end
            if(b2DMeasurementsOnly5)
                fprintf('2D - 5 dimensions only\n');
                fiveDims2Ds = values2DALL(n:end, 2:6);
                X2 = fiveDims2Ds;
            end
            if(b2DMeasurementsOnly6)
                fprintf('2D - 6 dimensions only (5+avg)\n');
                sixDims2Ds = values2DALL(n:end, arr22DMeasurementsOnly6);
                X2 = sixDims2Ds;
            end
            if(bUse11coordsP)
                p11PCs = coordsP11eigvecs(n:end, 2:end); 
            end
            if(bOriginalALLPCs)
                fprintf('%i Original PCs\n', numOriginalCoordsP);
                pNOrigPCs = originalPCsN(n:end,:);
            end

            order = unique(caseIDs3and4); % Order of the group labels
            cp = cvpartition(caseIDs3and4,'k',10); % Stratified cross-validation
            if(bCase1vs3vs4 && bCase3vs4)
                   cp = cp3and4;        
            end
            minfnX = @(z)crossval('mcr', X2, caseIDs3and4, 'Predfun', ...
                @(xtrain,ytrain,xtest)crossfun(xtrain,ytrain,...
                xtest,exp(z(1)),exp(z(2))),'partition',cp);
            opts = optimset('TolX',5e-4,'TolFun',5e-4);
            [searchmin fval] = fminsearch(minfnX, rand(2,1),opts);
            z = exp(searchmin);

            %Specificity/Sensitivity (with cross validation data subsets)
            clap3vs4 = classperf(caseIDs3and4);
            for i = 1:cp.NumTestSets
                trIdx = cp.training(i);
                teIdx = cp.test(i);   
                svmStruct2X = svmtrain(X2(trIdx,:), caseIDs3and4(trIdx,:), 'kernel_function','rbf',...
                    'rbf_sigma',z(1),'boxconstraint',z(2),'showplot',false);
                ytest = svmclassify(svmStruct2X,X2(teIdx,:));
                classperf(clap3vs4, ytest, teIdx);
            end

            fprintf('caseIDs3and4\n');

            sens = clap3vs4.Sensitivity
            spec = clap3vs4.Specificity
            clap3vs4.DiagnosticTable'


        %     success = false;

        %     %%%Separate pLength, pEpi and pEndo
        %     X = [pLength,pEpi];
        %     Y = [pEndo,pEpi];

            %no cross-validation 
        %     if(bQuadratic) %actually RBF
        %         figure, svmStructX = svmtrain(X, caseIDs3and4, 'kernel_function','rbf', 'showplot', true); %length/epi
        %         hold on
        %         xlabel('Length')
        %         ylabel('Epi')
        %         title('{\bf SVM Classes 3 vs 4}')
        %         hold off
        % 
        %         figure, svmStructY = svmtrain(Y, caseIDs3and4, 'kernel_function','rbf', 'showplot', true); %endo/epi
        %         hold on
        %         xlabel('Endo')
        %         ylabel('Epi')
        %         title('{\bf SVM Classes 3 vs 4}')
        %         hold off
        % 
        %         success = true;
        %     else
        %         figure, svmStructX = svmtrain(X, caseIDs3and4, 'showplot', true);
        %         hold on
        %         xlabel('Length')
        %         ylabel('Epi')
        %         title('{\bf SVM Classes 3 vs 4}')
        %         hold off
        % 
        %         figure, svmStructY = svmtrain(Y, caseIDs3and4, 'showplot', true);
        %         hold on
        %         xlabel('Endo')
        %         ylabel('Epi')
        %         title('{\bf SVM Classes 3 vs 4}')
        %         hold off
        % 
        %         success = true;
        %     end

        %     %SVM confusion matrices
        %     if(success)
        %         %no cross-validation 
        %         vX = svmclassify(svmStructX,X);
        %         fprintf('SVM Length-Epi Classes 3 vs 4 (no-cross)\n');
        %         confMatrixSVM3vs4X = confusionmat(caseIDs3and4, vX)    
        % 
        %         vY = svmclassify(svmStructY,Y);
        %         fprintf('SVM Endo-Epi Classes 3 vs 4 (no-cross)\n');
        %         confMatrixSVM3vs4Y = confusionmat(caseIDs3and4, vY)   
        %     end   

        %     %new classifier (cross-validation)
        %     [k,~] = size(X);
        %     c = cvpartition(k,'kfold',10);    
        %     order = unique(caseIDs3and4); % Order of the group labels
        %     cp = cvpartition(caseIDs3and4,'k',10); % Stratified cross-validation
        % 
        %     minfnX = @(z)crossval('mcr', X, caseIDs3and4, 'Predfun', ...
        %         @(xtrain,ytrain,xtest)crossfun(xtrain,ytrain,...
        %         xtest,exp(z(1)),exp(z(2))),'partition',cp);
        %     opts = optimset('TolX',5e-4,'TolFun',5e-4);
        %     [searchmin fval] = fminsearch(minfnX, rand(2,1),opts);
        %     z = exp(searchmin);
        %     figure, svmStruct2X = svmtrain(X, caseIDs3and4, 'kernel_function','rbf',...
        %         'rbf_sigma',z(1),'boxconstraint',z(2),'showplot',true);
        %     hold on
        %     xlabel('Length')
        %     ylabel('Epi')
        %     title('{\bf SVM Classes 3 vs 4}')
        %     hold off   
        %     vX = svmclassify(svmStruct2X,X);
        %     fprintf('SVM Length-Epi Classes 3 vs 4 (crossval)\n');
        %     confMatrixSVM1vs3X_CrossVal = confusionmat(caseIDs3and4, vX)
        % 
        %     minfnY = @(z)crossval('mcr', Y, caseIDs3and4, 'Predfun', ...
        %         @(xtrain,ytrain,xtest)crossfun(xtrain,ytrain,...
        %         xtest,exp(z(1)),exp(z(2))),'partition',cp);
        %     opts = optimset('TolX',5e-4,'TolFun',5e-4);
        %     [searchmin fval] = fminsearch(minfnY, rand(2,1),opts);
        %     z = exp(searchmin);
        %     figure, svmStruct2Y = svmtrain(Y, caseIDs3and4, 'kernel_function','rbf',...
        %         'rbf_sigma',z(1),'boxconstraint',z(2),'showplot',true);
        %     hold on
        %     xlabel('Endo')
        %     ylabel('Epi')
        %     title('{\bf SVM Classes 3 vs 4}')
        %     hold off
        %     vY = svmclassify(svmStruct2Y,Y);
        %     fprintf('SVM Endo-Epi Classes 3 vs 4 (crossval)\n');
        %     confMatrixSVM1vs3Y_CrossVal = confusionmat(caseIDs3and4, vY)
        end
        %Cases 1 vs 4
        if(bCase1vs3vs4 && bCase1vs4)
            caseIDs1and4 = [caseIDs1 caseIDs4];
            caseIDs1and4 = caseIDs1and4';

            %[m,~] = size(caseIDs1and4);
            [~,m] = size(caseIDs1);
            [~,n] = size(caseIDs4);

            pLength1 = coordsP(1:m,2)'; 
            pLength4 = coordsP((end-n)+1:end,2)';   
            pLength = [pLength1 pLength4]';
            pEndo1 = coordsP(1:m,3)';
            pEndo4 = coordsP((end-n)+1:end,3)';    
            pEndo = [pEndo1 pEndo4]';
            pEpi1 = coordsP(1:m,4)'; 
            pEpi4 = coordsP((end-n)+1:end,4)'; 
            pEpi = [pEpi1 pEpi4]';

            if(b2DMeasurements)
                pLength1 = values2D(1:m,2)'; 
                pLength4 = values2D((end-n)+1:end,2)';   
                pLength = [pLength1 pLength4]';
                pEndo1 = values2D(1:m,3)';
                pEndo4 = values2D((end-n)+1:end,3)';    
                pEndo = [pEndo1 pEndo4]';
                pEpi1 = values2D(1:m,4)'; 
                pEpi4 = values2D((end-n)+1:end,4)'; 
                pEpi = [pEpi1 pEpi4]';
            end
            if(bOriginal3PCs)
                pLength1 = originalPCs(1:m,2)'; 
                pLength4 = originalPCs((end-n)+1:end,2)';   
                pLength = [pLength1 pLength4]';
                pEndo1 = originalPCs(1:m,3)';
                pEndo4 = originalPCs((end-n)+1:end,3)';    
                pEndo = [pEndo1 pEndo4]';
                pEpi1 = originalPCs(1:m,4)'; 
                pEpi4 = originalPCs((end-n)+1:end,4)'; 
                pEpi = [pEpi1 pEpi4]';
            end

            X2 = [pLength,pEpi,pEndo];

            if(b2DMeasurementsALL)
                all2D_a = values2DALL(1:m, 2:13)';   
                all2D_b = values2DALL((end-n)+1:end, 2:13)';   
                if (b2DMeasurementsMMOnly == 1)
                    all2D_a = values2DALL(1:m, arr2DMeasurementsMMOnly)';   
                    all2D_b = values2DALL((end-n)+1:end, arr2DMeasurementsMMOnly)';   
                end

                X2 = [all2D_a all2D_b]';
            end
            if(b2DMeasurementsWallThickness)      
                wallTickness2D_a = values2DALL(1:m, 7:12)';
                wallTickness2D_b = values2DALL((end-n)+1:end, 7:12)';   
                X2 = [wallTickness2D_a wallTickness2D_b]';
            end
            if(b2DMeasurements11)        
                elevenDims2Ds_a = values2DALL(1:m, 2:12)'; 
                elevenDims2Ds_b = values2DALL((end-n)+1:end, 2:12)'; 
                X2 = [elevenDims2Ds_a elevenDims2Ds_b]';
            end
            if(b2DMeasurementsOnly5)
                fprintf('2D - 5 dimensions only\n');            
                fiveDims2Ds_a = values2DALL(1:m, 2:6)';
                fiveDims2Ds_b = values2DALL((end-n)+1:end, 2:6)';
                X2 = [fiveDims2Ds_a fiveDims2Ds_b]';
            end
            if(b2DMeasurementsOnly6)
                fprintf('2D - 6 dimensions only (5+avg)\n');
                sixDims2Ds_a = values2DALL(1:m, arr22DMeasurementsOnly6)';
                sixDims2Ds_b = values2DALL((end-n)+1:end, arr22DMeasurementsOnly6)';
                X2 = [sixDims2Ds_a sixDims2Ds_b]';
            end
            if(bUse11coordsP)
                p11PCs_a = coordsP11eigvecs(1:m, 2:end)';
                p11PCs_b = coordsP11eigvecs((end-n)+1:end, 2:end)';
                X2 = [p11PCs_a p11PCs_b]';
            end
            if(bOriginalALLPCs)
                pNOrigPCs_a = originalPCsN(1:m,:)';
                pNOrigPCs_b = originalPCsN((end-n)+1:end,:)';
                X2 = [pNOrigPCs_a pNOrigPCs_b]';            
            end

            order = unique(caseIDs1and4); % Order of the group labels
            cp = cvpartition(caseIDs1and4,'k',10); % Stratified cross-validation
            if(bCase1vs3vs4 && bCase1vs4)
                   cp = cp1and4;        
            end
            minfnX = @(z)crossval('mcr', X2, caseIDs1and4, 'Predfun', ...
                @(xtrain,ytrain,xtest)crossfun(xtrain,ytrain,...
                xtest,exp(z(1)),exp(z(2))),'partition',cp);
            opts = optimset('TolX',5e-4,'TolFun',5e-4);
            [searchmin fval] = fminsearch(minfnX, rand(2,1),opts);
            z = exp(searchmin);

            %Specificity/Sensitivity (with cross validation data subsets)
            clap1vs4 = classperf(caseIDs1and4);
            for i = 1:cp.NumTestSets
                trIdx = cp.training(i);
                teIdx = cp.test(i);   
                svmStruct2X = svmtrain(X2(trIdx,:), caseIDs1and4(trIdx,:), 'kernel_function','rbf',...
                    'rbf_sigma',z(1),'boxconstraint',z(2),'showplot',false);
                ytest = svmclassify(svmStruct2X,X2(teIdx,:));
                classperf(clap1vs4, ytest, teIdx);
            end

            fprintf('caseIDs1and4\n');

            sens = clap1vs4.Sensitivity
            spec = clap1vs4.Specificity
            clap1vs4.DiagnosticTable'
        end
    else %bCase3and4together == 1
        fprintf('Case1 vs Case3and4\n');
    %     [k,~] = size(X);
    %     c = cvpartition(k,'kfold',10);        
        order = unique(caseIDsInLine); % Order of the group labels
        cp = cvpartition(caseIDsInLine,'k',10); % Stratified cross-validation

    %     %%%Separate pLength, pEpi and pEndo
    %     %%% Useful for plotting

    %     X = [pLength,pEpi];
    %     Y = [pEndo,pEpi];
    %     minfnX = @(z)crossval('mcr', X, caseIDsInLine, 'Predfun', ...
    %         @(xtrain,ytrain,xtest)crossfun(xtrain,ytrain,...
    %         xtest,exp(z(1)),exp(z(2))),'partition',cp);
    %     opts = optimset('TolX',5e-4,'TolFun',5e-4);
    %     [searchmin fval] = fminsearch(minfnX, rand(2,1),opts);
    %     z = exp(searchmin);
    %     figure, svmStruct2X = svmtrain(X, caseIDsInLine, 'kernel_function','rbf',...
    %         'rbf_sigma',z(1),'boxconstraint',z(2),'showplot',true);
    %     hold on
    %     xlabel('Length')
    %     ylabel('Epi')
    %     title('{\bf SVM Classes 1 vs 3and4}')
    %     hold off   
    %     vX = svmclassify(svmStruct2X,X);
    %     fprintf('SVM Length-Epi Classes 1 vs 3and4 (crossval)\n');
    %     confMatrixSVM1vs3X_CrossVal = confusionmat(caseIDsInLine, vX)
    %     
    %     minfnY = @(z)crossval('mcr', Y, caseIDsInLine, 'Predfun', ...
    %         @(xtrain,ytrain,xtest)crossfun(xtrain,ytrain,...
    %         xtest,exp(z(1)),exp(z(2))),'partition',cp);
    %     opts = optimset('TolX',5e-4,'TolFun',5e-4);
    %     [searchmin fval] = fminsearch(minfnY, rand(2,1),opts);
    %     z = exp(searchmin);
    %     figure, svmStruct2Y = svmtrain(Y, caseIDsInLine, 'kernel_function','rbf',...
    %         'rbf_sigma',z(1),'boxconstraint',z(2),'showplot',true);
    %     hold on
    %     xlabel('Endo')
    %     ylabel('Epi')
    %     title('{\bf SVM Classes 1 vs 3and4}')
    %     hold off
    %     vY = svmclassify(svmStruct2Y,Y);
    %     fprintf('SVM Endo-Epi Classes 1 vs 3and4 (crossval)\n');
    %     confMatrixSVM1vs3Y_CrossVal = confusionmat(caseIDsInLine, vY)    



        X2 = [pLength,pEpi,pEndo];

        if(b2DMeasurementsALL)
            fprintf('2D - All dimensions\n');
            X2 = [length2DTmp volume2DTmp mass2DTmp endo2DTmp epi2DTmp anterio2DTmp...
                anteroLat2DTmp inferoLat2DTmp inferior2DTmp inferoSep2DTmp anteroSep2DTmp average2DTmp];
                if (b2DMeasurementsMMOnly == 1)
                        X2 = [length2DTmp endo2DTmp epi2DTmp anterio2DTmp...
                            anteroLat2DTmp inferoLat2DTmp inferior2DTmp inferoSep2DTmp anteroSep2DTmp];
                    fprintf('2D - 9 dimensions\n');
                end

        elseif(b2DMeasurementsWallThickness)
            fprintf('2D - 6 "Wall" dimensions\n');
            X2 = [anterio2DTmp anteroLat2DTmp inferoLat2DTmp inferior2DTmp inferoSep2DTmp anteroSep2DTmp];
        elseif(b2DMeasurements11)       
            fprintf('2D - 11 dimensions\n');
            X2 = [length2DTmp volume2DTmp mass2DTmp endo2DTmp epi2DTmp anterio2DTmp...
                anteroLat2DTmp inferoLat2DTmp inferior2DTmp inferoSep2DTmp anteroSep2DTmp];
        elseif(b2DMeasurementsOnly5)       
            fprintf('2D - 5 dimensions only\n');
            X2 = [length2DTmp volume2DTmp mass2DTmp endo2DTmp epi2DTmp];
        elseif(b2DMeasurementsOnly6)
            fprintf('2D - 6 dimensions only (5+avg)\n');
            X2 = [length2DTmp volume2DTmp mass2DTmp endo2DTmp epi2DTmp average2DTmp];
        end
        if(bUse11coordsP)
            fprintf('11 (a_priori+rest) PCs \n');
            X2 = coordsP11eigvecs(:, 2:end);
        end
        if(bOriginalALLPCs)
            fprintf('%i Original PCs\n', numOriginalCoordsP);
            X2 = originalPCsN;
        end

        minfnX = @(z)crossval('mcr', X2, caseIDsInLine, 'Predfun', ...
            @(xtrain,ytrain,xtest)crossfun(xtrain,ytrain,...
            xtest,exp(z(1)),exp(z(2))),'partition',cp);
        opts = optimset('TolX',5e-4,'TolFun',5e-4);
        [searchmin fval] = fminsearch(minfnX, rand(2,1),opts);
        z = exp(searchmin);

        %Specificity/Sensitivity (with cross validation data subsets)
        clap = classperf(caseIDsInLine);
        for i = 1:cp.NumTestSets
            trIdx = cp.training(i);
            teIdx = cp.test(i);   
            svmStruct2X = svmtrain(X2(trIdx,:), caseIDsInLine(trIdx,:), 'kernel_function','rbf',...
                'rbf_sigma',z(1),'boxconstraint',z(2),'showplot',false);
            ytest = svmclassify(svmStruct2X,X2(teIdx,:));
            classperf(clap, ytest, teIdx);
        end
        fprintf('Case1vsCase3and4together\n');
        sens = clap.Sensitivity
        spec = clap.Specificity
        clap.DiagnosticTable'
    end

end
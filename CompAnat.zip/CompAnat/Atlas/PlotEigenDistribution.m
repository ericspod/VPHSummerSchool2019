function [H] = PlotEigenDistribution(directory,eigvectors,options)
% Version control:
% - 02/10/14: rename from GetEigenSpaceAxis to PlotEigenDistribution, where
% there are two main options: plot as simple axes, with a star comparing
% the centre of distributions, or plot as box plot.
% - 09/09/13: class definition is an option

PlotType = 'BoxPlot';
orientation = 'horizontal';
BoxOutliers = 1;
ClassDefinition = NaN;
LegendLocation = 'left';
colourscheme = 1;
AtlasFileName = 'Atlas.mat';
iCases2highlight = [];
NumberSTDS = 2;
bAxisOff =1;
bFlipAxis = 0;
axislength =1000;
bTextMode =1;
if nargin>= 3
    if isfield(options,'nStd'),             NumberSTDS = options.nStd; end
    if isfield(options,'bAxisOff'),         bAxisOff = options.bAxisOff; end
    if isfield(options,'orientation'),      orientation = options.orientation; end
    if isfield(options,'ClassDefinition'),  ClassDefinition = options.ClassDefinition; end
    if isfield(options,'coefs'),            coefs = options.coefs;     end
    if isfield(options,'ListCases'),        ListCases = options.ListCases;     end
    if isfield(options,'colourscheme'),     colourscheme = options.colourscheme; end  
    if isfield(options,'BoxOutliers'),      BoxOutliers = options.BoxOutliers; end  
    if isfield(options,'LegendLocation'),   LegendLocation = options.LegendLocation; end  
    if isfield(options,'AtlasFileName'),    AtlasFileName = options.AtlasFileName; end  
    if isfield(options,'OutputDirectory'),  OutputDirectory = options.OutputDirectory; end  
    if isfield(options,'iCases2highlight'), iCases2highlight = options.iCases2highlight; end  
    if isfield(options,'atlasfileWithPath'),      atlasfileWithPath = options.atlasfileWithPath; end  
    if isfield(options,'bFlipAxis'),        bFlipAxis = options.bFlipAxis; end    
    if isfield(options,'axislength'),       axislength = options.axislength; end    
    if isfield(options,'bTextMode'),        bTextMode = options.bTextMode; end            
end

switch PlotType
    case 'BoxPlot'
        MkSize = 10;
        LnWidth= 1.5;
    case 'Star'
        MkSize = 20;
        LnWidth= 3;
end
        
options.eigvectors2output = eigvectors;

bClasses = isstruct(ClassDefinition);
if(bClasses)
    nClasses = numel(ClassDefinition);
    options.ClassDefinition = ClassDefinition;
else
    nClasses = 1;
end



nDims = numel(eigvectors);

switch orientation
    case 'horizontal'
        figuresize = [200 200 axislength (100 + 100*nDims)];
    case 'vertical'
        figuresize = [200 200 (100 + 100*nDims) axislength];
end
H = figure('color',[1 1 1],'OuterPosition',figuresize);

if ~exist('OutputDirectory','var')
    OutputDirectory = fullfile(directory, 'AtlasOutput/');
end
ss = [];
if ~exist('atlasfileWithPath','var')
    atlasfileWithPath = fullfile(OutputDirectory, AtlasFileName);
end
load(atlasfileWithPath);
Scales = ss;

% Now with this call the variable ListCases gets updated in case there is a
% incomplete case:
if exist('ListCases','var') && exist('coefs','var')
    % The coefficients have been provied, for example in a LDA analysis
    % The standard deviation is estimated:
    stdcoefs = std(coefs);
    Scales = stdcoefs.^2;
else
    [coefs,cases,~,ListCases] = GetEigenCoefficients(directory,options);
end


bNewFigures = 0;

if BoxOutliers, 
    symb = '*';
else
    symb = 'r';
end


Fsize = 15;
for iE = 1:nDims
    % P.Lamata (05/08/14): individual axes were all wrong (when generating
    % the automated pdf with modes of variation)
    iEig = eigvectors(iE);
    if(bNewFigures)
        %Create a new figure for each of the variation modes
        H = figure('color',[1 1 1],'OuterPosition',[0 10 1000 200]);
        Hs(iE) = subplot(1,1,1,'FontSize',Fsize); hold on; 
    else
        switch orientation
            case 'horizontal'
                nRows = nDims;
                nCols = 1;
            case 'vertical'
                nRows = 1;
                nCols = nDims;                
        end
        Hs = subplot(nRows,nCols,iE,'FontSize',Fsize); hold on;  
    end
    
    % Plot the (-2std +2std) interval:
    S1 = NumberSTDS*sqrt(Scales(end-iEig+1));
    switch orientation
        case 'horizontal'
            plot([-S1,S1],[0 0],'LineWidth',LnWidth,'Color',[.2 .2 .2]);
            plot(0,0,'+','MarkerEdgeColor',GetAtlasColor(1,2),'MarkerSize',MkSize,'LineWidth',LnWidth);
            plot(S1,0,'+','MarkerEdgeColor',GetAtlasColor(2,2),'MarkerSize',MkSize,'LineWidth',LnWidth);
            plot(-S1,0,'+','MarkerEdgeColor',GetAtlasColor(3,2),'MarkerSize',MkSize,'LineWidth',LnWidth);            
        case 'vertical'
            plot([0 0],[-S1,S1],'LineWidth',LnWidth,'Color',[.2 .2 .2]);
            plot(0,0,'+','MarkerEdgeColor',GetAtlasColor(1,2),'MarkerSize',MkSize,'LineWidth',LnWidth);
            plot(0,S1,'+','MarkerEdgeColor',GetAtlasColor(2,2),'MarkerSize',MkSize,'LineWidth',LnWidth);
            plot(0,-S1,'+','MarkerEdgeColor',GetAtlasColor(3,2),'MarkerSize',MkSize,'LineWidth',LnWidth);            
    end
    for iC=1:nClasses
        % Working with the relative index, defined within a list of valid
        % cases:
        if nClasses > 1
            I1 = GetIndexesPerClass(ClassDefinition,iC,ListCases);
        else
            % Take all cases:
            I1 = 1:size(coefs,2);
        end
        % Some cases could be indexed, but not having valid coefficients:
        I2 = find(~isnan(coefs(1,:)));
        Ic = intersect(I1,I2);
        Offset = 0.2*iC;
        x = coefs(iE,Ic);        
        if(bFlipAxis), x = -x; end
        switch PlotType            
            case 'BoxPlot'                
                boxplot(x,'colors',GetAtlasColor(iC,colourscheme),...
                    'orientation',orientation,'positions',Offset,...
                     'boxstyle','filled','symbol',symb,'medianstyle','target',...
                     'labels',' ');
%
            case 'Star'
                MeanCoor = mean(x);
                plot(MeanCoor,0,'*','MarkerEdgeColor',GetAtlasColor(iC,colourscheme),'MarkerSize',20,'LineWidth',3);
        end
        fprintf('Distribution of eigenvalue %i had %i valid samples: (%1.3f +/- %1.3f) - Variance = %1.3f\n',iEig,numel(Ic),mean(x),std(x),S1/NumberSTDS)
    end
    if BoxOutliers && strcmp(PlotType,'BoxPlot')
        Limit = max ( max(abs(coefs(iE,:)))  ,  1.1*S1);
    else
        Limit = 1.1 * S1;
    end
    switch orientation
        case 'horizontal'
            axis([-Limit Limit -.5 .5 + Offset]); 
        case 'vertical'
            axis([-.5, .5 + Offset, -Limit, Limit ]); 
    end
    %box 'off'
    if (bAxisOff)
        axis 'off';
    end
    
    if(bNewFigures)
        %Create a new figure for each of the variation modes
        set(Hs(iE),'YTickLabel','')
        set(Hs(iE),'YColor',get(gca,'Color'))    
    else
        %Plot all variation modes into a single figure
        if(bTextMode)
            textmode = sprintf('Mode %i (+/- %istd)',iEig,NumberSTDS);
            switch LegendLocation
                case 'title'
                    title(textmode);
                case 'left'
                    Xt = 1.2*(-Limit);
                    Yt = 0;
                    textmode = sprintf('Mode %i',iEig);
                    text(Xt,Yt,textmode);
                otherwise
                    fprintf('ERROR! option for the orientation of the text in the Eigen Distribution not recognised: %s\n',LegendLocation);
            end
        end
        %set(Hs,'XTickLabel','')
        %set(gca,'YTick',0)
        %set(gca,'YTickLabel',{sprintf('Mode %i',iEig)})
        %set(Hs,'XColor',get(gca,'Color'))
        %set(gca,'YColor',get(gca,'Color'))
    end
    if(numel(iCases2highlight)>0)
        % add stars in specific cases, and print number:
        Yt = Offset + 0.2;
        for i=1:numel(iCases2highlight)
            ID = iCases2highlight(i);
            I1 = find(ListCases == ID);
            x = coefs(iE,I1);
            plot(x,Yt,'*b');
            textID = sprintf('%i',ID);
            text(x,Yt+0.1,textID);
        end
    end
end
function [] = WriteCaseMetadata(MetadataFile,CasesForMetadata)
% Function to write the metadata of the meshes, for integration into
% VPH-Share.
%
% List of fields:
% 1. Title/FileName {dc:title}
% 2. Description {dc:description}
% 3. Author {dc:creator}
% 4. Publisher/Maintainer {dc:publisher} - Person responsible for day to day activities (could be same as author)
% 5. Resource Type {dc:type} (URL Link in your case)
% 6. Tags {dc:subject} - Keywords that represent the data file (e.g. Heart, LeftVentricle, MeshReconstruction, MRI etc.)
% 7. License {dc:rights} - Think carefully of the Data License agreement here. Commercialisation, Attribution, etc. 
% 8. Version {dc:version} - Manually assigned version, we can track updates to the data file
% 9. Language {dc:language} - (en_GB in your case)
% 10. Related Publications {dc:relation} - (http://www.ncbi.nlm.nih.gov/pubmed/23224059 , http://www.ncbi.nlm.nih.gov/pubmed/21788150 in your example case) 
% 11. Status [private, public] - Self Descriptive
% 12. Usage Conditions - Any particular conditions, e.g. User must register with AMDB to download file. etc.
% 13. Other Semantic Attributes


fid = fopen(MetadataFile,'w');
if fid==-1
    fprintf('Not possible to open %s\n',MetadataFile);
else
    iF = 1;
    Field(iF).name = 'Mesh name {dc:title}';
    
    iF = iF + 1;   iDescription = iF;
    Field(iF).name = 'Description {dc:description}';
    Field2Defaultvalue= 'Anatomy of the left ventricle reconstructed from a stack of cine MRI short axis slices at end diastole (first frame of sequence), as part of the population study analysing the differences of the pre-term heart [Lewandowski2013]. This mesh has been automatically built from the segmented anatomy (a binary image), using the meshing service of the AMDB, using the methods described in [Lamata2011].';
    iF = iF + 1;
    Field(iF).name = 'Author {dc:creator}';
    Field(iF).value= 'Dr. Pablo Lamata (Kings College of London)';
    iF = iF + 1;
    Field(iF).name = 'Publisher/Maintainer {dc:publisher}';
    Field(iF).value= 'Dr. Eric Kerfoot (Kings College of London)';
    iF = iF + 1;
    Field(iF).name = 'Resource Type {dc:type}';
    Field(iF).value= 'Link';
    iF = iF + 1;   iLink = iF;
    Field(iF).name = 'Resource {dc:source}';
    Field(iF).value= '';
    iF = iF + 1;    iTags = iF;
    Field(iF).name = 'Tags {dc:subject}';
    Field6Defaultvalue= 'Heart; Cardiac computational mesh; Tricubic Hermite interpolation; Mechanical mesh; left ventricle; ';
    iF = iF + 1;
    Field(iF).name = 'License {dc:rights}';
    Field(iF).value= 'Data provided for research use provided a proper reference of the two relevant papers (see Related Publications). No commercial use is allowed.';
    iF = iF + 1;
    Field(iF).name = 'Version {dc:version}';
    Field(iF).value= '1';
    iF = iF + 1;
    Field(iF).name = 'Language {dc:language}';
    Field(iF).value= 'en_GB';
    iF = iF + 1;
    Field(iF).name = 'Related Publications {dc:relation}';
    Field(iF).value= '[Lewandowski2013] The Preterm Heart in Adult Life: Cardiovascular Magnetic Resonance Reveals Distinct Differences in Left Ventricular Mass, Geometry and Function. http://www.ncbi.nlm.nih.gov/pubmed/23224059. [Lamata 2011] An accurate, fast and robust method to generate patient-specific cubic Hermite meshes http://www.ncbi.nlm.nih.gov/pubmed/21788150 ';
    iF = iF + 1;
    Field(iF).name = 'Status';
    Field(iF).value= 'public';
    iF = iF + 1;
    Field(iF).name = 'Usage Conditions';
    Field(iF).value= 'User must register with AMDB (Anatomical Model DataBase): http://amdb.isd.kcl.ac.uk to download file.';
    iF = iF + 1;   iFistCC = iF;
    Field(iF).name = 'Case characteristics: Age';
    iF = iF + 1;    
    Field(iF).name = 'Case characteristics: Height';
    iF = iF + 1;
    Field(iF).name = 'Case characteristics: Weight';
    iF = iF + 1;
    Field(iF).name = 'Case characteristics: Body Mass Index (BMI)';
    iF = iF + 1;
    Field(iF).name = 'Case characteristics: Body Surface Area (BSA)';
    iF = iF + 1;
    Field(iF).name = 'Case characteristics: Waist/hip ratio';
    iF = iF + 1;
    Field(iF).name = 'Case characteristics: Gestational age';
    iF = iF + 1;
    Field(iF).name = 'Case characteristics: Birth weight';
    
    
    for iF=1:numel(Field)
        fprintf(fid,'"%i. %s", ',iF,Field(iF).name);
    end
    fprintf(fid,'\n');
    for iC = 1:numel(CasesForMetadata)
        % Case specific data:
        % ... the name:
            Field(1).value = CasesForMetadata(iC).exname;
        % ... direct link to th edata:
            Field(iLink).value = sprintf('https://amdb.isd.kcl.ac.uk:8443/AMDBWebInt/downloadGeometricalModel.do?dId=%i&gmId=%i',235+iC,153+iC);
            % not so easy to automate...
            %  1: https://amdb.isd.kcl.ac.uk:8443/AMDBWebInt/downloadGeometricalModel.do?dId=236&gmId=154
            %  2: https://amdb.isd.kcl.ac.uk:8443/AMDBWebInt/downloadGeometricalModel.do?dId=237&gmId=155
            % 10: https://amdb.isd.kcl.ac.uk:8443/AMDBWebInt/downloadGeometricalModel.do?dId=245&gmId=163
        % ... further details about the case:
            Field(iDescription).value = [Field2Defaultvalue sprintf(' This case is a class %i in the study: a %s',CasesForMetadata(iC).classNumber, CasesForMetadata(iC).classDescription)];
        % ... class index to add in tags (also class description)
            Field(iTags).value = [Field6Defaultvalue sprintf('Population study: class number %i (see descripton); ',CasesForMetadata(iC).classNumber)]; 
        % ... and class charactersitics:
            Field(iFistCC).value = CasesForMetadata(iC).age;
            Field(iFistCC+1).value = CasesForMetadata(iC).Height;
            Field(iFistCC+2).value = CasesForMetadata(iC).Weight;
            Field(iFistCC+3).value = CasesForMetadata(iC).BMI;
            Field(iFistCC+4).value = CasesForMetadata(iC).BSA;
            Field(iFistCC+5).value = CasesForMetadata(iC).Waist_hip_ratio;
            Field(iFistCC+6).value = CasesForMetadata(iC).gestational_age;
            Field(iFistCC+7).value = CasesForMetadata(iC).birth_weight;
            
        for iF=1:numel(Field)
            fprintf(fid,'"%s", ',Field(iF).value);
        end
        fprintf(fid,'\n');
    end
    fprintf('Writting finished, report of %i cases available in %s\n',numel(CasesForMetadata),MetadataFile);
end


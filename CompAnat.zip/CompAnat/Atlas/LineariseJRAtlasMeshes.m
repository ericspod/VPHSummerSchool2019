function [] = LineariseJRAtlasMeshes(DataDirectory)
[ListCases] = GetCasesInDirectory(DataDirectory);
nCases = numel(ListCases);

for iCase = 1:nCases
    DirCase = [DataDirectory 'EVS' sprintf('%03i',iCase) '/zmask/Output_heartgen/'];
    Mesh = [DirCase 'Mesh'];
    MeshOut = 'MeshQed';
    QualityOut = ['JacobianRatio' MeshOut '.txt'];
    %if(~exist([DirCase MeshOut '.exnode'],'file'))
        if (exist([Mesh '.exnode'],'file'))
            CH = CubicMeshClass(Mesh);
            CH = CH.LineariseTransmural();    
            CH = CH.SetName(MeshOut);
            CH.WriteExFiles(DirCase);
            CH = CH.CalculateJacobianRatio();
            Quality = CH.Quality.Q3;
            fid = fopen([DirCase QualityOut],'w');
            fprintf(fid,'%f  %f\n',Quality,min(CH.Quality.JacobianRatio));
            fprintf(fid,'mean worse\n');
            fclose(fid);
        end
    %end
end

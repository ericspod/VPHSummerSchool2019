function [CaseNumber bValid] = GetNumberFromName(CaseFolderName,NamingStyle)

    %NamingStyle = 1 - Tailored for EVS111 naming
    %NamingStyle = 2 - For more general numbering, takes entire numerical
    %part of the name e.g. DTI27_15 -> 2715
    
    if nargin<2
        NamingStyle = 1;
    end
    

    CaseNumber = NaN;
    bValid = 0;
    
    switch NamingStyle
        case 1
            caseNumber4 = str2num(CaseFolderName(end-3:end));
            CaseNumber3 = str2num(CaseFolderName(end-2:end));
            CaseNumber2 = str2num(CaseFolderName(end-1:end));
            if numel(CaseNumber3)==1
                CaseNumber = CaseNumber3;
                bValid = 1;
            else if numel(CaseNumber2)==1
                    CaseNumber = CaseNumber2;
                    bValid = 1;
                else 
                    bValid = 0;
                end
            end
            if~bValid
                fprintf('ERROR! Data folder structure does not end with numeric characters.!\n');
                fprintf('       Issue with item: %s\n',CaseFolderName);
                return;
            end
        case 2
            CaseNumber = [];
            if ~isnumeric(CaseFolderName)
                % Instead can be str2num(CaseFolderName(regexp(CaseFolderName, '\d')))
                % Simply extracts all numbers in given order, no matter
                % where or how they are positioned in the case file name.
                [startIndex endIndex] = regexp(CaseFolderName,'\d+');
                
                for i = 1:numel(startIndex)
                    CaseNumber = [CaseNumber CaseFolderName(startIndex(i):endIndex(i))];
                end
                
            else
                CaseNumber = CaseFolderName;
            end
            
            
            
            if numel(CaseNumber) == 0
                bValid = 0;
                CaseNumber = NaN;
            else
                bValid = 1;
                if ~isnumeric(CaseNumber)
                    CaseNumber = str2num(CaseNumber);
                end
            end
            
    end
            
end
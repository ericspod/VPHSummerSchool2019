function [] = CheckSegmentationQuality(imagename,segmentationname)
% Function to assess the correct alignment of a reconstructed binary from
% TomTec output, overlaying it to the original image

iCase = 2;
bCompare2Grayscale = 0;
deltaDCMname = 0;

sliceoffset = 2;
switch iCase
    case 1, 
        IDscan =  5324;
        IDsegm = 4;
    case 2, 
        IDscan =  5350;
        IDsegm = 6;
        sliceoffset = 3;
    case 3, % 'GauCasey'
        IDscan =  5360;
        IDsegm = 3;
        sliceoffset = 0;
    case 4, % 'Weiss'
        IDscan =  5368;
        IDsegm = 7;
        deltaDCMname = -1;
    case 5, % 'OlsonGary'
        IDscan =  5334;
        IDsegm = 5;
        deltaDCMname = -4;
        
        
end

RootFolder = fullfile('F:\TomTec\WholeStackCohort\Original images\Amis_anonymisiert\',sprintf('Anonymisiert - %09i',iCase));
segmentationname = fullfile('F:\TomTec\Johanes\Twist_WholeStack_ResultFiles\AtlasTwist_WholeStack_JTK_1\AtlasData\',sprintf('Case%03i/binary.vtk',IDsegm));
scanname = fullfile('Sa Ed 20\',sprintf('SA ED rest - %i/IM-%04i-0001-0001.dcm',IDscan,iCase+deltaDCMname));
imagename = fullfile(RootFolder,scanname);

PabloSegmentation = fullfile('F:\TomTec\Johanes\Twist_WholeStack_ResultFiles\AtlasCheckOrientation\AtlasData\',sprintf('Case%03i',IDsegm),'binary.nii');

[bin,hdBin] = io_ReadMedicalImage(segmentationname);

if(bCompare2Grayscale)
    [Im,hdIm] = io_ReadMedicalImage(imagename);
else
    [Im,hdIm] = io_ReadMedicalImage(PabloSegmentation);
    figure('color',[1 1 1])
    show_segment_surface(Im,[0 0 0],hdBin.spacing,1);
    show_segment_surface(bin,[0 0 0],hdBin.spacing,0);    
end    
figure('color',[1 1 1])
nSlices = min(size(Im,3),size(bin,3));
    for iSlice = 1:nSlices
        subplot(3,nSlices,iSlice), imagesc(Im(:,:,sliceoffset+iSlice)), axis 'image';
        subplot(3,nSlices,nSlices+iSlice), imagesc(bin(:,:,iSlice)), axis 'image';
        % Visualise a change of origin: transpose starting bottom-up
        subplot(3,nSlices,2*nSlices+iSlice), imagesc(bin(:,:,nSlices-iSlice+1)'), axis 'image';
    end
end

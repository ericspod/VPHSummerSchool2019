function [] = MakeMovieModalVariation(OutputDirectory,iMode,options)

nStd = 2;
if isfield(options,'nStd'), nStd = options.nStd; end


iFrame = 0;
% One directory for each mode:
if isnumeric(iMode)
    MovieDir = fullfile(OutputDirectory,sprintf('movies/MovieMode%i',iMode));
else
    MovieDir = fullfile(OutputDirectory,sprintf('movies/MovieMode%s',iMode));
    iMode = [];
end
if ~exist(MovieDir), mkdir(MovieDir); end
for iStd = nStd:-0.25:-nStd    
    iFrame = iFrame + 1;
    options.CaptionName = sprintf('%03i',iFrame);
    options.MovieDir = MovieDir;
    ViewModalVariation(OutputDirectory,iMode,iStd,options);
end
% If not pausing, the last frame could still not be available for
% conversion, still writting:
pause(2);
io_imgs2avi(MovieDir, {'Image*.png',[1 iFrame],'%03d'}, 'tmp.avi');
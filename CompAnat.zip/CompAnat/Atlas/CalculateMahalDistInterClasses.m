% Shan 3 August 2017
% Try to calculate the Mahalanobis distance between control group and HCM group
% features are the PCAcoefficients

% run ScriptHCM, select the LoD and SP(if necessary)
% This will load AtlasClass:
% AtlasHG1s4.mat,AtlasHG2s4.mat,AtlasHG3s4.mat,AtlasHG4s4.mat,AtlasHG5s4.mat
% and set ground truth label for each subject by reading an excel sheet

% generate features
PCAcoef = struct(Atlas.PCAcoefs);
features = PCAcoef.coefficients;
features = features';
NrCases = size(features,1);
NrFeatures = size(features,2);

% feature name list
featureNames = cell(NrFeatures,1);
for i_feat = 1:NrFeatures
    featureNames{i_feat} = ['PCA coefficient ' num2str(i_feat)];
end

% generate class label list
classlabels = zeros(NrCases,1);
for i_class = 1:2
    tmp = struct(Atlas.Class(i_class));
    classlabels(tmp.Indexes) = i_class;    
end

lablist = char('Control','HCM');
classLabelsText = lablist(classlabels,:);

% generate PRTools dataset
% cd 'C:\Users\shg17\ShanGao\PRTools New\prtools'
ds = dataset(features,classLabelsText,'FEATLAB',char(featureNames));

% select features
ds_featSelected = ds(:,[1:10]);

% calculate inter-class Mahalanobis distance 
distmaha(ds_featSelected)



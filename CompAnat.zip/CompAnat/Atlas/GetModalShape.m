function CH = GetModalShape(CHmean,eigenV,S,DofsOrder)
% Function to add the eigenvector eigenV, multiplied by scale S, to the average
% description of shape

if nargin<4
    DofsOrder = 1;
end

MeanDofs = CHmean.GetDofs(DofsOrder);
nDofs = size(MeanDofs);
if numel(S) == 1
    % This is just an eigenvector
    OutDofs = MeanDofs + S*eigenV;
else
    % This is all the eigenvectors:
    S = reshape(S,1,prod(nDofs));
    % Flip the order:
    S = S(end:-1:1);
    Diff = S*eigenV';
    Difference = reshape(Diff,nDofs(1),nDofs(2));
    OutDofs = MeanDofs + Difference;
end
CH = CHmean.SetDofs(OutDofs,DofsOrder);
function [H] = PlotPCAcoordinates(coefs,cases,eigvectors,ClassDefinition,ListCases,options)
% It returns a handle to the last point drawn in order to allow the
% instertion of a legend


% Default options:
colourscheme = 1;
Fsize = 16;
casesFsize = 8;
iColor = 1;
bPaired = 0;
bLongitudinal = 0;
bPlotCaseString = 1;

if nargin>=6
    if isfield(options,'colourscheme'), colourscheme = options.colourscheme; end
    if isfield(options,'Fsize'), Fsize = options.Fsize; end
    if isfield(options,'iColor'), iColor = options.iColor; end 
    if isfield(options,'Paired_PatIDs') 
        bPaired = 1; 
        id1 = options.Paired_id1;
        id2 = options.Paired_id2;
        PatIDs = options.Paired_PatIDs;
    end 
    if isfield(options,'idX')
        idX = options.idX;
        PatIDs = options.Linked_PatIDs;
        bLongitudinal = 1;
    end
    if isfield(options,'bPlotCaseString'), bPlotCaseString = options.bPlotCaseString; end
end

if isnumeric(cases)
    % if the second argument is a list of digits, convert to a list of
    % strings:
    cases = strread(num2str(cases),'%s');
end



bHist = 1;
nDim = numel(eigvectors);

bClasses = isstruct(ClassDefinition);
if(bClasses)
    nClasses = numel(ClassDefinition);
    switch nClasses 
        case 0
            bClasses = 0;
        case 1
            if ClassDefinition(1).nCases == 0
                bClasses = 0;
            end            
    end
end

% Text added by each sample in the parametric space: a tiny fraction of all
% the span of shape coefficients, defined by the eigenvalues:
deltatext = mean(abs(coefs(~isnan(coefs))))/50;

switch nDim
    case 1
        if(bClasses)
            for iClass=1:nClasses
                %IndexesPerClass = ClassDefinition(iClass).Indexes;
                IndexesPerClass = GetIndexesPerClass(ClassDefinition,iClass,ListCases);
                x = coefs(IndexesPerClass);
                col = GetAtlasColor(iClass,colourscheme);
                if bHist
                    nHistCounts = max(numel(x)/5,10);                    
                    SemiTransparentHistogram(x,nHistCounts,col);                
                else
                    hold on;
                    y = zeros(numel(x),1);
                    % Simply plot the points
                    H = plot(x,y,'*','MarkerEdgeColor',col,'MarkerSize',10,'LineWidth',1.5);
                    if(bPlotCaseString)
                        text(x+deltatext,y+deltatext,cases(IndexesPerClass),'FontSize',9,'Rotation',90);
                    end
                end 
%                h = findobj(gca,'Type','patch');
%                set(h,'FaceColor',GetAtlasColor(iC,colourscheme),'EdgeColor','w')
            end
        else
            col = GetAtlasColor(iColor,colourscheme);
            H = plot(coefs,'MarkerEdgeColor',col);
        end
        xlabel(sprintf('Mode %i',eigvectors))
    case 2 
        hold on;
        if(bClasses)
            for iClass=1:nClasses
                %IndexesPerClass = ClassDefinition(iClass).Indexes;
                IndexesPerClass = GetIndexesPerClass(ClassDefinition,iClass,ListCases);
                x = coefs(eigvectors(1),IndexesPerClass);
                y = coefs(eigvectors(2),IndexesPerClass);
                col = GetAtlasColor(iClass,colourscheme);
                H = plot(x,y,'*','MarkerEdgeColor',col,'MarkerSize',10,'LineWidth',1.5);
                plot(mean(x),mean(y),'o','MarkerEdgeColor',col,'MarkerSize',20,'LineWidth',5);
            end
        else
            col = GetAtlasColor(iColor,colourscheme);
            x = coefs(eigvectors(1),:);
            y = coefs(eigvectors(2),:);
            H = plot(x,y,'*','MarkerEdgeColor',col,'MarkerSize',10,'LineWidth',1.5);
            plot(mean(x),mean(y),'o','MarkerEdgeColor',col,'MarkerSize',20,'LineWidth',5);
        end        
        if(bPaired)
            x = coefs(eigvectors(1),:);
            y = coefs(eigvectors(2),:);
            % link points from same patient ID:
            for iP = 1:numel(PatIDs)
                plot([x(id1(iP)) x(id2(iP))],[y(id1(iP)) y(id2(iP))],':m');
            end
        end
        if(bPlotCaseString)
            x = coefs(eigvectors(1),:);
            y = coefs(eigvectors(2),:);
            I = find(~isnan(x));
            text(x(I)+deltatext,y(I)+deltatext,cases(I));
        end
        xlabel(sprintf('Mode %i',eigvectors(1)))
        ylabel(sprintf('Mode %i',eigvectors(2)))
        axis equal;
        grid on;
        % Plot the centre of the xy axis in bold (reference of the 0,0
        X = get(gca(),'XLim');
        Y = get(gca(),'YLim');
        plot(X,[0 0],'k','LineWidth',3)
        plot([0 0],Y,'k','LineWidth',3)
    case 3
        hold on;
        if size(coefs,1) == 3
            li = 1:3;
        else
            li = eigvectors;
        end
        if(bClasses)
            hold on;
            for iClass=1:nClasses
                IndexesPerClass = GetIndexesPerClass(ClassDefinition,iClass,ListCases);
                x = coefs(li(1),IndexesPerClass);
                y = coefs(li(2),IndexesPerClass);
                z = coefs(li(3),IndexesPerClass);
                col = GetAtlasColor(iClass,colourscheme);
                % plot stars for every case (sample)
                H = plot3(x,y,z,'*','MarkerEdgeColor',col,'MarkerSize',10,'LineWidth',1.5);
                % plot circle as the average of all samples in this
                % particular class
                plot3(mean(x),mean(y),mean(z),'o','MarkerEdgeColor',col,'MarkerSize',20,'LineWidth',5);
            
                % labels of all cases:
                x = coefs(li(1),IndexesPerClass);
                y = coefs(li(2),IndexesPerClass);
                z = coefs(li(3),IndexesPerClass);
                if(bPlotCaseString)
                    % TOCHECK: 
                    cases2write = cases(IndexesPerClass);
                    %cases2write = ListCases(IndexesPerClass);
                    text(x+deltatext,y+deltatext,z+deltatext,cases2write,'FontSize',casesFsize);
                end
            end
        else
            col = GetAtlasColor(iColor,colourscheme);
            x = coefs(li(1),:);
            y = coefs(li(2),:);
            z = coefs(li(3),:);
            H = plot3(x,y,z,'*','MarkerEdgeColor',col);
            text(x+deltatext,y+deltatext,z+deltatext,cases,'FontSize',casesFsize);
        end
        
        if(bPaired)
            hold on;
            x = coefs(li(1),:);
            y = coefs(li(2),:);
            z = coefs(li(3),:);
            % link points from same patient ID:
            for iP = 1:numel(PatIDs)
                plot3([x(id1(iP)) x(id2(iP))],[y(id1(iP)) y(id2(iP))],[z(id1(iP)) z(id2(iP))],':m');
            end
        end
        if(bLongitudinal)
            % extension of paired, up to many linked
            hold on;
            x = coefs(li(1),:);
            y = coefs(li(2),:);
            z = coefs(li(3),:);
            % link points from same patient ID:
            for iP = 1:numel(PatIDs)
            % Build the linking
                XX = []; YY = []; ZZ = [];
                for iL = 1:size(idX,1)
                    index = idX(iL,iP);
                    XX = [XX x(index,:)];
                    YY = [YY x(index,:)];
                    ZZ = [ZZ x(index,:)];
                end
                plot3(XX,YY,ZZ,':c');
            end
        end
        
        labelword = 'Mode';
        xlabel(sprintf('%s %i',labelword,eigvectors(1)),'FontName','Arial','FontSize',Fsize)
        ylabel(sprintf('%s %i',labelword,eigvectors(2)),'FontName','Arial','FontSize',Fsize)
        zlabel(sprintf('%s %i',labelword,eigvectors(3)),'FontName','Arial','FontSize',Fsize)
        view(45,45);
        % Plot the centre of the xyZ axis in bold (reference of the 0,0
        X = get(gca(),'XLim');
        Y = get(gca(),'YLim');
        Z = get(gca(),'YLim');
        plot3(X,[0 0],[0 0],'k','LineWidth',3)
        plot3([0 0],Y,[0 0],'k','LineWidth',3)
        plot3([0 0],[0 0],Z,'k','LineWidth',3)
        grid on;
    otherwise
        fprintf(' Dimensions of parametric spece largern than 3, not able to represent in axes\n');
end
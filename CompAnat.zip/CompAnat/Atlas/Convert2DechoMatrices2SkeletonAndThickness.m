function DofVectors = Convert2DechoMatrices2SkeletonAndThickness(DofMatrices,iView,iCond)
% Function to convert the format of the degrees of freedom of an US contour
%
% INPUT: 
% - a set of matrices in the structure DofMatrices, having the fields
%     EndoCont2chMatrix: [4-D double]
%      EpiCont2chMatrix: [4-D double]
%     EndoCont3chMatrix: [4-D double]
%      EpiCont3chMatrix: [4-D double]
%     EndoCont4chMatrix: [4-D double]
%      EpiCont4chMatrix: [4-D double]
% - iView: the choice of view to output (2, 3 or 4 chamber view)
% - iCond: index of the experimental condition. In the first epoch atlas,
% this refers to the 'birth'(2) or 'fu'(1) condition. If nothing indicated,
% all valid cases are returned from all conditions. 
%
% OUTPUT: a big matrix with all degrees of freedom in a vector (one per
% column)

    if nargin<3
        bOnlyValid = 1;
    else
        bOnlyValid = 0;
    end
    switch iView
        case {2,'2'} 
            EndoDofs = DofMatrices.EndoCont2chMatrix;
            EpiDofs = DofMatrices.EpiCont2chMatrix;                
        case {3,'3'} 
            EndoDofs = DofMatrices.EndoCont3chMatrix;
            EpiDofs = DofMatrices.EpiCont3chMatrix;
        case {4,'4'} 
            EndoDofs = DofMatrices.EndoCont4chMatrix;
            EpiDofs = DofMatrices.EpiCont4chMatrix;
        otherwise
            fprintf('ERROR! Wrong choice of chamber view in Convert2DechoMatrices2Vectors.\n');
    end
    nTotalCases = size(EndoDofs,2);
    if(bOnlyValid)
        % Identify the valid cases:
        iValidEndo = ~isnan(EndoDofs(:,:,1,1));
        iValidEpi = ~isnan(EpiDofs(:,:,1,1));
        iValid = and(iValidEndo, iValidEpi);
        nValid = numel(find(iValid));
        nTotal = numel(iValid);
        fprintf(' %i chamber view: %i valid cases (out of %i possible files)\n',iView,nValid,nTotal);
        % Retrieve the valid cases:
        [ii,jj] = ind2sub(size(iValid),find(iValid));
        EndoValid = NaN * ones(nValid,size(EndoDofs,3),size(EndoDofs,4));
        EpiValid = NaN * ones(nValid,size(EndoDofs,3),size(EndoDofs,4));
        for iV = 1:nValid
            EndoValid(iV,:,:) = EndoDofs(ii(iV),jj(iV),:,:);
            EpiValid(iV,:,:) = EpiDofs(ii(iV),jj(iV),:,:);
        end
    else
        nValid = nTotalCases;
        fprintf(' %i chamber view: %i cases\n',iView,nTotalCases);
        EndoValid = squeeze(EndoDofs(iCond,:,:,:));
        EpiValid =  squeeze( EpiDofs(iCond,:,:,:));
    end
    [nV,nD,nF] = size(EpiValid);
    nDofs = nD*nF;

    % Assemble with all dofs in one line:        
    DofVectors = [reshape(EndoValid,nValid,nDofs) reshape(EpiValid,nValid,nDofs)];
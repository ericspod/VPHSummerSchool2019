function [ListCases,Directories] = GetCasesInDirectory(DataDirectory,ValidCasesID)
% Function to get the ID from the name of the directories in the AtlasData
% directory. 
% INPUT:
% - DataDirectory: where the folders per each case are going to be found
% - ValidCasesID: a partial list of the valid cases, so that the
% "Directories" output is returned accordingly.
%
% OUTPUT:
% - ListCases: with the ID from the name of folders
% - Directories: with the full name of the directory of each case 

    Directories = [];
    ListCases = [];    
    direct = dir(DataDirectory);
    nCases = numel(direct) - 2;

    iValid = 0;
    iCase = 0;
    for iC = 1:nCases
        iD = iC + 2;
        CaseFolderName = direct(iD).name;  
        % Check if this is a directory:
        CaseDir = fullfile(DataDirectory,CaseFolderName);
        if isdir(CaseDir)

            % Hack to find out the case number:
            % [IDcase bValid] = GetNumberFromName(CaseFolderName,2); 
            % Improved version (21/02/218):
            IDcase = GetIDfromName(CaseFolderName);
                   
            if(~isempty(IDcase))
                iCase = iCase + 1;
                ListCases(iCase) = IDcase;
                bValidDirectory = 0;
                if nargin < 2
                    bValidDirectory = 1;                
                else
                    I = find(ValidCasesID == ListCases(iCase));
                    if numel(I)>0
                        bValidDirectory = 1;
                    end
                end
                if bValidDirectory
                    iValid = iValid + 1;
                    Directories(iValid).name = CaseFolderName;
                    Directories(iValid).ID   = ListCases(iCase);
                end                              
            else
                fprintf('WARNING! Not possible to extract number from name %s\n',CaseFolderName);
            end
        end
    end
    fprintf(' A total of %i cases were identified (ID from end of name) from %s\n',iValid,DataDirectory)
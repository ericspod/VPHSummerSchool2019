function GroupedModes = GetModalCombinations(Modes2combine)

fprintf('DEPRECATED FUNCTION! Use BuildGroupedModes.m instead\n');

nModes = numel(Modes2combine);

iCombination = 0;
for nG=1:nModes
    % Explore all grouping combinations, 1 by 1, 2 by 2, etc:
    combinations = combnk(Modes2combine,nG);
    for j=1:size(combinations,1);
        iCombination =  iCombination + 1;
        GroupedModes{iCombination} = combinations(j,:);
    end
end
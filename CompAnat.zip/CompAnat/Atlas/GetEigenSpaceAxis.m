function [H] = GetEigenSpaceAxis(directory,eigvectors,options)
% Version control:
% - 09/09/13: class definition is an option

if nargin<3
    ClassDefinition = NaN;
    options.ClassDefinition = NaN;
else
    if isfield(options,'ClassDefinition')
        ClassDefinition = options.ClassDefinition;
    else
        ClassDefinition = NaN;
    end
    if isfield(options,'ListCases')
        ListCases = options.ListCases;
    end
    if isfield(options,'colourscheme'),     colourscheme = options.colourscheme; end  
end
        
options.eigvectors2output = eigvectors;
% Now with this call the variable ListCases gets updated in case there is a
% incomplete case:
[coefs,cases,~,ListCases] = GetEigenCoefficients(directory,options);

bClasses = isstruct(ClassDefinition);
if(bClasses)
    nClasses = numel(ClassDefinition);
end

nDims = numel(eigvectors);
if nDims == 1
    figuresize = [0 600 1000 250];
else
    figuresize = [0 10 1000 1000];
end
H = figure('color',[1 1 1],'OuterPosition',figuresize);

OutputDirectory = [directory '/AtlasOutput/'];
ss = [];
load([OutputDirectory 'Atlas.mat']);
Scales = ss;
NumberSTDS = 2;

bNewFigures = 0;

Fsize = 15;
for iE = 1:nDims
    % P.Lamata (05/08/14): individual axes were all wrong (when generating
    % the automated pdf with modes of variation)
    iEig = eigvectors(iE);
    if(bNewFigures)
        %Create a new figure for each of the variation modes
        H = figure('color',[1 1 1],'OuterPosition',[0 10 1000 200]);
        Hs(iE) = subplot(1,1,1,'FontSize',Fsize); hold on; 
    else
        Hs = subplot(nDims,1,iE,'FontSize',Fsize); hold on;  
    end
    
    % Plot the (-2std +2std) interval:
    S1 = NumberSTDS*sqrt(Scales(end-iEig+1));
    plot([-S1,S1],[0 0],'k','LineWidth',3);
    plot(0,0,'+','MarkerEdgeColor',GetAtlasColor(1,2),'MarkerSize',20,'LineWidth',3);
    plot(S1,0,'+','MarkerEdgeColor',GetAtlasColor(2,2),'MarkerSize',20,'LineWidth',3);
    plot(-S1,0,'+','MarkerEdgeColor',GetAtlasColor(3,2),'MarkerSize',20,'LineWidth',3);
    for iC=1:nClasses
        % Working with the relative index, defined within a list of valid
        % cases:
        I1 = GetIndexesPerClass(ClassDefinition,iC,ListCases);
        x = coefs(iE,I1);
        MeanCoor = mean(x);
        plot(MeanCoor,0,'*','MarkerEdgeColor',GetAtlasColor(iC,colourscheme),'MarkerSize',20,'LineWidth',3);
        fprintf('Mean coordinate %i made out of %i valid samples\n',iEig,numel(I1))
    end
    axis(1.1*[-S1 S1 -1 1]); 
    
    if(bNewFigures)
        %Create a new figure for each of the variation modes
        set(Hs(iE),'YTickLabel','')
        set(Hs(iE),'YColor',get(gca,'Color'))    
    else
        %Plot all variation modes into a single figure
        
        %set(Hs,'XTickLabel','')
        set(Hs,'YTickLabel','')
        %set(Hs,'XColor',get(gca,'Color'))
        set(Hs,'YColor',get(gca,'Color'))
    end
end
function CH = SolveRigidBodyMotion(CH,options)
% Function to solve the alignment between meshes during the construction of
% and atlas, with parameters:
%
% INPUT:
% - CH: the mesh to be transformed
% - options:
%    AtlasAlignmentOption: main option, choice among different strategies
%    to have two geometries aligned. 
%       'NA': No Alignment
%       'C': just the centre of mass
%       'R': centre of mass and rotation (need of a reference mesh)
%       'S': centre, rotation and scale (need of a reference mesh)
%       'rv': align only the second axis of inertia (defined by either the 
%       position of the RV, as stored in [CaseDirectory 'RVPosition.mat'],
%       or by a node ID should be provided to know the direction of the 
%       second axis of inertia.
%
%
% By Pablo Lamata. Oxford, 4 April 2012

% Version control
% - 11/05/2015: clean alignment options
% - 07/05/2015: enable a rotation alignment to a reference mesh (usually an
% atlas provided)
% - 05/05/2015: rotation alignment now possible by the index of the node
% pointing in the second inertial axis (assuming first is [0 0 1])

AtlasAlignmentOption = -1;

bDebug = 0;
bSecAx = 0;
bRVdirAvailable = 0;

RVdirFile = 'RVPosition.mat';

if nargin >=2
    if isfield(options,'AtlasAlignmentOption'), AtlasAlignmentOption = options.AtlasAlignmentOption;    end    
    if isfield(options,'iShapeSpace'), AtlasAlignmentOption = options.iShapeSpace;    end    
    if isfield(options,'CaseDirectory'),        
        CaseDirectory = options.CaseDirectory;    
        bRVdirAvailable = 1;
    end    
    if isfield(options,'iNodeSecondAxis'), 
        iNodeSecondAxis = options.iNodeSecondAxis;
        bSecAx = 1;
    end
    if isfield(options,'ReferenceMesh'),        ReferenceMesh = options.ReferenceMesh; end
end

bMoveCentre2Origin = 0;
bAlignRVlocations  = 0;
bComputeAlignmentMatrix = 0;
R = eye(3);

switch AtlasAlignmentOption
    case {0,'NA'}
        % No Alignment
        return;
    case {1,'C'}
        % Align only the centre of mass
        bMoveCentre2Origin = 1;
    case {2,'R'}
        % Align centre of mass and rotation
        bMoveCentre2Origin = 1;
        bComputeAlignmentMatrix = 1;
        AlignmentOption = 'R';
    case {3,'S'}
        % Align centre of mass, rotation and scale
        bMoveCentre2Origin = 1;
        bComputeAlignmentMatrix = 1;
        AlignmentOption = 'MT';
    case {4,'rv'}
        % Align centre of mass and a "rotation": align second axis of
        % inertia
        bMoveCentre2Origin = 1;
        bAlignRVlocations = 1;  
    otherwise
        error('No shape space defined to correct body motion\n');
end

if(bMoveCentre2Origin)
    CH = CH.MoveCentre2Origin();
end

if(bComputeAlignmentMatrix)
    if ~exist('ReferenceMesh','var'), 
        fprintf('ERROR! No reference mesh to estimate the rotation provided in SolveRigidBodyMotion.m - exit without rigid alignment\n'); 
    end
    if isempty(ReferenceMesh)
        fprintf('ERROR! Empt reference mesh to estimate the rotation provided in SolveRigidBodyMotion.m - exit without rigid alignment\n'); 
    end
    points1 = CH.GetNodeCoorValue(1:CH.nNodes);
    points2 = ReferenceMesh.GetNodeCoorValue(1:CH.nNodes);
    % function takes care of alignment. several options are possible 
    T = MatchPoints(points2,points1,AlignmentOption);
    % Transform the mesh:
    R = T(1:3,1:3);
    titletex = 'BEFORE ROT';
end

if(bAlignRVlocations)
    % Direction to the RV in the template mesh:
    RVdir = [1 0];
    if(~bRVdirAvailable) && (~bSecAx)
        fprintf('ERROR! Not enough information to align the second axis of inertia!\n')
        fprintf('       Need to provide either CaseDirectory where %s file is,\n',RVdirFile );
        fprintf('       or the node index that points in the direction of the second axis.\n');
    end
    if(bSecAx)
        % It is assumed that the main axis is [0 0 1]!!
        % Now the second axis is found by 
        Dir3d = CH.GetNodeCoorValue(iNodeSecondAxis) - CH.GetMeshCentre();
        RVdir = Dir3d(1:2);
        RVdir = RVdir ./ sqrt(sum(RVdir.^2));
        if(bDebug), fprintf('Second axis direction from node %i: %1.1f, %1.1f\n',iNodeSecondAxis,RVdir); end
    else
        fileRV = fullfile(CaseDirectory ,RVdirFile);
        if exist(fileRV,'file')
            % The RV position was given in the image
            load([CaseDirectory 'RVPosition.mat']);
            %... this loads the variable RVdirection 
            RVdir = RVdirection;
            if(bDebug), fprintf('RV direction in the basal slice: %1.1f, %1.1f\n',RVdir); end
        else
            fprintf('ERROR! no file with the RV direction found in %s\n',CaseDirectory);
            fprintf('       and no index of node pointing in the direction of second axis!\n');
            fprintf('       So not possible to align shape for the correct computation of an atlas.\n');
        end
    end
    % Need to "derotate" by the ammount indicated in RV:
    % RVdir(1): indicates the ammount in x axis!
    % RVdir(2): indicates the ammount in y axis!
    RVdir = RVdir / sqrt(dot(RVdir,RVdir));
    angle = 180 * atan(RVdir(2)/RVdir(1)) / pi;
    %fprintf('Angle = %1.1f� in case %s\n',angle,direct(iD).name);
    if(bDebug), fprintf('Angle = %1.1f�\n',angle); end
    %RVdir = -RVdir;
    % CAUTION! THE ROTATION MATRIX SHOULD NOT BE:
    %     [  c  s  0 ]
    %     [ -s  c  0 ]
    %     [  0  0  1 ]
    % but should be like:
    %     [  c -s  0 ]
    %     [  s  c  0 ]
    %     [  0  0  1 ]
    % In order to "de-rotate" the amount of RVdir
    v1 = [ RVdir(1) -RVdir(2) 0];
    v2 = [ RVdir(2)  RVdir(1) 0];
    v3 = [0 0 1];
    R = [v1' v2' v3'];        
    PCA = PCAtransformation();
    R2 = PCA.BuildRotMatrixFromTwoVectors(v1,v2);
    titletex = sprintf('BEFORE ROT. Angle %1.1f� (RVdir = %1.3f,%1.3f)',angle,RVdir);
end

if (bDebug)
    figure;
    subplot(2,1,1)
    CH.plotWireframe()
    CH.plotElement(10);
    view(0,90)
    title(titletex)
end
CH = CH.rotateMesh(R,[0 0 0]);
if (bDebug)
    subplot(2,1,2)
    CH.plotWireframe()
    CH.plotElement(10);
    view(0,90)
    title(sprintf('AFTER ROT: Case %s',CaseDirectory))
    %pause
    R
end
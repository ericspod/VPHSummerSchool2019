function [ p ] = ShapeCoefficientsRegression( Directory, options )
%UNTITLED Perform Shape coefficient regression %GG

if ~exist('coefficients','var')
        [coefficients,cases] = GetEigenCoefficients(Directory,options);
end
    


%%%%The following could be used to load specific a-priori eigenvectors

% load(fullfile(directory, ['Atlas' '.mat'])); %load V
% load(fullfile(directory, ['MeshCoordinates' '.mat'])); %load mesh coordinates and mean value
% 
% % bLoadAllCoeffs = 1;
% % if(bLoadAllCoeffs)
% %     %Load all eigenvectors in V
% % else
% %     %Load specific a-priori eigenvectors
% % end
% 
% nEigVecs = 10;
% 
% Vreversed = fliplr(V);
% Vsubset = Vreversed(:,1:nEigVecs);
%  
% [m, ~] = size(ValidDofsInLine);
% nTempValidCases = m;
% 
% 
% origValidDofsInLine = ValidDofsInLine;  %copy original coordinate values
% 
% coefficient = Vsubset;  %copy PCs
% 
% %obtain the standardised or adjusted data
% Ds = origValidDofsInLine - repmat(MeanDofsLn,nTempValidCases,1);
% 
% %data is projected onto the eigenvectors matrix obtained through PCA, 
% %getting the coordinates p in the eigenspace:
% p = coefficient' * Ds'; 


end


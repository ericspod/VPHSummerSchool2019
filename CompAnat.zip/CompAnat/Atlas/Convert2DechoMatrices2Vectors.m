function DofVectors = Convert2DechoMatrices2Vectors(DofMatrices,iView,options)
% Function to convert the format of the degrees of freedom of an US contour
%
% INPUT: 
% - a set of matrices in the structure DofMatrices, having the fields
%     EndoCont2chMatrix: [4-D double]
%      EpiCont2chMatrix: [4-D double]
%     EndoCont3chMatrix: [4-D double]
%      EpiCont3chMatrix: [4-D double]
%     EndoCont4chMatrix: [4-D double]
%      EpiCont4chMatrix: [4-D double]
% 
%   each matrix with [nConds,nCases,nDofsPerField,nFields]
%
% - iView: the choice of view to output (2, 3 or 4 chamber view)
% - iCond: index of the experimental condition. In the first epoch atlas,
% this refers to the 'birth'(2) or 'fu'(1) condition. If nothing indicated,
% all valid cases are returned from all conditions. 
%
% OUTPUT: a big matrix with all degrees of freedom in a vector (one per
% column)

    
    bOnlyValid = 1;
    Encoding = 'contours';
    if nargin>=3
        if isfield(options,'iCond')
            iCond = options.iCond;
            % hack to get Madrid data to work
            bOnlyValid = 1;
        end
        if isfield(options,'Encoding')
            Encoding = options.Encoding;
        end
    end
    switch iView
        case {2,'2'} 
            EndoDofs = DofMatrices.EndoCont2chMatrix;
            EpiDofs = DofMatrices.EpiCont2chMatrix;                
        case {3,'3'} 
            EndoDofs = DofMatrices.EndoCont3chMatrix;
            EpiDofs = DofMatrices.EpiCont3chMatrix;
        case {4,'4'} 
            EndoDofs = DofMatrices.EndoCont4chMatrix;
            EpiDofs = DofMatrices.EpiCont4chMatrix;
        otherwise
            fprintf('ERROR! Wrong choice of chamber view in Convert2DechoMatrices2Vectors.\n');
    end
    nTotalCases = size(EndoDofs,2);
    bEndo = 1; bEpi = 1;
    if(bOnlyValid)        
        % Identify the valid cases:
        iValidEndo = ~isnan(EndoDofs(:,:,1,1));
        iValidEpi = ~isnan(EpiDofs(:,:,1,1));
        if numel(find(iValidEndo==0))==numel(iValidEndo), bEndo = 0; iValid= iValidEpi; end
        if numel(find(iValidEpi==0))==numel(iValidEpi),   bEpi = 0;  iValid= iValidEndo; end
        if bEndo&&bEpi
            iValid = and(iValidEndo, iValidEpi);
        end
        nValid = numel(find(iValid));
        nTotal = numel(iValid);
        fprintf(' %i chamber view: %i valid cases (out of %i possible files)\n',iView,nValid,nTotal);
        % Retrieve the valid cases:
        [ii,jj] = ind2sub(size(iValid),find(iValid));
        EndoValid = NaN * ones(nValid,size(EndoDofs,3),size(EndoDofs,4));
        EpiValid = NaN * ones(nValid,size(EndoDofs,3),size(EndoDofs,4));
        for iV = 1:nValid
            EndoValid(iV,:,:) = EndoDofs(ii(iV),jj(iV),:,:);
            EpiValid(iV,:,:) = EpiDofs(ii(iV),jj(iV),:,:);
        end
    else
        nValid = nTotalCases;
        fprintf(' %i chamber view: %i cases\n',iView,nTotalCases);
        EndoValid = squeeze(EndoDofs(iCond,:,:,:));
        EpiValid =  squeeze( EpiDofs(iCond,:,:,:));
    end
    [nV,nD,nF] = size(EpiValid);
    nDofs = nD*nF;

    % Assemble with all dofs in one line:   
    DofVectors = [];
    switch Encoding
        case 'contours'
            if (bEndo)
                DofVectors = [DofVectors reshape(EndoValid,nValid,nDofs)];
            else
                DofVectors = [DofVectors zeros(nV,nDofs)];
            end
            if (bEpi)
                DofVectors = [DofVectors reshape(EpiValid,nValid,nDofs)];
            else
                DofVectors = [DofVectors zeros(nV,nDofs)];
            end
        case 'skeleton'
            skeleton = (EndoValid + EpiValid) / 2;
            thickness= (EpiValid - EndoValid);
            DofVectors = [reshape(skeleton,nValid,nDofs) reshape(thickness,nValid,nDofs)];
        case 'RatioSkeleton'
            skeleton = (EndoValid + EpiValid) / 2;
            thickness= (EpiValid - EndoValid);
            ratio = thickness./skeleton;
            DofVectors = [reshape(ratio,nValid,nDofs) reshape(ratio,nValid,nDofs)];
        otherwise
            fprintf(' ERROR! Not recognised encoding: %\n',Encoding);
    end
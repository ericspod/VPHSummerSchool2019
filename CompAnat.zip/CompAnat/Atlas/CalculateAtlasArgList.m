function [] = CalculateAtlasArgList(directory, varargin)
% Function that wrappes the function CalculateAtlas by parsing a list of 
% commandline arguments and creating the options struct.

    options = {};
    
    if iscell(varargin)
        nArg = numel(varargin);
    else
        nArg = size(varargin,2);
    end
    iArg = 1;
    
    while (iArg <= nArg)
       variable = char(varargin(iArg));
       
       switch lower(variable)
           case {'-cases2include', '-Cases2Include'}
               iArg = iArg + 1;
               options.Cases2Include = varargin{iArg};
           case {'-atlasfilename', '-AtlasFileName'}
               iArg = iArg + 1;
               options.AtlasFileName = char(varargin{iArg});
           case {'-brvdirfromsa', '-bRVDirFromSA'}
               options.bRVdirFromSA = 1;
           case {'-lod', '-LoD'}
               iArg = iArg + 1;
               options.LoD = ParseInput(varargin{iArg});
           case {'-topology', '-Topology'}
               iArg = iArg + 1;
               options.topology = char(varargin{iArg});
           case {'-subdirectory', '-SubDirectory'}
               iArg = iArg + 1;
               options.SubDirectory = char(varargin{iArg});
           case {'-binaryname', '-BinaryName'}
               iArg = iArg + 1;
               options.BinaryName = char(varargin{iArg});
           case {'-bonlygenerateatlasstatistics', '-bOnlyGenerateAtlasStatistics'}
               options.bOnlyGenerateAtlasStatistics = 1;
           case {'-bcorrectgreyscale2segmentationorientation', '-bCorrectGreyScale2SegmentationOrientation'}
               options.bCorrectGreyScale2SegmentationOrientation = 1;
           case {'-surname'}
               iArg = iArg + 1;
               options.surname = char(varargin{iArg});
           case {'-rvpoollabel', '-RVpoolLabel'}
               iArg = iArg + 1;
               options.RVpoolLabel = ParseInput(varargin{iArg});
           case {'-myolabel', '-MyoLabel'}
               iArg = iArg + 1;
               options.MyoLabel = ParseInput(varargin{iArg});
           case {'-assemblebinarymasks', '-AssembleBinaryMasks'}
               options.AssembleBinaryMask = 1;
           case {'-namingconvention', '-NamingConvention'}
               options.NamingConvention = 1;
           case {'-surnamecases', '-surnameCases'}
               iArg = iArg + 1;
               options.surnameCases = char(varargin{iArg});
           case {'-atlassurname', '-AtlasSurname'}
               iArg = iArg + 1;
               options.AtlasSurname = char(varargin{iArg});
           case {'-bmovecentre2origin', '-bMoveCentre2Origin'}
               options.bMoveCentre2Origin = 1;
           case {'-bforcegetedframefromsa', '-bForceGetEDframeFromSA'}
               options.bForceGetEDframeFromSA = 1;
           case {'-pumpkinfolder'}
               disp('-pumpkinfolder found');
               iArg = iArg + 1;
               options.pumpkinFolder = char(varargin{iArg});
           case {'-a'}
               disp('-a found');
               %iArg = iArg + 1;
               %options.pumpkinFolder = char(varargin{iArg});
%            case {'-p'}
%                iArg = iArg + 1;
%                options.pumpkinFolder = char(varargin{iArg});
           otherwise
                disp('Notice! Option ignorred:');
                disp(varargin(iArg));
       end
       iArg = iArg + 1;
    end
    %options
    CalculateAtlas(directory, options);
end


function [output] = ParseInput(input,bCharacters)
% Function converting strings into numbers and arrays

    if nargin<2
        % Flag to indicate you expect a string:
        bCharacters = 0;
    end
    if ischar(input)
        % This is used in a command line:
        output = str2double(input);
    else
        % This is used when calling the function from matlab:
        output = cell2mat(input);
    end

    if(~bCharacters)
        % And if the argument was a char, the cell was converted into a char, and
        % we need to convert it to numeric:
        if ischar(output)
            output = str2double(output);
        end
    end
end
function [coefficientsOut,caseNames,Handles,caseIDs] = GetEigenCoefficients(directory,options)
% INPUT:
% - directory of atlas data
% - The definition of classes (labels) of the cases
%
% OUTPUT:
% - coefficientsOut (coordinates): of all meshes
% - caseNames: with the names of the cases (name of the folder)
% - Handles: to the figures to save the plots afterwards
% - caseIDs: with the number of the valid casis (paired with cases), in
% case some of the input cases were not correct/complete
%
% Version control:
% - 19/01/15: merge with Gerardo completed
% - 19/01/15: partial merge with Gerardo: removed part that was not
% compatible and relying on an additonal unexisting function
% (importCoordsFile.m)
% - 10/11/14: two changes
% 1. generalise to other types of shape representation (data structure). 
% 2. enable the possibility of sub-classes within a case (birth/fu).
% - 09/09/13: class definition is an option

bDebug = 0;
bDebugDofSearch = 0;
bAlingmentCheck = 0;

%==========================================================================
% Hard coded definition of directory and files:
if isfield(options,'DataDirectory')
    DataDirectory = options.DataDirectory;
else
    DataDirectory = fullfile(directory, 'AtlasData');
end
if isfield(options,'TemplateDirectory')
    TemplateDirectory = options.DataDirectory;
else
    TemplateDirectory = fullfile(directory, 'TemplateDir');
end
OutputDirectory = fullfile(directory, 'AtlasOutput');

% Default options and naming of files:
AtlasFileName   = 'Atlas.mat';
AtlasSurname    = '';

% Naming of files:
SubDirectory    = '/';
ClassDefinition = '';
bUseMedialAxis = 0;
bUseWallThicknessOnly = 0;
bUseEpiNodes = 0;
bUseEndoNodes = 0;
bClassesAvailable = 0;

DofsOrder = 1;

% A variable to encode if the naming is based on an input image in each
% case, or on an input text file:
KeyFileKind4Mapping = 'image';
% Get all cases in data directory, this can be overwritten later in options
ListCases = GetCasesInDirectory(DataDirectory);

% For the echo contours
Encoding = 'contours';


bSave = 1;

%nDims = size(V);
bPlot = 0;
iEig2plot = 1:5;
bRecalculateEigenCoords = 0;
iEig = 'all';
eigvectors2output = iEig;
VectorClass = NaN;
H1 = NaN;
H2 = NaN;
colourscheme = 1;
bSolveVerticalFlip = 0;
if nargin==2    
    if isfield(options,'OutputDirectory'), OutputDirectory = options.OutputDirectory; end
    if isfield(options,'bDebugDofSearch'), bDebugDofSearch = options.bDebugDofSearch; end
    if isfield(options,'bAlingmentCheck'), bAlingmentCheck = options.bAlingmentCheck; end
    
    if isfield(options,'bSave'), bSave = options.bSave; end
    if isfield(options,'atlasfileWithPath'), atlasfileWithPath = options.atlasfileWithPath; end
    
    if isfield(options,'AtlasFileName'), AtlasFileName = options.AtlasFileName; end
    if isfield(options,'CoordsMatFileName'), CoordsMatFileName = options.CoordsMatFileName; end    
    
    if isfield(options,'AtlasSurname'), AtlasSurname = options.AtlasSurname; end
    if isfield(options,'KeyFileKind4Mapping'), KeyFileKind4Mapping = options.KeyFileKind4Mapping; end    
    if isfield(options,'eigvectors2output'), eigvectors2output = options.eigvectors2output; end
    if isfield(options,'iEig'),  iEig = options.iEig; end
    if isfield(options,'iEig2plot'),  iEig2plot = options.iEig2plot; end
    if isfield(options,'bPlot'), bPlot = options.bPlot; end
    if isfield(options,'bRecalculateEigenCoords'), bRecalculateEigenCoords = options.bRecalculateEigenCoords; end    
    if isfield(options,'VectorClass'), VectorClass = options.VectorClass; end
    if isfield(options,'SubDirectory'),  SubDirectory = options.SubDirectory;  end
    if isfield(options,'ClassDefinition')  
        ClassDefinition = options.ClassDefinition;  
        if isstruct(ClassDefinition)
            bClassesAvailable = 1;
        end
    end
    if isfield(options,'ListCases')    
        ListCases = options.ListCases;    end
%     if isfield(options,'ListOfFileNames')   %Accepts list of filenames to search for
%         ListOfFileNames = options.ListOfFileNames;
%         bListOfFileNames = 1;
%     end
%     if isfield(options,'partialFileName'),    partialFileName = options.partialFileName;    end
    if isfield(options,'colourscheme'),     colourscheme = options.colourscheme; end  
    if isfield(options,'bUseMedialAxis')   bUseMedialAxis = options.bUseMedialAxis; end  
    if isfield(options,'bUseWallThicknessOnly'),  bUseWallThicknessOnly = options.bUseWallThicknessOnly; end
    
    if isfield(options,'bUseEpiNodes'),  bUseEpiNodes = options.bUseEpiNodes; end
    if isfield(options,'bUseEndoNodes'),  bUseEndoNodes = options.bUseEndoNodes; end
    
    if isfield(options,'Dofs4stats'),     Dofs4stats = options.Dofs4stats;     end
    if isfield(options,'DofsOrder'),      DofsOrder = options.DofsOrder;     end
    
    if isfield(options,'Encoding'),      Encoding = options.Encoding;     end
    
    if isfield(options,'DofWeights'),      DofWeights = options.DofWeights;     end
    if isfield(options,'EigenVector'),     GivenEigenVector = options.EigenVector;     end
    if isfield(options,'MatrixDofs'),      MatrixDofs = options.MatrixDofs;     end
    
    if isfield(options,'TemplateVerticalDir')
        % Some meshes might be flipped upside down:
        TemplateVerticalDir = options.TemplateVerticalDir;
        bSolveVerticalFlip = 1;
    end
end

% Check if there is a special condition:
cond = '';
if isfield(options,'iCond') &&    (  isfield(options,'PostName') || isfield(options,'DirPostName')  )
    if  isfield(options,'PostName')
        cond = cell2mat(options.PostName(options.iCond));
    end
    if isfield(options,'DirPostName')
        cond = cell2mat(options.DirPostName(options.iCond));
    end
end
                        
% File with coordinates:
if ~exist('CoordsMatFileName','var')
    CoordsMatFileName = fullfile(OutputDirectory ,['/Coordinates' AtlasSurname cond '.mat']);
end

if(bUseMedialAxis || bUseWallThicknessOnly)
    load(fullfile(OutputDirectory, 'MedialAxisMean.mat'));
end

if(bUseEpiNodes || bUseEndoNodes)
    load(fullfile(OutputDirectory, 'SurfaceNodesMean.mat'));
end

nCases = numel(ListCases);
iValidCase = 0;
AllCasesNames = {};

%==========================================================================
% Load the atlas: 'V','ss' and 'MeanDofs'

if ~exist('atlasfileWithPath','var')
    atlasfileWithPath = fullfile(OutputDirectory, AtlasFileName);
end
load(atlasfileWithPath);

% No need of this hack, 27/08/2018 PL:
% if strcmp(KeyFileKind4Mapping,'text')
%     % reshape in nCoordenateFields x nDofsPerCoord
%     % hack for the 2D echo contours here
%     nCF = 2;
%     i1 = numel(MeanDofs)/4; i2 = i1+1;
%     i3 = numel(MeanDofs)/2; i4 = i3+1;
%     i5 = 3*numel(MeanDofs)/4; i6 = i5+1;
% 
%     % X coordinate:
%     MeanD(1,:) = [MeanDofs(1:i1) MeanDofs(i4:i5)];
%     MeanD(2,:) = [MeanDofs(i2:i3) MeanDofs(i6:end)];
%     MeanDofs = MeanD';
% end

if strcmp(iEig, 'all')
    iEig = (1:size(V,1));
end
if strcmp(eigvectors2output, 'all')
    eigvectors2output = (1:size(V,1));
end
nCoords = numel(iEig);
if exist('GivenEigenVector','var')
    nCoords = 1;
    eigvectors2output = 1;
    atlasfileWithPath = 'EigenVector provided in arguments';
end
coefficients = NaN * ones(nCoords,nCases);

bCoordsAvailable = 0;
if exist(CoordsMatFileName,'file')
    bCoordsAvailable = 1;
end
bDofsAvailable = 0;
if exist('MatrixDofs','var')
    bDofsAvailable = 1;
end
if bCoordsAvailable && ~bRecalculateEigenCoords
    fprintf('Loading PCA coordinates from %s\n',CoordsMatFileName);
    load(CoordsMatFileName);
    if exist('PCAcoefs','var')
        % Unpack the data:
        coefficients = PCAcoefs.coefficients;
        CaseNames = PCAcoefs.CaseNames;
        ListCases = PCAcoefs.ListCases;
        fprintf(' Loaded %i valid coefficients from %s\n',numel(ListCases),CoordsMatFileName);
    else
        if ~exist('coefficients','var')
            fprintf(' WARNING! No (PCAcoefs OR coefficients) variable loaded from %s\n',CoordsMatFileName);
        end        
        if exist('AllCasesNames','var')
            ListCases = [AllCasesNames.ID];
            for iC = 1:numel(AllCasesNames)
                nname = AllCasesNames(iC).name;
                if iC == 1
                    CaseNames(iC,:) = nname;
                    nChars = numel(nname);
                else
                    if numel(nname)>=nChars
                        CaseNames(iC,:) = nname(end-nChars+1:end);
                    else
                        CaseNames(iC,1:numel(nname)) = nname;
                    end
                end
            end
        else
            ListCases = [];
            CaseNames = [];
        end
    end
else
    fprintf('Computing PCA coordinates from axes defined in %s\n',atlasfileWithPath);
    if isfield(options,'AtlasAlignmentOption')
        ShapeSpace = options.AtlasAlignmentOption;
    end
    if isfield(options,'iShapeSpace')
        ShapeSpace = options.iShapeSpace;
    end
    if exist('ShapeSpace','var')
        if isnumeric(ShapeSpace)
            fprintf('    Alignment option: %i \n',ShapeSpace);   
        else
            fprintf('    Alignment option: %s \n',ShapeSpace);
        end
    end
    % Need to recompute the coefficients:
    iValid = [];
    fprintf('\nStarting the computation coefficients from %i possible cases\n',nCases);
    for iC = 1:nCases
        iCase = ListCases(iC);       
        % Flag to indicate that iCase is the ID of the case (from folder
        % name):
        options.bCaseID = 1;
        options.SubDirectory = SubDirectory;
        [ KeyFile, output ] = CaseMappingAtlas( DataDirectory, iCase, options );
        CaseFolderName = output.CaseFolderName;
        CaseDirectory = output.CaseDirectory; 
        if isnan(CaseFolderName)
            fprintf('ERROR! No folder corresponding to ID=%i in directory %s\n',iCase,DataDirectory);
            if isfield(options,'iCond')
                fprintf(' ... case in condition %i: \n',options.iCond);
            end
        else
            if ~isempty(output.MeshName) || ~isempty(KeyFile)
            
                if ~strcmp(KeyFileKind4Mapping,'text')
                    MeanDofs = CHmean.GetDofs(DofsOrder);                  
                end
                % Now we look for the degrees of freedom of this case,
                % after finding the KeyFile:
                AllCasesNames(iC).name = CaseFolderName;
                AllCasesNames(iC).ID = output.CaseID;
                bValidCase = 0;                                              
                if ~(bDofsAvailable)
                    switch KeyFileKind4Mapping
                        case 'image'
                            bValidfile =0;
                            MeshName = output.MeshName;
                            MeshDirectory = output.MeshDirectory;
                            MeshFile = fullfile(MeshDirectory,[MeshName '.exnode']);
                            if iscell(MeshFile)
                                nM = numel(MeshFile);
                            else
                                nM = 1; MeshFile{1} = MeshFile; MeshDirectory{1} = MeshDirectory;
                            end
                            for iM = 1:nM
                                MeshFileName = MeshFile{iM};
                                if exist(MeshFileName,'file')
                                    bValidfile = 1;
                                    break
                                else
                                    TryMeshName = 'Mesh';
                                    MeshFileName = fullfile(MeshDirectory{iM},[TryMeshName '.exnode']);
                                    if exist(MeshFileName,'file')
                                        bValidfile = 1;
                                        MeshName = TryMeshName;
                                        break
                                    end
                                end
                            end
                            % Retain the right choice of directory:
                            MeshDirectory = MeshDirectory{iM};
                            if(bValidfile)
                                bValidCase = 1;
                                iValidCase = iValidCase + 1;
                                filename = fullfile(MeshDirectory, MeshName);
                                if exist('CH','var')
                                    % Spare the reading of the exelem
                                    CH = CH.ReadAndUpdateNodes([filename '.exnode']);
                                else
                                    % Spare the need to store the exelem in
                                    % every case:
                                    CH = loadCase(filename , TemplateDirectory);
                                    %CH = CubicMeshClass(fullfile(MeshDirectory, MeshName));
                                end
                                
                                if (bSolveVerticalFlip)
                                    % stablish what the "vertical" direction is from the
                                    % template:
                                    if isfield(options,'iNodeSecondAxis')
                                        [OrientMatrix] = GetLVmeshOrientation(CH,options.iNodeSecondAxis);
                                        CaseVerticalDir = OrientMatrix(:,1);
                                        if dot(TemplateVerticalDir,CaseVerticalDir)<0
                                            % Need to flip 180 the
                                            % orientation, arbitrarily in X 
                                            CH = CH.rotateMeshOnAxis(180,'X'); 
                                        end
                                    else
                                        fprintf('WARNING! not possible to flip, need of node pointing in secon main axis direction\n');
                                    end
                                end
                                    
                                optionsRigidMotion = options;
                                optionsRigidMotion.CaseDirectory = CaseDirectory;                            
                                CH = SolveRigidBodyMotion(CH,optionsRigidMotion);
                                if(bAlingmentCheck)
                                    CH = CH.SetName('aligncheck');
                                    CH.WriteExFiles('./');
                                    CHmean.WriteExFiles('./');
                                    opt.CH2 = CHmean.name;
                                    cmGuiViewMesh('./','aligncheck',opt);
                                end
                                % We retrieve here all the dofs of each mesh,
                                % and of the mean mesh, regardless the ones
                                % that are used for the PCA. The only important
                                % thing is the DofsOrder
                                Dofs = CH.GetDofs(DofsOrder);                                
                                if(bUseMedialAxis) %Use calculated medial axes instead of the entire CH mesh
                                    [medialAxisInfo CHMedialAxis] = MedialAxis(CH);
                                    medialAxisNodes = medialAxisInfo(:,1:4); %get only x,y,z coords (and wall thickness)
                                    Dofs = medialAxisNodes;
                                    MeanDofs = MedialAxisMean;        
                                elseif(bUseWallThicknessOnly)
                                    [medialAxisInfo, ~] = MedialAxis(CH);
                                    medialAxisNodes = medialAxisInfo(:,4:4); %get only x,y,z coords
                                    Dofs = medialAxisNodes';
                                    MeanDofs = MedialAxisMean;        
                                elseif(bUseEpiNodes || bUseEndoNodes) %surface nodes
                                        surfaceNodePos    = [];
                                        if(bUseEpiNodes)
                                            chdofs = CH.GetDofs();
                                            epiNodesIdx = CH.FindEpiNodes(bCLagrange4CornersOnly);
                                            EpiNodePos  = chdofs(epiNodesIdx,:);
                                            surfaceNodePos = [surfaceNodePos; EpiNodePos];
                                        end                   
                                        if(bUseEndoNodes)
                                            chdofs = CH.GetDofs();
                                            endoNodesIdx = CH.FindEndoNodes(bCLagrange4CornersOnly);
                                            EndoNodePos  = chdofs(endoNodesIdx,:);
                                            surfaceNodePos = [surfaceNodePos; EndoNodePos];
                                        end
                                        Dofs = surfaceNodePos;
                                        MeanDofs = SurfaceNodesMean;
                                end
                            else
                                fprintf('ERROR! No mesh found! Image exists: %s\n',KeyFile);
                                fprintf('       Mesh does not exist: %s\n',MeshFileName);                                
                            end
                        case {'text','contourimage'}
                            % check that we have the ones of the conditons we want:
                            % - Atlassurname encodes the chamber view:
                            ch = options.AtlasSurname;
                            % - The experimental condition is in variable
                            % "cond"
                            % Now the name of the right dof file:
                            % The dofs are in a mat file, like mesh013USfit013birthFrame01dofs
                            DofFileNamePrototype = fullfile(CaseDirectory,['*' cond '*dofs.mat']);
                            DofFiles = ls(DofFileNamePrototype);
                            nF = size(DofFiles,1);
                            if nF>1
                                if bDebugDofSearch
                                    fprintf('WARNING! Not unique definition of the dof file. Possibilities:\n');
                                    for iF = 1:nF
                                        fprintf('      %i: %s\n', iF, DofFiles(iF,:));
                                    end
                                    fprintf(' ... in an attempt to recover, taking the fist one\n');
                                end
                                temp = DofFiles(1,:);
                                DofFiles = temp;
                            end                            
                            DofFileWithPath = fullfile(CaseDirectory,DofFiles);
                            if exist(DofFileWithPath,'file')&&nF>0    
                                clear('EndoDofs','EpiDofs','EndoCont2Ch','EpiCont2Ch','EndoCont3Ch','EpiCont3Ch','EndoCont4Ch','EpiCont4Ch')
                                % load the LinearMeshes with the dofs:
                                load(DofFileWithPath);
                                % it may well be that there were dofs, but not the ones of each contour:
                                switch ch
                                    case {'2','2ch','2chamber'}
                                        if exist('EndoCont2Ch','var'), EndoDofs = EndoCont2Ch.GetDofs(); end
                                        if exist('EpiCont2Ch','var'), EpiDofs = EpiCont2Ch.GetDofs(); end
                                    case {'3','3ch','3chamber'}
                                        if exist('EndoCont3Ch','var'), EndoDofs = EndoCont3Ch.GetDofs(); end
                                        if exist('EpiCont3Ch','var'), EpiDofs = EpiCont3Ch.GetDofs(); end
                                    case {'4','4ch','4chamber'}
                                        if exist('EndoCont4Ch','var'), EndoDofs = EndoCont4Ch.GetDofs(); end
                                        if exist('EpiCont4Ch','var'), EpiDofs = EpiCont4Ch.GetDofs(); end
                                    otherwise
                                        fprintf('ERROR! chamber view not recognised from the surname of the atlas\n')
                                        fprintf('       surname = %s\n',options.AtlasSurname)
                                end
                                bEndo = 0; bEpi = 0;
                                if exist('EndoDofs','var'), bEndo = 1; nDofs = numel(EndoDofs); end   
                                if exist('EpiDofs','var'),  bEpi  = 1; nDofs = numel(EpiDofs);  end
                                if bEndo||bEpi
                                    bValidCase = 1;                        
                                    iValidCase = iValidCase + 1;
                                    switch Encoding
                                        case 'contours'
                                            Dofs = [];
                                            if (1)
                                                % one row per coordinate field:
                                                if bEndo, Dofs = [Dofs reshape(EndoDofs,1,nDofs)]; else Dofs = [Dofs; zeros(1,nDofs)]; end
                                                if bEpi,  Dofs = [Dofs reshape(EpiDofs,1,nDofs)];  else Dofs = [Dofs; zeros(1,nDofs)]; end
                                            else
                                                if bEndo, Dofs = [Dofs EndoDofs']; else Dofs = [Dofs zeros(2,nDofs/2)]; end
                                                if bEpi,  Dofs = [Dofs EpiDofs'];  else Dofs = [Dofs zeros(2,nDofs/2)]; end
                                            end
                                            Dofs = Dofs';
                                            % One single vector, first endo
                                            % then epi:
                                            Dofs = reshape(Dofs,1,2*nDofs);
                                        case 'skeleton'
                                            skeleton = (EndoDofs + EpiDofs) / 2;
                                            thickness= (EpiDofs - EndoDofs);
                                            Dofs = [reshape(skeleton,1,nDofs) reshape(thickness,1,nDofs)];
                                        case 'RatioSkeleton'
                                            skeleton = (EndoDofs + EpiDofs) / 2;
                                            thickness= (EpiDofs - EndoDofs);
                                            ratio = thickness./skeleton;
                                            Dofs = [reshape(ratio,1,nDofs) reshape(ratio,1,nDofs)];
                                    end
                                end
                            else
                                fprintf('WARNING! No data in caseID %i, condition "%s"\n',output.CaseID,cond);
                            end
                                                % If any other shape space:
                            switch ShapeSpace
                                case {'R',2}
                                    % do nothing
                                case {'S',3}
                                    % Scale only from the dofs of the values, not
                                    % the derivatives:
                                    Scale = sqrt(sum( Dofs(1:2:end).^2 ) ) / sqrt(sum(MeanDofs(1:2:end).^2)) ;
                                    CaseDofs = Dofs / Scale;
                                case {'skelS'}

                                otherwise
                                    % Do nothing;
                            end
                    end
                    if(bValidCase)
                        MatrixDofs(iC,:,:) = Dofs;
                        % MatrixDofs(iC,:) = Dofs; % this is needed for
                        % the single contours! TODO: make this robust
                    end
                else
                    % These dofs have already been pre-aligned!
                    Dofs = squeeze(MatrixDofs(iC,:,:));
                    % So no need of:
                    if(0)
                        CH = CHmean;
                        CH = CH.SetDofs(Dofs);                    
                        optionsRigidMotion = options;
                        optionsRigidMotion.CaseDirectory = CaseDirectory;                            
                        CH = SolveRigidBodyMotion(CH,optionsRigidMotion);
                        Dofs = CH.GetDofs();
                    end
                    bValidCase = 1;
                    iValidCase = iValidCase + 1;
                end
                if(bValidCase)
                    % These are all the dofs of the mesh:
                    OriginalDofs = Dofs;
                    Dofs = OriginalDofs - MeanDofs;
                    % It could be that only part of the dofs are used
                    % to compute coefficients (PCA on part of the dofs):
                    nDofs = size(Dofs);         % Size of complete dofs
                    nDofs2retrieve = nDofs;
                    if exist('Dofs4stats','var')
                        % Dofs4stats encodes the dofs per coordinate field
                        nDofs2retrieve(1) = numel(Dofs4stats);
                    end
                    %fprintf(' Computing PCA coefs from %i dofs (out of %i of the mesh)\n',nDofs2retrieve(1),nDofs(1));
                    ShapeDofs = reshape(Dofs,1,prod(nDofs));
                    
                    % Account for the possible scale factor of the dofs to
                    % account for the different "energy" of each basis
                    if exist('DofWeights','var')
                        ShapeDofs = ShapeDofs .* DofWeights;
                    end
                    for iE = 1:nCoords
                        iEigen = iEig(iE);         
                        if ~exist('GivenEigenVector','var')
                            EigenVector = GetVector(iEigen,V,nDofs2retrieve);
                        else
                            EigenVector = GivenEigenVector;
                        end
                        if exist('Dofs4stats','var')
                            % The rest of the elements of the original average mesh are null:
                            eig = zeros(nDofs);
                            EigenVector = reshape(EigenVector,numel(Dofs4stats),3);
                            eig(Dofs4stats,:) = EigenVector;
                            EigenVector = eig;
                        end                        
                        EigenDofs = reshape(EigenVector,1,prod(nDofs));                        
                        coefficients(iE,iC) = ShapeDofs * EigenDofs';

                        if(bDebug)
                            subplot(321); imagesc(OriginalDofs); title(sprintf('Dofs case %i',iC));
                            subplot(323), imagesc(MeanDofs); title('Mean Dofs');
                            subplot(325), imagesc(Dofs); title('Dofs without mean');
                            subplot(322), imagesc(GetVector(1,V,nDofs2retrieve)); title(sprintf('Eigenvector %i',iE));
                            subplot(324), imagesc(EigenVector); title(sprintf('Eigenvector %i with valid DOFS',iE));
                            pause();
                        end
                    end
                    CasesNames(iValidCase).name = CaseFolderName;
                    CasesNames(iValidCase).ID = output.CaseID;
                    AllCasesNames(iC).name = CaseFolderName;
                    AllCasesNames(iC).ID = output.CaseID;
                    iValid = [iValid iC];
                else
                    fprintf(' Directory without the image! (%s)\n',CaseDirectory);
                end
            else
                fprintf(' Directory without the key file! (%s)\n',CaseDirectory);
            end     
        end
    end
    % Retrieve only the valid ones
    AllCasesNames = CasesNames;
    coefficients = coefficients(:,iValid);
    
    % Check mean dofs
    Mean1 = squeeze(mean(MatrixDofs,1));
    diffe = MeanDofs - Mean1;
    fprintf(' Computed %i valid coefficients (out of %i). Condition: %s. AtlasSubGroup: %s.\n',numel(CasesNames),numel(AllCasesNames),cond,AtlasSurname);
    % flag removed on 25/03/15 to allow the milk study:
    if(bSave)
        fprintf('Saving shape coefficients for all cases to %s\n',CoordsMatFileName);
        save(CoordsMatFileName,'AllCasesNames','coefficients');
    end
end

% The computation has been made in the complete list of directories in AtlasData, but now need to select the valid ones:
iValid = [];
nTotal = numel(AllCasesNames);
if nTotal == numel(ListCases)
    iValid = 1:nTotal;
else
    for iAll = 1:nTotal
        if isfield(AllCasesNames(1),'ID')
            if numel(AllCasesNames(iAll).ID)>0
                bValid = 1;
                ID = AllCasesNames(iAll).ID;
            else
                bValid = 0;
            end
        else
            ID = GetIDfromName(AllCasesNames(iAll).name);
            if isnumeric(ID), bValid = 1; else bValid = 0; end
        end
        if bValid                
            I = find(ListCases == ID);
            if numel(I) > 0
                iValid = [iValid iAll];
            end
        end
    end
end
AllCasesNames = AllCasesNames(iValid);
coefficients = coefficients(:,iValid);
fprintf(' There are %i valid coefficients (out of %i possible cases)\n',numel(iValid),nTotal);


% Build the caseNames
if numel(AllCasesNames)>0
    cases = squeeze(struct2cell(AllCasesNames));
    caseNames = cases(1,:);
    caseIDs = cell2mat(cases(2,:));
         % CAUTION! If there is a case that was wrong, there will be an empty cell, and
         % then on less caseID. Nevertheless, coefficients will also have an
         % empty row, and therefore they will not match later!
     % Therefore...
    caseIDs = ListCases;
%     nIDs = size(caseIDs,2);
%     fprintf('A total of %i cases with valid ID after computation of coefficients\n',nIDs);
else
    if exist('PCAcoefs','var')
        caseNames = CaseNames;
        caseIDs = ListCases;
    end
end
        
coefficientsOut = coefficients(eigvectors2output,:);
% check if the size is correct
% nIDs = size(caseIDs,2);
% nCoefs = size(coefficientsOut,2);
% if nIDs ~= nCoefs
%     error('When retrieving coefficients, number of cases did not match! %i coefs retrieved, and % expected\n',nCoefs,nIDs)    
% end
    
if ~isnan(VectorClass)
    bBoxPlot = 1;
else
    bBoxPlot = 0;
end
   
H1 = NaN; H2 = NaN; H3 = NaN;
if(bPlot)
    H1 = figure('color',[1 1 1],'OuterPosition',[0 10 1800 1500]);
    H2 = figure('color',[1 1 1],'OuterPosition',[500 10 800 1200]);
    if(bBoxPlot), H3 = figure('color',[1 1 1],'OuterPosition',[500 10 400 1200]);   end    
end
Handles = [H1 H2 H3];

nCoords2plot = numel(iEig2plot);
    for iC = 1:nCoords2plot
        if(bPlot)&&(iC<=nCoords2plot)
            figure(H1); subplot(nCoords2plot,1,iC); hold on;
            figure(H2); subplot(nCoords2plot,1,iC); hold on;
            if(bBoxPlot), figure(H3); subplot(nCoords2plot,1,iC); hold on; end
        end
        if(bClassesAvailable)
            if isstruct(ClassDefinition)                
                Class = ClassDefinition;
                nClasses = numel(Class);
            else
                % TODO: Create analogous structure:
                [nCasesPerClass nClasses] = size(ClassDefinition);
                IndexesPerClass = zeros(nClasses,nCasesPerClass);
                for iClass=1:nClasses
                    Class(iClass).Indexes = ClassDefinition(:,iClass);
                    Class(iClass).nCases = numel(ClassDefinition(:,iClass));
                end
            end
            ValidFileID = sort(cell2mat({Class(:).FileID}));
            for iClass = 1:nClasses
                IndexesPerClass = GetIndexesPerClass(Class,iClass,ListCases,0);
                if(bPlot)&&(iC<=nCoords2plot)
                    AllCoefs = coefficients(iC,:);
                    coefs2bar = zeros(size(AllCoefs));
                    coefs2bar(IndexesPerClass) = AllCoefs(IndexesPerClass);
                    coefs2hist = AllCoefs(IndexesPerClass);
                    figure(H1);  bar(coefs2bar,'FaceColor',GetAtlasColor(iClass,colourscheme));
                    figure(H2);  [A,B] = hist(coefs2hist,10); bar(B,A,'FaceColor',GetAtlasColor(iClass,colourscheme)); alpha(0.5)                    
                end
            end
            if(bBoxPlot)&&(bPlot)&&(iC<=nCoords2plot), figure(H3); 
                ValidCoeffs = AllCoefs(ValidFileID);
                boxplot(ValidCoeffs,VectorClass);  end
        else
            if(bPlot)&&(iC<=nCoords2plot)
                 bar(coefficients(iC,:)); end
        end
        if(bPlot)&&(iC<=nCoords2plot)
            figure(H1);  
                set(gca,'XTick',1:nCases)
                set(gca,'XTickLabel',cases)
                title(sprintf('Coordinate %i',iEig(iC)))
            figure(H2);  
                title(sprintf('Coordinate %i',iEig(iC)))
            if(bBoxPlot)
                figure(H3);  
                title(sprintf('Coordinate %i',iEig(iC)))
            end
        end
    end
    a=1;
end

function ID = GetIDfromName(name)
% Function to retrieve the numeric of a name ending in an unknown number of
% digits.
    bFromTheEnd = 1;
    ID = 0; II = 0;
    for In = numel(name):-1:1                    
        if(bFromTheEnd)
            character = name(In);
            if character>='0' && character<='9'
                % This is a digit:
                digits(In) = str2num(character);
                II = II + 1;
                ID = ID + digits(In) * 10^(II-1);
            else
                bFromTheEnd = 0;
            end
        end
    end                
end

function CaseFolderName = FindFolderWithID(direct,iCase)
% Function to find the folder with the name that ends in the digits of the
% iCase:
    CaseFolderName = NaN;
    for iDirect = 1:numel(direct)
        name = direct(iDirect).name;
        ID = GetIDfromName(name);
        if ID == iCase
            CaseFolderName = name;
            return;
        end
    end
end

function [CH] = loadCase(filename , TemplateDirectory)
    if isfile([filename '.exelem'])
        CH = CubicMeshClass(filename);
    else
        bRead = 1;
        EXnodefile = [filename '.exnode'];
        EXelemfile = ls( fullfile(TemplateDirectory , '*.exelem') );
        if size(EXelemfile,1) == 1
            EXelemfile = fullfile(TemplateDirectory , EXelemfile);
        else
            if size(EXelemfile,1) > 1
                fprintf('WARNING! More than 1 exelem in TemplateDir - taken the first in alphabetical order\n');
                EXelemfile = fullfile(TemplateDirectory , EXelemfile(1,:) );                        
            else
                fprintf('ERROR! No exelem file found, neither in casedir nor in TemplateDir!\n');
                bRead = 0;
            end
        end
        if(bRead)
            CH = CubicMeshClass(EXnodefile,EXelemfile);
        end
    end
end
    function [ClassDefinition,Cases2include,rawExcelData,rawTextExcel] = LoadAtlasClass(Directory, ClinicalFile, options)
    
        bDataUnzipped = 1;
        bMapClass = 1;
        bOnlyIncludeCasesInExcelFile = 0;
        bRestrictedClasses = 0;
        Cases2include = [];
        rawExcelData = [];
        rawTextExcel = [];
        AtlasVersion = 0;
        bLinkingNeed = 0;
        bTakeMeshing = 0;
        
        % Addition in March 2019:
        bMapCaseID = 1;
        
        if isfield(options,'bOnlyIncludeCasesInExcelFile') 
            bOnlyIncludeCasesInExcelFile= options.bOnlyIncludeCasesInExcelFile ;
        end
        if isfield(options,'bDataUnzipped') 
            bDataUnzipped= options.bDataUnzipped ;
        end
        if isfield(options,'bRestrictedClasses') 
            bRestrictedClasses= options.bRestrictedClasses ;
        end
        if isfield(options,'bTakeMeshing') 
            bTakeMeshing= options.bTakeMeshing ;
        end
        if isfield(options,'bMapClass') 
            bMapClass= options.bMapClass ;
        end
        if isfield(options,'LinkingExcel')
            bLinkingNeed = 1;
            excel2 = options.LinkingExcel;
        end
        
        if isfield(options,'MeshDirectory') 
            MeshDirectory= options.MeshDirectory ;
        else
            fprintf('WARNING! No MeshDirectory provided in options (LoadAtlasClass.m)\n');
        end
        if isfield(options,'DataDirectory') 
            DataDirectory= options.DataDirectory ;
        else
            fprintf('WARNING! No DataDirectory provided in options (LoadAtlasClass.m)\n');
        end
        if isfield(options,'AtlasVersion')
            AtlasVersion= options.AtlasVersion ;
        end
        if(bOnlyIncludeCasesInExcelFile)
            % need to know which classes are to be retrieved:
            if isfield(options,'classes2include') 
                classes2include= options.classes2include ;
            else
                fprintf('ERROR! No classes2include provided in options (LoadAtlasClass.m)\n');
            end
        end
        if bTakeMeshing
            Directory2map = MeshDirectory;
        else
            Directory2map = DataDirectory;
        end
        
        
        ClinicalFileWithPath = fullfile(Directory, ClinicalFile);
        fprintf('Loading class info from %s\n',ClinicalFileWithPath);
        if(bLinkingNeed)
            [ClassDefinitionInfo,textdata] = LoadUnlinkedClass(excel2,ClinicalFileWithPath,options);
        else
            [ClassDefinitionInfo,textdata,raw] = xlsread(ClinicalFileWithPath);
            % Try to retrieve caseID if it is not numeric
            if bMapCaseID
                CandiateFirstCaseID = ClassDefinitionInfo(1,1);
                % Look in first column, is it numeric? if not, convert to
                % numeric. First row might be explanations, look second row
                [nRows,nColumns] = size(textdata);
                if ~isempty(cell2mat(textdata(2,1)))
                    % First column to be converted!                    
                    nCols = size(ClassDefinitionInfo,2);
                    nCases = size(ClassDefinitionInfo,1);
                    CaseIDs = zeros(nRows,1);
                    for ii = nRows-nCases+1:nRows
                        CaseIDs(ii) = GetIDfromName(cell2mat(textdata(ii,1)));
                    end
                    % Make CaseIDs the first column:
                    ClassDefinitionInfo2(:,1) = CaseIDs(nRows-nCases+1:nRows);
                    ClassDefinitionInfo2(:,2:1+nCols) = ClassDefinitionInfo;
                    ClassDefinitionInfo = ClassDefinitionInfo2;
                end
            end
        end
        rawExcelData = ClassDefinitionInfo;
        rawTextExcel = textdata;  
        if (~bMapClass)
             ClassDefinition = ClassDefinitionInfo;
        else
            optionsExcel = options;
            optionsExcel.Study = AtlasVersion;
            optionsExcel.txt = textdata;
    %         Now the optionsExcel.iColumnClass encodes the old ColumnResponseInClinicalFile
    %         if(~isnan(ColumnResponseInClinicalFile))
    %             optionsExcel.iColumnClass = ColumnResponseInClinicalFile;
    %         end
            [ClassDefinition,VectorClass,CaseMapping] = OrderExcelDataInClassStructure(ClassDefinitionInfo,Directory2map,optionsExcel);
        end
        if(bDataUnzipped)
            if(bRestrictedClasses)
                temp = ClassDefinition(classes2include);
                clear ClassDefinition;
                ClassDefinition= temp;
            end
        end    
        if(bOnlyIncludeCasesInExcelFile)
            fprintf(' WARNING! The cases included in analysis are all the cases in the excel file %s\n',ClinicalFile);
            fprintf('          The clases included for the analysis are: ');
            fprintf(' %i,',classes2include);
            fprintf('\n');
            Cases2include = [ClassDefinition(classes2include).PatID];            
            fprintf('          As a result, %i cases are included\n',numel(Cases2include));
        end

function [ID,phases,class,IDoriginal] = GetIDandPHfromName(filename,namingConventionORoffset)
% Function to get the patient ID and phases of the heart cycle from the
% name of the file. Adapted to the naming convention used with Georgial and
% Thackshy in the atrial shape analysis project.
%
% By Pablo Lamata. Zaragoza, January 2016

off = 2;

if nargin<2
    namingConvention = 2;
else
    if namingConventionORoffset >0
        if namingConventionORoffset>2
            off = namingConventionORoffset;
        else
            off = 2;
        end
        namingConvention = 2;
    else
        namingConvention = 0;
    end
end

switch namingConvention
    case 0
        phases = sscanf(filename(end-1:end),'%i');
        class = sscanf(filename(end-3:end-2),'%i');
        ID = sscanf(filename(end-4:end-4),'%i');        
        % check if further digits of the name:
        for ichar = 1:numel(filename)-5
            is = 4+ichar;
            I = sscanf(filename(end-is:end-is),'%i');
            if I>=0 & I<=9
                ID = ID + I*10^ichar;
            end
        end
        IDoriginal = ID;
    case 1
        % Patient ID is at the beginning of the name:
        ID = sscanf(filename,'%i',1);
        if numel(ID)>1
            a=1;
        end

        % Phases are after the keyword 'phases'
        keyword = 'phases';
        c0 = strfind(filename,keyword);
        if isempty(c0)
            keyword = 'pha';
            c0 = strfind(filename,keyword);
        end    
        % Get all digits after the keyword
        phases = sscanf(filename(c0+numel(keyword):end),'%i');
        IDoriginal = ID;
    case 2
        % Example: G01D1_1.nii
        ID = sscanf(filename(off:3),'%i');
        if numel(ID)>1
            % do not know why, sometimes '08' gets into two digits...
            ID = ID(1)*10 + ID(2);
        end
        IDoriginal = ID;
        phases = sscanf(filename(off+5),'%i');
        class = sscanf(filename(off+3),'%i');
        if isempty(phases)
            phases = 0;
        end
        % Make a unique ID
        ID = ID*100 + phases*10 + class;
        if numel(ID)>1
            a=1;
        end
        if phases==0
            phases = [];
        end
        
end




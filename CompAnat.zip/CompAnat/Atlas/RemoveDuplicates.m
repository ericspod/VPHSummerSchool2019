function [NewDistance,NewIm,NewIed] = RemoveDuplicates(Distance,im,Ied)
% Function to remove a duplicate from the list of slices (oritinated from a
% duplicate existance of files, exported twice in Argus).

[DistanceSorted,I2] = sort(Distance);

[nX nY nSlicesIn] = size(im);
NewIm = NaN * ones(nX,nY,nSlicesIn/2);
NewDistance = NaN * ones(1,nSlicesIn/2);
NewIed = NaN * ones(1,nSlicesIn/2);

inewZ = 0;
for iSsort = 1:nSlicesIn
    if(iSsort)>1
        Increment = DistanceSorted(iSsort) - DistanceSorted(iSsort-1);
    else
        % Always take the first slice:
        Increment = 1;
    end
    if Increment ~= 0
        iSlice = I2(iSsort);
        %inewZ = int8(floor((iSlice+1)/2));
        inewZ = int8(floor((iSsort+1)/2));
        NewIm(:,:,inewZ) = im(:,:,iSlice);
        NewDistance(inewZ) = Distance(iSlice);
        NewIed(inewZ) = Ied(iSlice);
    end
end
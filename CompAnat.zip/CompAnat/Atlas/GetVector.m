function vec = GetVector(iVector,V,nDofs)
% The eigenvectors are ordered in inverse importance from eig
%
% OPTIONAL:
% - nDofs: in case the dofs are to be ordered in a different manner, like
% in the x,y,z coordinate fields of a mesh, then we introduce in nDofs =
% (nDofsPerCoordindate, 3)

if nargin<3
    nDofs(1) = size(V,1);
    nDofs(2) = 1;
end

if iVector<1
    fprintf('ERROR! Wrong choice of iVector in GetVector (%f)\n',iVector);
    vec = NaN;
    return
end
% The number of eigenvectors in V is cropped to save memory burden, and
% thus any vector above the number of cases is simply all zeros:
nVectors = size(V,2);
if iVector > nVectors
    vec = zeros(nDofs);
    return;
end

    iV = iVector -1;
    vec = reshape(V(:,end-iV),nDofs(1),nDofs(2));
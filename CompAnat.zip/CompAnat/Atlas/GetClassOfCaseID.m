function [label,bValidClassFound,bWrongClass] = GetClassOfCaseID(ClassDefinition,PatID,PossibleLabels)
    % Function to get the label (cathegory) of case PatID
    % 
    % INPUT:
    % - ClassDefinition: structure with the information of each
    % subject: the class it belongs, etc.
    % - PatID: patient identifier
    % - PossibleLabels: optional parameter to restrict the valid labels
    % to be returned;
    %
    % OUTPUT:
    % - label: local ID of the class among the list of
    % "PossibleLabels", or absolute ID of the class among all the
    % classes in ClassDefinition (if the third parameter is not
    % provided)
    
    bDebug = 0;

    if nargin>=3 
        bCheckPossibleLabels = 1;
    else
        bCheckPossibleLabels = 0;
    end

    label = NaN;

    bValidClassFound = 0;
    bWrongClass = 1;
    for iClass = 1:numel(ClassDefinition);
        I = find(ClassDefinition(iClass).PatID == PatID);
        if numel(I) == 1
            if bValidClassFound
                fprintf('ERROR! Case %i belongs to two different classes\n',PatID);
            else
                if(bCheckPossibleLabels)
                    % Now need to check if this is one of the two classes to
                    % compare:
                    iCl = find( PossibleLabels == iClass );
                    if numel(iCl)>0
                        label = iCl;
                        bValidClassFound = 1;
                        bWrongClass = 0;
                    else
                        if bDebug
                            bWrongClass = 1;
                            fprintf('Case %i belongs to class %i, which is not included (only %i and %i are)\n',PatID,iClass,classes2include);
                        end
                    end
                else
                    label = iClass;
                    bValidClassFound = 1;
                end
            end
        end
    end
end
function [AUCs,iSignifDif,Sensitivities,Specificities,LDAout,OptPoint] = AtlasLinearDiscriminantAnalysis(GroupedModes,coefficients,ClassDefinition,ListCases,V,options)
% Function to make a linear discriminant analysis of the shape
% coefficients by:
% - Fisher
% - Evaluate: cross validation AUC of the ROC
%
% By Pablo Lamata. Zaragoza, 19 May 2015
% 
% Version control:
% - 13/08/16: remove cases from other classes than "classes2include" from
% the analysis!!

bDebug = 1;

% Parameters
    classes2include = [1 2];
    bPredictive = 0;
        nLeaveOut = 1;
        nRepetitions = 1000; % Number of times a leave-K out is run
    bModelROC = 0;
    bROCFisherLinearMode = 1;
        bPrintROCs = 0;
        bPlotAUCconficenceBounds = 1;
        bPrintAllROCs = 0;
    bViewFisherLinearMode = 0;
    bOverlayExtremes = 0;
        ZoomFactor = 6;
    bFigureHandleProvided = 0;
    bCheckReproducible = 0;
    versionstring = '';
    iComparison = [];
    plotcolor= 'b';
    
    bEigenvectorsAvailable = 1;
    
    bMeasureDeviance = 1;
    
    pThreshold = 0.05;
    aucThreshold = 0.55;
    
    bPromptPerfSummary = 0;
    
    if isfield(options,'pThreshold'), pThreshold = options.pThreshold; end
    if isfield(options,'classes2include'), classes2include = options.classes2include; end
    if isfield(options,'bPredictive'), bPredictive = options.bPredictive; end
    if isfield(options,'bModelROC'), bModelROC = options.bModelROC; end
    
    if isfield(options,'nLeaveOut'), nLeaveOut = options.nLeaveOut; end
    if isfield(options,'nRepetitions'), nRepetitions = options.nRepetitions; end
    if isfield(options,'bCheckReproducible'), bCheckReproducible = options.bCheckReproducible; end
    if isfield(options,'iMeshing'), iMeshing = options.iMeshing; end
    if isfield(options,'iShapeSpace'), iShapeSpace = options.iShapeSpace; end
    
    if isfield(options,'bROCFisherLinearMode'), bROCFisherLinearMode = options.bROCFisherLinearMode; end
    if isfield(options,'bPrintROCs'), bPrintROCs = options.bPrintROCs; end
    if isfield(options,'bPrintAllROCs'), bPrintAllROCs = options.bPrintAllROCs; end
    
    if isfield(options,'bPlotAUCconficenceBounds'), bPlotAUCconficenceBounds = options.bPlotAUCconficenceBounds; end
    if isfield(options,'bViewFisherLinearMode'), bViewFisherLinearMode = options.bViewFisherLinearMode; end
    if isfield(options,'bOverlayExtremes'), bOverlayExtremes = options.bOverlayExtremes; end
    if isfield(options,'ZoomFactor'), ZoomFactor = options.ZoomFactor; end
    if isfield(options,'OutputDirectory'), OutputDirectory = options.OutputDirectory; end
    if isfield(options,'versionstring'), versionstring = options.versionstring; end
    if isfield(options,'plotcolor'), plotcolor = options.plotcolor; end
    if isfield(options,'FigureHandle'), 
        FigureHandle = options.FigureHandle; 
        bFigureHandleProvided = 1;
    end
    
%% Check parameters:
    % The classes to explore should be in the class:
    for iC = 1:numel(classes2include)
        C = classes2include(iC);
        if C>numel(ClassDefinition)
            fprintf('ERROR: wrong choice of class to compare.\n')
            fprintf('       class %i is not defined (only %i are defined)\n',C,numel(ClassDefinition));
            return
        end
    end
    
    if isempty(V) 
        bEigenvectorsAvailable = 0;
    else
        if isnan(V(1,1))
            bEigenvectorsAvailable = 0;
        end
    end
    
    if nLeaveOut == 1
        nRepetitions = 1;
    end
%% Begin
nC = ceil(sqrt(numel(GroupedModes))); 
nR = nC;
% The list of cases
if ~isfield(options,'Cases2include')
    options.Cases2include = ListCases;
end
nCases = numel(options.Cases2include);
    
if(bModelROC)
    bPredictive = 0;
end

if(bCheckReproducible)
    repstr = 'Reprod';
    if ~exist('iMeshing','var')
        fprintf('ERROR! Need of iMeshing to check reproducibility in the AtlasLinearDiscriminantAnalysis.m\n');
    end
    if ~exist('iShapeSpace','var')
        fprintf('ERROR! Need of iShapeSpace to check reproducibility in the AtlasLinearDiscriminantAnalysis.m\n');
    end
else
    repstr = '';
end

[iValidCases,ClassificationLabels] = GetValidCases(ListCases,options.Cases2include,ClassDefinition,classes2include);

bKfold = 0;
if(bPrintROCs)
    ROCdir = fullfile(OutputDirectory,'ROCs');
    if ~exist(ROCdir,'dir'), mkdir(ROCdir); end
    Hroc = figure('color',[1 1 1],'OuterPosition',[100 100 150+nC*150 150+nR*150]); 
end

ValidListCases = ListCases(iValidCases);
ValidCoefficients = coefficients(:,iValidCases);
ValidClassificationLabels = ClassificationLabels(iValidCases);

nValidCases = numel(iValidCases);
if(bPredictive)
    bKfold = 1;
    nKfold = round(nValidCases/nLeaveOut);
    AllCases = 1:nValidCases;
    if ~bKfold
        AllCombinations = combnk(AllCases,nLeaveOut);
        nLeaveIterations = size(AllCombinations,1);
        for iT = 1:nLeaveIterations
            TestingSets{iT} = AllCombinations(iT,:);
            TrainingSets{iT}  = setdiff(AllCases,TestingSets{iT});
        end        
        if(nLeaveIterations>2000)
            nLeaveIterations = 2000;
            bKfold = 1;        
        end
    else
        for iR = 1:nRepetitions
            % create cross validation data set from your data
            % "ClassificationLabels": numerical vector which contains the right
            % label for each observation
            % nKfold: number of cross validations
            Partitions(iR) = cvpartition(ValidClassificationLabels,'k',nKfold);
            nLeaveIterations = nKfold;
        end
    end
    predstring = 'pred';
else
    nLeaveOut = 0;
    nLeaveIterations = 1;
    predstring = '';
    bPlotConfidenceBounds = 0;
end

iSignifDif = [];
nGr = numel(GroupedModes);
% AUCs = zeros(1,nGr);
AUCs = zeros(nGr,nRepetitions);
AUCstd        = zeros(1,nGr);
AUCconfbounds = zeros(2,nGr);
Sensitivities = zeros(nGr,nRepetitions);
Specificities = zeros(nGr,nRepetitions);
II            = zeros(nGr,nRepetitions);
OptPoint      = zeros(nGr,nRepetitions);
Significances = zeros(nGr,nRepetitions);
fprintf(' Starting the evaluation of %i combinations of PCA coordinates\n',nGr);




for iG = 1:nGr
    % Loop over all possible combinations of PCA modes:
    GM = GroupedModes{iG};      

    
    bValidCombination = 1;
    if bCheckReproducible
        % A criteria to check if it is worth exploring this combination
        ReproducibleModes = GetReproducibleModes(iMeshing,iShapeSpace);
        IsReproduible = ismember(GM,ReproducibleModes);
        if sum(IsReproduible)<numel(IsReproduible)
            bValidCombination = 0;
        end
    end
    if(bValidCombination)
        PredictedScores = NaN * ones(numel(ListCases),nRepetitions);
        for iR=1:nRepetitions
            labels = cell(1,nLeaveIterations);
            scores = cell(1,nLeaveIterations);            
            for iLeaveOutIteration = 1:nLeaveIterations
                if(bPredictive)
                    bPlotConfidenceBounds = 1;
                    if(bKfold)
                        % Build the model with smaller number of samples:
                        % variables hold index of observation that will be used
                        % for training/testing
                        c = Partitions(iR);
                        iCases4Training =  c.training(iLeaveOutIteration);
                        iCases4Testing  =  c.test(iLeaveOutIteration);
                    else
                        iCases4Training = TrainingSets{iLeaveOutIteration};
                        iCases4Testing  = TestingSets{iLeaveOutIteration};                
                    end
                    ListCases4training = ValidListCases( iCases4Training );
                    coefficientsTraining = ValidCoefficients(:,iCases4Training);
                    % collect relevant coefficients only
                    coefficientsTesting = ValidCoefficients(:,iCases4Testing);
                    iTest = ValidListCases(iCases4Testing);
                else
                    ListCases4training = ValidListCases;
                    coefficientsTraining = ValidCoefficients;
                    coefficientsTesting = ValidCoefficients;
                end                
                I1 = GetIndexesPerClass(ClassDefinition,classes2include(1),ListCases4training,0);            
                I2 = GetIndexesPerClass(ClassDefinition,classes2include(2),ListCases4training,0);
                % coefficients we will actually use for analysis
                % GM: number of coeffients per observation
                % I1/2: devides controll from onco
                % class 1: contr. ED
                % class 2: control ES
                % class 3: onco ED
                % class 4: onco ES
                x1 = coefficientsTraining(GM, I1 ) ;
                x2 = coefficientsTraining(GM, I2 ) ;
                xx1 = x1(:,~isnan(x1(1,:)));
                xx2 = x2(:,~isnan(x2(1,:)));
                % w is weight vector determined by LDA. Has same dimension as
                % GM 
                % train on seperate xx1 (control) and xx2 (onco) 
                % only data from our trainings data sample is used
                [w,p] = fisher( xx1 , xx2 );
                Significances(iG) = p;
                % The predicted scores:
                % multiply first GM coeff. from the test data set with the
                % weight vector w found by LDA
                wC = w.'*coefficientsTesting(GM,:);
                if(bPredictive)
                    clear 'IDs';
                    %PredictedScores(iTest) = wC;
                    % Need to index with respect to the original ListCases:
                    CasesIDs = ValidListCases(iCases4Testing);
                    for iii = 1:numel(CasesIDs)
                        IDs(iii) = find(ListCases == CasesIDs(iii));
                    end
                    %PredictedScores(find(iCases4Testing)) = wC;
                    if numel(IDs) ~= numel(wC)
                        fprintf('error, size does not match: %i IDs and %i wC\n',numel(IDs),numel(wC));
                    end
                    PredictedScores( IDs ) = wC;
                end
                if(bPredictive)
                    % Store the predicted scores, and associated labels, of
                    % the cases for testing:
                    labels{iLeaveOutIteration} = ValidClassificationLabels(iCases4Testing);
                    scores{iLeaveOutIteration} = wC;                
                else
                    % Store all the scores already in one go:
                    labels = ValidClassificationLabels;
                    scores = wC; 
                end
            end
            if(bROCFisherLinearMode)
        %         if nLeaveOut == 1
        %             labels = cell2mat(labels);
        %             scores = cell2mat(scores);
        %             bPlotConfidenceBounds = 0;
        %         end
                % Compute the roc:
                [X,Y,T,AUC,OPTROCPT] = ComputeROC(labels,scores,bModelROC);
                Xs(iG,:) = X(:,1)';
                Ys(iG,:) = Y(:,1)';
                clear ('labels', 'scores');
                AUCs(iG,iR) = AUC(1);
                if(bPlotAUCconficenceBounds) && numel(AUC)>=3
                    AUCconfbounds(1,iG) = AUC(2);
                    AUCconfbounds(2,iG) = AUC(3);
                end
                Sensitivities(iG,iR) = 1-OPTROCPT(1);
                Specificities(iG,iR) = OPTROCPT(2);
                % Optimal point:
                Ix = find(X==OPTROCPT(1));
                Iy = find(Y==OPTROCPT(2));
                PossiblePoints = intersect(Ix,Iy);
                % When OPTROCPT is 0, several options are returned (corners):
                II(iG,iR) = PossiblePoints(1);
                OptPoint(iG,iR) = T(II(iG,iR));
                stringmodes = sprintf('%i,',GM);
                PerformanceSummary = sprintf('AUC=%1.3f.Opt=%1.2f(m%s)',AUC(1),OptPoint(iG),stringmodes);
                if (bPrintROCs)
                    subplot(nR,nC,iG)
                    plot(X(:,1),Y(:,1));
                    hold on;
                    plot(X(II(iG,iR)),Y(II(iG,iR)),'ro');
                    if bPlotConfidenceBounds
                        errorbar(X(:,1),Y(:,1),Y(:,2)-Y(:,1),Y(:,3)-Y(:,1),':k');
    %                     plot(X(:,2),Y(:,2),'r');
    %                     plot(X(:,3),Y(:,3),'r');
                        axis([0 1 0 1]);
                    end
                    title(PerformanceSummary);
                end
                if(bPromptPerfSummary)
                    fprintf('Performance summary: %s\n',PerformanceSummary);
                end
                if(~bPredictive)
                    % Keep track of the mode combinations that led to
                    % significant differences after the LDA:
                    if (AUC>aucThreshold)&&(p<pThreshold)
                        iSignifDif = [iSignifDif iG];
                    end
                end
            else
                if(~bPredictive)
                    % Keep track of the mode combinations that led to
                    % significant differences after the LDA:
                    if (p<pThreshold)
                        iSignifDif = [iSignifDif iG];
                    end
                end            
            end
            if(bPredictive)
                % Complete the predicted scores if there were invalid
                % cases, not needed for the cross-validation, but to have
                % the complete list of LDA coefficients.
                if numel(ValidListCases) < numel(ListCases)
                    % Train with all valid cases:
                    ListCases4training = ValidListCases;
                    coefficientsTraining = ValidCoefficients;
                    I1 = GetIndexesPerClass(ClassDefinition,classes2include(1),ListCases4training,0);            
                    I2 = GetIndexesPerClass(ClassDefinition,classes2include(2),ListCases4training,0);  
                    x1 = coefficientsTraining(GM, I1 ) ;
                    x2 = coefficientsTraining(GM, I2 ) ;
                    xx1 = x1(:,~isnan(x1(1,:)));
                    xx2 = x2(:,~isnan(x2(1,:)));
                    [w,p] = fisher( xx1 , xx2 );
                    for iCase = 1:numel(ListCases)
                        if isnan(PredictedScores(iCase,iR))
                            %fprintf('Computing prediction of case %i\n',iCase);
                            wC = w.'*coefficients(GM,iCase);
                            PredictedScores(iCase,iR) = wC;
                        end
                    end
                end
            end
        end
        % Get the average performance of the repetitions
        mAUCs = mean(AUCs,2);
        
        
        if(bEigenvectorsAvailable)
            % Compute the "Fishervector":
            FV = 0;
            for iC = 1:numel(GM)
                FV = FV + w(iC) * GetVector(GM(iC),V);
            end

            % Compute the std in this vector:
            FVstd = std(wC);
            if(bViewFisherLinearMode)||bOverlayExtremes
                % Visualise the variation:
                options.GivenEigenVector = FV;
                options.STD = FVstd;
                options.ZoomFactor = ZoomFactor;
                if(bViewFisherLinearMode)
                    DirName = [sprintf('FisherC%iM',iComparison) sprintf('%i',GM)];
                % MakeMovieModalVariation(OutputDirectory,DirName,options);
                    % Also, overlay the two extremes:
                end
                if(bOverlayExtremes)
                    if options.STD == 0
                        fprintf('ERROR! Only one sample used to estimate the std, which resulted in null\n')
                        fprintf('   ... please check that you are computing a "resubstitution" and not a predictive AUC!!!\n')
                    end
                    options.CaptionName = ['OverlayExtremeFisherM' sprintf('%i',GM)];            
                    options.bOverlayExtremes = bOverlayExtremes;
                    ViewModalVariation(OutputDirectory,[],2,options);
                end                
            end
        else
            FV = [];
            FVstd = 0;
        end
        %GetModalShape(CHmean,FV,2*FVstd);

        
    end
    xString(iG).name = sprintf('%i,',GM);
end

% Add the output of the ROC points to be able to plot it:
LDAout.Xs = Xs;
LDAout.Ys = Ys;
% Save the cros-validation scores for each leave-1 out:
LDAout.PredictedScores = mean(PredictedScores,2);
LDAout.stdPredictedScores = std(PredictedScores,0,2);
LDAout.ListCases = ListCases;
LDAout.Significances = Significances;

fprintf(' End of the evaluation of %i combinations of PCA coordinates\n',nGr);
if(bROCFisherLinearMode)
    filename = [ sprintf('ROC%s_%sG%iLeave%iOut%s',predstring,versionstring,numel(GroupedModes),nLeaveOut,repstr)];
    if(bPrintROCs)
        export_fig(fullfile(ROCdir,[filename '.png']),'-png',Hroc);%,'-m3','-painters',H);
        savefig(Hroc,fullfile(ROCdir,[filename '.fig']));
    end
end

nRocs = numel(mAUCs);
if nRocs == 1
    bPrintAllROCs = 0;
else
    if(bFigureHandleProvided)
        figure(FigureHandle);
        bPrintAllROCs = 1;
    else
        if(bPrintAllROCs)
            HallROCs = figure('color',[1 1 1]);    
        end
    end
end
if bPrintAllROCs
    hold on;

    
    if nRocs > 1
        plot(mAUCs,[plotcolor '*:']);
        if bPlotAUCconficenceBounds
            % Plot the range:
            hold on;
            for iRoc = 1:nRocs
                x = iRoc;
                y1= AUCconfbounds(1,iRoc);
                y2= AUCconfbounds(2,iRoc);
                plot([x x],[y1 y2],[plotcolor '-']);
            end
        end
    end
    if(~bFigureHandleProvided)&&(nRocs>1)
        [~,I] = sort(mAUCs,'descend');
        set(gca,'XTick',I(1));    
        set(gca,'XTickLabel',{xString(I(1)).name});
        filename = [ sprintf('SummaryAUC%s_%s%s',predstring,versionstring,repstr) '.png'];
        export_fig(fullfile(OutputDirectory,filename),'-png',HallROCs);    
    end
end


if bMeasureDeviance && ~bPredictive % if predictive, only one wC has been computed
    % A model fit quality. It is a linear regression model with one
    % coefficient:
    X = wC;
    response = NaN*ones(1,numel(wC));
    for iC = 1:numel(classes2include)
        I = GetIndexesPerClass(ClassDefinition,classes2include(iC),ValidListCases,0);           
        response(I) = iC;
    end
    mdl = fitglm(X,response);
    Result = devianceTest(mdl);
    LDAout.mdl = mdl;
    LDAout.Deviance = Result;
end
  

% Prepare output
LDAout.ClassesCompared = classes2include;
LDAout.GM = GM;
LDAout.wC = wC;
LDAout.w  = w;
LDAout.Mode = FV;
LDAout.Std  = FVstd;
LDAout.I1 = I1;
LDAout.I2 = I2;
LDAout.p  = p;
LDAout.OptPoint = OptPoint;
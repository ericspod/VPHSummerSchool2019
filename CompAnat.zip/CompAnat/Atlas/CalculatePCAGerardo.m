function [ output_args ] = CalculatePCAGerardo(directory,options)
%Create "anatomical" eigenvectors from mean shape

    % Naming of files:
    surname                     = '';
    BinaryName                  = 'BinaryMask.vtk';
    SubDirectory                = '/';
    
    bSelectedCases              = 0;
    postfix = '/AtlasData/';
    bStep0_Alternative          = 0;
    RefDir                  = 'E:\data\JR\Atlas_v2.1\';
    CaseDirectories             = '';
    Cases2exclude           = [];
    bPerformResidualPCA = 1;
    ss = [];
    bListOfCases = 0;
    AtlasFileName               = 'Atlas.mat';
    AprioriAtlasFileName               = 'AtlasApriori.mat';
    
    bUseDerivativesSubset = 0; %Whether to keep all derivatives in cHermite
    bSurfaceNodesOnly = 0;
    bPerformPCAClassification = 1;
    
    bCLagrange4CornersOnly = 0;
    
    %options    
    if nargin==2
        if isfield(options,'Cases2include')
            Cases2include = options.Cases2include;
            bSelectedCases = 1;
        end
        if isfield(options,'SubDirectory'),  SubDirectory = options.SubDirectory;  end    
        if isfield(options,'postfix'),       postfix = options.postfix; end   
        if isfield(options,'CaseDirectories'),  CaseDirectories = options.CaseDirectories; end
        if isfield(options,'surname'),       surname  = options.surname;  end
        if isfield(options,'ListOfCases')
            ListOfCases = options.ListOfCases;
            bListOfCases = 1;
        end       
        if isfield(options,'bUseDerivativesSubset'), bUseDerivativesSubset = options.bUseDerivativesSubset; end      
        if isfield(options,'bSurfaceNodesOnly'), bSurfaceNodesOnly = options.bSurfaceNodesOnly; end      
        if isfield(options,'bPerformPCAClassification'), bPerformPCAClassification = options.bPerformPCAClassification; end
        if isfield(options,'bCLagrange4CornersOnly'), bCLagrange4CornersOnly = options.bCLagrange4CornersOnly; end        
    end
    
    DataDirectory = [directory postfix];
    OutputDirectory = [directory '/AtlasOutput/']; 
    CurrentDirectory = pwd;

    if(bStep0_Alternative)
        direct = dir([RefDir 'AtlasData/']);
    else
        direct = dir(DataDirectory);
    end
    nCases = numel(direct) - 2;

    if strcmp(BinaryName,'SubDirectoryName')
        bSearchSubDirectoryNameFile = 1;
    else
        bSearchSubDirectoryNameFile = 0;
    end

    fprintf('Reading Atlas.m file...');
    load(fullfile(OutputDirectory, ['Atlas' surname '.mat']));
    fprintf('done! \n');
    
    if(bSurfaceNodesOnly) %these variables have been saved in CalculateAtlasGerardo.m
        load(fullfile(OutputDirectory, 'SurfaceNodesMean.mat'));
    end
    
    load(fullfile(OutputDirectory, 'MeshCoordinates.mat'));
    
    %read files from directories to get correct number of cases in the PCA
    bValidCases = zeros(1,nCases);
    
    if(bSelectedCases)
        nCasesForPCA = numel(Cases2include);
    else
        nCasesForPCA = nCases;
    end
    
    if(bListOfCases)
        nCasesForPCA = numel(ListOfCases);
    end
    
    for iCase = 1:nCasesForPCA
    
        if(~isempty(CaseDirectories))
            CaseDir = options.CaseDirectories(iCase).name;
        else
            iD = iCase + 2;
            CaseDir = direct(iD).name;
        end    
        CaseDirectory = [DataDirectory CaseDir SubDirectory];
        if bSearchSubDirectoryNameFile
            BinaryName = SearchSubDirectoryNameFile(CaseDir,CaseDirectory,surname);        
        end        
        if ~isnan(BinaryName)
            MeshName = [RemovePathAndExtension(BinaryName) '_mesh']; %GGG
            MeshDirectory = [CaseDirectory 'Output_heartgen/'];
            CaseNumber = GetNumberFromName(CaseDir);%str2num(direct(iD).name(end-2:end));
            if find(Cases2exclude == CaseNumber)>0
                fprintf('Case %i is excluded\n',CaseNumber);
            else
                if exist([MeshDirectory MeshName '.exnode'],'file')
                    bValidCases(iCase) = 1;
                    LVCaseNumber(iCase) = CaseNumber;
                end
            end
        end
    end
    
    %Perform a-priori shape changes according to modes of variation
    modalOptions.OutputDirectory = OutputDirectory;
    modalOptions.directory = directory;
                    
    nValidCases = numel(find(bValidCases));
    fprintf('Analysis with %i valid cases\n',nValidCases);    
    
    %%--PCA Calculation
                  
    nTempValidCases = nValidCases;

%   Create flag options in dictionary-like structure
    variationModes.('bAxisElongation')      =1;
    variationModes.('bEpiChange')           =1; 
    variationModes.('bEndoChange')          =1; 
    variationModes.('bBasalRadiusChange')   =0;
    variationModes.('bApicalPositionChange')=0;
        
    [m,~] = size(fieldnames(variationModes));   
    
    allVarValues = struct2cell(variationModes); %convert to cell array
    originalVariationModesOptions = variationModes; %copy original flag options
    
    scale = 1.0;
    atlasNumCases = 10;
    numOfAprioriModes = 0;
    
    modalOptions.plotOutput = 0; %whether to display template mesh being currently generated
    modalOptions.bEpiEndoChangeAllDirections = 0; % 0 = only radial scaling (x,y coords)   
    modalOptions.bSurfaceNodesOnly = bSurfaceNodesOnly;
    modalOptions.bCLagrange4CornersOnly = bCLagrange4CornersOnly;
    
    maxScale = 2.0;
    scaleDelta = (maxScale/nTempValidCases);

    for j = 1:m        
        TemplateFromMeanMatrixDofs = [];
        TemplateFromMeanDofsInLine = [];
        
        if(allVarValues{j} ~= 0)
            numOfAprioriModes = numOfAprioriModes + 1;
            
            for i = 1:atlasNumCases %nTempValidCases
                %set extreme values for each loop to force shape changes in this dimension
                %when calculating the PCA, eigenvalues will result in the
                %direction of most change (variability)            

                scale = scale + scaleDelta;

                if(variationModes.bAxisElongation == 1)
                    modalOptions.bAxisElongation = 1;
                    modalOptions.elongationDelta = scale;         
                    EigVecName = 'AxisElongation';
                    
                elseif(variationModes.bEpiChange == 1)
                    modalOptions.bEpiChange = 1;
                    modalOptions.epiScaleDelta = scale;
                    EigVecName = 'EpiChange';
                    
                elseif(variationModes.bEndoChange == 1)
                    modalOptions.bEndoChange = 1;
                    modalOptions.endoScaleDelta = scale/3;
                    EigVecName = 'EndoChange';

                elseif(variationModes.bBasalRadiusChange == 1)
                    modalOptions.bBasalRadiusChange = 1;
                    modalOptions.baseRadiusDelta = scale*1.5;
                    EigVecName = 'BasalRadiusChange';                    

                elseif(variationModes.bApicalPositionChange == 1)
                    modalOptions.bApicalPositionChange = 1;
                    modalOptions.apexOffsetDelta = -scale*3;
                    EigVecName = 'ApexOffsetChange';
                end
                
                %...etc

                DofsMeanShape = CHmean.GetDofs();
                model = CreateShapeModalVariations(CHmean, DofsMeanShape, modalOptions, i);
                nModelDofs = size(model);        
                
                if(CHmean.InterpolationBasis == 1 && bUseDerivativesSubset) %Don't use all derivatives in cHermite
                    
                    %derivativesList is the list of derivatives indices in the form of:
                    %derivativesList = [duds1 duds2 duds3 duds12 duds13 duds23 duds123]
                    %derivativesList = [1 1 0 1 0 0 0]; %keep only duds1, duds2 and duds12
                    derivativesList = [0 0 0 0 0 0 0]; %keep no derivatives
                    
                    model = NeglectMeshDerivatives(model, derivativesList, CHmean.nNodes);                    
                end
                
                %store current model in matrix of models
                TemplateFromMeanMatrixDofs(i,:,:) = model;
                %reshape above matrix to store elements in a linear way
                TemplateFromMeanDofsInLine(i,:) = reshape(TemplateFromMeanMatrixDofs(i,:,:),1,prod(nModelDofs));
                
                if(i == atlasNumCases)
                    if(variationModes.bAxisElongation == 1)
                        variationModes.bAxisElongation = 0;
                        modalOptions.bAxisElongation = 0;
                    elseif(variationModes.bEpiChange == 1)
                        variationModes.bEpiChange = 0;
                        modalOptions.bEpiChange = 0;
                    elseif(variationModes.bEndoChange == 1)
                        variationModes.bEndoChange = 0;
                        modalOptions.bEndoChange = 0;
                    end
                end
            end        
            
            ValidTemplateFromMeanMatrixDofs = TemplateFromMeanMatrixDofs; %copy all shapes
            ValidTemplateFromMeanDofsInLine = TemplateFromMeanDofsInLine; 

            %PCA on deformed shapes to get eigenvalues
            TemplateFromMeanDofsMeanShape = mean(ValidTemplateFromMeanMatrixDofs,1);	%mean among all models (matrix as k,m,n)
            TemplateFromMeanDofsMeanShape = squeeze(TemplateFromMeanDofsMeanShape);     %reduce matrix dimension to (m,n) 

            TemplateFromMeanMeanDofsLn = reshape(TemplateFromMeanDofsMeanShape,1,prod(nModelDofs));  %copy to linear array (1,n)
            TemplateFromMeanMatrixDofsWithoutMean = ValidTemplateFromMeanDofsInLine - repmat(TemplateFromMeanMeanDofsLn,atlasNumCases,1); %nTempValidCases,1); 
            TempBMean = TemplateFromMeanMatrixDofsWithoutMean;
            TempCOVMean = TempBMean'*TempBMean/atlasNumCases; %nTempValidCases;
            fprintf('Eigenanalysis of template covariance matrix of %s with size %ix%i\n',EigVecName,size(TempCOVMean));
            [TempVMean,TempSMean] = eig(TempCOVMean);
            TempssMean = diag(TempSMean);

            %save individual PC eigenvector
            EigVectorCurrent = TempVMean(:,end); %PC
             save([OutputDirectory EigVecName],'EigVectorCurrent'); 

            EigAprioriVectors(:,numOfAprioriModes) = EigVectorCurrent;
        end
    end
    
    variationModes = originalVariationModesOptions; %restore original flag options (just in case)
        
    nameVariable = ['EigAprioriVectors' num2str(cell2mat(allVarValues'))];
    save([OutputDirectory nameVariable],'EigAprioriVectors');
    
    if(bSurfaceNodesOnly)
        DofsMeanShape = SurfaceNodesMean;
    end
    
    MeanDofsLn = reshape(DofsMeanShape,1,prod(nModelDofs));
    
    %TODO: A function could be added here to load EigAprioriVectors from a folder
    %location for future studies
    
    %
    % Now we need to ortho-normalise!
    bEnforceOrthonormality = 0;
    
    isOrthogonal = EigAprioriVectors' * EigAprioriVectors;
    eigVectorMatrix = EigAprioriVectors;
    
    if(bEnforceOrthonormality)
        determinant = det(isOrthogonal);
        %if(determinant ~= 1)  %%TODO: Check
            %enforce orthonormality of eigenvector matrix
            [q,r] = Orthogonalisation(EigAprioriVectors);
            eigVectorMatrix = q;
        %end
    end
    EigVectorsMean = eigVectorMatrix;
    
    % sort the variances in decreasing order
    [~, rindices1] = sort(-1*ss);
    VCdiag1 = ss(rindices1);
    PCs = V(:,rindices1);   %sorted PCs of original eigenvectors
    
    [o,p] = size(EigVectorsMean);
    signs = ones(o, p); 
    signs = -1 * signs;
    EigVectorsMean = signs .* EigVectorsMean;
       
    origValidDofsInLine = ValidDofsInLine;  %copy original values
    
    coefficient = EigVectorsMean; %Replace all Apriori PCs
    
    %obtain the standardised or adjusted data
    Ds = origValidDofsInLine - repmat(MeanDofsLn,nTempValidCases,1); 
    
    %data is projected onto the eigenvectors matrix obtained through PCA, 
    %getting the coordinates p in the eigenspace:
    p = coefficient' * Ds'; 
    
    %coordinates multiplied by the original basis, representing an approximation 
    %of the original adjusted data
    b = coefficient * p;
    
    %there is part of the original data that is not represented by these 
    %coordinates, and this is the residual:
    r = Ds - b';

    %Finally, to get the approximation of the original shape, and the 
    %residual shape, we add it to the mean of the original data. 
    Dprime = b' + repmat(MeanDofsLn,nTempValidCases,1); %approx data
    R = r + repmat(MeanDofsLn,nTempValidCases,1);       %residual shape
    
    resi = origValidDofsInLine - Dprime; %this is the same as r
    %or can also calculate residuas as:
    %resi2 = Ds + repmat(MeanDofsLn,nTempValidCases,1) - (b' + repmat(MeanDofsLn,nTempValidCases,1));
   
    %TODO: Should we use correlation matrix? ValidDofsInLine includes
    %derivatives and vertex positions in the same matrix
    
    if(bPerformResidualPCA)    
    %%PCA based on residuals, overwrite V, ss, and CHmean

        reconstructedDataTranspose = R; %r = for residuals
        meanReconstructedData = mean(reconstructedDataTranspose,1);
        DofsMeanShapeReconst = reshape(meanReconstructedData, nModelDofs(1), nModelDofs(2));
        MeanDofsLn = reshape(DofsMeanShapeReconst,1,prod(nModelDofs));
        MatrixDofsWithoutMean = reconstructedDataTranspose - repmat(MeanDofsLn,nValidCases,1);
        BPCs = MatrixDofsWithoutMean;
        COVPCs = BPCs'*BPCs/nValidCases;
        fprintf('Eigenanalysis of A-priori covariance matrix of size %ix%i after residuals\n',size(COVPCs));
        [V,SSPCs] = eig(COVPCs);
        ss = diag(SSPCs);

        fprintf('Saving Covariance and STD from A-priori Pincipal Components\n');
        save([OutputDirectory AprioriAtlasFileName],'V','ss','CHmean');
        
        ScoresInEigenspace = origValidDofsInLine(:,:)*coefficient(:,:); %scores of 3 PCs       
    end       
    
    PCAResidualsFileName = 'PCAShapeResiduals';
    save([OutputDirectory PCAResidualsFileName],'LVCaseNumber','p','PCs','Ds','EigVectorsMean','nValidCases','BPCs');
    
    %Call classification script
        
    if(bPerformPCAClassification)
        CallPCAClassification( OutputDirectory );
    end
    
end


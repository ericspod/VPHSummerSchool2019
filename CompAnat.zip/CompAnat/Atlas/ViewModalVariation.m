function [HT] = ViewModalVariation(directory,iEig,nStd,options)
% Generate the extreme change in the meshes accordingly to a direction of
% anatomical change.
%
% Version control
% - 16/05/2015: possibility of using a given "Eigenvector" and an
% estimation of its variance by its "STD" directly
% - 16/05/2015: possibility of using a given "Eigenvector" and an
% estimation of its variance by its "STD" directly

ss = [];
AtlasSurname = '';
AtlasFileName = 'Atlas.mat';
bCaptionAverage = 0;
bGetGeoMetrics = 0;
bGivenEigenvector = 0;
bOverlayExtremes = 0;
bAutomaticExit =1;
bFlipAxis = 0;
colourscheme = 2; % Another good option is 10, blue and gold.
DofsOrder = 1;

bViewThickness= 0;
    ThicknessViewOption = 2;
    bGrouped = 1;
    MinThickness = 5;
    MaxThickness = 15;
b3Dmeshes = 1;

bExitAfterFirstRender = 0;

Mvertical = [];
bSmallCaption =1;
bMovie = 0;
    ZoomFactor = 8;
    
OutputDir = fullfile(directory,'Modes');

% For the Bull's eye
bDiff = 0;

if nargin==4
    if isfield(options,'STD'),   
        STD = options.STD;    
        bGivenEigenvector = 1;
    end
    if isfield(options,'OutputDir'), OutputDir = options.OutputDir; end
    if isfield(options,'GivenEigenVector'),   
        GivenEigenVector = options.GivenEigenVector;   
        bGivenEigenvector = 1;
    end    
    if isfield(options,'bAutomaticExit'),     bAutomaticExit = options.bAutomaticExit;    end
    if isfield(options,'bSmallCaption'),      bSmallCaption = options.bSmallCaption;    end
    if isfield(options,'bOverlayExtremes'),     bOverlayExtremes = options.bOverlayExtremes;    end
    if isfield(options,'bCaptionAverage'),      bCaptionAverage = options.bCaptionAverage;  end
    if isfield(options,'bMovie'),               bMovie = options.bMovie;                    end
    if isfield(options,'ZoomFactor'),           ZoomFactor = options.ZoomFactor;            end
    if isfield(options,'MovieDir'), 
        OutputDir = options.MovieDir;
        bMovie = 1;
    end
    if isfield(options,'CaptionName'),          CaptionName = options.CaptionName;          end
    if isfield(options,'AtlasFileName'),        AtlasFileName = options.AtlasFileName;      end
    if isfield(options,'AtlasSurname'),         AtlasSurname = options.AtlasSurname;        end
    if isfield(options,'iSeptumNode'),          iSeptumNode = options.iSeptumNode;          end
    if isfield(options,'iNodeSecondAxis'), 
        iP = 1;
        opt.NodesColors(iP,1) = options.iNodeSecondAxis;
        opt.NodesColors(iP,2) = 1;  % codifies green color
    end
    if isfield(options,'bGetGeoMetrics'),       bGetGeoMetrics = options.bGetGeoMetrics;    end
    if isfield(options,'Mvertical'),            Mvertical = options.Mvertical;              end  
    if isfield(options,'orthoFRONT'),           opt.orthoFRONT = options.orthoFRONT;        end
    if isfield(options,'EP'),                   opt.EP = options.EP;        end
    if isfield(options,'IP'),                   opt.IP = options.IP;        end    
    if isfield(options,'HeartVisualizationStyle'), opt.HeartVisualizationStyle = options.HeartVisualizationStyle; end
    if isfield(options,'bDeleteLines'),         opt.bDeleteLines = options.bDeleteLines; end
    
    if isfield(options,'Dofs4stats'),           Dofs4stats = options.Dofs4stats;          end
    if isfield(options,'DofsOrder'),            DofsOrder = options.DofsOrder;          end
    if isfield(options,'bEpiOnly'),           	opt.bEpiOnly = options.bEpiOnly;          end
    if isfield(options,'bFlipAxis'),           	bFlipAxis = options.bFlipAxis;          end    
    if isfield(options,'DofWeights'),           DofWeights = options.DofWeights;          end    
    if isfield(options,'colourscheme'),         colourscheme = options.colourscheme;          end    
    if isfield(options,'bViewThickness'),       bViewThickness = options.bViewThickness;          end    
    if isfield(options,'b3Dmeshes'),            b3Dmeshes = options.b3Dmeshes;          end  
    if isfield(options,'bDiff'),                bDiff = options.bDiff;          end    
    if ~isfield(options,'MinThickness'),        options.MinThickness = MinThickness; end
    if ~isfield(options,'MaxThickness'),        options.MaxThickness = MaxThickness; end
end

if ~exist(OutputDir,'dir')
    fprintf('Creating directory %s\n',OutputDir);
    mkdir(OutputDir);
end
% This loads CHmean:
load(fullfile(directory, AtlasFileName));
nDofs = size(CHmean.GetDofs());

if(bGivenEigenvector)
    if ~exist('STD','var')
        fprintf('ERROR! not possible to view modal variation, no STD of the eigenvector introduced\n');
        return;
    end
    if ~exist('GivenEigenVector','var')
        fprintf('ERROR! not possible to view modal variation, no Eigenvector introduced\n');
        return;
    end
    fprintf(' Generating modal variation with STD (from input) = %1.2f; nStd = %1.0f.\n',STD,nStd);
    S1 = nStd*STD;
    % This is going to be used to compute a new mesh instance, dofs are
    % thus ordered accordingly to (nDofsPerCoorField, 3): 
    nDofsEV = nDofs;
    if exist('Dofs4stats','var')
        % The eigenvector built in the  LDA is ordered the other way
        % around:
        nDofsEV(1) = numel(Dofs4stats);
        nDofsEV(2) = 3;
    end        
    eigenvector = reshape(GivenEigenVector,nDofsEV(1),nDofsEV(2));
    iEig = 0;
else
    STD = sqrt(ss(end-iEig+1));
    if STD == 0
        fprintf(' ERROR! Null eigenvalue retrieved - null modal variation\n');
    else
        fprintf(' Generating modal variation with STD (from eigenvalue) = %1.2f; nStd = %1.0f.\n',STD,nStd);
        S1 = nStd*STD;
    %S1 = 90.533882390814400;%nStd*sqrt(ss(end-iEig+1));
        nDofs2retrieve = nDofs;
        if exist('Dofs4stats','var')
            nDofs2retrieve(1) = numel(Dofs4stats);
        end
        eigenvector = GetVector(iEig,V,nDofs2retrieve);
    end
end

if exist('Dofs4stats','var')
    % The rest of the elements of the original average mesh are null:
    eig = zeros(nDofs);
    eig(Dofs4stats,:) = eigenvector;
    eigenvector = eig;
end

ModEigPreWeighting = sqrt(sum(eigenvector(:).^2));
if exist('DofWeights','var')
    DofWeights = reshape(DofWeights,nDofs(1),nDofs(2));
    eigenvector = eigenvector./DofWeights;
end

if(bFlipAxis)
    S1 = -S1;
end
S2 = -S1;

    

ModEig = sqrt(sum(eigenvector(:).^2));
fprintf('Eigenvalue*nStd = %1.3f. Eigenvector with module = %1.5f (MUST BE 1!); after weighting, module = %1.5f,\n',abs(S1),ModEigPreWeighting,ModEig);

opt.ColorCH1 = GetAtlasColor(1,2);
[namePos,PosM] = ExportModalMesh(OutputDir,CHmean,eigenvector,S1,iEig,bGetGeoMetrics,Mvertical,DofsOrder);
[nameNeg,NegM] = ExportModalMesh(OutputDir,CHmean,eigenvector,S2,iEig,bGetGeoMetrics,Mvertical,DofsOrder);


if exist('CaptionName','var')
    opt.CaptionName = CaptionName;
else
    opt.CaptionName = sprintf('Atlas%sMode%i',AtlasSurname,iEig);
end

HT = NaN;
if(bViewThickness)
    switch ThicknessViewOption
        case 1 % Initial approximate segmental way:
            HT = figure('color',[1 1 1],'OuterPosition',[100 100 1000 500]);
            subplot(131)
            if(bDiff)
                strmean= '';
                options.Difference2mesh = CHmean;
            else
                strmean = 'Average';
                options = [];
            end
            WallThicknessMeshDisplay( NegM , iSeptumNode , options)
            title(sprintf('%s-%istd',strmean,nStd))
            subplot(132)
            WallThicknessMeshDisplay( CHmean , iSeptumNode)
            title('Average')
            subplot(133)
            WallThicknessMeshDisplay( PosM , iSeptumNode , options)
            title(sprintf('%s+%istd',strmean,nStd))
        case 2
            % Each extreme individually:
            if ~exist('options','var')
                options = [];
            end
            if (bGrouped)
                options.bNewFig = 1;
                options.nRows = 3;
                options.iRow = 1;
                options.bColumn = 1;
            end
            Hn = BullsEye(NegM,options);
            if (bGrouped)
                options.bNewFig = 0;
                options.iRow = 2;
            end
            Hm = BullsEye(CHmean,options);
            if (bGrouped)
                options.iRow = 3;
            end
            Hp = BullsEye(PosM,options);
            if (bGrouped), HT = Hn;
            else           HT = [Hn Hm Hp]; end
    end
    for ii = 1:numel(HT)
        switch ii
            case 1, if numel(HT)==1, name = ''; else name = 'Neg'; end
            case 2, name = 'Mean';
            case 3, name = 'Pos';
        end
        name = [ name sprintf('%1.1fStd',nStd) ];
        export_fig(fullfile(OutputDir,sprintf('Thickness_%s_%s',opt.CaptionName,name)),'-png','-m2',HT(ii));
    end
end   

if(bMovie)
    if exist('CaptionName','var')
        opt.CaptionName = CaptionName;
    else
        opt.CaptionName = sprintf('MovieAtlas%sMode%iStd%1.2f',AtlasSurname,iEig,S);   
    end
else 
    if exist('CaptionName','var')
        opt.CaptionName = CaptionName;
    else
        %opt.CaptionName = sprintf('Atlas%sMode%iMean',AtlasSurname,iEig);  
        opt.ColorCH1 = GetAtlasColor(2,2);
        opt.CaptionName = sprintf('Atlas%sMode%iPositive',AtlasSurname,iEig);
    end
end

if b3Dmeshes
    opt.bOrthographic = 1;
    opt.ViewAngle = 35;
    opt.bAutomaticExit = bAutomaticExit;

    opt.bSmallCaption = bSmallCaption;
    opt.ZoomFactor = ZoomFactor;

    if ~isempty(Mvertical)
        CHmean = CHmean.rotateMesh(Mvertical);
    end
    currentDir = pwd;
    cd(OutputDir);

    CHmean = CHmean.SetName('mean2visualise');
    CHmean.WriteExFiles('./');
    % Update where the data is now:
    CHmean.DataDir = './';

    if ~exist([CHmean.name '.exelem'],'file')
        wait(1);
    end

    if(bCaptionAverage)
        % Generate a caption with the average mesh:
        opt.CaptionName = sprintf('Atlas%sMode%iMean',AtlasSurname,iEig);
        cmGuiViewMesh('./',CHmean,opt);
        opt.ColorCH1 = GetAtlasColor(2,2);
    end

    % The second mesh to render is the mean, with the color of the mean:
    opt.CH2 = CHmean;
    opt.ColorCH2 = GetAtlasColor(1,2);
    if(bMovie)
        % Scale the color in intermediate steps:
        opt.ColorCH1 = GetAtlasColor(4,2,nStd);
        opt.CH2RenderStyle = 'render_wireframe';
        bExitAfterFirstRender = 1;
        % Fix the view point, the zoom:
        opt.IP = CHmean.GetMeshCentre();
        opt.EP = opt.IP - ZoomFactor*[0 0 CHmean.BB(5)];
        opt.UP = [opt.IP(1:2) 1];
    end
    if(bOverlayExtremes)
        % Colour of one extreme, for namePos:
        opt.ColorCH1 = GetAtlasColor(2,colourscheme);
        % Colour of other extreme, for nameNeg:
        opt.ColorCH2 = GetAtlasColor(3,colourscheme);
        opt.CH2 = nameNeg;
        if ~isfield(options,'CaptionName')
            % if no "forced name" given in the parameters:
            opt.CaptionName = sprintf('Atlas%sMode%iExtremes',AtlasSurname,iEig);
        end
        bExitAfterFirstRender = 1;
    end

    cmGuiViewMesh('./',namePos,opt);

    if(bExitAfterFirstRender)
        cd(currentDir);
        return;
    end

    %opt.CHmodePositive = '';
    %opt.CHmodeNegative = nameNeg;
    opt.CH2 = CHmean;
    opt.ColorCH1 = GetAtlasColor(3,2);
    opt.ColorCH2 = GetAtlasColor(1,2);
    opt.CaptionName = sprintf('Atlas%sMode%iNegative',AtlasSurname,iEig);
    cmGuiViewMesh('./',nameNeg,opt);
    cd(currentDir);
end

function [name,CH,metrics] = ExportModalMesh(OutputDirectory,CHmean,eigenvector,S,iV,bGetGeoMetrics,Mvertical,DofsOrder)
% Function to export a modal variation of an average mesh. The eigenvectors
% are contained in the matrix V, in an inverted order of importance, iV
% indicates which mode is taken (firs, second, etc), and S is the scale
% applied to the eigenvector.

CH = GetModalShape(CHmean,eigenvector,S,DofsOrder);
% cmGui does not like names with '-'!
if sign(S)==-1
    sig = 'n';
else
    sig = '';
end
name = [CHmean.name sprintf('Eigen%iScale%s%i',iV,sig,abs(int16(S)))];
if ~isempty(Mvertical)
    % Reorient mesh accordingly to the orientation matrix introduced as
    % parameter (meant to be the one that reorients vertically):
    CH = CH.rotateMesh(Mvertical);
end
CH.name = name;
CH.GroupName = name;
% CH.InterpolationBasis = 1; %GGG
CH.WriteExFiles(OutputDirectory);
if(bGetGeoMetrics)
    optGeo.fileOut = sprintf('GeoMetricsMode%i%s.txt',iV,sig);
    metrics = GetLVgeometricMetrics(CH,optGeo);
end





function [X,Y,T,AUC,OPTROCPT] = ComputeROC(labels,scores,option)
% The AUC of the Receiver Operator Curve can be computed either from the
% discrete samples, or from building a discriminant model 

DefaultOption = 0;
bDebug = 1;

if nargin<3
    option = DefaultOption;
end

if iscell(labels)
    UniqueLab = unique(cell2mat(labels));
else
    UniqueLab = unique(labels);
end
if numel(UniqueLab) ~= 2
    fprintf(' ERROR! labels introduced are more than 2!\n');
    return;
end

if iscell(labels)
    iNanLabel = find(isnan(cell2mat(labels)));
else
    iNanLabel = find(isnan(labels));
end
if numel(iNanLabel)>0
    fprintf(' WARNING! %i labels were NaN in the computation of ROC\n',numel(iNanLabel));
end
if iscell(labels)
    iNanScore = find(isnan(cell2mat(scores)));
else
    iNanScore = find(isnan(scores));
end
if numel(iNanScore)>0
    fprintf(' WARNING! %i scores were NaN in the computation of ROC\n',numel(iNanScore));
end
iNaN = [iNanLabel iNanScore];
scores(iNaN) = [];
labels(iNaN) = [];

switch option
    case 0
        % By discrete samples
        [X,Y,T,AUC,OPTROCPT] = perfcurve(labels,scores,UniqueLab(1));
        if AUC(1)<0.5
            [X,Y,T,AUC,OPTROCPT] = perfcurve(labels,scores,UniqueLab(2));
        end
    otherwise
        % Classification analysis: build a discriminant model
        if iscell( labels(1) )
            % Need to convert numeric to string:            
            Var2Predict =    cell2mat(labels)   ;            
        else
            Var2Predict = labels;
        end
%         Var2Predict = Var2Predict - min(Var2Predict);
%         Var2Predict = logical(Var2Predict);
%         UniqueLab = unique(Var2Predict);
        if iscell( scores(1) )
            % Need to convert numeric to string:            
            Predictor =    cell2mat(scores)   ;            
        else
            Predictor = scores;
        end
        % The fitting should have the array in a single column!
        Predictor = reshape(Predictor,numel(Predictor),1);
        clas = fitcdiscr(Predictor,Var2Predict,...
                'DiscrimType','linear');

        % use posteriors as new predictors and compute AUC
        [~,CVpost1] = kfoldPredict(crossval(clas,'leaveout','on'));        
        %[~,RSpost] = resubPredict(clas);
        
        [X,Y,T,AUC,OPTROCPT] = perfcurve(Var2Predict, CVpost1(:,2), UniqueLab(2));
        if AUC<0.5
            fprintf('WARNING! auc<0.5 not expected from a-posteriori probability\n');
            [X,Y,T,AUC,OPTROCPT] = perfcurve(Var2Predict, CVpost1(:,2), UniqueLab(1));
        end
        
        bUnderstandProcess = 0;

        if bUnderstandProcess
            [~,CVpost2] = kfoldPredict(crossval(clas,'KFold',10));
            [X,Y,T,AUC12,OPTROCPT] = perfcurve(Var2Predict, CVpost2(:,2), UniqueLab(2));
            if AUC12<0.5
                fprintf('WARNING! auc<0.5 not expected from a-posteriori probability\n');
                [X,Y,T,AUC12,OPTROCPT] = perfcurve(Var2Predict, CVpost2(:,2), UniqueLab(1));
            end
            for ii = 1:2
                switch ii
                    case 1, CVpost = CVpost1; str = 'leaveout'; AUC = AUC;
                    case 2, CVpost = CVpost2; str = 'KFold'; AUC = AUC12;
                end
               % For discriminant analysis, the score of a classification is 
               % the posterior probability of the classification. 
               figure('color',[1 1 1]);
               subplot(121)
                   % posteriory probability of Predictor being class 1 or class 2
                   % plot(Predictor,CVpost(:,1),'*b'); hold on;
                   iPos = Var2Predict== UniqueLab(1);
                   iNeg = Var2Predict== UniqueLab(2);
                   plot(Predictor(iPos),CVpost(iPos,2),'*r'); hold on;
                   plot(Predictor(iNeg),CVpost(iNeg,2),'*b'); 
                   xlabel('Predictor (shape score)'); ylabel('A posteriori Probability (class 2)')
                   %legend('Class 1','Class 2')
                   title(sprintf('AUC = %1.3f (%s)',AUC,str));
                   axis([min(Predictor) max(Predictor) 0 1]);
               subplot(222)
               plot(Predictor(iPos),Var2Predict(iPos),'*r'); hold on;
               plot(Predictor(iNeg),Var2Predict(iNeg),'*b');
               xlabel('Predictor (shape score)'); ylabel('Label to predict');
               subplot(224)
               plot(CVpost(:,2),Var2Predict,'*');
               xlabel('Predictor (a posteriori prob of class 2)'); ylabel('Label to predict');
            end
           a=1;
        end
        
        if bDebug
            [~,~,~,AUC2] = perfcurve(labels,scores,UniqueLab(1));
            if AUC2(1)<0.5
                [~,~,~,AUC2] = perfcurve(labels,scores,UniqueLab(2));
            end
            fprintf('Differences in AUC = %f (AUCmodel = %f, AUCdiscrete = %f\n',AUC-AUC2(1),AUC,AUC2(1));
        end
end

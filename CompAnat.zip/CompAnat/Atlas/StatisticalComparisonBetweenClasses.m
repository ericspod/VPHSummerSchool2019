function [Hstat] = StatisticalComparisonBetweenClasses(coefficients,options)
% Function to compute the T-test or Hotelling T2 statistical tests in the
% set of coefficients of a given population
%
% INPUT:
% - coefficients: shape descriptors per each case
% - ClassDefinition: structure with the information of classes
%

%==========================================================================
% Default options:
    cmpC = [];
    % Significance of the test, 5%, 1%...
    significance = 0.01;
    % Boolean: paired or not paired samples:
    bPairedTest = 0;
    % Boolean: make the T-test:
    bIndividualTtest = 1;
        % Number of coordinates to analyse:
        nCoefsMax2IncludeT = 15;
    % Boolean: make the HotellingT2:
    bHotellingT2 = 0;
        %HotDims = 1:1000;
        HotDims = [5 4 3 2 6];
        nCoefsMax2IncludeH = 2;
    % Boolean: make power calculations
    bPowerCalculations = 0;
    % Boolean: make Bonferroni Correction
    bBonferroniCorrection = 0;
    
    StringStudy = '';
    
    Fsize = 12;
    Font = 'Arial';
%==========================================================================

    if nargin>=2
        if isfield(options,'cmpC'),             cmpC = options.cmpC; end
        if isfield(options,'bIndividualTtest'), bIndividualTtest = options.bIndividualTtest; end
        if isfield(options,'bPairedTest'),      bPairedTest = options.bPairedTest; end
        if isfield(options,'bHotellingT2'),     bHotellingT2 = options.bHotellingT2; end
        if isfield(options,'nCoefsMax2IncludeT'), nCoefsMax2IncludeT = options.nCoefsMax2IncludeT; end
        if isfield(options,'nCoefsMax2IncludeH'), nCoefsMax2IncludeH = options.nCoefsMax2IncludeH; end
        if isfield(options,'significance'),     significance = options.significance; end
        % Two optional arguments that are needed if the subgroups are not
        % provided:
        if isfield(options,'ClassDefinition'),  ClassDefinition = options.ClassDefinition; end
        if isfield(options,'ListCases'),        ListCases = options.ListCases; end
        if isfield(options,'StringStudy'),      StringStudy = options.StringStudy; end       
        if isfield(options,'bBonferroniCorrection'),      bBonferroniCorrection = options.bBonferroniCorrection; end     
        if isfield(options,'Legend'),       
            % Strings with the description of the two groups under study
            strCl1 = options.Legend{1};
            strCl2 = options.Legend{2};
        end
    end

    nClasses = numel(ClassDefinition);
    if isempty(cmpC)
        % Generate all possible comparisons accordingly to the number of
        % classes:
        
        i = 0;
        for iC1 = 1:nClasses-1
            for iC2 = iC1+1:nClasses
                i = i+1;
                cmpC(i,:) = [iC1 iC2];
            end
        end
    end
    if nClasses<=1
        fprintf(' ERROR! Not enough number of classes loaded\n');
        return;
    end
    nComparisons = size(cmpC,1);
    nRowsPlot = ceil(nComparisons/4);
    nColumns  = ceil(nComparisons/nRowsPlot);
    Hstat = figure('color',[1 1 1],'OuterPosition',[100 100 100+250*nColumns 100+150*(nRowsPlot+1)]);
    for iComparison = 1:nComparisons
        Class1 = cmpC(iComparison,1);
        Class2 = cmpC(iComparison,2);
        if(bIndividualTtest)
            YString = 'P-value (t-test)';
            iCoefs = 1:nCoefsMax2IncludeT;
            Hcoefs = zeros(1,numel(iCoefs));
            Pcoefs = zeros(1,numel(iCoefs));
            for iC = iCoefs
                if iscell(coefficients)
                    % The two groups are already provided:
                    Coefs1 = coefficients{Class1};
                    Coefs2 = coefficients{Class2};
                    Group1 = Coefs1(iC,:);
                    Group2 = Coefs2(iC,:);
                else
                    I1 = GetIndexesPerClass(ClassDefinition,Class1,ListCases);
                    Group1 = coefficients(iC,I1);
                    I2 = GetIndexesPerClass(ClassDefinition,Class2,ListCases);
                    Group2 = coefficients(iC,I2);
                end
                % Remove the NaNs:
                Group1 = Group1(~isnan(Group1));
                Group2 = Group2(~isnan(Group2));
                nC1 = numel(Group1);
                nC2 = numel(Group2);
                bTestDone = 0;
                if bPairedTest
                    % check same number of valid samples:
                    if nC1~=nC2
                        fprintf('ERROR! Not same number of valid samples in each group for a paired test!\n')
                        fprintf('  ... reverting to a non paired test\n');
                    else
                        [h,p] = ttest(Group1,Group2);
                        bTestDone = 1;
                    end
                end
                if(~bTestDone)
                    [h,p] = ttest2(Group1,Group2);
                end
                Hcoefs(iC) = h;
                Pcoefs(iC) = p;
                if(bPowerCalculations)
                    testtype = 't';
                    p0 = [mean(Group1) std(Group1)];
                    p1 = mean(Group2);
                    beta = 0.8;
                    alpha = 0.005;
                    sampleSize = 150;
                    signal(iC) = abs(p1 - p0(1));
                    noise(iC) = p0(2);
                    nPower(iC) = sampsizepwr(testtype,p0,p1,beta,[],'alpha',alpha,'tail','both');
                    PowerWithGivenSize(iC) = sampsizepwr(testtype,p0,p1,[],sampleSize,'tail','both','alpha',alpha);
                end
            end
        end
        if(bHotellingT2)   
            YString = 'P-value of two-sample HotellingT2 - independent'; 
            Pcoefs = ones(1,numel(nCoefsMax2IncludeH)); 
            for LastCoeff = 2:nCoefsMax2IncludeH
                iCoefsHot =  HotDims(1:LastCoeff);    
                fprintf('Hotelling T2 test with coordinates: ');
                fprintf('%i, ',iCoefsHot);
                fprintf('\n')   
                % iCoefsHot = [1 2 7 10];
                % Build the matrix of data: add a '1' or '2' in front of each
                % sample, and assemble per rows in a big matrix:
                nCoefs = numel(iCoefsHot);        
                iClass1 = GetIndexesPerClass(ClassDefinition,Class1,ListCases);
                nC1 = numel(iClass1);
                iClass2 = GetIndexesPerClass(ClassDefinition,Class2,ListCases);
                nC2 = numel(iClass2);
                X(2:nCoefs+1,1:nC1) = coefficients(iCoefsHot,iClass1);
                X(1,1:nC1) = 1;
                X(2:nCoefs+1,nC1+1:nC1+nC2) = coefficients(iCoefsHot,GetIndexesPerClass(ClassDefinition,Class2,ListCases));
                X(1,nC1+1:nC1+nC2) = 2;
                %Hresults = HotellingT2(X',significance);
                Hresults = T2Hot2iho(X',significance);
                Pcoefs(LastCoeff) = Hresults.P;
            end        
            iCoefs = 2:LastCoeff;
        end
        if(bBonferroniCorrection)
            Pcoefs = Pcoefs * numel(iCoefs);
            Pcoefs(Pcoefs>1) = 1;
        end
        subplot(nRowsPlot,nColumns,iComparison,'FontSize',Fsize)
        semilogy(Pcoefs,'*','MarkerSize',8,'LineWidth',1.2); hold on;        
        semilogy([0 max(iCoefs)+1],[significance significance],'r');
        set(gca,'YDir','reverse')
        %title(sprintf('Class %i vs class %i',Class1,Class2)); 
        xlabel('Mode'); ylabel(YString)
        MinY = 10^-3;
        if min(Pcoefs)<MinY
            MinY = 0.8*min(Pcoefs);
        end
        axis([0 numel(iCoefs)+1 MinY 1]);
        if ~exist('strCl1','var'), TstrCl1 = sprintf('%i',Class1); else TstrCl1 = strCl1; end;
        if ~exist('strCl2','var'), TstrCl2 = sprintf('%i',Class2); else TstrCl2 = strCl2; end;
        
        title(sprintf('%s %s(n=%i) vs %s(n=%i)',StringStudy,TstrCl1,nC1,TstrCl2,nC2));
    end
    set(findall(Hstat,'type','text'),'FontName',Font,'FontSize',Fsize)    
    
        if(bPowerCalculations)
            ratio = signal./noise;
            for nS = 1:10
                Msignal(nS) = mean(signal(1:nS));
                Mnoise(nS) = mean(noise(1:nS));
                Mratio(nS) = mean(ratio(1:nS));
            end
            figure('color',[1 1 1]);
            subplot(221)
            plot(nPower);
            xlabel('coefficient number')
            ylabel(sprintf('N for beta %1.2f, alpha %1.3f',beta,alpha))
            subplot(222)
            plot(PowerWithGivenSize);
            xlabel('coefficient number')
            ylabel(sprintf('Power with N=%i',sampleSize))
            subplot(234)
            plot(signal);
            hold on; plot(Msignal,'r');
            xlabel('coefficient number')
            ylabel('Signal (average difference)')
            subplot(235)
            plot(noise);
            hold on; plot(Mnoise,'r');
            xlabel('coefficient number')
            ylabel('Noise (std in group 1)')
            subplot(236)
            plot(ratio);
            hold on; plot(Mratio,'r');
            xlabel('coefficient number')
            ylabel('Signal/Noise')
        end

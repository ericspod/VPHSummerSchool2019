function [mesh] = GetMeshFromID(DataDir,ID)
% Function to get the mesh with a given ID from the atlas data structure

% List the names of directories in the Data Directory (one per case):
cases = dir(DataDir);
nFolders = numel(cases);

bFound = 0;
iC = 0;
while ~bFound && iC<nFolders
    iC = iC + 1;
    ID2 = GetIDfromName(cases(iC).name);
    if ID2 == ID
        bFound = 1;
        CaseDir = fullfile(DataDir,cases(iC).name);
        MeshRoot = fullfile(CaseDir,'Output_heartgen');
        EXnode = ls([MeshRoot '\*_mesh.exnode']);
        EXelem = ls([MeshRoot '\*_mesh.exelem']);
        mesh = CubicMeshClass(fullfile(MeshRoot,EXnode),fullfile(MeshRoot,EXelem));               
        return;
    end
end

fprintf('WARNING! Case with ID %i not found in %s\n',ID,DataDir);

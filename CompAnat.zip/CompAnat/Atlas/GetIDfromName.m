function [ID,postIDstring,preIDstring] = GetIDfromName(name,options)
% Function to retrieve the numeric of a name ending in an unknown number of
% digits.
%
% Version control
% - v2 (24 jan 2018): the ID takes all digits in a string, and concatenates
% them in a single integer
% - the original version assumed that the case ID, or mesh ID, only had
% the numeric data at the end of the string of the folder name. 
%
% TODO: prompt out the post and pre ID fields!

    bAllDigits = 1;
    bNotEnd = 0;
    ID = 0; II = 0;    
    bOneDigitHit = 0;
    postIDstring = '';
    preIDstring = '';
    nDigits = 0;
    
    if nargin>=2
        if isfield(options,'bNotEnd'), bNotEnd = options.bNotEnd; end
        if isfield(options,'bAllDigits'), bAllDigits = options.bAllDigits; end
    end
    
    nChars = numel(name);
    bDigit = zeros(1,nChars);
    for In = numel(name):-1:1                    
        character = name(In);        
        if character>='0' && character<='9'
            % This is a digit:
            nDigits = nDigits + 1;
            digits(nDigits) = str2num(character);
            bDigit(In) = 1;
        end
    end
    
    % build the integer number:
    ID = 0;
    % default option: use all digits:
    iD = 1:nDigits;
    ExponentOffset = 0;
    if ~bAllDigits
        % We take the first or the last digits:
        I  = find(bDigit);           % which characters are indexes
        I2 = I(2:end) - I(1:end-1);  % the difference between two digits
        I3 = 1 + find(I2>1);            % which digits are not consecutive
        if bNotEnd
            % We take the last joint group of digits
            iD = I3(end):nDigits;
            ExponentOffset = I3(end);
        else
            % We take the first digits
            iD = 1:I3(1);
        end
    end
   
    for i = iD
       ID = ID + digits(i) * 10^(i-1-ExponentOffset);
    end
end
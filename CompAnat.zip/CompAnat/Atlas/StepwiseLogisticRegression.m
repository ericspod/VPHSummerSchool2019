function [b,dev,st,in] = StepwiseLogisticRegression(x,Var2Predict,distribution)
    % Use sequential feature selection to order the features according to how
    % much they contribute to the model
    
    if nargin<3
        distribution = 'binomial';
    end
    
    % Number of predictors:
    m = size(x,2);
    
    maxdev = chi2inv(.95,1); 
    opt = statset('display','iter','TolFun',maxdev,'TolTypeFun','abs');
    [in,history] = sequentialfs(@fitter2,x,Var2Predict,'cv','none',...
        'nullmodel',true,'opt',opt,'direction','f');

    dev = history.Crit; 

    nfeatures = sum(in);
    figure;
    plot((0:nfeatures)',dev,'b-x', nfeatures,dev(nfeatures+1),'ro')
    title('Prediction optimization as more features are added');
    
    [b,dev,st] = glmfit(x(:,in),Var2Predict,distribution);
    
    B = zeros(2,m+1);
    B(1,[true,in]) = b';
    B(2,[true,in]) = st.se';
    disp('Reduced model')
    disp(B)

function dev = fitter2(x,y)
    [b,dev] = glmfit(x,y,'binomial');
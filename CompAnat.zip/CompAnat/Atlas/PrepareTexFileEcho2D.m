function [] = PrepareTexFileEcho2D(TexFile,ValidNames,options)
% A function to prepare the .tex file to load all figures in a single pdf
% file:

% ------------------------------------------------------
% Two captions per case:
nCols = 2;
nCasesPerPage = 3;
if nargin==3
    if isfield(options,'nCasesPerPage'),    nCasesPerPage = options.nCasesPerPage; end    
end

nCases = numel(ValidNames);
if nCases == 0
    fprintf('ERROR! No cases introduced\n');
    return;
end

bLandscape = 0;

% Relative path from where the tex file is, to where the root of cases is:
fid = fopen(TexFile,'w');
if fid==-1
    fprintf('Not possible to create TEX file %s\n',TexFile);
    return
end
fprintf('Preparing TEX file %s\n',TexFile);


width = 1/(nCols);
s='c ';
% One more column for the case number:
for k=1:nCols, s=horzcat(s,{'c '}); end
s=cell2mat(s);

fprintf(fid,'\\documentclass[a4paper]{article}\n');
fprintf(fid,'\\usepackage{morefloats}\n');
fprintf(fid,'\\usepackage{graphicx}\n');
fprintf(fid,'\\usepackage{multirow}\n');
fprintf(fid,'\\usepackage{color}\n');
if(bLandscape),     
    fprintf(fid,'\\usepackage[landscape]{geometry}\n'); 
    fprintf(fid,'\\textheight = 450pt\n');
    %fprintf(fid,'\\topmargin = -100pt\n'); 
    %fprintf(fid,'\\oddsidemargin= 0pt\n'); 
    %fprintf(fid,'\\textwidth = 650pt\n'); 
    fprintf(fid,'\\hoffset = -80pt\n'); 
    %fprintf(fid,'\\voffset = -30pt\n'); 
    %fprintf(fid,'\\marginparwidth = 0pt\n'); 
else
    fprintf(fid,'\\topmargin = -40pt\n');
    fprintf(fid,'\\oddsidemargin= 0pt\n');
    fprintf(fid,'\\textwidth = 450pt\n');
    fprintf(fid,'\\textheight = 700pt\n');
end

fprintf(fid,'\\begin{document}\n');

nTables = ceil(nCases/nCasesPerPage);


for iTable=1:nTables
    iCase0 = (iTable-1)*nCasesPerPage + 1;
    iCase1 = iTable*nCasesPerPage;
    if iCase1>nCases
        iCase1 = nCases;
    end
    fprintf(fid,'\n\\begin{table}[ht]\n');
    fprintf(fid,'  \\centering\n');
    
    % A table with a number of columns given by the number of Components:
    fprintf(fid,['  \\begin{tabular}[t]{' s '}\n']);
    for iCase = iCase0:iCase1
        filename = [ValidNames{iCase} '.png'];
        [path name] = GetPath(filename);
        caseID = sscanf(name(5:end),'%i');
        % First column is case number:
        fprintf(fid,'  Case %i &',caseID);
        % Second column is the image saved in the ValidCases variable:
        
        IncludeGraphicsIfExist(fid,filename,width);
        fprintf(fid,' &');
        
        % and now see the 3D mesh:
        Dir3Dmesh = [path sprintf('mesh%i',caseID) '/'];
        name3DmeshImage = ls([Dir3Dmesh 'Image*']);
        IncludeGraphicsIfExist(fid,[Dir3Dmesh name3DmeshImage],width);
        fprintf(fid,'\\\\ \n');
    end    
    fprintf(fid,'  \\end{tabular}\n');
    fprintf(fid,'\\end{table}\n');

end
fprintf(fid,'\\end{document}\n');
fclose(fid);

    
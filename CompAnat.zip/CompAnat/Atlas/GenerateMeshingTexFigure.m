function [] = GenerateMeshingTexFigure(ResultsDir,ResultsName,options)
    
    % Default options:
    nRowsPerPage = 6;
    iHeart0 = 1;
    iHeart1 = 1;
    %DataCohort = 1;
    bCohortIndex  = 0;
    LoDini = 3;
    LoDincrement = 2;
    LoDend = 3;
    SAini = 1;
    SAend = 1;
    version = '';
    subversion = 1;
    bNegJacPoints = 0;
    %bForSim = 0;
    bForSimSmoothed = 0;
    bAccuracy = 0;
    bIndexes = 0;
    JRAtlasVersion = 1;
    bLoDs = 0; 
    bTrunkatedAnatomy = 0;
    OutMeshingDir = 'Output_heartgen';
    
    TexFile = fullfile(ResultsDir,[ ResultsName '.tex']);
    if nargin==3
        if isfield(options,'DataCohort'), 
            DataCohort = options.DataCohort; 
            bCohortIndex = 1;
        end
        if isfield(options,'OutMeshingDir'), OutMeshingDir = options.OutMeshingDir; end
        if isfield(options,'DataDirName'), DataDirName = options.DataDirName; end
        if isfield(options,'nRowsPerPage'), nRowsPerPage = options.nRowsPerPage; end
        if isfield(options,'iHeart0'), iHeart0 = options.iHeart0; end
        if isfield(options,'iHeart1'), iHeart1 = options.iHeart1; end
        if isfield(options,'LoDini'), LoDini = options.LoDini; end
        if isfield(options,'LoDincrement'), LoDincrement = options.LoDincrement; end
        if isfield(options,'LoDend'), LoDend = options.LoDend; end
        if isfield(options,'SAini'), SAini = options.SAini; end
        if isfield(options,'SAend'), SAend = options.SAend; end
        if isfield(options,'version'), version = options.version; end
        if isfield(options,'bNegJacPoints'), bNegJacPoints = options.bNegJacPoints; end
        %if isfield(options,'bForSim'), bForSim = options.bForSim; end
        if isfield(options,'bForSimSmoothed'), bForSimSmoothed = options.bForSimSmoothed; end
        if isfield(options,'bAccuracy'), bAccuracy = options.bAccuracy; end
        if isfield(options,'bIndexes'), bIndexes = options.bIndexes; end
        if isfield(options,'bLoDs'), bLoDs = options.bLoDs; end
        if isfield(options,'bTrunkatedAnatomy'), bTrunkatedAnatomy = options.bTrunkatedAnatomy; end        
        if isfield(options,'JRAtlasVersion'), JRAtlasVersion = options.JRAtlasVersion; end        
        if isfield(options,'subversion'), subversion = options.subversion; end  
    end
    
    if (SAend>1)
        bSAstudy = 1;
    else
        bSAstudy = 0;
    end
    
    nCols = 2  + bNegJacPoints + bAccuracy + bForSimSmoothed;
    LoDs = LoDini:LoDincrement:LoDend;
    nLoDs = numel(LoDs);
    SAs = SAini:1:SAend;
    nSAs  = SAend - SAini + 1;
    if (~bLoDs) 
        if nLoDs >1
            bLoDs = 1;    else        bLoDs = 0;    end
    end
    
    nRowsPerCase = 1 + floor((LoDend-LoDini)/LoDincrement);
    if bSAstudy
        nRowsPerCase = nRowsPerCase + (SAend - SAini);
    end
    
    nCases = iHeart1 - iHeart0 + 1;
    MaxCasesPerFile = 90;
    nTotalRows = nCases*nRowsPerCase;
    if  nTotalRows > MaxCasesPerFile
        % Need to split the output file, otherwise there are too many floats:
        nTexFiles = ceil(nTotalRows/MaxCasesPerFile);
        for iTexFile = 1:nTexFiles
            iH0 = 1 + ((iTexFile - 1) * MaxCasesPerFile)/nRowsPerCase;
            iH1 = iH0 + MaxCasesPerFile/nRowsPerCase - 1;
            if iH1>iHeart1
                iH1 = iHeart1;
            end
            options.iHeart0 = iH0;
            options.iHeart1 = iH1;
            PartialResultsName = [ResultsName 'Part' num2str(iTexFile)];
            GenerateMeshingTexFigure(ResultsDir,PartialResultsName,options);
        end        
        return;
    end
    
    fid = fopen(TexFile,'w');
    if fid==-1
        fprintf('Not possible to create TEX file %s\n',TexFile);
        return
    else
        fprintf('Generating tex file: %s\n',TexFile);
    end
    width = 1/nCols;
    
    
    fprintf(fid,'\\documentclass[a4paper]{article}\n');
    fprintf(fid,'\\usepackage{graphicx}\n');
    fprintf(fid,'\\usepackage{morefloats}\n');
        
    % to allow the use of spaces in the file path:
    fprintf(fid,'\\usepackage{graphicx}\n');
    fprintf(fid,'\\usepackage[space]{grffile}\n');
    
    bLandscape = 0;
    if(bLandscape), 
        nRowsPerPage = 3;
        fprintf(fid,'\\usepackage[landscape]{geometry}\n'); 
        fprintf(fid,'\\textheight = 450pt\n');
        %fprintf(fid,'\\topmargin = -100pt\n'); 
        %fprintf(fid,'\\oddsidemargin= 0pt\n'); 
        %fprintf(fid,'\\textwidth = 650pt\n'); 
        fprintf(fid,'\\hoffset = -80pt\n'); 
        %fprintf(fid,'\\voffset = -30pt\n'); 
        %fprintf(fid,'\\marginparwidth = 0pt\n'); 
    else
        fprintf(fid,'\\topmargin = -40pt\n');
        fprintf(fid,'\\oddsidemargin= 0pt\n');
        fprintf(fid,'\\textwidth = 400pt\n');
        fprintf(fid,'\\textheight = 700pt\n');
    end
    fprintf(fid,'\\begin{document}\n');
    if(bIndexes)
        fprintf(fid,'\\section{Summary of accuracy and quality of cases under study} \n');
        fprintf(fid,'  \\includegraphics[width=1\\textwidth]{%s} \\\\  \n',[ReplaceSlash(ResultsDir) ResultsName '.jpg']);
    end
    fprintf(fid,'\\section{List of cases}\n');
    nCases = iHeart1 - iHeart0 + 1;
    nCasesDescriptionPerPage = 50;
    nTablesDescription = ceil(nCases/nCasesDescriptionPerPage);
    for iTable = 1:nTablesDescription
        iCase0 = iHeart0 + (iTable-1)*nCasesDescriptionPerPage;
        iCase1 = iCase0 + nCasesDescriptionPerPage -1;
        if iCase1>nCases
            iCase1 = iHeart1;
        end
        fprintf(fid,'\\begin{table}[ht]\n');
        fprintf(fid,'  \\centering\n');
        fprintf(fid,['  \\begin{tabular}[t]{c|c|c|c}\n']);
        fprintf(fid,['  Case & Type & Name & Path \\\\ \n']);
        for iHeart=iCase0:iCase1      
            if (bCohortIndex)
                [binary,heartType] = CaseMappingAllCohorts(ResultsDir,DataCohort,iHeart,JRAtlasVersion,subversion,options.SubDirectory,options.BinaryName);     
            else
                heartType = '';
                if ~exist('DataDirName','var')
                    fprintf('ERROR! No DataDirName introduced in options of GenerateMeshingTexFigure\n');
                    return;
                else                    
                    [ binary, output ] = CaseMappingAtlas( DataDirName, iHeart, options);
                    binary = fullfile(output.CaseDirectory ,binary);
                end
            end
            if(~isnan(binary))
                [name,path,extension,decomposedpath] = RemovePathAndExtension(binary);
                if isempty(name) || strcmp(name, binary(end))
                    name = 'Not found';
                end
                % Check if the directory exists:
                if numel(ls(path))>0
                    % Names without underslashes:
                    name1 = removeunderslashes(name);
                    name2 = removeunderslashes(ReplaceSlash(decomposedpath(end).name));
                    fprintf(fid,' %i & %s & $%s$ & $%s$ \\\\ \n',iHeart,heartType,name1,name2);
                end
            end
        end
        fprintf(fid,'  \\end{tabular}\n');        
        fprintf(fid,'\\end{table}\n');
    end
        
    fprintf(fid,'\\section{Caption of results}\n');
    s='c ';
    % One more column for the case number:
    for k=1:nCols, s=horzcat(s,{'c '}); end
    s=cell2mat(s);
    nCases = iHeart1 - iHeart0 + 1;
    Hearts = iHeart0:iHeart1;
    nTables = ceil(nCases*(1 + bLoDs*(nLoDs-1) + bSAstudy*(nSAs-1))/nRowsPerPage);
    SA0 =  1; SA1 = SA0;
    for iTable=1:nTables      
        nPageCase = (nRowsPerPage/nRowsPerCase);
        if nPageCase > 1
            nPageCase = floor(nPageCase);
            iCase0 = (iTable-1)*nPageCase + 1;
            iCase1 = iTable*nPageCase;
        else
            nPagesPerCase  = ceil(nRowsPerCase/nRowsPerPage);
            iCase0 = 1 + floor((iTable-1)/nPagesPerCase);
            iCase1 = iCase0;
            SA0 = 1 + (rem(iTable-1,nPagesPerCase)*nRowsPerPage);
            SA1 = SA0 + nRowsPerPage -1;
            if SA1>nSAs
                SA1 = nSAs;
            end
        end
        if iCase1>nCases
            iCase1 = nCases;
        end
        if nPageCase ==0 
            fprintf('ERROR! Null nPageCase\n');
        end
        fprintf(fid,'\\begin{table}\n');
        fprintf(fid,'  \\centering\n');
        fprintf(fid,['  \\begin{tabular}[t]{' s '}\n']);
        % First column is case number:
        ThirdColumnText = '';
        if bNegJacPoints
            ThirdColumnText = '& Negative Jacobians?';
        end
        FourthColumnText = '';
        if bAccuracy
            FourthColumnText = '& Fitting error (mm)';
        end
        if bForSimSmoothed
            FourthColumnText = '& Simulation mesh smoothed';
        end
            
        fprintf(fid,'  Case & Initialization & Result %s %s \\\\ \n',ThirdColumnText,FourthColumnText);
        for iHeart = Hearts(iCase0):Hearts(iCase1)
            if (bCohortIndex)
                [binary,heartType] = CaseMappingAllCohorts(ResultsDir, DataCohort,iHeart,JRAtlasVersion,subversion,options.SubDirectory,options.BinaryName);     
            else
                if ~exist('DataDirName','var')
                    fprintf('ERROR! No DataDirName introduced in options of GenerateMeshingTexFigure\n');
                    fclose(fid);
                    return;
                else                    
                    [ binary, output ] = CaseMappingAtlas( DataDirName, iHeart, options);
                    if(~isnan(binary))
                        binary = fullfile(output.CaseDirectory,binary);
                    end
                end
            end
            if(~isnan(binary))
                [name,path,extension] = RemovePathAndExtension(binary);
                if(bTrunkatedAnatomy)
                    name = [name 'OLtrunkated'];
                end
                % Check if the directory exists:
                if numel(ls(path))>0
                    for iLoD = LoDs
                        for iSA = SAs(SA0):SAs(SA1)
                            if(bSAstudy)
                                surnameSA = sprintf('SA%i',iSA);
                            else
                                surnameSA = '';
                            end
                            bCheckDirectory = 0;
                            if iscell(OutMeshingDir)
                                for iO = 1:numel(OutMeshingDir)
                                    ODir = fullfile( path , OutMeshingDir{iO} );
                                    if exist(ODir,'dir')
                                        RightOutMeshingDir = OutMeshingDir{iO};
                                        bCheckDirectory = 1;
                                        break
                                    end
                                end
                            else
                                if exist( fullfile(path,OutMeshingDir), 'dir')
                                    bCheckDirectory = 1;
                                    RightOutMeshingDir = OutMeshingDir;
                                end
                            end
                            if (bCheckDirectory)
                                if bLoDs
                                    fprintf(fid,' %iLoD%i%s & \n',iHeart,iLoD,surnameSA);
                                    path2captions = fullfile(path , [RightOutMeshingDir version sprintf('LoD%i/',iLoD) surnameSA '/']);
                                else 
                                    fprintf(fid,' %i%s & \n',iHeart,surnameSA);
                                    path2captions = [path RightOutMeshingDir version surnameSA '/'];
                                    if ~exist(path2captions,'dir')
                                        path2captions = output.MeshDirectory;
                                    end
                                end                            
                                nameInit = fullfile(path2captions ,'Image_Initialization.jpg');
                                if numel(ls(nameInit))>0                            
                                    nameMesh = fullfile(path2captions, sprintf('Image_%s%s_mesh.jpg',name,surnameSA));
                                    IncludeGraphicsIfExist(fid,nameInit,width);
                                    fprintf(fid,' &\n');
                                    bSuccess = IncludeGraphicsIfExist(fid,nameMesh,width,'',0);
                                    if ~bSuccess
                                        % In case it has been generated by a
                                        % nodal warping:
                                        nameMesh = fullfile(path2captions, sprintf('Image_%s%s_mesh_byM3.jpg',name,surnameSA));
                                        bSuccess = IncludeGraphicsIfExist(fid,nameMesh,width);
                                    end
                                    if(bNegJacPoints)
                                        fprintf(fid,' &\n');
                                        nameQuality = fullfile(path2captions, sprintf('ImageSearchBadQuality%s%s_mesh.png',name,surnameSA));
                                        IncludeGraphicsIfExist(fid,nameQuality,width);                    
                                    end   
                                    if(bForSimSmoothed)
                                        fprintf(fid,' &\n');
                                        nameSim = fullfile(path2captions,sprintf('Image%s_mesh_ForSim_smoothed.png',name));
                                        IncludeGraphicsIfExist(fid,nameSim,width);                    
                                    end
                                    if(bAccuracy)
                                        fprintf(fid,' &\n');                                  

                                        ReportFile = [ReplaceSlash(path2captions) sprintf('PersonalizationReport%s%s.txt',name,surnameSA)];
                                        fileVersion = 'newVersion';

                                        %user-defined list of cases with old version of PersonalizationReport.txt
                                        if isfield(options, 'surnameCases')                                                                                
                                            FileIndex = find(options.ListCases(iHeart) == options.surnameCases);
                                            if(FileIndex > 0)
                                                fileVersion = 'oldVersion';
                                            end    
                                        end

                                        [Report,bValid] = ReadPersonalizationReport(ReportFile, fileVersion);
                                        if(bValid), widthAccuracyImage = width * 0.8;
                                        else widthAccuracyImage = width; end

    %                                     nameQuality = [ReplaceSlash(path2captions) 'ImageFittingErrorMesh.png'];
                                        nameQuality = fullfile(path2captions, sprintf('ImageDistances2ClosestPoint%s%s.png',name,surnameSA));
                                        alternativeRootName{1} = fullfile(path2captions, 'ImageDistances2ClosestPoint');
                                        alternativeRootName{2} = fullfile(path, 'ImageDistances2ClosestPoint');
                                        alternativeRootName{3} = fullfile(path2captions, 'ImageFittingErrorMesh');                                        
                                        IncludeGraphicsIfExist(fid,nameQuality,widthAccuracyImage,alternativeRootName);    
                                        if(bValid)
                                            % One more line with this information:
                                            fprintf(fid,'\\\\ \n');
                                            fprintf(fid,' & & & \n');
                                            fprintf(fid,'%1.2f +/- %1.2f (max=%1.2f)',Report.MeanEuclDist,Report.StdEuclDist,Report.MaxEuclDist); 
                                        end                                    
                                    end
                                else
                                    fprintf(fid,'(no init step)\n');
                                end
                            else
                                fprintf(fid,'(no output dir)\n');
                            end
                            fprintf(fid,'\\\\ \n');
                        end
                    end
                end
            end
        end
        fprintf(fid,'  \\end{tabular}\n');       
        fprintf(fid,'\\end{table}\n');
        fprintf(fid, '\\newpage\n');
        
    end

    files = dir(fullfile(ResultsDir, 'ImageAtlasMode*MeanMean.png'));
    modesplotted = numel(files);
    if (modesplotted > 0)
        fprintf(fid, '\\section{Atlas output}\n\n');
        fprintf(fid, '\\subsection{Model variations in shape}\n\n');
        fprintf(fid,'\\begin{table}\n');
        fprintf(fid,'  \\centering\n');
        fprintf(fid,'  \\begin{tabular}[t]{r | c c c}\n');
        fprintf(fid,'  Mode & Average - Mean & Average & Average + Mean \\\\\n');
        fprintf(fid,'\hr\n');
        for i = 1:modesplotted
           fprintf(fid, '%i & \n', i);
           fprintf(fid, '\\includegraphics[width=0.33\\textwidth]{ImageAtlasMode%iNegativeMean.png}&\n', i); 
           fprintf(fid, '\\includegraphics[width=0.33\\textwidth]{ImageAtlasMode%iMeanMean.png}&\n', i); 
          fprintf(fid, '\\includegraphics[width=0.33\\textwidth]{ImageAtlasMode%iPositiveMean.png}\\\\\n', i); 
        end
        fprintf(fid,'  \\end{tabular}\n');       
        fprintf(fid,'\\end{table}\n');
    end

    files = dir(fullfile(ResultsDir, 'IndividualDistributionsStudy*.png'));
    nStudies = numel(files);
    if (nStudies > 0)
        fprintf(fid, '\\subsection{Individual distribution of cases}\n\n');
        fprintf(fid,'\\begin{table}\n');
        fprintf(fid,'  \\centering\n');
        fprintf(fid,'  \\begin{tabular}[t]{r c}\n');
        for i = 1 : nStudies
            fprintf(fid, '%i &\n', i);
            file2include = files(i).name;
            fprintf(fid, '\\includegraphics[width=0.33\\textwidth]{%s}\\\\\n', file2include); 
        end
        fprintf(fid,'  \\end{tabular}\n');       
        fprintf(fid,'\\end{table}\n');
    end

%     files = dir(fullfile(ResultsDir, '*.png'));
%     for i = 3:numel(files)
%        fprintf(fid, '\\includegraphics[width=0.33\\textwidth]{%s}\\\\\n', fullfile(ResultsDir, files(i).name));
%     end

    fprintf(fid,'\\end{document}\n');
    fclose(fid);
end

function [name] = removeunderslashes(nameIN)
    I = nameIN=='_';
    name = nameIN;
    name(I) = '';
end
function [binary,heartType] = CaseMappingAllCohorts(resultDir,DataCohort,iHeart,JRAtlasVersion,subversion,subfolder,binaryname)
    binary = NaN;
    switch DataCohort
        case 1              
            [binary, heartType] = CaseMeshingServiceMapping(iHeart);                            
        case 2
            [binary, heartType] = CaseJRMapping(resultDir,iHeart,JRAtlasVersion,subversion,subfolder,binaryname);
        case {3,4}
            iString = num2str(iHeart);
            if DataCohort==3
                Root = ['E:\data\MESHING\GrandChallenge\Case' iString '\'];
            else
                Root = ['E:\data\MESHING\GrandChallengeKCLcases\Case' iString '\'];
            end
            binary = [Root 'binary_' iString];
            heartType = 'BiV';
        otherwise
            % TODO: DEFAULT SEARCH FOR DATA:
                dirname = direct(iCase2findIndirect).name;
                BinaryName = SearchSubDirectoryNameFile(dirname,CaseDirectory,surname);        

        fprintf('ERROR! Not possible to retrieve naming of cases, cohort %i not implemented yet!\n',DataCohort);
    end 
end
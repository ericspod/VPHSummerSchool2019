function [output] = ParseInput(input,bCharacters)
% Function converting strings into numbers and arrays

    if nargin<2
        % Flag to indicate you expect a string:
        bCharacters = 0;
    end
    if ischar(input)
        % This is used in a command line:
        output = str2double(input);
    else
        % This is used when calling the function from matlab:
        output = cell2mat(input);
    end

    if(~bCharacters)
        % And if the argument was a char, the cell was converted into a char, and
        % we need to convert it to numeric:
        if ischar(output)
            output = str2double(output);
        end
    end
end
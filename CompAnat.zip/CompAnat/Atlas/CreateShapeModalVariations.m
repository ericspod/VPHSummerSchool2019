function [ singleModel ] = CreateShapeModalVariations( CH, MartrixDof, options, iCase )

    %Function to modify the mesh shape according to some 
    %predefined main modes of variation. The resulting shapes will be
    %analysed using PCA

    %CH - c.Hermite model of single shape with all DOFs (e.g. 3504)
    %MartrixDof - matrix of the single shape with all DOFs (e.g. 3504)

    %options to select main variation modes
    bAxisElongation = 0;
    bScaleUpDown = 0;
    bEpiChange = 0;
    bEndoChange = 0;
    bBasalRadiusChange = 0;
    bApicalPositionChange = 0;
    
    %AllDirections = 1 mean that scaling will be expanding/contracting
    %from the centre of mass (along x,y,z coords = 3DOF), if AllDirections = 0 the scaling would be
    %radial (expanding/contracting will happen only along x,y coords = 2DOF)
    bEpiEndoChangeAllDirections = 1; %default = 1

    elongationDelta = 1.1; %elongation along main axis (assuming correct upward axis)    
    scalingDelta = 1.2; %scale up/down of entire volume
    epiScaleDelta = 1.1; %scale up/down of epicardial nodes
    endoScaleDelta = 0.8; %scale up/down of endocardial nodes
    baseRadiusDelta = 1.2; %scale ratio of basal plane nodes
    apexOffsetDelta = 1.0; %apex offset

    transformation = '';
    bSurfaceOnly = 0;
    
    plotOutput = 0;
    
    %TODO: copy options to local variables
    if isfield(options,'OutputDirectory'), OutputDirectory = options.OutputDirectory; end
%     if isfield(options,'directory'), directory = options.directory; end
    if isfield(options,'plotOutput'), plotOutput = options.plotOutput; end
    if isfield(options,'bEpiEndoChangeAllDirections'), bEpiEndoChangeAllDirections = options.bEpiEndoChangeAllDirections; end
    
    if isfield(options,'bAxisElongation'), bAxisElongation = options.bAxisElongation; end
    if isfield(options,'elongationDelta'), elongationDelta = options.elongationDelta; end
    if isfield(options,'bEpiChange'), bEpiChange = options.bEpiChange; end
    if isfield(options,'epiScaleDelta'), epiScaleDelta = options.epiScaleDelta; end
    if isfield(options,'bEndoChange'), bEndoChange = options.bEndoChange; end
    if isfield(options,'endoScaleDelta'), endoScaleDelta = options.endoScaleDelta; end
    if isfield(options,'bBasalRadiusChange'), bBasalRadiusChange = options.bBasalRadiusChange; end
    if isfield(options,'baseRadiusDelta'), baseRadiusDelta = options.baseRadiusDelta; end
    if isfield(options,'bApicalPositionChange'), bApicalPositionChange = options.bApicalPositionChange; end
    if isfield(options,'apexOffsetDelta'), apexOffsetDelta = options.apexOffsetDelta; end
    if isfield(options,'bSurfaceNodesOnly'), bSurfaceNodesOnly = options.bSurfaceNodesOnly; end
    
    
    PC1Mat = [1 0 0; 0 1 0; 0 0 elongationDelta]; %1st PC
    PC2Mat = [scalingDelta 0 0; 0 scalingDelta 0; 0 0 scalingDelta]; %2nd PC
    
    if(bEpiEndoChangeAllDirections)
        %scaling from centre of mass along x,y,z directions (3DOF)
        PC3Mat = [epiScaleDelta 0 0; 0 epiScaleDelta 0; 0 0 epiScaleDelta]; %3rd PC
        PC4Mat = [endoScaleDelta 0 0; 0 endoScaleDelta 0; 0 0 endoScaleDelta]; %4th PC
    else
        %scaling radially along x,y directions (2DOF)
        PC3Mat = [epiScaleDelta 0 0; 0 epiScaleDelta 0; 0 0 1]; %3rd PC
        PC4Mat = [endoScaleDelta 0 0; 0 endoScaleDelta 0; 0 0 1]; %4th PC
    end
    

    %Check whether CH.DilateNodeCoordinate would make the node
    %transformation more robust (by recomputing derivatives? - only in c.Hermite)

      
    singleModel = MartrixDof; %copy entire model        
    coordinatesSingleModel = singleModel(1:CH.nNodes, :); %copy only 3D xyz coords

    %Apply transformations to all vertices. Assume all models are centered in the origin

    if(bAxisElongation)     %Long axis elongation
        transformation = 'AxisElongation';
%%%         coordinates only
%         result = PC1Mat * coordinatesSingleModel'; 
%         coordinatesSingleModel = result';
        
        chDofs = CH.GetDofs(); 
        transformedMesh = PC1Mat * chDofs';
        coordinatesSingleModel = transformedMesh;
        coordinatesSingleModel = coordinatesSingleModel'; 
    end                
    if(bScaleUpDown)        %Scale Up/Down
        result = PC2Mat * coordinatesSingleModel'; 
        coordinatesSingleModel = result';
    end        
    if(bEpiChange)          %Modify Epicardium
        transformation = 'Epi';
        [epiNodes] = FindEpiNodes(CH);  %Find Epicardium indices
        %Transform only coords (neglect derivatives)
%         coordsEpiSingleModel = coordinatesSingleModel(epiNodes,:); %copy node coords of epi indices
% 
%         transf = PC3Mat * coordsEpiSingleModel'; %transform selected nodes
% 
%         originalCoords = coordinatesSingleModel; 
%         %replace transformed nodes into corresponding rows of matrix
%         for ii = 1:numel(epiNodes)
%             jj = epiNodes(ii);
%             originalCoords(jj,:) = transf(:,ii)';
%         end
%         result = originalCoords'; %finally copy into resulting matrix
%         coordinatesSingleModel = result';
        
        %Transform Coords and Derivs
        [nN] = numel(epiNodes);
        [numcoords b c]= size(CH.coordinates); 

        if(CH.InterpolationBasis == 1) %only cHermite
            
            for leap = 1:8   % 1 coords + 7 derivs (duds1, duds2, duds3...)
                nJump = leap - 1;
                indicesTmp = (numcoords * nJump) + epiNodes;

                for j=1:nN
                    idx = (nN * nJump)+j;
                    epiIndices(idx) =  indicesTmp(j);               
                end
            end

            coordsDerivsEpiNodes = epiIndices;
        else
            coordsDerivsEpiNodes = epiNodes;
        end
        
        %obj = CH.FindExternalSurfaces();
        chDofs = CH.GetDofs(); 
        transformedMesh = PC3Mat * chDofs'; %transform all coords+derivs               
        coordinatesSingleModel = chDofs';  %get original model with all indices
        
        %replace only indices that correspond to endocardium
        coordinatesSingleModel(:,coordsDerivsEpiNodes) = transformedMesh(:,coordsDerivsEpiNodes);       
        coordinatesSingleModel = coordinatesSingleModel';  
        
    end
    if(bEndoChange)         %Modify Endocardium
        transformation = 'Endo';
        [endoNodes] = FindEndoNodes(CH);  %Find Endocardium indices

%%%       Transform only coords (neglect derivatives)
%         coordsEndoSingleModel = coordinatesSingleModel(endoNodes,:); %copy node coords of epi indices
% 
%         transf = PC4Mat * coordsEndoSingleModel'; %transform selected nodes
% 
%         originalCoords = coordinatesSingleModel; 
%         %replace transformed nodes into corresponding rows of matrix            
%         for ii = 1:numel(endoNodes)
%             jj = endoNodes(ii);
%             originalCoords(jj,:) = transf(:,ii)';
%         end
%         result = originalCoords'; %finally copy into resulting matrix     
%         coordinatesSingleModel = result';
        
        [nN] = numel(endoNodes);
        [numcoords b c]= size(CH.coordinates); 
        
        if(CH.InterpolationBasis == 1) %only cHermite
            %Transform Coords and Derivs
            %get indices of endocardium corresponding 1 coords + 7 derivs (duds1, duds2, duds3...)
            %using the same linear indices as the results given by GetDofs()
            %(e.g. 1168 DOFs)

            for leap = 1:8   % 1 coords + 7 derivs (duds1, duds2, duds3...)
                nJump = leap - 1;
                indicesTmp = (numcoords * nJump) + endoNodes;

                for j=1:nN
                    idx = (nN * nJump)+j;
                    endoIndices(idx) =  indicesTmp(j);               
                end
            end
            
            coordsDerivsEndoNodes = endoIndices;            
        else
            coordsDerivsEndoNodes = endoNodes;
        end
                
        chDofs = CH.GetDofs(); 
        transformedMesh = PC4Mat * chDofs'; %transform all coords+derivs               
        coordinatesSingleModel = chDofs';  %get original model with all indices
        
        %replace only indices that correspond to endocardium
        coordinatesSingleModel(:,coordsDerivsEndoNodes) = transformedMesh(:,coordsDerivsEndoNodes);       
        coordinatesSingleModel = coordinatesSingleModel';               
    end

    bOnlyBasalTopNodes = 0;

    %TODO: Refactor following cases for cLagrange Meshes
    
    if(bBasalRadiusChange)  %Basal plane radial changes
        %get basal nodes of LV
        meshTopology = GetCardiacMeshTopology(CH);
        nodeLayerStructure = meshTopology.NodeLayer; %access to structure
        [cols,numLayers] = size(meshTopology.NodeLayer);
        
        if bOnlyBasalTopNodes
            %to select only top nodes, otherwise gradually increase radius
            %from base towards apex
            numLayers = 2;  %select row 1 (after decrease - 1 below)
        end
        
        for kk = 1:numLayers - 1 % -1 is to avoid apical nodes

        layerIndices = nodeLayerStructure(kk).EpiNodes; %change to .nodes if necessary to select epi & endo nodes
        baseRadiusDelta = baseRadiusDelta - 0.2;
        
%         basalIndices = meshTopology.basalNodes;
        layerNodesCoords = coordinatesSingleModel(layerIndices,:);
        centroid = mean(layerNodesCoords); %centroid of basal nodes

        finalLayerNodesCoords = zeros(numel(layerIndices), 3); %allocate variable
        
        for ii = 1:numel(layerIndices);            
            %vector for each node and centroid
            vectorRadius = layerNodesCoords(ii,:) - centroid;
            normalRadius = NormaliseVector(vectorRadius);                
            normalRadius = normalRadius .* baseRadiusDelta; 
            %expand node coordinates along radius vector
            finalLayerNodesCoords(ii,:) = layerNodesCoords(ii,:) + normalRadius; 
            coordinatesSingleModel(layerIndices(ii),:) = finalLayerNodesCoords(ii,:);
        end

%         %Assume 1st Basal index corresponds to most Anterior node
%         %then calculate radius of anterior direction
%         anteriorNode = basalNodesCoords(1,:);
%         x2 = (centroid(1) - anteriorNode(1));
%         y2 = (centroid(2) - anteriorNode(2));
%         z2 = (centroid(3) - anteriorNode(3));        
%         radius = sqrt(x2*x2 + y2*y2 + z2*z2);
        
        end
    end
    
    if(bApicalPositionChange)  %Basal to apex offset changes
        %get layer nodes of LV
        meshTopology = GetCardiacMeshTopology(CH);
        nodeLayerStructure = meshTopology.NodeLayer; %access to structure
        [cols,numLayers] = size(meshTopology.NodeLayer);
                
        initialApexOffset = 0.0;
        apexDelta = (apexOffsetDelta - initialApexOffset) / numLayers;
        
        for kk = 2:numLayers

        layerIndices = nodeLayerStructure(kk).nodes; %change to .nodes if necessary to select epi & endo nodes
        
        initialApexOffset = initialApexOffset + apexDelta;
        apexOffsetVect = [initialApexOffset initialApexOffset 0]; %along x,y directions (2DOF)
        
        layerNodesCoords = coordinatesSingleModel(layerIndices,:);
        centroid = mean(layerNodesCoords); %centroid of basal nodes        

        finalLayerNodesCoords = zeros(numel(layerIndices), 3); %allocate variable
        
        for ii = 1:numel(layerIndices);            
            %vector for each node and centroid
            vectorRadius = layerNodesCoords(ii,:) - centroid;
            vectorRadius(3) = 0; %neglect changes in Z axis for now
            
            normalRadius = NormaliseVector(vectorRadius); %%??
            normalRadius = normalRadius + apexOffsetVect; %%??
            
            %expand node coordinates along vector
            finalLayerNodesCoords(ii,:) = layerNodesCoords(ii,:) + normalRadius; 
            coordinatesSingleModel(layerIndices(ii),:) = finalLayerNodesCoords(ii,:);
        end

%         %Assume 1st Basal index corresponds to most Anterior node
%         %then calculate radius of anterior direction
%         anteriorNode = basalNodesCoords(1,:);
%         x2 = (centroid(1) - anteriorNode(1));
%         y2 = (centroid(2) - anteriorNode(2));
%         z2 = (centroid(3) - anteriorNode(3));        
%         radius = sqrt(x2*x2 + y2*y2 + z2*z2);
        
        end
    end    
    
    %Only 3D coordinates were modified (skipped derivatives),
    %now copy modified coordinates into corresponding matrix (which has all
    %derivatives)

    [k,~] = size(coordinatesSingleModel);
    singleModel = CopyTransformedMatrix(singleModel, coordinatesSingleModel, k);

    
    %display single mesh: for testing only
    if(plotOutput)
        artificialDirName = '/syntheticMeshes/';

        OutMeshDir = [OutputDirectory artificialDirName];
%         thisMeshDir = [OutMeshDir num2str(iCase)];
% 
        if ~exist(OutMeshDir)
            mkdir(OutMeshDir);
        end

        nameOut = [transformation 'Artificial' num2str(iCase) '_mesh'];
        CH1 = CH.SetDofs(singleModel);
        DisplayCHModel(CH1, nameOut, OutMeshDir);
    end
    
    if(bSurfaceNodesOnly)
        CHTemp = CH.SetDofs(singleModel);
        epiNodes = FindEpiNodes(CHTemp);
        endoNodes = FindEndoNodes(CHTemp);
        singleModelIndices = [epiNodes endoNodes];
        singleModel = singleModel(singleModelIndices,:);
    end
end


function [originalMatrix] = CopyTransformedMatrix(originalMatrix, coordinateMatrix, nNodes)
    deformedModel = coordinateMatrix;
    originalMatrix(1:nNodes,:) = deformedModel(:,:);
end

function [v] = NormaliseVector(v)
    v = v / Module(v);
end

function [module] = Module(vector)
    module = sqrt(vector(1)^2 + vector(2)^2 + vector(3)^2);
end
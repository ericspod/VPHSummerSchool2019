% makes atlas of every 5th phase of the cardiac cycle using CINE images
% based on mymakeatlas4.m, images created using readCINE.m
% data in /December2014/16Dec_rem2
% Marta, 16/12/2014

close all
clear all

subjnam='Lbn';
subjnum=0:5:45; % phases of cardiac cycle
nsu=length(subjnum);
% nDofs=[2320 3];
goodnii=0;
nodot=1;
maketemplate=ones(size(subjnum)); %cat(2,zeros(1,44),ones(1,nsu-44));

% MatrixDofs=zeros(nsu,nDofs(1),nDofs(2));
% DofsInLine=zeros(nsu,prod(nDofs));

LoD = 1;
InitOption = 1; % in CubicHermitePersonalisationV2.m, this will be 4
SenseRot = 2;
bpname = 'C:/Users/mv12/Documents/DataforAtlas/NewHenryData/ellipsoidAproxGT2_nE12121';
template = strcat(bpname,'LVpool');

basdirec = strcat('C:/Users/mv12/Documents/DataforAtlas/newCINE/',subjnam);
cd(basdirec)
MeshDirec = strcat(basdirec,'Output_heartgen/');

opts.AtlasSurname=strcat('CINE_',subjnam);
for i=1:nsu
    close all
    su=num2str(subjnum(i));
    disp(['------- Phase ' su ' ---------'])
    % binname = strcat('CineROIs_Bcr_',su); % DONE
    binname = strcat('CineROIs_',subjnam,'_',su); 
    
%     direc=strcat(basdirec,su);
    binary = [basdirec binname '.nii'];
    MeshName = [binname '_mesh']; 
    
    if nodot
       nii=load_nii(binary);
       nii.img=removedotfromnii(nii.img);
       save_nii(nii,binary);
    end
    
    if maketemplate(i)
        disp('Making template...')
        if goodnii
            nii=load_nii(binary);
            niinew=make_nii(nii.img,nii.hdr.dime.pixdim(2:4));
            save_nii(niinew,binary);
        end
     heartgen2(binary,'-Template',template,'-LoD',LoD,'-InitOption',InitOption,...
            '-SenseRot',SenseRot,'-HeartType','Sphere','-bReport',0,...
            '-SecondROI',bpname);
        system(['mcubes ' binary ' MCUBES_' binary(1:end-4) '.vtk 0.5']);
        ex2vtk([MeshDirec MeshName '.exnode'],[MeshDirec MeshName '.exelem']);
    end
   
    % code below from CalculateAtlas.m
    MeshName = [binname '_mesh']; 
    MeshDirec = strcat(basdirec,'Output_heartgen/');
    if exist([MeshDirec MeshName '.exnode'],'file')
        CH = CubicMeshClass([MeshDirec MeshName]);
        nDofs = size(CH.GetDofs());
%         MatrixDofs = zeros(length(subjnum),nDofs(1),nDofs(2));
%         DofsInLine = zeros(nCases,prod(nDofs));
        CH = SolveRigidBodyMotion(CH,MeshDirec);
        MatrixDofs(i,:,:) = CH.GetDofs();
        DofsInLine(i,:) = reshape(MatrixDofs(i,:,:),1,prod(nDofs));
    else
        disp(['Subject: ' f(1:end-4) '- could not find mesh files to do atlas analysis']);
        disp(['Mesh: ' MeshDirec MeshName]);
        return;
    end
end

% Principal component analysis of the dofs - from CalculateAtlas.m
DofsMeanShape = squeeze(mean(MatrixDofs,1));   
CHmean = CH.SetDofs(DofsMeanShape);        
CHmean.name = 'Mean';
CHmean.GroupName = 'Mean';
CHmean.WriteExFiles(MeshDirec);

MeanDofsLn = reshape(DofsMeanShape,1,prod(nDofs));
B = DofsInLine - repmat(MeanDofsLn,nsu,1); % remove mean
COV = B'*B/nsu;
fprintf(1,'Eigenanalysis of covariance matrix of size %ix%i\n',size(COV));
[V,S] = eig(COV);
ss = diag(S);
disp('Done!')

Scalc=S;
clear S
clear iEig

save(strcat('Atlas',opts.AtlasSurname,'.mat'));

%% visualisation tools - from ScriptAtlas.m

for i=1:5
    ViewModalVariation(basdirec,i,1,opts);
end
pause(1); % to give time for all figures to be saved
GenerateAtlasModesTexFigure(basdirec,opts);
% mymeasurevol;
myPCanalysis;

% coefficients = GetEigenCoefficients(basdirec);
% vectors = 1;
% options.ClassDefinition=1;
% coefficients = GetEigenCoefficients(basdirec,options);
% GetEigenSpace(basdirec,vectors,options);
% PlotEigenDisubjnum{k}bution(basdirec,1);

save(strcat('Atlas',opts.AtlasSurname));    
disp('End.');
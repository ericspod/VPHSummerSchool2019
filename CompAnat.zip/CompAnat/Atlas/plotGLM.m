function plotGLM(b,x,Y)
    yfit = glmval(b,x,'logit');
    plot(Y,'o')
    hold on
    plot(yfit,'x','LineWidth',2);
    iValid = find(~isnan(yfit));
    nSamples = numel(iValid);
    % Binarise response:
    ybin = zeros(size(Y));
    ybin(yfit>=0.5) = 1;
    aa = logical(Y(iValid));
    bb = logical(ybin(iValid));
    SuccRate = 100* (1 - sum( abs( aa-bb ) ) / nSamples);
    fprintf(' Response in %i cases, %1.2f%% of success\n',nSamples,SuccRate);
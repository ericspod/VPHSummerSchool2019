function [] = PlotEchoThickness(Dofs,color,LineWidth,bPoints,bEpiOnly)
% Function to plot the thickness of the LV, accoringly to the encoding
% convention that the first half of the dofs are the skeleton, and the
% second half bring the (Epi - Endo)

bDebug = 0;

if nargin<2
    color = 'b';
end
if nargin<3
    LineWidth = 3;
end
if nargin<4
    bPoints = 0;
end
if nargin<5
    bEpiOnly = 0;
end

% The key is to "unfold" the reshape that put all dofs in one line:
nDofs = numel(Dofs);
nDxC = nDofs/2;

SkeletonDofs = Dofs(1:nDxC);
SkeletonDofs = reshape(SkeletonDofs,nDxC/2,2);
ThickDofs = Dofs(1+nDxC:end);
ThickDofs = reshape(ThickDofs,nDxC/2,2);
% Differentiate if dofs are encoding endo/epi or skel/thick:
if mean(abs(ThickDofs(:,1))) > 0.5 * mean(abs(SkeletonDofs(:,1)))
    % This is an Endo/Epi
    Endo = SkeletonDofs;
    Epi  = ThickDofs;
    % As in GetEigenCoefficients:
    SkeletonDofs =  (Endo + Epi)  / 2;
    ThickDofs =  Epi - Endo;    
end


nElementsPerContour = (nDxC/4 - 1);

SkeletonCont = LinearMeshClass;
SkeletonCont = SkeletonCont.SetTopology(nElementsPerContour);
ThickCont = SkeletonCont;

SkeletonCont = SkeletonCont.SetDofs(SkeletonDofs);
ThickCont  = ThickCont.SetDofs(ThickDofs);

hold on;

% Old way to plot it (as in PlotEchoContours.m);
%    ThickCont.plot(color,LineWidth,bPoints);

nS = 10;
t = 0:1/nS:ThickCont.nElems;
points = ThickCont.LineEvaluation(t);
Thickness = sqrt(sum(points.^2,2));
hold on;
plot(t,Thickness,'color',color, 'LineWidth',LineWidth);
if(bPoints)
    Pts = Thickness(1:nS:end);
    Ts = t(1:nS:end);
    plot(Ts,Pts,'o','color',color, 'LineWidth',LineWidth);
end
title('Thickness');

if bDebug
    subplot(1,2,1)
    ThickCont.plot(color,LineWidth);
    hold on;
    SkeletonCont.plot(color,LineWidth);
    title('Contours');

    subplot(1,2,2)
    plot(t,Thickness,'color',color, 'LineWidth',LineWidth);
    title('Thickness');
    a=1;
end
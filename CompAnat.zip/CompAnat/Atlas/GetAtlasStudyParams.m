function StudyParams = GetAtlasStudyParams(AtlasVersion,subversion,iComparison,iShapeSpace)
% Function to encode the specific details of each atlas study
% 
% INPUT:
% - AtlasVersion: an integer that points to each of the atlas studies
% (cohort, characteristics, etc).
% - Subversion: the same number of cases can be analysed in different ways,
% taking different subgroups, and making different statistics on them
% (different PCA axes for example). This is encoded in this numberic
% variable.
% - iComparison: there can be different cathegorical data per each case,
% (different definition of response for example).

if nargin<3
    iComparison = 1;
end

% Default options (for all JR results):
StudyParams.RootName = 'EVS';
options.LoD = 3;
options.bRVdirFromSA = 1;
options.BinaryName = 'BinaryMask.vtk';
options.SubDirectory = '/zmask/';
options.AssembleBinaryMasks = 0; % Used after MITK saved labels in different files
options.NamingConvention = 1; %Original naming convention 
options.surnameCases = NaN;
options.bTailorSlitTemplate = 0;
options.nE = [6 12 1];

options.bSolveRotation = 0;
options.bSolveRotationAndScale = 0;
StudyParams.ClassCriteria = '';

    switch AtlasVersion
        case 1 %First , without meshing improvements
            StudyParams.Directory = 'E:\data\JR\Atlas_v1.0\';
            StudyParams.ClinicalFile = 'EVSuncoding.xlsx';
            StudyParams.bMapClass = 0; 
        case 2 % Ago 2013, registration constrained by empty region at base
            StudyParams.Directory = 'E:\data\JR\Atlas_v2.0\';
        case {3,6}
            % A correction on the generation of cloud of points from binary
            % mask in order to get an accurate picture of fitting accuracy
            %StudyParams.Directory = 'E:\data\JR\Atlas_v2.1\';       %E:\data %GGG 
            %StudyParams.Directory = 'F:\Atlas\JR\Atlas_v2.1\';   
            %StudyParams.Directory = 'C:\Data\data\JR\Atlas_v2.1\'; 
            StudyParams.Directory = 'F:\JR preterm data\Atlas_v2.1';  
            StudyParams.optionsExcel.iColumnClass = 3;
            StudyParams.nGroups = 3;
            switch AtlasVersion
                case 3           
                    switch subversion
                        case 1      
                            % Do nothing; 
                            StudyParams.optionsExcel.iColumnClass = 2;
                        case 2
                            % Breast/Formula milk
                            StudyParams.bOnlyGenerateAtlasStatistics = 1;
                            StudyParams.ClinicalFile = 'MilkCategories.xlsx';
                            StudyParams.optionsExcel.iColumnClass = 2;
                            StudyParams.classes2include = [1 2 3];
                            StudyParams.AtlasSurname = 'MilkStudy';
                            StudyParams.colourscheme = 5;      
                        case 3
                            % Impact of PDA
                            StudyParams.bOnlyGenerateAtlasStatistics = 1;                  
                            StudyParams.ClinicalFile = 'PDAvsnoPDA.xlsx';
                            StudyParams.optionsExcel.iColumnClass = 2;
                            StudyParams.AtlasSurname = 'PDAStudy';
                            StudyParams.colourscheme = 5;                       
                    end
                    
                case 6
                    % TODO: CODE THE COMPUTATION OF THE ATLAS WITH A SUBSET OF
                    % ALL THE CASES!!
                    StudyParams.AtlasSurname = 'Classes12';
                    StudyParams.bOnlyGenerateAtlasStatistics = 1;
                    StudyParams.classes2include = [1 2];
                    StudyParams.bRestrictedClasses = 1;
            % No change in the generation of the meshes, but the atlas is only
            % computed from "preterms" and "term age matched".                 
            end
        case {4,5}
            % No change in the computation of the atlas from 3, but a change in
            % which classes are analysed:
            StudyParams.bStep1_CalculateAtlas = 0;        
            %StudyParams.Directory = 'E:\data\JR\Atlas_v2.1\';
            StudyParams.Directory = 'F:\JR preterm data\Atlas_v2.1';
            StudyParams.ClinicalFile = 'preeclampsia_gestationalage_Pablo.xlsx';
            switch AtlasVersion
                case 4, StudyParams.StudyClass = 2;
                case 5, StudyParams.StudyClass = 3;
            end
        case 7
            StudyParams.Directory = 'E:\data\JR\AtlasRV_v1.0\';
            StudyParams.topology = 'BiV';
        case {8,9,10}
            % Female cohort
            switch subversion
                case 1 
                    StudyParams.Directory = 'E:\data\JRfemalecohort\Atlas v1.0\';
                case 2
                    StudyParams.Directory = 'E:\data\JRfemalecohort\Atlas v2.0\';
            end
            StudyParams.ClinicalFile = 'CohortDesign.xlsx';
            StudyParams.StudyClass = 4;
            StudyParams.RootName = 'OXPCS';
            StudyParams.HotDims   = [1 2 7 10];
            if AtlasVersion == 9
                % further analysis, comparing other kind of classes:
                StudyParams.StudyClass = 5;
                StudyParams.GroupedClasses{1} = 1;
                StudyParams.GroupedClasses{2} = [2 3];
            end
            if AtlasVersion == 10
                % further analysis, comparing other kind of classes:
                StudyParams.StudyClass = 6;
                StudyParams.GroupedClasses{1} = [1 2];
                StudyParams.GroupedClasses{2} = 3;
            end
        case 11
            % Generation of meshes after the improvements of the female
            % cohort (mainly about preventing base tilting), with the hope
            % of improving mesh quality for the meshing paper.
            StudyParams.Directory = 'E:\data\JR\Atlas_v3.0\';               
        case 12
            %RootDir = 'E:\data\SSFP\AtlasSHF\'; %'F:\Atlas\AtlasSHF\';
            RootDir = 'F:\Atlas\CRT\AtlasSHF\'; 
            StudyParams.RootName = '';    
            options.LoD = 3;
            options.bRVdirFromSA = 0;
            options.BinaryName = 'SubDirectoryName';
            options.SubDirectory = '/';            
            
            options.RVpoolLabel = 2;
            options.MyoLabel = 1;
            StudyParams.nGroups   = 2;        
            switch subversion
                case 1 % manual segmentations
                    StudyParams.Directory = [RootDir 'ManualSegmentations\']; 
                    % naming of the binary files:
                    options.surname = 'b';
                    StudyParams.HotDims   = [2 5 12 23 30];    
                    options.Cases2include = [1:4 6:16 18:21];
                case 2
                    StudyParams.Directory = [RootDir 'UCLsegmentations\']; 
                    if(0)
                        options.bCorrectGrayscale2SegmentationOrientation = 1;
                    else
                        % Once binary segmentations have been reoriented:
                        options.bCorrectGrayscale2SegmentationOrientation = 0;
                        options.surname = 'R';
                    end
                    options.MyoLabel = [204 205];
                    options.RVpoolLabel = 600;
                    % Cases 10, 15 and 20 were wrong, and 5 had no
                    % anatomical definition:
                    options.Cases2include = [1:4 6:9 11:14 16:19 21];
                    StudyParams.HotDims   = [6 1 2 9];    
            end
        case 13
            StudyParams.RootName = 'ROI_';
                    
            switch subversion
                case 1
                    StudyParams.Directory = 'F:\Atlas\JamesWongAtlas\Version1\';
                    options.RVpoolLabel = 1;
                    options.MyoLabel = 3;
                case 2
                    StudyParams.Directory = 'F:\Atlas\JamesWongAtlas\Version2\';
                    options.RVpoolLabel = 2;
                    options.MyoLabel = 1;
                case 3
                    StudyParams.Directory = 'F:\Atlas\JamesWongAtlas\Version3\';
                    options.RVpoolLabel = 2;
                    options.MyoLabel = 1;
                    StudyParams.ClinicalFile = 'First 12 pts for Pablo.xlsx';
                    options.Cases2include = [40    41    43    44    45    46    47    48    51    52    53];
                case 4
                    StudyParams.Directory = 'F:\Atlas\JamesWongAtlas\Version4\';
                    options.RVpoolLabel = 2;
                    options.MyoLabel = 1;
                    StudyParams.ClinicalFile = 'full dataset HLHS for Pablo.xlsx';
                case 5
                    StudyParams.Directory = 'F:\Atlas\JamesWongAtlas\Version5\';
                    options.RVpoolLabel = 2;
                    options.MyoLabel = 1;
                    StudyParams.ClinicalFile = 'full dataset HLHS for Pablo.xlsx';                    
                    options.bTailorSlitTemplate = 1;
                    options.topology = 'LVL';
                    options.nE = [5 12 1];
                case 6
                    % Restrict to data of stages I and II only
                    StudyParams.Directory = 'F:\Atlas\JamesWongAtlas\Version5\';
                    options.RVpoolLabel = 2;
                    options.MyoLabel = 1;
                    StudyParams.ClinicalFile = 'full dataset HLHS for Pablo stageI-II.xlsx';                    
                    options.bTailorSlitTemplate = 1;
                    options.topology = 'LVL';
                    options.nE = [5 12 1];
                    options.Cases2include = [1 2 4:9 12:15 17:22 24 25 28:35 37 39:41 43:48 51:54 56:61 63 64 67:74 76 78 201 202 204 205 209:211 214:216 218:227 230:237 239:244];
            end
            options.LoD = 3;
            options.bRVdirFromSA = 0;
            options.BinaryName = 'SubDirectoryName';
            options.SubDirectory = '/';                      
        
            switch iComparison
                case 1, % Compare the surgical technique: expect to see mode 6 differences 
                    StudyParams.optionsExcel.iColumnClass = 5;
                    StudyParams.colourscheme = 1;
                case 2, % Compare the stage of the surgery: expect to see mode 2 differences
                    StudyParams.optionsExcel.iColumnClass = 4;
                    StudyParams.colourscheme = 4;
                case 3, % Compare the slit vs globular topology
                    StudyParams.optionsExcel.iColumnClass = 3;
                    StudyParams.colourscheme = 2;
                case 4, % Compare the surgical technique in stage I
                    StudyParams.optionsExcel.iColumnClass = 6;
                    StudyParams.colourscheme = 1;
                case 5, % Compare the surgical technique in stage II: expect to see mode 6 differences 
                    StudyParams.optionsExcel.iColumnClass = 7;
                    StudyParams.colourscheme = 1;
            end

        case {14,15} 
            RootDir = 'F:\Atlas\CRT_KCL\';
            
            StudyParams.RootName = '';    
            options.LoD = 3;
            options.bRVdirFromSA = 0;
            options.BinaryName = 'SubDirectoryName';
            options.SubDirectory = '/';            
            options.topology = 'BiV';
            
            options.RVpoolLabel = 2;
            options.MyoLabel = 1;
            StudyParams.nGroups   = 2;        
            switch subversion
                case 1 % manual segmentations
                    StudyParams.Directory = [RootDir 'ManualSegmentations\']; 
                    % naming of the binary files:
                    options.surname = 'b';
                    StudyParams.HotDims   = [2 5 12 23 30];    
                    options.Cases2include = [1:4 6:16 18:21];
                case 2
                    StudyParams.Directory = [RootDir 'UCLsegmentations\']; 
                    options.SubDirectory = '/segmentation/ucl/';            
                    options.MyoLabel = 18;
                    options.RVpoolLabel = 35; 
            end
            
        case 15
            switch subversion
                case 1
                    % 3D US HCM cases from the JR (R.Bates)
                    RootDir = 'C:\DataFromRoss\';
                    StudyParams.Directory = [RootDir 'Atlas_v1.0\'];
                    options.SubDirectory = '/';            
                    options.RVpoolLabel = 2;
                    options.MyoLabel = 1;
                    options.AssembleBinaryMasks = 1;
                    options.bRVdirFromSA = 0;
                    options.NamingConvention = 2;
                    options.LoD = 5;
                case 2
                    %   MRI SA Stack HCM from JR (R.Bates)
                    RootDir = 'C:/DataFromRoss/';
                    StudyParams.Directory = [RootDir 'MRDataFolder/'];
                    StudyParams.StudyClass = 7;
                    options.SubDirectory = '/';       
                    options.bRVdirFromSA = 0;
                    options.bRVpoolLabel = 1;
                    options.RVpoolLabel = 2;
                    options.MyoLabel = 1;
                    options.AssembleBinaryMasks = 0;
                    options.NamingConvention = 2;
                    options.LoD = 5;
                    options.BinaryName = 'SubDirectoryName';
                    options.surname = 'binary';
                    
            end
                    
        case 16
            switch iComparison
                case 1
                    StudyParams.optionsExcel.iColumnClass = 2; %EDV 
                    StudyParams.ClassCriteria = 'EDV';
                case 2
                    StudyParams.optionsExcel.iColumnClass = 6; %6 = column corresponding to ESV
                    StudyParams.ClassCriteria = 'ESV';
                case 3
                    StudyParams.optionsExcel.iColumnClass = 7; %6 = column corresponding to ESV
                    StudyParams.ClassCriteria = 'Cohort';
                    StudyParams.classes2include = [1 2 3];
                case 4
                    StudyParams.optionsExcel.iColumnClass = 8; %6 = column corresponding to ESV
                    StudyParams.ClassCriteria = 'ReproEDV';     
                case 5
                    StudyParams.optionsExcel.iColumnClass = 9; %6 = column corresponding to ESV
                    StudyParams.ClassCriteria = 'Trigger';  
                    StudyParams.classes2include = [1 2 3];   
            end
            RootDir = 'F:\Atlas\CRT';
            options.topology = 'LV';     
            options.LoD = 3;                     
            switch subversion
                case 1
                   % Complete CRT cohort
%                    Gerardo's directories
%                    StudyParams.Directory = 'E:\data\SSFP\CRT_New(LatestEva)\Complete\MITKbased\EDV_10percent\LatestCohortNewEvaCases(51cases)\cHermiteFull\';
%                    StudyParams.ClinicalFile = 'CaseIdentities10pc_AllCorrect_51cases.xlsx';%'CaseIdentities10pc_AllCorrect.xlsx'; 
                   StudyParams.Directory = fullfile(RootDir, 'Complete');
                   StudyParams.ClinicalFile = 'CaseIdentities10pc_AllCorrect_50cases.xlsx';%'CaseIdentities10pc_AllCorrect.xlsx'; 
            
                case 2 
                    %%To compare cohorts in different folders (Sheffield
                    %%Only) comparing different segmentations
                    
                    %%Manual segmentation (David Warriner's segmentation)      
                    %%'bsmooth' = after applying mean filter to binary mask 
                    Cohorts.surname = 'bsmooth';  
                    Cohorts.Directory = 'W:\Atlas\CRTCases\SheffieldSegmentations\ManualSegmentation\';
                    %%Gerardo's segmentation using MITK
                    Cohorts(2).surname = '';            
                    Cohorts(2).Directory = 'W:\Atlas\CRTCases\SheffieldSegmentations\GerardoSegmentation\';
                    %%Pablo's segmentation using MITK
                    Cohorts(3).surname = 'g';            
                    Cohorts(3).Directory = 'W:\Atlas\CRTCases\SheffieldSegmentations\PabloSegmentation\';
                    StudyParams.Cohorts = Cohorts;
                    StudyParams.Directory = 'W:\Atlas\CRTCases\SheffieldSegmentations\ManualSegmentation\'; %default for Sheffield cohort
                    StudyParams.ClinicalFile = 'CaseIdentities10pc_SHFCases.xlsx';            
                    %options.surname = ''; %bsmooth';
             
                case 3
                   StudyParams.Directory = fullfile(RootDir, 'Complete50');
                   StudyParams.ClinicalFile = 'CaseIdentities10pc_AllCorrect_50cases.xlsx';%'CaseIdentities10pc_AllCorrect.xlsx'; 
                    % A more closed base with LVL, and decreased number of elements
                    % in longitudinal to match the original 6:
                    options.topology = 'LVL';                        
                    options.nE = [5 12 1];
                    % Added 07/05/2015:
                    %options.AtlasAlignmentOption = 'NA';
                    options.iNodeSecondAxis = 130;
                case 4
                   StudyParams.Directory = fullfile(RootDir, 'Complete50b');
                   StudyParams.ClinicalFile = 'CaseIdentities10pc_AllCorrect_50cases.xlsx';%'CaseIdentities10pc_AllCorrect.xlsx'; 
                   StudyParams.ClinicalFile = '../ResponseDefinition/CRTcohort.xlsx';
                   % A baseline to compare to previous:
                   options.topology = 'LV';                        
                   options.nE = [6 12 1];
                   %options.AtlasAlignmentOption = 'NA';
                   options.iNodeSecondAxis = 130;
                case 5
                   StudyParams.Directory = fullfile(RootDir, 'Warriner19');
                   StudyParams.ClinicalFile = 'CaseIdentities10pc_AllCorrect_50cases.xlsx';%'CaseIdentities10pc_AllCorrect.xlsx'; 
                    options.topology = 'LVL';                        
                    options.nE = [5 12 1];
                case 6
                   StudyParams.Directory = fullfile(RootDir, 'Lamata19');
                   StudyParams.ClinicalFile = 'CaseIdentities10pc_AllCorrect_50cases.xlsx';%'CaseIdentities10pc_AllCorrect.xlsx'; 
                    options.topology = 'LVL';                        
                    options.nE = [5 12 1];
                case 7
                   StudyParams.Directory = fullfile(RootDir, 'Warriner19RVGG');
                   StudyParams.ClinicalFile = 'CaseIdentities10pc_AllCorrect_50cases.xlsx';%'CaseIdentities10pc_AllCorrect.xlsx'; 
                    options.topology = 'LVL';                        
                    options.nE = [5 12 1];
                case 8
                   StudyParams.Directory = fullfile(RootDir, 'Lamata19RVGG');
                   StudyParams.ClinicalFile = 'CaseIdentities10pc_AllCorrect_50cases.xlsx';%'CaseIdentities10pc_AllCorrect.xlsx'; 
                   options.topology = 'LVL';                        
                   options.nE = [5 12 1];
                case 9
                   StudyParams.Directory = fullfile(RootDir, 'Warriner19b');
                   StudyParams.ClinicalFile = 'CaseIdentities10pc_AllCorrect_50cases.xlsx';%'CaseIdentities10pc_AllCorrect.xlsx'; 
                    options.topology = 'LV';                        
                    options.nE = [6 12 1];
                case 10
                   StudyParams.Directory = fullfile(RootDir, 'Lamata19b');
                   StudyParams.ClinicalFile = 'CaseIdentities10pc_AllCorrect_50cases.xlsx';%'CaseIdentities10pc_AllCorrect.xlsx'; 
                    options.topology = 'LV';                        
                    options.nE = [6 12 1];
                case 11
                    % Decreasing the LoD
                   options.LoD = 2;
                   StudyParams.Directory = fullfile(RootDir, 'Complete50c');
                   StudyParams.ClinicalFile = 'CaseIdentities10pc_AllCorrect_50cases.xlsx';%'CaseIdentities10pc_AllCorrect.xlsx'; 
                   options.topology = 'LV';                        
                   options.nE = [6 12 1];
                   options.iNodeSecondAxis = 130;
                case 12
                    % Decreasing the LoD
                   options.LoD = 2;
                   StudyParams.Directory = fullfile(RootDir, 'Complete50d');
                   StudyParams.ClinicalFile = 'CaseIdentities10pc_AllCorrect_50cases.xlsx';%'CaseIdentities10pc_AllCorrect.xlsx'; 
                   options.topology = 'LV';                        
                   options.nE = [6 12 1];
                   options.iNodeSecondAxis = 130;
                case 13
                   StudyParams.Directory = fullfile(RootDir, 'FinalAtlas');
                   StudyParams.ClinicalFile = '../ResponseDefinition/CRTcohort.xlsx';
                   % A baseline to compare to previous:
                   options.topology = 'LV';                        
                   options.nE = [6 12 1];
                   options.iNodeSecondAxis = 130;
                case {14,15,16,17,18,19}                     
                   StudyParams.ClinicalFile = '../ResponseDefinition/CRTcohort.xlsx';
                    switch subversion
                        case 14, StudyParams.Directory = fullfile(RootDir, 'Lamata50b');
                        case 15, StudyParams.Directory = fullfile(RootDir, 'LamGon50b');
                        case 16, StudyParams.Directory = fullfile(RootDir, 'Gon50bPCA100');
                        case 17, StudyParams.Directory = fullfile(RootDir, 'Lam50bPCA100');
                        case 18, StudyParams.Directory = fullfile(RootDir, 'Ave50bPCA100');
                        case 19, StudyParams.Directory = fullfile(RootDir, 'Ave50bPCA50');
                    end
                   
                   % A baseline to compare to previous:
                   options.topology = 'LV';                        
                   options.nE = [6 12 1];
                   options.iNodeSecondAxis = 130;
            end
            
            options.BinaryName = 'SubDirectoryName';
            options.SubDirectory = '/';            
            
            %Rest of parameters...
            StudyParams.RootName = '';  
               

            options.RVpoolLabel = 2;    
            options.bRVdirFromSA = 0;
            options.MyoLabel = 1;
            StudyParams.nGroups   = 2;  
            
%             %Other deprecated options: 
%             %A) JR 224cases cohort
%             StudyParams.Directory = 'E:\data\JR\Atlas_v2.1\cubicLagrangeFixed\';
%             StudyParams.ClinicalFile = 'caseidentities.xlsx';            
%             options.BinaryName = 'BinaryMask.vtk';
%             options.SubDirectory = '/zmask/';

%             %B) If using NAF (for machine learning testing - Works only on Linux)
%             if(isunix()) 
%                StudyParams.Directory = '/home/ggg13/Documents/data/data/SSFP/CRT_New(LatestEva)/Complete/MITKbased/EDV_10percent/cLagrange/cubicLagrangeFixed/';
%             end
                        
%             %C) Generate mesh data from SSFP images
%             StudyParams.Directory = 'E:\data\SSFP\MITK-based_AtlasData\ManualSegmentationOnly\SHF\';
%             options.surname = 'bsmooth';
%             StudyParams.ClinicalFile = 'CaseIdentities10pc_SHFCases.xlsx'; 

%             %D) Sheffield Cases Only
%             StudyParams.Directory = 'E:\data\SSFP\CRT\SHFOnly\';
%             StudyParams.ClinicalFile = 'CaseIdentitiesSHF.xlsx';            

        case 17
            % David Cox:
            StudyParams.Directory = 'F:\Atlas\DavidCox\';
            StudyParams.RootName = '';    
            options.LoD = 2;
            options.BinaryName = 'SubDirectoryName';
            options.SubDirectory = '/';            
            options.topology = 'LV';
            

            options.RVpoolLabel = 3;
            options.MyoLabel = 2;
            StudyParams.nGroups   = 5; 
            StudyParams.ClinicalFile = 'LV_Segmentation_cohorts.xlsx';
            options.bRVdirFromSA = 0;
                        
            options.AssembleBinaryMasks = 1;
            
        case 18
            % DN: New test case for creating an atlas
            % RootDir = 'F:\Atlas\HCMfromJR\DataFromRoss\';
            mdir = mfilename('fullpath');
            RootDir = fullfile(mdir, '../../../../VPH/Atlas_Input/data/JR/');
            %RootDir = '/home/dn14/Documents/VPH/Atlas_Input/data/JR/'; % DN(110413): use local directory
            StudyParams.Directory = [RootDir 'Atlas_v2.1/'];
            options.SubDirectory = '/';            
            options.RVpoolLabel = 2;
            options.MyoLabel = 1;
            options.AssembleBinaryMasks = 0;
        case 19
            RootDir = 'F:\Atlas\Etel\AtlasEcho/'; % DN(110413): use local directory
            StudyParams.Directory = RootDir;
            options.SubDirectory = '/';            
            options.RVpoolLabel = 100;
            options.MyoLabel = 250;          
            options.topology = 'LV';
            options.BinaryName = 'SubDirectoryName';
            options.bRVdirFromSA = 0;
        case 20
            RootDir = 'F:\Atlas\GenerationR\21July2014_Nof5_CardiacScans/';
            StudyParams.Directory = RootDir;
            options.SubDirectory = '/';            
            options.RVpoolLabel = 3;
            options.MyoLabel = 1;          
            options.topology = 'LV';
            options.BinaryName = 'binary.vtk';
            options.bRVdirFromSA = 0;
        case 21
            % Female cohort from Henry Boardman
            options.BinaryName = 'SubDirectoryName';
            
            switch iComparison
                case 1
                    StudyParams.optionsExcel.iColumnClass = 2;  
                    StudyParams.ClassCriteria = 'AllClasses';
                    StudyParams.classes2include = [1 2 3 4 5];
                    StudyParams.nGroups = 5; 
                case 2
                    StudyParams.optionsExcel.iColumnClass = 3; 
                    StudyParams.ClassCriteria = 'gPET';
                    StudyParams.classes2include = [1 2 4 5];
                case 3
                    StudyParams.optionsExcel.iColumnClass = 4; 
                    StudyParams.ClassCriteria = 'gPETPIH';
                    StudyParams.classes2include = [1 2 5];                                                
            end
            switch subversion
                case 1
                    RootDir = 'F:\Atlas\JRfemalecohort\Atlasv3.0/';
                    options.topology = 'BiV';
                case 2
                    RootDir = 'F:\Atlas\JRfemalecohort\Atlasv3.1/';
                    options.topology = 'LV';
                case 3
                    RootDir = 'F:\Atlas\JRfemalecohort\Atlasv4.0/';
                    options.topology = 'LVL';                        
                    options.nE = [5 12 1];
                    options.LocalDicomFolder = '';  
                    %StudyParams.optionsExcel.iColumnClass = 1;
                    StudyParams.optionsExcel.bForceGetText =1;
                    % To be used once cmr42 contours have been extracted
                    options.BinaryName = 'binary.vtk';
                    % Used to remesh the cases that were flipped: 
                    %options.Cases2include = [2, 144, 143, 148, 170, 171, 200, 15, 35, 42, 217, 223, 5, 6, 179, 206, 202, 214];
                    %options.Cases2include = [188 198];
                    %options.Cases2include = [177 ];
                    StudyParams.ClinicalFile = 'code list for Pablo.xlsx';
                    StudyParams.ClinicalFile = 'code list for Pablo corrected.xlsx';                    
                    % To solve the rotation orientation:
                    options.iNodeSecondAxis = 130;
                case 4
                    % Henry's PVS 43 cases
                    RootDir = 'F:\Atlas\PVSHarry\Atlas';
                    options.topology = 'LVL';  
                    options.nE = [5 12 1];
                    StudyParams.Directory = RootDir;
                    options.SubDirectory = '/';          
                    options.BinaryName = 'SubDirectoryName';
                    StudyParams.ClinicalFile = 'codebreaker FINAL corrected.xlsx';
                    StudyParams.classes2include = [1 2];
                    StudyParams.nGroups = 2; 
                case 5
                    % Henry's PVS 153 cases
                    RootDir = 'F:\Atlas\JRfemalecohort\Atlasv5.0/';
                    options.topology = 'LVL';  
                    options.nE = [5 12 1];
                    StudyParams.Directory = RootDir;
                    options.SubDirectory = '/';          
                    options.BinaryName = 'SubDirectoryName';
                    StudyParams.ClinicalFile = 'codebreaker FINAL corrected.xlsx';
            end
            StudyParams.Directory = RootDir;
            options.SubDirectory = '/';            
            options.RVpoolLabel = 2;
            options.MyoLabel = 1;          
            options.bRVdirFromSA = 0;
        case 22
            % First atlas study of the aorta. Meshes are generated outside,
            % in the ScriptHarry.m
            RootDir = 'F:\Atlas\Aorta\AtlasHarry10cases\';
            StudyParams.bOnlyGenerateAtlasStatistics = 1;
            StudyParams.Directory = RootDir;
            options.SubDirectory = '/';          
            options.topology = 'arch';  
            options.BinaryName = 'SubDirectoryName';
            StudyParams.ClinicalFile = 'cases.xlsx'; 
            StudyParams.classes2include = [1 2 3 4];
            options.Cases2include = [1:40];
        case 23
            % Repetition of case 3, but from LVL topology, incorporating
            % two main changes with respect to this cohort:
            % 1. Improved masking (prevent base tilting), as cohort 11,
            % atlas v3.0
            % 2. Improved template: now LVL
            StudyParams.Directory = 'F:\Atlas\JR\Atlas_v4.0\';   
            StudyParams.optionsExcel.iColumnClass = 3;
            switch subversion
                case 1      
                    % Do nothing;
                case 2
                    % Breast/Formula milk
                    StudyParams.bOnlyGenerateAtlasStatistics = 1;
                    % One for the creation of the PCA axes:
                    StudyParams.ClinicalFile = 'caseidentities.xlsx';                    
                    % And another for the classification task:                    
                    StudyParams.ClinicalFile = 'MilkCategories.xlsx';
                    StudyParams.optionsExcel.iColumnClass = 2;
                    StudyParams.classes2include = [1 2 3];
                    StudyParams.nGroups = 3;
                    StudyParams.AtlasSurname = 'MilkStudy';
                    StudyParams.colourscheme = 5;    
                case 3
                    StudyParams.Directory = 'F:\Atlas\JR\Atlas_v5.0\'; 
                    options.topology = 'LVL';                                
                    options.nE = [5 12 1];    
            end
            switch iComparison
                case 1
                    StudyParams.optionsExcel.iColumnClass = 2; %term birth
                    StudyParams.nGroups = 3; 
                    StudyParams.classes2include = [1 2 3];
                case 2            
                    StudyParams.ClinicalFile = 'MilkCategories.xlsx';     
                    StudyParams.optionsExcel.iColumnClass = 2;
                    StudyParams.classes2include = [1 2 3];
                    StudyParams.nGroups = 3;
                    StudyParams.AtlasSurname = 'MilkStudy';
                    StudyParams.colourscheme = 5;           
                    StudyParams.bOnlyGenerateAtlasStatistics = 1;   
                case 3            
                    StudyParams.ClinicalFile = 'MilkCategories.xlsx';     
                    StudyParams.optionsExcel.iColumnClass = 2;
                    StudyParams.classes2include = [1 2];
                    StudyParams.nGroups = 2;
                    StudyParams.AtlasSurname = 'MilkStudy';
                    StudyParams.colourscheme = 5;           
                    StudyParams.bOnlyGenerateAtlasStatistics = 1;               
                case 4
                    % Used for the Fisher analysis
                    StudyParams.optionsExcel.iColumnClass = 2; %term birth
                    StudyParams.nGroups = 2; 
                    StudyParams.classes2include = [1 2];
            end
        case 24
            % HF Leipzig
            RootDir = 'F:\Atlas\HFLeipzig\Atlas\';
            StudyParams.Directory = RootDir;
            options.SubDirectory = '/';          
            options.topology = 'LVL';  
            %options.BinaryName = 'SubDirectoryName';
            options.BinaryName = 'Binary.vtk';
            options.MyoLabel = 1;      
            StudyParams.bSubApexSlice = 0;
            options.LoD = 1;
            StudyParams.ClinicalFile = 'ClinicalInfo.xlsx';
            StudyParams.classes2include = [1 2 3];
        case 25
            % Eva Sammut's DCM
            RootDir = 'F:\Atlas\DCM_Sammut\Atlas';
            StudyParams.Directory = RootDir;
            options.SubDirectory = '/';          
            options.topology = 'LVL';  
            options.BinaryName = 'SubDirectoryName';
            %options.BinaryName = 'Binary.vtk';
            options.MyoLabel = 1;              
            options.RVpoolLabel = 2;
            options.bRVdirFromSA = 0;   
            options.LoD = 3;
            StudyParams.ClinicalFile = 'ClinicalInfo.xlsx';
            StudyParams.classes2include = [1 2];
            StudyParams.nGroups = 2; 
            
            switch iComparison
                case 1
                    StudyParams.optionsExcel.iColumnClass = 2; %DCM / control
                case 2            
                    StudyParams.optionsExcel.iColumnClass = 3; %syst/diast
                    StudyParams.colourscheme = 5;           
                case 3            
                    StudyParams.optionsExcel.iColumnClass = 4; %syst/diast
                    StudyParams.colourscheme = 1;           
                    StudyParams.classes2include = [1:4];
                    StudyParams.nGroups = 4; 
                case 4
                    StudyParams.optionsExcel.iColumnClass = 5; % diast only
                    StudyParams.colourscheme = 1;           
                    StudyParams.classes2include = [1:2];
                    StudyParams.nGroups = 2; 
            end
    end
    
    options.DataDirectory = fullfile(StudyParams.Directory, 'AtlasData');
    OutputDirectory = fullfile(StudyParams.Directory, 'AtlasOutput');


    if nargin>=4
        OutputDirectory = RenameOutputDirectory(OutputDirectory,iShapeSpace);
        options.AtlasAlignmentOption = iShapeSpace;
    else
        % The default implicit option done in all previous atlases:
        options.AtlasAlignmentOption = 'rv';
    end
    options.OutputDirectory = OutputDirectory;

    if ~isdir(OutputDirectory)
        mkdir(OutputDirectory);
    end
    
    StudyParams.options = options;
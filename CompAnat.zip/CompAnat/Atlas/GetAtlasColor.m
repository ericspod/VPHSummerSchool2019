function [color] = GetAtlasColor(iClass,colorscheme,S)
% Colour definition depending on the ith class item following the
% classification criteria colorscheme
if nargin<2
    colorscheme = 0;
end

average = [  0  33  71]/255;

if iClass == 0
    color = average;
    return;
end

switch colorscheme
    case 0
        color = GetColor(iClass);
    case 1
        % this is the classification among:
        % 1=preterm-born, 
        % 2=term-born young adults (age matched) and 
        % 3=older term-born adults 
        switch iClass 
            case 1, color = [ 72 145 220]/255;
            case 2, color = [105 145  59]/255;
            case 3, color = [135 36   52]/255;
            case 4, color = [0 0 220]/255;
            case 5, color = [0 220 0]/255;
            case 6, color = [220 0 0]/255;
            case 7, color = [0 220 220]/255;
            case 8, color = [220 220 0]/255;
            case 9, color = [220 0 220]/255;
            case 10, color = [50 50 50]/255;
            otherwise
                fprintf('ERROR! Color %i for color scheme %i not defined!\n',iClass,colorscheme);
        end
    case 2
        % this is the classification among:
        % 1=average
        % 2=+2std
        % 3=-2std
        Plus2st = [153  51 255]/255;
        Minu2st = [207 122  48]/255;
        switch iClass 
            case 1, color = average;
            case 2, color = Plus2st; %color = [235 168 203]/255;
            case 3, color = Minu2st;
            case 4, 
                % An intermediate, accordingly to arg(3)
                if S > 0
                    color = average * (2-S)/2 + Plus2st * (S)/2;
                else
                    color = average * (2+S)/2 + Minu2st * (-S)/2;
                end
            otherwise
                fprintf('ERROR! Color %i for color scheme %i not defined!\n',iClass,colorscheme);
        end
    case 3
        % Other color scheme among two classes
        switch iClass 
            case 1, color = [ 129 10 10]/255;
            case 2, color = [ 10 10 129]/255;
            otherwise
                fprintf('ERROR! Color %i for color scheme %i not defined!\n',iClass,colorscheme);
        end
    case 4
        % Other color scheme among three classes
        switch iClass 
            case 1, color = [ 229 229 0]/255;
            case 2, color = [ 10 129 29]/255;
            case 3, color = [ 229 10 229]/255;
            otherwise
                fprintf('ERROR! Color %i for color scheme %i not defined!\n',iClass,colorscheme);
        end        
    case 5
        % this is the classification among:
        % 1=breast preterms
        % 2=formula preterms
        % 3=term-born young adults (age matched)
        switch iClass 
            case 1, color = [ 207 122 48]/255;
            case 2, color = [158 206 235]/255;
            case 3, color = [105 145  59]/255;
            otherwise
                fprintf('ERROR! Color %i for color scheme %i not defined!\n',iClass,colorscheme);
        end
    case 6
        % this is the classification among:
        % 1=preterm-born, birth
        % 2=term-born at birth 
        % 3=preterm-born, fu
        % 4=term-born at fu 
        switch iClass 
            case 1, color = [  0 145 220]/350;
            case 2, color = [204   0   0]/256;
            case 3, color = [  0 204 145]/256;
            case 4, color = [204 102   0]/256;
        end
    case 7
        switch iClass 
            case 1, color = [105 145  59]/205;
            case 2, color = [105 145  59]/300;
            case 3, color = [204 20 100]/256;
            case 4, color = [204 0 202]/256;
        end
    case 8 % Paired comparisons, from dark to light
        switch iClass 
            % Green:
            case 1, color = [105 145  59]/350;
            case 2, color = [105 145  59]/200;
            % Red:
            case 3, color = [224 20 100]/400;
            case 4, color = [224 20 100]/255;
            % Blue:
            case 5, color = [ 72 145 220]/400;
            case 6, color = [ 72 145 220]/255;
        end
    case 9
        switch iClass 
            % Green:
            case 1, color = [105 145  59]/200;
            % red
            case 2, color = [225 0  0]/256;
        end
    case 10
        % this is the classification among:
        % 1=average
        % 2=+2std
        % 3=-2std
        switch iClass 
            % Gold:
            case 3, color = [255 255*0.7  0]/256;
            % Blue
            case 2, color = [0 0 225]/256;
        end
    case 11
        switch iClass 
            % Hypertensive by valve, a redish:
            case 1, color = [168 56 59]/256;
            % After solution by surgery, a blue:
            case 2, color = [170 121 57]/256;
            % Controls, a green
            case 3, color = [50 138 46]/256;            
            % Second kind of hypertensive
            case 4, color = [41 81 109]/256;
        end        
        
    otherwise
        fprintf('ERROR! Color scheme %i not defined!\n',colorscheme);
end
        
        
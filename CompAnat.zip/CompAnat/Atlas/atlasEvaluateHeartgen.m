function atlasEvaluateHeartgen(heartgenCallFile, rootFolder, sendReceiveFolder, CaseList, lobcderFile)
    
    if (nargin > 1)
        if numel(sendReceiveFolder) > 0
            atlasEvaluateHeartgenPumpkin(heartgenCallFile, rootFolder, sendReceiveFolder);
        else
            atlasEvaluateHeartgenLobcder(heartgenCallFile, rootFolder, CaseList, lobcderFile);
        end
    else
        atlasEvaluateHeartgenSequential(heartgenCallFile);    
    end
    
    %delete(heartgenCallFile);
end %function atlasEvaluateHeartgen(...)

function atlasEvaluateHeartgenSequential(heartgenCallFile)

    %execute the heartgen calls
    fid = fopen(heartgenCallFile, 'r');
    if (~fid)
       disp(['Error: unable to open heartgenCallFile' heartgenCallFile]) 
       return
    end
    lineCell = textscan(fid, '%s', 'Delimiter', '\n');
    lineArray = lineCell{1};
    CurrentDirectory = cd;
    for i = 1:numel(lineArray)
        r = regexp(lineArray{i}, ' ', 'split');
        
        caseDirectory = fileparts(r{1});
        cd(caseDirectory);
        %cd(fullfile(DataDirectory))
        disp(lineArray{i});
        eval(['heartgen2 ' lineArray{i}]);
    end
    % For some reason, fid is invalid at this stage of the script??
    %fclose(fid);
    cd(CurrentDirectory);
end %function atlasEvaluateHeartgenSequential(...)


function atlasEvaluateHeartgenLobcder(heartgenCallFile, rootFolder, CaseList, lobcderFile)
    %execute the heartgen calls
    fid = fopen(heartgenCallFile, 'r');
    if (~fid)
       disp(['Error: unable to open heartgenCallFile' heartgenCallFile]) 
       return
    end
    lineCell = textscan(fid, '%s', 'Delimiter', '\n');
    lineArray = lineCell{1};
    fclose(fid);
    nInputFile = numel(lineArray);
    
    
    nMaxVM = 10;
    nNodes = min(nInputFile, nMaxVM);
    nCasesPerNode = ceil(nInputFile / nNodes);
    zipFiles = cell(nNodes,1);
    nCaseArray = ones(nNodes,1) * 0;
    
    % split heartgenCallFile into heartgen.arg files placed next to the input
    for i = 1:nInputFile
        command = lineArray{i};
        commandParts = strsplit(command, ' ');
        commandPath = commandParts{1};
        commandArgs = sprintf('%s ', commandParts{2:end});
        argPath = fullfile(fileparts(commandPath), 'heartgen.arg');
        fid = fopen(argPath, 'w');
        fprintf(fid, '%s', commandArgs);
        fclose(fid);
    end
    
    
    dispatchfolder = fullfile(fileparts(fileparts(rootFolder)), 'Dispatch');
    if  ~exist(dispatchfolder, 'dir')
        mkdir(fileparts(dispatchfolder), 'Dispatch')
    end
    
    for i = 1:nNodes
        if i > 1
            nCaseStart = nCaseArray(i-1) + 1;
        else
            nCaseStart = 1;
            %nCaseStart = (i - 1) * nCasesPerNode + 1;
        end
        %nCaseEnd = min(i * nCasesPerNode, nInputFile);
        nCaseEnd = min(nInputFile, nCaseStart + round((nInputFile - nCaseStart) / (nNodes - i)) - 1);
        nCaseArray(i) = nCaseEnd;% - nCaseStart;
        zipname = fullfile(dispatchfolder, sprintf('AtlasData%03i-%03i.zip', nCaseStart, nCaseEnd));
        zipFiles{i} = zipname;
        zip(zipname, CaseList(nCaseStart:nCaseEnd), fileparts(CaseList{1}))
    end
    
    startLobcderHeartgen(zipFiles, lobcderFile);
    
    
end %function atlasEvaluateHeartgenLobcder(...)



function startLobcderHeartgen(zipFiles, lobcderFile)
    fid = fopen(lobcderFile, 'r')
    lineCell = textscan(fid, '%s', 'Delimiter', '\n');
    lineArray = lineCell{1};
    fclose(fid);
    
    lobcderContent = struct();
    for i = 1 : numel(lineArray)
       line = lineArray{i};
       a = strfind(line, ' ');
       lobcderContent = setfield(lobcderContent, line(1:a(1)-1), line(a(1):end));
    end
    
    cmdFile = fullfile(fileparts(lobcderFile), 'lobcdercmd.txt');
    zipFilesLobcder = uploadToLobcder(lobcderContent, zipFiles, cmdFile);
    
    % invoke heartgen_lobcder_worker
    callHeartgenLobcderWorker(zipFilesLobcder);
    
    
    downloadFromLobcder(lobcderContent, zipFiles, cmdFile);

end %function startLobcderHeartgen(...)

function zipFilesLobcder = uploadToLobcder(lobcderContent, zipFiles, cmdFile)

    writeNetRCFile(lobcderContent);
    
    zipFilesLobcder = cell(numel(zipFiles));
    
    % write file with commands to upload
    lobcderPath = getfield(lobcderContent, 'lobcderdir');
    fprintf(fid, 'cd %s', fileparts(lobcderPath));
    fid = fopen(cmdFile);
    for i = 1:numel(zipFiles)
        fprintf(fid, 'put %s\n', zipFiles{i});
        [zippath, zipname, zipext] = fileparts(zipFiles{i});
        zipFilesLobcder{i} = fullfile(fileparts(lobcderPath), [zipname zipext]);
    end
    fprintf(fid, 'exit\n');
    fclose(fid);
    
    [status, result] = system(['lobcder --rcfile=~/.netrc http://lobcder.vph.cyfronet.pl/lobcder/dav < ' cmdFile]);
    if status ~= 0
       disp(result);
       zipFilesLobcder = {};
    end
    
end %function uploadToLobcder(...)

function downloadFromLobcder(lobcderContent, zipFiles, cmdFile)

    writeNetRCFile(lobcderContent);
    
    % write file with commands to upload
    lobcderPath = getfield(lobcderContent, 'lobcderdir');
    fprintf(fid, 'cd %s', fileparts(lobcderPath));
    fid = fopen(cmdFile);
    for i = 1:numel(zipFiles)
        [zippath, zipname, zipext] = fileparts(zipFiles{i});
        sourcefile = fullfile(fileparts(lobcderPath), [zipname '_output.zip']);
        targetfile = fullfile(fileparts(lobcderPath), fileparts(sourecefile));
        fprintf(fid, 'get %s %s\n', sourcefile, targetfile);
    end
    fprintf(fid, 'exit\n');
    fclose(fid);
    
    [status, result] = system(['lobcder --rcfile=~/.netrc http://lobcder.vph.cyfronet.pl/lobcder/dav < ' cmdFile]);
    if status ~= 0
       disp(result);
    end
    
end %function downloadFromLobcder(...)

function writeNetRCFile(lobcderContent)
    
    fid = fopen('~/.netrc', 'w');
    fprintf(fid, 'machine lobcder.vph.cyfronet.pl\n');
    fprintf(fid, 'login %s\n', getfield(lobcderContent, 'login'));
    fprintf(fid, 'password %s\n', getfield(lobcderContent, 'password'));
    fclose(fid);
    
end %writeNetRCFile(...)


function callHeartgenLobcderWorker(zipFilesLobcder)
    % do something to invoke virtual machines as soon as it it running...

end %funciton callHeartgenLobcderWorker(...)

function atlasEvaluateHeartgenPumpkin(heartgenCallFile, rootFolder, sendReceiveFolder)


    ship = sprintf('%s', datestr(now))
    uuid = char(java.util.UUID.randomUUID);
    packageData = {
'    ['
'    {'
'        "box": "0",'
'        "fragment" :"0",'
'        "e": "E",'
['        "ship": "' ship '",']
['        "container": "' uuid '",']
'        "last_func" : "None",'
'        "stop_func" : "None",'
'        "state" : "New",'
'        "ttl" : "600",'
'        "t_otype" : "None",'
'        "t_state" : "None",'
'        "last_contact" : "None"'
'    },'
'    {},'
'    {'
'        "stag": "ImageArchiveZip:RAW",'
'        "data": "data/testzip.zip",'
'        "exstate": "0000",'
'        "func": ""'
'    }'
'    ]'
}
    %execute the heartgen calls
    fid = fopen(heartgenCallFile, 'r');
    if (~fid)
       disp(['Error: unable to open heartgenCallFile' heartgenCallFile]) 
       return
    end
    lineCell = textscan(fid, '%s', 'Delimiter', '\n');
    lineArray = lineCell{1};
    fclose(fid);
    nInputFile = numel(lineArray);
    inputFileName = cell(2*nInputFile,1);
    
    for i = 1:numel(lineArray)
        command = lineArray{i};
        commandParts = strsplit(command, ' ');
        commandPath = commandParts{1};
        commandArgs = sprintf('%s ', commandParts{2:end});
        argPath = fullfile(fileparts(commandPath), 'heartgen.arg');
        fid = fopen(argPath, 'w');
        fprintf(fid, '%s', commandArgs);
        fclose(fid);
        inputFileName(nInputFile+i) = {argPath(numel(fullfile(rootFolder, '../'))+1:end)};
        inputFileName(i) = {commandPath(numel(fullfile(rootFolder, '../'))+1:end)};
        
    end
    
    delete(fullfile(sendReceiveFolder, 'data', 'testzip_meshed.zip'));
    delete(fullfile(sendReceiveFolder, 'data', 'testzip.zip'));
    delete('testzip.zip')
    zip('testzip.zip', inputFileName, fullfile(rootFolder, '../'));
    movefile('testzip.zip', fullfile(sendReceiveFolder, 'data'));
    
    
    % system('cp testzip.zip sendFolder')
    id = numel(dir(fullfile(sendReceiveFolder, 'rx')));
    dataPackageFilename = ['DataPackage' num2str(id) '.pkt'];
    %fid = fopen(fullfile(sendReceiveFolder, 'rx', dataPackageFilename), 'w');
    fid = fopen(dataPackageFilename, 'w');
    fprintf(fid, '%s\n', packageData{:});
    fclose(fid);
    %movefile(dataPackageFilename, fullfile(sendReceiveFolder, 'rx'));
    system(['mv ' dataPackageFilename ' ' fullfile(sendReceiveFolder, 'rx')]);
    
    % wait for result to merge into folder
    while(1)
       %if(exist(fullfile(sendReceiveFolder, 'data', 'testzip_meshed.zip'), 'file'))
       if(exist(fullfile(sendReceiveFolder, 'data', 'testzip_meshed.done'), 'file'))
           break
       else
           pause(2)
       end
    end
    
    % merge results into folder
    unzip(fullfile(sendReceiveFolder, 'data', 'testzip_meshed.zip'), fullfile(rootFolder, '../'));
    delete(fullfile(sendReceiveFolder, 'data', 'testzip_meshed.done'));
    delete(fullfile(sendReceiveFolder, 'data', 'testzip_meshed.zip'));
end %function atlasEvaluateHeartgenPumpkin(...)
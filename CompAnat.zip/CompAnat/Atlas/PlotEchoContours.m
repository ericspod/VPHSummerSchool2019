function [] = PlotEchoContours(Dofs,color,LineWidth,bPoints,bEpiOnly)
% Function to plot the contours of the LV, accordingly to the convention
% adopted in the CalculateUSAtlas when assembling the degrees of freedom of
% the endo and epi contours

if nargin<2
    color = 'b';
end
if nargin<3
    LineWidth = 3;
end
if nargin<4
    bPoints = 0;
end
if nargin<5
    bEpiOnly = 0;
end

% The key is to "unfold" the reshape that put all dofs in one line:
% - The first half corresponds to endo, the second half to epi
% - 
nDofs = numel(Dofs);
nDxC = nDofs/2;
EndoDofs = Dofs(1:nDxC);
EndoDofs = reshape(EndoDofs,nDxC/2,2);
EpiDofs = Dofs(1+nDxC:end);
EpiDofs = reshape(EpiDofs,nDxC/2,2);

nElementsPerContour = (nDxC/4 - 1);

EndoCont = LinearMeshClass;
EndoCont = EndoCont.SetTopology(nElementsPerContour);
EpiCont = EndoCont;

EndoCont = EndoCont.SetDofs(EndoDofs);
EpiCont  = EpiCont.SetDofs(EpiDofs);

hold on;

if max(abs(EpiCont.dofs))>0
    EpiCont.plot(color,LineWidth,bPoints);
end
if(~bEpiOnly)
    if max(abs(EndoCont.dofs))>0
        EndoCont.plot(color,LineWidth,bPoints);
    end
end

view(-90,90);
axis 'equal';
%grid 'on';



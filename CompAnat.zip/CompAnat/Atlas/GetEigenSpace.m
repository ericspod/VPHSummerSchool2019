function [H] = GetEigenSpace(directory,eigvectors,options)
% Function to visualise the space of the eigencoordinates.
% 
% INPUT:
% - directory: where the atlas data and results are
% - eigvectors: integer of the shape coordinates to visualise. This should
% be a combination of:
%     One number: a 1D plot
%     Two numbers, a 2D plot
%     Three numbers, a 3D plot
% - options. A list of possibilities, among which:
%   - ClassDefinition: structure with the class corresponding to each ID
%   - iCond: an integer that codifies which experimental condition is used
%   to visualise. If iCond has more than one number, each of them will be
%   visualised as a different class.
%
% OUTPUT:
% - H: handle of the figure of the plot

ClassDefinition = NaN;
colourscheme = 1;
PlotSize = 1200;
bNewFig = 1;
bLoadCoefs = 1;

if nargin==3
    if isfield(options,'ListCases')
        casesIncluded = options.ListCases;
    end
    if isfield(options,'coefPCA')
        coefs = options.coefPCA ;
        bLoadCoefs = 0;
    end
    if isfield(options,'ClassDefinition')
        ClassDefinition = options.ClassDefinition;
    end   
    if isfield(options,'colourscheme'), colourscheme = options.colourscheme; end  
    if isfield(options,'PlotSize'),     PlotSize = options.PlotSize; end  
    if isfield(options,'bNewFig'),      bNewFig = options.bNewFig;   end
    if isfield(options,'bPlotCaseString'), optionsPlot.bPlotCaseString = options.bPlotCaseString; end
end

Fsize = 15;
nDim = numel(eigvectors);
if nDim>1 && bNewFig
    % If only one dimension, it's plotted in current axis in order to
    % enable a subplot array
    H = figure('color',[1 1 1],'OuterPosition',[0 -400 PlotSize PlotSize]);
    axes('FontSize',Fsize);
else
    H = NaN;
end

options.eigvectors2output = eigvectors;
options.ClassDefinition = ClassDefinition;
if isfield(options,'iCond')
    if numel(options.iCond)>1
        AllConds = options.iCond;
        % Visualise as if they were different classes:
        for iC = 1:numel(AllConds)
            options.iCond = AllConds(iC);            
            [coefs,cases,~,casesIncluded] = GetEigenCoefficients(directory,options);
            %PlotCoordinates(coefs,cases,eigvectors,ClassDefinition,casesIncluded,colourscheme,Fsize,iC);
            PlotCoordinatesTest(coefs,cases,eigvectors,ClassDefinition,casesIncluded,0);            
        end
        title('Coordinate space');
        return;
    end
end
if(bLoadCoefs)
    [coefs,cases,~,casesIncluded] = GetEigenCoefficients(directory,options);
end
optionsPlot.Fsize = Fsize;
optionsPlot.colourscheme = colourscheme;

%PlotPCAcoordinates(coefs,cases,eigvectors,ClassDefinition,casesIncluded,optionsPlot);
PlotPCAcoordinates(coefs,casesIncluded,eigvectors,ClassDefinition,casesIncluded,optionsPlot);


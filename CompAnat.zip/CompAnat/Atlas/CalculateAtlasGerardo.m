function [] = CalculateAtlasGerardo(directory,options)
% Function to calculate an atlas of all shapes contained in a given
% directory.

iCase0 = 20;
iCase1 = iCase0; %'end';
bOnlyGenerateAtlasStatistics = 0;
topology = 'LV';

% Naming of files:
surname                     = '';
BinaryName                  = 'BinaryMask.vtk';
GrayscRootName              = 'Grayscale';
SubDirectory                = '/';

% Optional steps:
bRemoveOutputFolders        = 0;
bUnzipImages                = 0;
bMoveBinaries2Folders       = 0;
bCorrectGrayscale2SegmentationOrientation = 0;
bStep0_ExtractSegmentation  = 0;
    bForceGetEDframeFromSA  = 0;
    
bStep0_Alternative          = 0;
    RefDir                  = 'E:\data\JR\Atlas_v2.1\';
    
% Main steps:    
bStep1_GenerateMeshes       = 1;
    LoD                     = 3;
    bRVdirFromSA            = 0;
    bGenerateReports        = 1;
    bForceRecreationMeshes  = 1;
bStep2_GenerateAtlas        = 1;
    Cases2exclude           = [];%[61];
bDeleteImages               = 0;

bSelectedCases              = 0;
AtlasFileName               = 'Atlas.mat';

bRVpoolLabel                = 0;
MyoLabel                    = NaN;
bListOfCases = 0;
CaseDirectories             = '';

bUseDerivativesSubset = 0; %Whether to keep all derivatives in further PCA study
bUseWallThicknessOnly = 0;

postfix = '/AtlasData/';

bOnlyGenerateAtlasStatisticsFromSource = 0;
sourceFilesDir = '';
bStep2_GenerateAtlasFromSource = 0;

bComputeAPrioriPCA = 0;
bPerformResidualPCA = 0;
bCLagrange4CornersOnly = 0; %get only 4 nodes in each face of cLagrange, instead of default 16 nodes
bAvoidMeanSubstrationInPCA = 0; %Do not substract mean to make PCA (for testing purposes)

if nargin==2
%     if isfield(options,'RefDir')
%         RefDir = options.RefDir;
%     end
    if isfield(options,'Cases2include')
        Cases2include = options.Cases2include;
        bSelectedCases = 1;
    end
    if isfield(options,'AtlasFileName'), AtlasFileName = options.AtlasFileName; end
    if isfield(options,'bRVdirFromSA'),  bRVdirFromSA  = options.bRVdirFromSA;  end
    if isfield(options,'LoD'),           LoD = options.LoD;  end
    if isfield(options,'topology'),      topology = options.topology;  end
    if isfield(options,'SubDirectory'),  SubDirectory = options.SubDirectory;  end
    if isfield(options,'BinaryName'),    BinaryName = options.BinaryName;  end
    if isfield(options,'bOnlyGenerateAtlasStatistics'), bOnlyGenerateAtlasStatistics = options.bOnlyGenerateAtlasStatistics; end
    if isfield(options,'bCorrectGrayscale2SegmentationOrientation'), bCorrectGrayscale2SegmentationOrientation = options.bCorrectGrayscale2SegmentationOrientation; end    
    if isfield(options,'surname'),       surname  = options.surname;  end
    if isfield(options,'RVpoolLabel'),   bRVpoolLabel = 1; RVpoolLabel = options.RVpoolLabel; end
    if isfield(options,'MyoLabel'),      MyoLabel = options.MyoLabel; end    
    if isfield(options,'postfix'),       postfix = options.postfix; end   
    if isfield(options,'ListOfCases')
        ListOfCases = options.ListOfCases;
        bListOfCases = 1;
    end
    
    if isfield(options,'surnameCases'),    surnameCases = options.surnameCases; end      
    if isfield(options,'surnameID'),       surnameID = options.surnameID; end      
    
    if isfield(options,'bUseDerivativesSubset'), bUseDerivativesSubset = options.bUseDerivativesSubset; end      
    if isfield(options,'CaseDirectories'),  CaseDirectories = options.CaseDirectories; end
    if isfield(options,'bUseMedialAxis'),  bUseMedialAxis = options.bUseMedialAxis; end
    if isfield(options,'bUseWallThicknessOnly'),  bUseWallThicknessOnly = options.bUseWallThicknessOnly; end
    
    if isfield(options,'bUseEpiNodes'),  bUseEpiNodes = options.bUseEpiNodes; end
    if isfield(options,'bUseEndoNodes'),  bUseEndoNodes = options.bUseEndoNodes; end
    if isfield(options,'bOnlyGenerateAtlasStatisticsFromSource'), bOnlyGenerateAtlasStatisticsFromSource = options.bOnlyGenerateAtlasStatisticsFromSource; end
    if isfield(options,'SourceFilesDir'), SourceFilesDir = options.SourceFilesDir; end
    
    if isfield(options,'bComputeAPrioriPCA'), bComputeAPrioriPCA = options.bComputeAPrioriPCA; end
    if isfield(options,'bPerformResidualPCA'), bPerformResidualPCA = options.bPerformResidualPCA; end
    if isfield(options,'bCLagrange4CornersOnly'), bCLagrange4CornersOnly = options.bCLagrange4CornersOnly; end    
    if isfield(options,'bAvoidMeanSubstrationInPCA'), bAvoidMeanSubstrationInPCA = options.bAvoidMeanSubstrationInPCA; end    
end


bDataCompletenessAnalysis   = 0;

if(bOnlyGenerateAtlasStatistics)
    bUnzipImages                = 0;
    bMoveBinaries2Folders       = 0;
    bCorrectGrayscale2SegmentationOrientation = 0;
    bStep0_ExtractSegmentation  = 0;
    bStep1_GenerateMeshes       = 0;
    bStep2_GenerateAtlas        = 1;
    bDeleteImages               = 0;
        
    if(bOnlyGenerateAtlasStatisticsFromSource) %data from source (text) files
        bStep2_GenerateAtlas        = 0;
        bStep2_GenerateAtlasFromSource = 1;
    end
    
end




CompressedInitialData = [directory '/EVScontours/'];
DataDirectory = [directory postfix];
OutputDirectory = [directory '/AtlasOutput/']; 
CurrentDirectory = pwd;

if(bUnzipImages)
    directZIP = dir(CompressedInitialData);
    nCasesZIP = numel(directZIP) - 2;
    for iCase = iCase0:nCasesZIP
        iD = iCase + 2;  
        ItemName = directZIP(iD).name;
        if ~strcmp(ItemName(1),'.')
            CaseDirectory = [CompressedInitialData ItemName];
            ZipFile = CaseDirectory;
            % The string of the case is up to the first '.'
            I = find(ItemName == '.');
            CaseString = ItemName(1:I(1)-1);
            DestinyDir = [DataDirectory CaseString];
            if ~exist(DestinyDir)
                mkdir(DestinyDir);
            end
            system(sprintf('unzip.exe "%s" -d "%s"',ZipFile,DestinyDir));
        end
    end
end

if(bMoveBinaries2Folders)
    ListOfFiles = dir (DataDirectory);
    character2defineName = '.';
    CreateFolders(ListOfFiles,DataDirectory,character2defineName);    
end

if(bStep0_Alternative)
    direct = dir([RefDir 'AtlasData/']);
else
    direct = dir(DataDirectory);
end
nCases = numel(direct) - 2;
if iCase1 == 'end';
    iCase1 = nCases;
end
if strcmp(BinaryName,'SubDirectoryName')
    bSearchSubDirectoryNameFile = 1;
else
    bSearchSubDirectoryNameFile = 0;
end

if(bCorrectGrayscale2SegmentationOrientation)
    % Hack to align the UCL segmentations to the original grayscales:
    for iCase = iCase0:iCase1
        iD = iCase + 2;
        CaseDirectory = [DataDirectory direct(iD).name SubDirectory];
        if bSearchSubDirectoryNameFile
            BinaryName = SearchSubDirectoryNameFile(direct,iD,CaseDirectory,surname);        
        end        
        % Read the binary mask:
        [segm,hd] = io_ReadMedicalImage([CaseDirectory BinaryName]);
        % Permutation (rotations):
        segm = permute(segm,[2 3 1]);
        segm = segm(:,end:-1:1,:);
        segm = segm(end:-1:1,:,:);
        % Get the correct header (from grayscale image):
        GrayscName = sprintf('%s%03i.gipl',GrayscRootName,iCase);
        [gray,hdgray] = io_ReadMedicalImage([CaseDirectory GrayscName]);
        if~isnan(gray)
            NewSurname = 'R';
            NewName = [direct(iD).name NewSurname '.gipl'];
            io_WriteMedicalImage([CaseDirectory NewName],segm,hdgray);
        end
    end
end


ErrorStep0 = NaN* ones(1,nCases);

if(bRemoveOutputFolders)
    for iCase = iCase0:iCase1
        iD = iCase + 2;
        CaseDirectory = [DataDirectory direct(iD).name SubDirectory];
        Files2delete = [CaseDirectory 'Output_heartgen\*'];
        fprintf('Removing %s\n', Files2delete);
        delete(Files2delete);
        Files2delete = [CaseDirectory 'Output_heartgen\temp\*'];
        fprintf('Removing %s\n', Files2delete);
        delete(Files2delete);
    end   
end


if(bStep0_ExtractSegmentation)
    fprintf('------------------------------------------------------------\n');
    fprintf(' 0. Extract segmentations from Argus export\n');
    fprintf('------------------------------------------------------------\n');
    for iCase = iCase0:iCase1
        iD = iCase + 2;
        CaseDirectory = [DataDirectory direct(iD).name SubDirectory];
        options.bForceGetEDframeFromSA = bForceGetEDframeFromSA;
        options.topology = topology;
        [mask,bSearchForRVcircle,bError] = GetSegmentationMaskFromArgusOutput(CaseDirectory,options);
        ErrorStep0(iCase) = bError;
    end
end
%figure, plot(ErrorStep0);


if(bStep1_GenerateMeshes)
    fprintf('------------------------------------------------------------\n');
    fprintf(' 1. Generate meshes\n');
    fprintf('------------------------------------------------------------\n');
    for iCase = iCase0:iCase1
        close all;
        WallT = NaN;
        iD = iCase + 2;
        CaseDirectory = [DataDirectory direct(iD).name SubDirectory];
        if bSearchSubDirectoryNameFile
            BinaryName = SearchSubDirectoryNameFile(direct,iD,CaseDirectory,surname);        
        end
        if ~isnan(BinaryName)
            MeshName = [RemovePathAndExtension(BinaryName) '_mesh'];
            if(bStep0_Alternative)
                % Copy the images and data from existing folder (RefDir):
                RefCaseDir = [RefDir 'AtlasData/' direct(iD).name SubDirectory];
                if ~exist(CaseDirectory,'dir')
                    mkdir(CaseDirectory);
                end
                if exist([RefCaseDir BinaryName],'file')
                    copyfile([RefCaseDir BinaryName],[CaseDirectory BinaryName]);
                    copyfile([RefCaseDir 'RVPosition.mat'],[CaseDirectory 'RVPosition.mat']);
                end
            end
            if exist([CaseDirectory BinaryName],'file')
                if(bRVdirFromSA)
                    RVdirFile = [CaseDirectory 'RVPosition.mat'];
                    if exist(RVdirFile,'file')
                        % The RV position was given in the image
                        load([CaseDirectory 'RVPosition.mat']);
                        %... this loads the variable RVdirection 
                        RVdir = RVdirection;
                        if isnan(WallThPix.TrueOne)
                            if isnan(WallThPix.FromDispersion)
                                fprintf('WARNING! Wall thickness not available in this case\n');                        
                            else
                                WallT = WallThPix.FromDispersion;
                            end
                        else
                            WallT = WallThPix.TrueOne;
                        end
                        % Convert WallTh to physical units (header loaded from
                        % 'RVPosition.mat')
                        if exist('hd','var')
                            WallT = WallT * mean(hd.spacing(1:2));
                        else
                            fprintf('ERROR! Variable "hd" does not exist as expected\n');
                        end
                    else
                        fprintf('ERROR! No mesh generated: right Ventricle direction and wall thickness not available in this case\n');
                        fprintf('  File: %s\n',RVdirFile);
                    end
                end
                MeshDirectory = [CaseDirectory 'Output_heartgen/'];
                if ~exist([MeshDirectory MeshName '.exnode'])||bForceRecreationMeshes
                    % Create the mesh:
                    cd(CaseDirectory);

                    % Change 11/03/2013: rely on the WallT
                    % computation inside heartgen2!
    %                            heartgen2([CaseDirectory BinaryName],'-HeartType','LV','-nE',6,12,1,'-LoD',LoD,'-RVdir',RVdir(1),RVdir(2),'-WallT',WallT,'-bReport',bGenerateReports);
                    if(bRVdirFromSA)
                        heartgen2([CaseDirectory BinaryName],'-HeartType',topology,'-MyoLabel',MyoLabel,'-nE',6,12,1,'-LoD',LoD,'-RVdir',RVdir(1),RVdir(2),'-bReport',bGenerateReports);
                    else
                        if(bRVpoolLabel)
                            heartgen2([CaseDirectory BinaryName],'-HeartType',topology,'-MyoLabel',MyoLabel,'-nE',6,12,1,'-LoD',LoD,'-RVpoolLabel',RVpoolLabel,'-bReport',bGenerateReports);
                        else
                            heartgen2([CaseDirectory BinaryName],'-HeartType',topology,'-MyoLabel',MyoLabel,'-nE',6,12,1,'-LoD',LoD,'-bReport',bGenerateReports);
                        end
                    end                            
                    cd(CurrentDirectory);
                end
            end
        end
    end
end    

%Generate eigenvalues
TemplateDirectory = 'E:\data\GG\';
TemplateMeshName = 'LV6121cH'; %template of canonical LV mesh used to generate apriori eigvectors
OutputMeshDirectory = [TemplateDirectory 'Output_heartgen/'];

bGenerateAtlasVectors = 0;
EigVector1 = nan;

if bGenerateAtlasVectors %This will not be used, canonical mesh doesn't represent a current subject's anatomy
    %load LV template to perform N deformations on this shape
    %PCA will be done on the deformed shapes to obtain the eigenvectors
    %corresponding to the different deformations (elongation, epi/endo
    %changes, etc).
    if exist([TemplateDirectory TemplateMeshName '.exnode'],'file')
        CHTemplate = CubicMeshClass([TemplateDirectory TemplateMeshName]);
        CHTemplate = SolveRigidBodyMotion(CHTemplate,OutputMeshDirectory);
        TemplateModel(:,:) = CHTemplate.GetDofs();
        nDofs = size(CHTemplate.GetDofs());
        [k,m,n] = size(TemplateModel);
        %Perform shape changes according to modes of variation
        modalOptions.OutputDirectory = OutputDirectory;
        modalOptions.directory = directory;

        %types of deformation
        modalOptions.bAxisElongation = 1;
        modalOptions.bEpiChange = 0;
        modalOptions.bEndoChange = 0;
        modalOptions.bBasalRadiusChange = 0;

        nTempValidCases = 3;
        for i = 1:nTempValidCases
            %set extreme values for each loop to force shape changes in this dimension
            %when calculating the PCA, eigenvalues will result in the
            %direction of most change (variability)            
            modalOptions.elongationDelta = i+1; 
            %modalOptions.epiScaleDelta = i+1; %...etc

            model = CreateShapeModalVariations(CHTemplate, TemplateModel, modalOptions, i);
            %store current model in matrix of models
            TemplateMatrixDofs(i,:,:) = model;
            %reshape above matrix to store elements in a linear way
            TemplateDofsInLine(i,:) = reshape(TemplateMatrixDofs(i,:,:),1,prod(nDofs));
        end

        ValidTemplateMatrixDofs = TemplateMatrixDofs; %copy all shapes
        ValidTemplateDofsInLine = TemplateDofsInLine; 

        %PCA on deformed shapes to get eigenvalues
        TemplateDofsMeanShape = mean(ValidTemplateMatrixDofs,1);	%mean among all models (matrix as k,m,n)
        TemplateDofsMeanShape = squeeze(TemplateDofsMeanShape);     %reduce matrix dimension to (m,n) 

        TemplateMeanDofsLn = reshape(TemplateDofsMeanShape,1,prod(nDofs));  %copy to linear array (1,n)
        TemplateMatrixDofsWithoutMean = ValidTemplateDofsInLine - repmat(TemplateMeanDofsLn,nTempValidCases,1); 
        TempB = TemplateMatrixDofsWithoutMean;
        TempCOV = TempB'*TempB/nTempValidCases;
        %fprintf('Eigenanalysis of template covariance matrix of size %ix%i\n',size(TempCOV));
        [TempV,TempS] = eig(TempCOV);
        Tempss = diag(TempS);

        EigVector1 = TempV(:,end); %elongation PC1
    end
end

if(bStep2_GenerateAtlasFromSource)
    fprintf('------------------------------------------------------------\n');
    fprintf(' 2. Make the statistics From Source Files\n');
    fprintf('------------------------------------------------------------\n');
    if ~exist(OutputDirectory,'dir')
        mkdir(OutputDirectory);
    end
    %bValidCases = zeros(1,nCases);
    bDofSizeDefined = 0;
    
    
    direct = dir(SourceFilesDir); 
    %sizeDir = numel(direct);
        
    nCasesSource = numel(direct) - 2;
    
    for iCase = 1 : nCasesSource        
        iD = iCase + 2; % to ignore . and ..
        CaseFileName = direct(iD).name;
        sFile = importCoordsFile([SourceFilesDir CaseFileName]);
        nDofs = size(sFile);
        
        %data points are assumed to be centered (as given by ShapeWorks)
        
        MatrixDofs(iCase,:,:) = sFile;
        DofsInLine(iCase,:) = reshape(MatrixDofs(iCase,:,:),1,prod(nDofs));
        bValidCases(iCase) = 1;
        
    end
    % Reduce the matrix to the number of valid cases:
    MartrixValidDofs = MatrixDofs(find(bValidCases),:,:);
    ValidDofsInLine  = DofsInLine(find(bValidCases),:);
    nValidCases = numel(find(bValidCases));
    fprintf('Analysis with %i valid cases\n',nValidCases);
    
    % Principal component analysis of the dofs:
    DofsMeanShape = mean(MartrixValidDofs,1);	%mean among all models (matrix as k,m,n)
    DofsMeanShape = squeeze(DofsMeanShape);     %reduce matrix dimension to (m,n)        
    
    %CH = CubicMeshClass(); %We won't use it, but save it for compatibility while saving
    CHmean = DofsMeanShape;
    
    MeanDofsLn = reshape(DofsMeanShape,1,prod(nDofs));  %copy to linear array (1,n)
    MatrixDofsWithoutMean = ValidDofsInLine - repmat(MeanDofsLn,nValidCases,1); 
    B = MatrixDofsWithoutMean;
    COV = B'*B/nValidCases;
    fprintf('Eigenanalysis of covariance matrix of size %ix%i\n',size(COV));
    [V,S] = eig(COV);
    ss = diag(S);
    
    save([OutputDirectory 'Atlas.mat'],'V','ss','CHmean','direct'); %save original PCA from all current cases
    
end

if(bStep2_GenerateAtlas)
    fprintf('------------------------------------------------------------\n');
    fprintf(' 2. Make the statistics\n');
    fprintf('------------------------------------------------------------\n');
    if ~exist(OutputDirectory,'dir')
        mkdir(OutputDirectory);
    end
    bValidCases = zeros(1,nCases);
    bDofSizeDefined = 0;
    
    %load images as normal (this is for internal debugging)
    bReadImagesFromSource = 1;%0; 
    
   if(bReadImagesFromSource)
        
    if(bSelectedCases)
        nCasesForPCA = numel(Cases2include);
    else
        nCasesForPCA = nCases;
    end
    
    if(bListOfCases)
        nCasesForPCA = numel(ListOfCases);
    end
    
    for iCase = 1:nCasesForPCA

        if(~isempty(CaseDirectories))
            CaseDir = options.CaseDirectories(iCase).name;
        else
            iD = iCase + 2;
            CaseDir = direct(iD).name;
        end
        CaseDirectory = [DataDirectory CaseDir SubDirectory];
        if bSearchSubDirectoryNameFile
            BinaryName = SearchSubDirectoryNameFile(CaseDir,CaseDirectory,surname);        
        end        
        if ~isnan(BinaryName)
            MeshName = [RemovePathAndExtension(BinaryName) '_mesh']; %GG
            MeshDirectory = [CaseDirectory 'Output_heartgen/'];
            CaseNumber = GetNumberFromName(CaseDir);
            if find(Cases2exclude == CaseNumber)>0
                fprintf('Case %i is excluded\n',CaseNumber);
            else
                if exist([MeshDirectory MeshName '.exnode'],'file')
                    CH = CubicMeshClass([MeshDirectory MeshName]);                    
                                            
                     if (~bDofSizeDefined && (~bUseMedialAxis && ~bUseWallThicknessOnly)...
                         && (~bUseEpiNodes && ~bUseEndoNodes) ) %don't pre-assign size if bUseMedialAxis is used                        
                        nDofs = size(CH.GetDofs());
                        MatrixDofs = zeros(nCases,nDofs(1),nDofs(2));
                        DofsInLine = zeros(nCases,prod(nDofs));                        
%                         ModifiedMatrixDofs = zeros(nCases,nDofs(1),nDofs(2)); %is this needed?
%                         ModifiedDofsInLine = zeros(nCases,prod(nDofs));                        
                        bDofSizeDefined = 1;                                               
                     end
                    

                    
                    CH = SolveRigidBodyMotion(CH,CaseDirectory);
                    
                    %bUseDerivativesSubset=0; %GG
                    if(bUseDerivativesSubset) %Don't use all derivatives in normal meshes                   
                        %derivativesList is the list of derivatives indices in the form:
                        %derivativesList = [duds1 duds2 duds3 duds12 duds13 duds23 duds123]
                        derivativesList = [0 0 0 0 0 0 0]; %keep no derivatives
                        model = NeglectMeshDerivatives(CH.GetDofs(), derivativesList, CH.nNodes);                    
                        CH = CH.SetDofs(model);
                    end
                    
                    if(bUseMedialAxis)  %medial axis plus wall thickness                                                                  
                        [medialAxisInfo CHMedialAxis] = MedialAxis(CH);
                        medialAxisNodes = medialAxisInfo(:,1:4); %get only x,y,z coords (4th column is wall thickness)
                        nDofs = size(medialAxisNodes); 
                        MatrixDofs(iCase,:,:) = medialAxisNodes;     
                    elseif(bUseWallThicknessOnly)
                        bSaveSkeleton = 0;
                        [medialAxisInfo, CHMedialAxis] = MedialAxis(CH, bSaveSkeleton);
                        medialAxisNodes = medialAxisInfo(:,4:4); %get only wall thickness info
                        nDofs = size(medialAxisNodes); 
                        MatrixDofs(iCase,:,:) = medialAxisNodes; 
                        MatrixWallThicknessDofs(iCase,:,:) = CHMedialAxis.GetDofs();
                    elseif(bUseEpiNodes || bUseEndoNodes) %surface nodes
                        
                        surfaceNodePos = [];
                        if(bUseEpiNodes)
                            chdofs = CH.GetDofs();
                            epiNodesIdx = CH.FindEpiNodes(bCLagrange4CornersOnly);
                            EpiNodePos  = chdofs(epiNodesIdx,:);
                            surfaceNodePos = [surfaceNodePos; EpiNodePos];
                        end                   
                        if(bUseEndoNodes)
                            chdofs = CH.GetDofs();
                            endoNodesIdx = CH.FindEndoNodes(bCLagrange4CornersOnly);
                            EndoNodePos  = chdofs(endoNodesIdx,:);
                            surfaceNodePos = [surfaceNodePos; EndoNodePos];
                        end
                    
                        nDofs = size(surfaceNodePos); 
                        MatrixDofs(iCase,:,:) = surfaceNodePos;   
                    else                        
                        MatrixDofs(iCase,:,:) = CH.GetDofs();
                    end
                    
                    DofsInLine(iCase,:) = reshape(MatrixDofs(iCase,:,:),1,prod(nDofs));
                    bValidCases(iCase) = 1;
                    
                    LVCaseNumber(iCase) = CaseNumber;
                    
                    bCalculate2DMeshMeaurements = 0; %GG
                    if(bCalculate2DMeshMeaurements)
                        
                        %calculate LV length for each mesh
                        LVLenght(iCase) = LVMeasurements(CH, 'LVLength');
                        %calculate LV lumen/external diameter for each mesh                    
                        LVLumenDiameter(iCase) = LVMeasurements(CH, 'LumenDiameter');
                        LVExternalDiameter(iCase) = LVMeasurements(CH, 'ExternalDiameter');
                    end
                    
                    %Perform a-priori shape changes according to modes of variation
                    modalOptions.OutputDirectory = OutputDirectory;
                    modalOptions.directory = directory;
                    
                end
            end                        
        end
    end
    % Reduce the matrix to the number of valid cases:
    MartrixValidDofs = MatrixDofs(find(bValidCases),:,:);
    ValidDofsInLine  = DofsInLine(find(bValidCases),:);
    nValidCases = numel(find(bValidCases));
    fprintf('Analysis with %i valid cases\n',nValidCases);
    % Remove the rigid translation:

    if(bCalculate2DMeshMeaurements)
        %save LV measurements data
        save([OutputDirectory 'LVMeasurements'],'LVCaseNumber','LVLenght','LVLumenDiameter','LVExternalDiameter'); 
    end
    
%     %Store deformed shapes into matrices
%     ValidModifiedMatrixDofs = ModifiedMatrixDofs(find(bValidCases),:,:); %is this needed?
%     ValidModifiedDofsInLine = ModifiedDofsInLine(find(bValidCases),:);

    
    % Principal component analysis of the dofs:
    DofsMeanShape = mean(MartrixValidDofs,1);	%mean among all models (matrix as k,m,n)
    DofsMeanShape = squeeze(DofsMeanShape);     %reduce matrix dimension to (m,n)        
    
    if(bUseMedialAxis)                        
        MedialAxisMean = DofsMeanShape;
        save([OutputDirectory 'MedialAxisMean.mat'],'MedialAxisMean'); 
        CHmean = SetMedialAxisMesh( CH, MedialAxisMean ); %create new mesh with medial axis skeleton
    elseif(bUseWallThicknessOnly)
        MedialAxisMean = DofsMeanShape;
        save([OutputDirectory 'MedialAxisMean.mat'],'MedialAxisMean');
        %CHmean = CH;  %just copy last CH mesh (we may not use it)
        
        MartrixWallThicknessValidDofs = MatrixWallThicknessDofs(find(bValidCases),:,:);
        DofsMeanShapeWallThickness = mean(MartrixWallThicknessValidDofs,1);
        DofsMeanShapeWallThickness = squeeze(DofsMeanShapeWallThickness);
        CHmean = CH.SetDofs(DofsMeanShapeWallThickness); 
    elseif(bUseEpiNodes || bUseEndoNodes) %surface nodes
        SurfaceNodesMean = DofsMeanShape;
        save([OutputDirectory 'SurfaceNodesMean.mat'],'SurfaceNodesMean','ValidDofsInLine','DofsMeanShape');
        CHmean = CH;  %just copy last CH mesh (we may not use it)
    else
        CHmean = CH.SetDofs(DofsMeanShape);        
    end
           
    CHmean.name = 'Mean';
    CHmean.GroupName = 'Mean';
    CHmean.WriteExFiles(OutputDirectory);
    
    MeanDofsLn = reshape(DofsMeanShape,1,prod(nDofs));  %copy to linear array (1,n)
    MatrixDofsWithoutMean = ValidDofsInLine - repmat(MeanDofsLn,nValidCases,1); 
    if(bAvoidMeanSubstrationInPCA) %Do not substract mean to make PCA (for testing purposes)
        MatrixDofsWithoutMean = ValidDofsInLine; 
    end
    B = MatrixDofsWithoutMean;
    COV = B'*B/nValidCases;
    fprintf('Eigenanalysis of covariance matrix of size %ix%i\n',size(COV));
    [V,S] = eig(COV);
    ss = diag(S);
    
    save([OutputDirectory AtlasFileName],'V','ss','CHmean'); %save original PCA from all current cases
    
    MeshCoordinatesFileName = 'MeshCoordinates.mat'; %used in case we want to load specific a-priori eigenvectors
    save([OutputDirectory MeshCoordinatesFileName],'MeanDofsLn','ValidDofsInLine'); 
    
    
    end %end read images from source

end



if(bDataCompletenessAnalysis)
    cases = iCase0:nCases;
    BinaryMissing = ones(1,numel(cases));
    RVorieMissing = ones(1,numel(cases));
    for iCase = cases
        iD = iCase + 2;
        CaseDirectory = [DataDirectory direct(iD).name SubDirectory];
        % The unzip step is not checked, since there is no much point in that

        % The segmentation from argus should have:
        File = [CaseDirectory SubDirectory 'RVposition.mat'];
        if exist(File,'file')
            RVorieMissing(iCase) = 0;
            Names2plotRV(iCase).name = '';
        else
            Names2plotRV(iCase).name = direct(iD).name;
        end
        % The file with the RV orientation:
        File = [CaseDirectory SubDirectory 'BinaryMask.vtk'];
        if exist(File,'file')
            BinaryMissing(iCase) = 0;
            Names2plot(iCase).name = '';
        else
            Names2plot(iCase).name = direct(iD).name;
        end
        
    end
    figure('color',[1 1 1],'OuterPosition',[-400 600 12000 500]);
    subplot(211)
    imagesc(BinaryMissing);
    set(gca,'XTick',cases);    
    set(gca,'XTickLabel',{Names2plot(cases).name});
    title('Cases with binary mask missing')
    subplot(212)
    imagesc(RVorieMissing);
    set(gca,'XTick',cases);    
    set(gca,'XTickLabel',{Names2plotRV(cases).name});
    title('Cases with RV orientation missing')
end

if(bDeleteImages)
    for iCase = 1:nCases
        iD = iCase + 2;
        CaseDirectory = [DataDirectory direct(iD).name SubDirectory];
        if exist(CaseDirectory,'dir')
            %ZipFile = [CaseDirectory '/images.zip'];
            Files2zip = [CaseDirectory '/*.IMA'];
            %system(sprintf('zip.exe "%s" "%s"',ZipFile,Files2zip));
            delete(Files2zip);
        end
        TempMeshingDirectory = [DataDirectory direct(iD).name SubDirectory '/Output_heartgen/temp'];
        if exist(TempMeshingDirectory,'dir')
            Files2zip = [TempMeshingDirectory '/*.tiff'];
            delete(Files2zip);
            Files2zip = [TempMeshingDirectory '/*.vtk'];
            delete(Files2zip);
        end
    end
end
end



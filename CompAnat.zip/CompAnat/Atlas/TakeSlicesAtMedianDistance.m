function [NewDistance,NewIm,NewIed] = TakeSlicesAtMedianDistance(Distance,im,Ied)
% Function to take the slices that have the median distance between them.

[nX nY nSlicesIn] = size(im);

[DistancesOrdered,I2] = sort(Distance,'ascend');
Increment = DistancesOrdered(2:end) - DistancesOrdered(1:end-1);
% Analyse the sequence of "Distance", and get the "median"
GoodSpacing = mode(round(Increment*10000))/10000;
% Evaluate two guesses of good distances, from first and second:
epsilon = 0.01;
for iEval = 1:8
    First = DistancesOrdered(iEval);
    NewDis = First + [0:1:nSlicesIn]*GoodSpacing;
    iDf = 0;
    % Find the number of distances present:
    for iD = 1:nSlicesIn
        Dist = Distance(iD);
        if numel(find(abs(NewDis - Dist) < epsilon)) == 1
            iDf =  iDf + 1;
            NewI(iEval,iDf) = Ied(iD);
            NewIloc(iEval,iDf) = iD;
        end
    end
    Metric(iEval) = iDf;
end
% Get the one with highest metric:
I = find(Metric==max(Metric));
NewIed = NewI(I(1),1:max(Metric));
NewIlocal = NewIloc(I(1),1:max(Metric));
NewDistance = Distance(NewIlocal);
NewIm = im(:,:,NewIlocal);


function [Classes,VectorClass,CaseMapping] = OrderExcelDataInClassStructure(ClassDef,DataDirectory,options)
%function [Classes,VectorClass,CaseMapping] = OrderExcelDataInClassStructure(ClassDef,DataDirectory,Study,classDefColumn) %%Old

% INPUT:
% - options:
%      ... iColumnClass: column in the excel file with the info about the
%      class (in case multiple classification criterions).
%      ... Study: Option to codify which study, and which paramters, to get:
%      1: on the 226 patients, get one of the three classes
%      2: on the pre-terms, get preeclampsia class
%      3: on the pre-terms, get gestational age class
% OUTPUT:
% - Classes: an array of definition of a class, each with:
%      *TypeInFile: a variable with the label given to the class in the
%      excel file
%      *IndexingChoice: a boolean between 1 (by PatID) or 0 (by MeshID)
%      *PatID: an array with all numbers of the Patient ID (number in the folder name)
%      *MeshID: an array with the mesh ID - there could be several meshes
%      from the same PatID
%      *FileID: an array with all indexes of the patient folder (number of folder)
%      *Indexes: an array with all local indexes, from 1 to the number of
%      valid patients in each class
% - CaseMapping: an array with the mapping between PatID and FileID
%      *CaseMapping(iValidCase).PatID = PatID;
%      *CaseMapping(iValidCase).FileID = FileID;

% THE CORRESPONDING EXCEL FILE NEEDS TO HAVE BEEN READ BEFOREHAND!
bDebug = 0;

% Default options
Study = 0;
iColumnClass = 2;
bTxt = 0;
bForceGetText = 0;
bSelectOrigMesh=0;

bPermutation = 0;

VectorClass = [];
CaseMapping = [];

if nargin >= 3
    if isfield(options,'Study'), Study = options.Study; end
    if isfield(options,'iColumnClass'), iColumnClass = options.iColumnClass; end
    if isfield(options,'txt'), txt = options.txt; bTxt=1; end
    if isfield(options,'bForceGetText'), bForceGetText = options.bForceGetText; end
    if isfield(options,'bSelectOrigMesh'), bSelectOrigMesh = options.bSelectOrigMesh; end
    if isfield(options,'bPermutation'), bPermutation = options.bPermutation; end
    
end

if(bTxt)
    % xlsread will return the ID of cases as a string if it has not only
    % digits (like in epoch001):
    [nExpectedCases, nFields] = size(ClassDef);
    nStrings = size(txt);
    % The default option is to have the first raw in the excel with a
    % legend, so the first valid case is the raw 2:
    i0 = 2;
    if nStrings(1) == nExpectedCases
        % The first raw has a valid case
        i0 = 1;
    else
        if nStrings(1) == nExpectedCases + 1
            % The second raw has a valid case
            i0 = 2;
        end
    end
    iCase = 0;
    % the ID is supposed to be at the first column:
    iColumn = 1;
    ID = NaN * ones(nExpectedCases,1);
    if nStrings>=nExpectedCases
        for ii = i0:nStrings
            iCase = iCase+1;        
            string2scan = txt{ii,iColumn};
            ID(iCase) = GetIDfromName(string2scan);
        end
        % now ammend ClassDef
        NewClassDef(:,2:nFields+1) = ClassDef;
        NewClassDef(:,1) = ID;
        % And a quick heuristic to know if the numeric part of the excel was
        % not enough to identify both patient ID and class:
        if nFields < iColumnClass || bForceGetText
            ClassDef = NewClassDef;
        end
    end
end

[nrows ncols] = size(ClassDef);

iValidCase = 0;
Classes(1).TypeInFile = 1;
Classes(1).PatID = [];
Classes(1).Indexes = [];
Classes(1).FileID = [];
Classes(1).MeshID = [];
classDefCol = NaN;

if(exist('classDefColumn','var'))
    classDefCol = classDefColumn;
end
    
% List of available cases (PatIDs):
ListCases = GetCasesInDirectory(DataDirectory);

% List all MeshID side the directory
ListMeshes = dir(DataDirectory);
ListMeshes(1:2) = [];
MeshIDs = [];
for iMesh = 1:size(ListMeshes,1)
    MeshName = ListMeshes(iMesh).name;
    if isdir(fullfile(DataDirectory,MeshName))    
        MeshID = GetIDfromName(MeshName);
        MeshIDs = [MeshIDs; MeshID]; %#ok<AGROW>
    end
end

if bPermutation
    if(bSelectOrigMesh)
        ListCases = options.OrigCaseIdx(:,2);
        Index_OrigCase = options.OrigCaseIdx(:,1);
    end

    ListCases = RemoveInfo_LoD_Perm(ListCases);
end
VectorClass = zeros(1,numel(ListCases));

fprintf(' %i (out of %i possible cases - lines in excel file) cases found in %s\n',numel(ListCases),nrows,DataDirectory);

% Check if we have the "true/false": add a 1
ClassData = ClassDef(1:nrows,iColumnClass);
UV = unique(ClassData);
if numel(UV)==2, if min(UV)==0, ClassDef(1:nrows,iColumnClass) = ClassData+1; end; end

FilesInExcelFile = [];
FilesWrongClassInfo = [];
CasesNotInDirectory = [];

for ir = 1:nrows
    PatID = ClassDef(ir,1);
    if isnumeric(PatID)&&~isnan(PatID)
        
        % Check if the data of this case is available in the directory:
        FileIndex = find(ListCases == PatID);
        
        if numel(FileIndex)>0
            FilesInExcelFile = [FilesInExcelFile FileIndex];
            if(bSelectOrigMesh)
                iValidCase = Index_OrigCase(FileIndex);
            else
                iValidCase = FileIndex;
            end
            
            if size(ClassDef,2)<iColumnClass
                fprintf('ERROR! column number is larger that number of columns - have you selected the right column?\n');
                return;
            end
            ClassInFile = ClassDef(ir,iColumnClass);
%             switch Study
%                 case 3
%                     % Information is in the third column in excel file
%                     ClassInFile = ClassDef(ir,3);                   
%                 otherwise
%                     if(~isnan(classDefCol))
%                         %user-defined column in excel file
%                         ClassInFile = ClassDef(ir,classDefCol);
%                     else
%                         % Information is in the second column in excel file
%                         ClassInFile = ClassDef(ir,2);
%                     end
%             end
            [iClass,bNewClass] = GetClassIndex(ClassInFile,Classes,Study);
            if(iClass>0) 
                if(bNewClass)
                    Classes(iClass).TypeInFile = ClassInFile;
                end
                Classes(iClass).PatID   = [Classes(iClass).PatID PatID];
                Classes(iClass).MeshID = [Classes(iClass).MeshID; MeshIDs(iValidCase)];
                Classes(iClass).Indexes = [Classes(iClass).Indexes iValidCase];
                Classes(iClass).FileID  = [Classes(iClass).FileID iValidCase];
                VectorClass(FileIndex) = iClass;
                %fprintf('Case %i is of class %i\n',iValidCase,iClass);
            else
                if(bDebug)
                    fprintf('Case %i does not have a valid class! (class = %i) CHECK CLINICAL FILE!!\n',PatID,iClass);
                end
                FilesWrongClassInfo = [FilesWrongClassInfo FileIndex];
            end  
            
            if(bSelectOrigMesh)
                CaseMapping(FileIndex).PatID = PatID;
                CaseMapping(FileIndex).FileID = iValidCase;
                CaseMapping(FileIndex).MeshID = MeshIDs(iValidCase);
            else
                for j = 1:numel(iValidCase)
                    CaseMapping(iValidCase(j)).PatID = PatID;
                    CaseMapping(iValidCase(j)).FileID = FileIndex(j);
                    CaseMapping(iValidCase(j)).MeshID = MeshIDs(FileIndex(j));
                end
            end
            
        else
            if(bDebug)
                fprintf('Case %i is not available\n',PatID);
            end
            CasesNotInDirectory = [CasesNotInDirectory PatID];
        end
    end
end

FilesInExcelFile = unique(FilesInExcelFile);
FilesMissing = setdiff(1:numel(ListCases),FilesInExcelFile);

VarName = txt(1,iColumnClass);
countValidCase = 0;
for iC = 1:numel(Classes)
    Classes(iC).nCases = numel(Classes(iC).Indexes);
    Classes(iC).VariableName = VarName;
    countValidCase = countValidCase + Classes(iC).nCases;
end

fprintf(' Total of %i cases correctly mapped to class (from %i cases in the data directory).\n',countValidCase,numel(ListCases));
fprintf(' %i cases in directory without info in excel file: %s.\n',numel(FilesMissing),sprintf('%i,',(ListCases(FilesMissing)) ));
fprintf(' %i cases in directory without valid info in excel file: %s.\n',numel(FilesWrongClassInfo),sprintf('%i,',(ListCases(FilesWrongClassInfo)) ));
fprintf(' %i cases in excel without directory: %s.\n',numel(CasesNotInDirectory),sprintf('%i,',CasesNotInDirectory ));

            
function [iClass,bNewClass] = GetClassIndex(ClassInFile,Class,Study)
    nClassesDefined = numel(Class);
    bNewClass = 1;
    for iC=1:nClassesDefined
        if Class(iC).TypeInFile == ClassInFile        
            bNewClass = 0;
        end
    end
    switch Study
        case 1
            switch ClassInFile
                % 1=preterm-born, 
                % 3=term-born young adults (age matched) and 
                % 4=older term-born adults 
                case 1, iClass = 1;
                case 3, iClass = 2;
                case 4, iClass = 3;
                otherwise, iClass = NaN;
                    fprintf('ERROR! Class in file not recognised: %i\n',ClassInFile);
            end
        case {4,5,6}
            switch ClassInFile
                % 0 (control), 1 (late pet) or 2 (early pet).
                case 0, iClass = 1;
                case 1, iClass = 2;
                case 2, iClass = 3;
                otherwise, iClass = NaN;
                    fprintf('ERROR! Class in file not recognised: %i\n',ClassInFile);
            end
        otherwise
            iClass = ClassInFile;
    end
            

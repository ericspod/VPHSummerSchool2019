function [] = CalculateAtlas(directory,options)
% Function to calculate an atlas of all shapes contained in a given
% directory. 
% 
% OUTPUT: 
% - AtlasOutput/atlas.mat, with three variables stored there:
%       'V': eigenvectors
%       'ss': eigenvalues
%       'CHmean': average shape
%   CAUTION! the name of this file can change, in case the user want to
%   explore differen versions of the PCA axes built from the data! This is
%   changed with paramter options.AtlasFileName
% - AtlasOutput/Mean.exnode and .exelem: average shape
% - AtlasOutput/AtlasGenerationReport.txt: details of which cases were used
%
% Version control:
% 05/05/15: iterative search of the atlas. So far, only one iteration,
% starting from the template, so no need to save the cases corrected for
% alignment or the intermediate reference (computation done based on the template).
% 20/04/15: all atlas.mat now have a version, atlas1.mat, etc.
% 23/05/14: if a short axis stack, the world coordinates should be avoided
% in a shape analysis, because they will introduce an aritificial rotation.
% New flag in heartgen:
% '-bAtlasStudy'

AtlasFileName               = 'Atlas.mat';

iCase0 = 1;
iCase1 = 'end';
bOnlyGenerateMeshes =0;
bOnlyGenerateAtlasStatistics = 0;
bOnlyDeleteTempImages = 0;
topology = 'LV';
% This is the number of elements arbitrarily chosen in the first papers,
% and kept as the default:
nE = [6 12 1];

% Naming of files:
%subversion                  = '';
surname                     = '';
BinaryName                  = 'BinaryMask.vtk';
GrayscRootName              = 'Grayscale';
SubDirectory                = '/';

% Optional steps:
bRemoveOutputFolders        = 0;
bUnzipImages                = 0;
bMoveBinaries2Folders       = 0;
bCorrectGrayscale2SegmentationOrientation = 0;
bStep0_ExtractSegmentation  = 0;
    bForceGetEDframeFromSA  = 0;    

bStep0_AssembleBinaryMasks  = 0;

% Main steps:    
bStep1_GenerateMeshes       = 1;
    LoD                     = 3;
    bRVdirFromSA            = 0;
    bGenerateReports        = 1;
    bForceRecreationMeshes  = 1;
    bManualInitAlignment    = 0;
bStep2_GenerateAtlas        = 1;
    Cases2exclude           = [];%[61];
bDeleteImages               = 1;

bSelectedCases              = 0;

bRVpoolLabel                = 0;
MyoLabel                    = NaN;
CaseDirectories             = '';
bServerVersion              = 0;
pumpkinFolder               = '';
bSlitShapes                 = 0;

if nargin==2
    if isfield(options,'AtlasFileName'),        AtlasFileName = options.AtlasFileName; end
    if isfield(options,'Cases2include')
        Cases2include = options.Cases2include;
        bSelectedCases = 1;
    end
    if isfield(options,'nE'),            nE = options.nE; end
    if isfield(options,'iCase0'),        iCase0 = options.iCase0; end
    if isfield(options,'iCase1'),        iCase1 = options.iCase1; end
    if isfield(options,'bRVdirFromSA'),  bRVdirFromSA  = options.bRVdirFromSA;  end
    if isfield(options,'LoD'),           LoD = options.LoD;  end
    if isfield(options,'topology'),      topology = options.topology;  end
    if isfield(options,'SubDirectory'),  SubDirectory = options.SubDirectory;  end
    if isfield(options,'BinaryName'),    BinaryName = options.BinaryName;  end       
    if isfield(options,'bOnlyGenerateMeshes'), bOnlyGenerateMeshes = options.bOnlyGenerateMeshes; end
    if isfield(options,'bStep0_ExtractSegmentation'), bStep0_ExtractSegmentation = options.bStep0_ExtractSegmentation; end
    
    if isfield(options,'bOnlyGenerateAtlasStatistics'), bOnlyGenerateAtlasStatistics = options.bOnlyGenerateAtlasStatistics; end
    if isfield(options,'bOnlyDeleteTempImages'), bOnlyDeleteTempImages = options.bOnlyDeleteTempImages; end
    if isfield(options,'bCorrectGrayscale2SegmentationOrientation'), bCorrectGrayscale2SegmentationOrientation = options.bCorrectGrayscale2SegmentationOrientation; end    
    if isfield(options,'surname'),       surname  = options.surname;  end
    if isfield(options,'RVpoolLabel'),    bRVpoolLabel = 1; RVpoolLabel = options.RVpoolLabel; end
    if isfield(options,'MyoLabel'),       MyoLabel = options.MyoLabel; end 
    if isfield(options,'AssembleBinaryMasks'),       bStep0_AssembleBinaryMasks = options.AssembleBinaryMasks; end 
    if isfield(options,'pumpkinFolder'),  pumpkinFolder = options.pumpkinFolder; end
    if isfield(options,'CaseDirectories'),  CaseDirectories = options.CaseDirectories; end
    if isfield(options,'InitAngles'),  
        if ~isnan(options.InitAngles)
            bManualInitAlignment = 1;
            InitAngles = options.InitAngles;
        end
    end    
    if isfield(options,'SlitShapes')
        % Matrix with the boolean indicating which case has been labeled as
        % "slit":
        SlitShapes = options.SlitShapes;
        bSlitShapes = 1;
    end
    if isfield(options,'bSubApexSlice')
        bSubApexSlice = options.bSubApexSlice;
    end
end

ReportFilName               = 'AtlasGenerationReport.txt';

bDataCompletenessAnalysis   = 0;

if(bOnlyGenerateAtlasStatistics)
    bUnzipImages                = 0;
    bMoveBinaries2Folders       = 0;
    bCorrectGrayscale2SegmentationOrientation = 0;
    bStep0_ExtractSegmentation  = 0;
    bStep1_GenerateMeshes       = 0;
    bStep2_GenerateAtlas        = 1;
    bDeleteImages               = 0;
    bStep0_AssembleBinaryMasks         = 0;
end

if(bOnlyGenerateMeshes)
    bUnzipImages                = 0;
    bMoveBinaries2Folders       = 0;
    bCorrectGrayscale2SegmentationOrientation = 0;
    bStep0_ExtractSegmentation  = 0;
    bStep1_GenerateMeshes       = 1;
    bStep2_GenerateAtlas        = 0;
    bDeleteImages               = 0;
    bStep0_AssembleBinaryMasks         = 0;
end

if(bOnlyDeleteTempImages)
    bUnzipImages                = 0;
    bMoveBinaries2Folders       = 0;
    bCorrectGrayscale2SegmentationOrientation = 0;
    bStep0_ExtractSegmentation  = 0;
    bStep1_GenerateMeshes       = 0;
    bStep2_GenerateAtlas        = 0;
    bDeleteImages               = 1;
    bStep0_AssembleBinaryMasks         = 0;
end

% Dummy call of heartgen2 to make it visible for the Matlab compiler
try 
    heartgen2()
catch
    
end

CompressedInitialData = fullfile(directory, 'EVScontours/');
DataDirectory = fullfile(directory, 'AtlasData');
% Now forced to have this option to avoid a chance for bugs:
OutputDirectory = options.OutputDirectory;
%OutputDirectory = fullfile(directory, 'AtlasOutput');
CurrentDirectory = pwd;


if(bUnzipImages)
    directZIP = dir(CompressedInitialData);
    nCasesZIP = numel(directZIP) - 2;
    for iCase = iCase0:nCasesZIP
        iD = iCase + 2;  
        ItemName = directZIP(iD).name;
        if ~strcmp(ItemName(1),'.')
            CaseDirectory = [CompressedInitialData ItemName];
            ZipFile = CaseDirectory;
            % The string of the case is up to the first '.'
            I = find(ItemName == '.');
            CaseString = ItemName(1:I(1)-1);
            DestinyDir = fullfile(DataDirectory, CaseString);
            if ~exist(DestinyDir)
                mkdir(DestinyDir);
            end
            system(sprintf('unzip.exe "%s" -d "%s"',ZipFile,DestinyDir));
        end
    end
end

if(bMoveBinaries2Folders)
    ListOfFiles = dir (DataDirectory);
    character2defineName = '.';
    CreateFolders(ListOfFiles,DataDirectory,character2defineName);    
end

direct = dir(DataDirectory);

nCases = numel(direct) - 2;
if nCases == -2
    fprintf('Directory: %s\n',DataDirectory);
    error(' No data found in directory');    
end
if iCase1 == 'end';
    iCase1 = nCases;
end

if(bStep0_AssembleBinaryMasks)
    % Code tailored to the exportation from MITK:
    for iCase = iCase0:iCase1
        iD = iCase + 2;
        CaseDirectory = fullfile(DataDirectory, direct(iD).name, SubDirectory);
        %surname = 'DifferenceFrom_AortaEntry.gipl';
        surname = 'LV.gipl';
        NameLV = SearchSubDirectoryNameFile(direct,iD,CaseDirectory,surname); 
        %surname = 'right ventricle.gipl';
        surname = 'RV.gipl';
        NameRVpool = SearchSubDirectoryNameFile(direct,iD,CaseDirectory,surname);
        [imLV,hd] = io_ReadMedicalImage(fullfile(CaseDirectory, NameLV));
        [imRV,hd] = io_ReadMedicalImage(fullfile(CaseDirectory, NameRVpool));
        binaryIm = imLV;
        binaryIm(find(imRV)) = 2;
        io_WriteMedicalImage(fullfile(CaseDirectory, direct(iD).name, 'binary.gipl'),binaryIm,hd);
    end
end


if strcmp(BinaryName,'SubDirectoryName')
    bSearchSubDirectoryNameFile = 1;
else
    bSearchSubDirectoryNameFile = 0;
end

if(bCorrectGrayscale2SegmentationOrientation)
    % Hack to align the UCL segmentations to the original grayscales:
    for iCase = iCase0:iCase1
        iD = iCase + 2;
        CaseDirectory = fullfile(DataDirectory, direct(iD).name, SubDirectory);
        if bSearchSubDirectoryNameFile
            BinaryName = SearchSubDirectoryNameFile(direct(iD).name,CaseDirectory,surname);        
        end        
        % Read the binary mask:
        [segm,hd] = io_ReadMedicalImage(fullfile(CaseDirectory, BinaryName));
        % Permutation (rotations):
        segm = permute(segm,[2 3 1]);
        segm = segm(:,end:-1:1,:);
        segm = segm(end:-1:1,:,:);
        % Get the correct header (from grayscale image):
        GrayscName = sprintf('%s%03i.gipl',GrayscRootName,iCase);
        [gray,hdgray] = io_ReadMedicalImage(fullfile(CaseDirectory, GrayscName));
        if~isnan(gray)
            NewSurname = 'R';
            NewName = [direct(iD).name NewSurname '.gipl'];
            io_WriteMedicalImage(fullfile(CaseDirectory, NewName),segm,hdgray);
        end
    end
end


ErrorStep0 = NaN* ones(1,nCases);

if(bRemoveOutputFolders)
    for iCase = iCase0:iCase1
        iD = iCase + 2;
        CaseDirectory = fullfile(DataDirectory, direct(iD).name, SubDirectory);
        Files2delete = fullfile(CaseDirectory, 'Output_heartgen', '*');
        fprintf('Removing %s\n', Files2delete);
        delete(Files2delete);
        Files2delete = fullfile(CaseDirectory, 'Output_heartgen', 'temp', '*');
        fprintf('Removing %s\n', Files2delete);
        delete(Files2delete);
    end   
end


if(bStep0_ExtractSegmentation)
    fprintf('------------------------------------------------------------\n');
    fprintf(' 0. Extract segmentations from Argus export\n');
    fprintf('------------------------------------------------------------\n');
    for iCase = iCase0:iCase1
        iD = iCase + 2;
        CaseDirectory = fullfile(DataDirectory, direct(iD).name, SubDirectory);
        options.bForceGetEDframeFromSA = bForceGetEDframeFromSA;
        options.topology = topology;
        [mask,bSearchForRVcircle,bError] = io_GetSegmentationMaskFromArgusOutput(CaseDirectory,options);
        ErrorStep0(iCase) = bError;
        close all;
    end
end
%figure, plot(ErrorStep0);


if(bSelectedCases)
    iCase1 = numel(Cases2include);
    iCase0 = 1;
end

if(bStep1_GenerateMeshes)
    fprintf('------------------------------------------------------------\n');
    fprintf(' 1. Generate meshes\n');
    fprintf('------------------------------------------------------------\n');
    %heartgenCallFile = fullfile(DataDirectory, 'AtlasHeartgenCalls.txt');
    heartgenCallFile = 'AtlasHeartgenCalls.txt';
    %if(bServerVersion)
        filePointer = fopen(heartgenCallFile, 'w');
        if (filePointer < 0) 
           disp(['Error: cannot open heartgenCallFile ' heartgenCallFile])
           return
        else
            nCases2mesh = 0;
            disp(['Opening of heartgenCallFile ' heartgenCallFile ' successfull'])
        end
    %end

    for iCase = iCase0:iCase1
        close all;
        WallT = NaN;
        if(bSelectedCases)
            directname = FindDirectWithNuber(direct,Cases2include(iCase));
        else
            iD = iCase + 2;
            directname = direct(iD).name ;            
        end
        CaseDirectory = fullfile(DataDirectory, directname, SubDirectory);
        if bSearchSubDirectoryNameFile
            BinaryName = SearchSubDirectoryNameFile(directname,CaseDirectory,surname);        
        end
        if ~isnan(BinaryName)
            [name,ext] = RemoveExtensionFromImageName(BinaryName);
            if strcmp(ext,'.cvi42wsx')
                % Search for a directory with the original images:
                if ~isfield(options,'LocalDicomFolder')
                    LocalDicomFolder = 'DICOMdir';
                else
                    LocalDicomFolder = options.LocalDicomFolder;
                end
                options.DICOMDirectory = fullfile(CaseDirectory,LocalDicomFolder);                 
                [im,hd,ErrorReport] = io_GetSegmentationMaskFromCMR42Output(fullfile(CaseDirectory,BinaryName),options);
                if ~ErrorReport.bError
                    BinaryName = 'binary.vtk';
                    io_WriteMedicalImage(fullfile(CaseDirectory,BinaryName),im,hd);
                end
            end

            MeshName = [RemovePathAndExtension(BinaryName) '_mesh'];
%             if(bStep0_Alternative)
%                 % Copy the images and data from existing folder (RefDir):
%                 RefCaseDir = [RefDir 'AtlasData/' directname SubDirectory]
%                 if ~exist(CaseDirectory,'dir')
%                     mkdir(CaseDirectory);
%                 end
%                 if exist([RefCaseDir BinaryName],'file')
%                     copyfile([RefCaseDir BinaryName],[CaseDirectory BinaryName]);
%                     copyfile([RefCaseDir 'RVposition.mat'],[CaseDirectory 'RVposition.mat']);
%                 end
%             end
            if exist(fullfile(CaseDirectory, BinaryName),'file')
                if(bRVdirFromSA)
                    RVdirFile = fullfile(CaseDirectory, 'RVposition.mat');
                    if exist(RVdirFile,'file')
                        % The RV position was given in the image
                        load(RVdirFile);
                        %... this loads the variable RVdirection 
                        RVdir = RVdirection;
                        if exist('WallThPix','var')
                            if isnan(WallThPix.TrueOne)
                                if isnan(WallThPix.FromDispersion)
                                    fprintf('WARNING! Wall thickness not available in this case\n');                        
                                else
                                    WallT = WallThPix.FromDispersion;
                                end
                            else
                                WallT = WallThPix.TrueOne;
                            end
                        end
                        % Convert WallTh to physical units (header loaded from
                        % 'RVposition.mat')
                        if exist('hd','var')
                            WallT = WallT * mean(hd.spacing(1:2));
                        else
                            fprintf('ERROR! Variable "hd" does not exist as expected\n');
                        end
                    else
                        fprintf('ERROR! No mesh generated: right Ventricle direction and wall thickness not available in this case\n');
                        fprintf('  File: %s\n',RVdirFile);
                    end
                end
                MeshDirectory = fullfile(CaseDirectory, 'Output_heartgen');
                heartgen_arg = [];
                StringArgnE = [' -nE ',int2str(nE(1)), ' ' int2str(nE(2)), ' ' int2str(nE(3))];
                if ~exist(fullfile(MeshDirectory, [MeshName '.exnode']))||bForceRecreationMeshes
                    % Create the mesh:
                    cd(CaseDirectory);

                    % Change 11/03/2013: rely on the WallT
                    % computation inside heartgen2!
    %                            heartgen2([CaseDirectory BinaryName],'-HeartType','LV',StringArgnE,'-LoD',LoD,'-RVdir',RVdir(1),RVdir(2),'-WallT',WallT,'-bReport',bGenerateReports);
                    if(bRVdirFromSA)
                        heartgen_arg = [fullfile(CaseDirectory, BinaryName), ' -HeartType ', topology,' -MyoLabel ',int2str(MyoLabel), StringArgnE, ' -LoD ',int2str(LoD),' -RVdir ',num2str(RVdir(1)), ' ', num2str(RVdir(2)),' -bReport ', int2str(bGenerateReports)];
                        %heartgen2([CaseDirectory BinaryName],'-HeartType',topology,'-MyoLabel',MyoLabel,StringArgnE,'-LoD',LoD,'-RVdir',RVdir(1),RVdir(2),'-bReport',bGenerateReports);
                    else
                        if(bRVpoolLabel)
                            heartgen_arg = [fullfile(CaseDirectory, BinaryName),' -HeartType ',topology,' -MyoLabel ',int2str(MyoLabel),StringArgnE,' -LoD ',int2str(LoD),' -RVpoolLabel ',int2str(RVpoolLabel),' -bReport ',int2str(bGenerateReports)];
                            %heartgen2([CaseDirectory BinaryName],'-HeartType',topology,'-MyoLabel',MyoLabel,StringArgnE,'-LoD',LoD,'-RVpoolLabel',RVpoolLabel,'-bReport',bGenerateReports);
                        else
                            if strcmp(topology(1:2),'LV')
                                fprintf('ERROR! meshes of the left ventricle require additional information to constrain the shape: the location of the right ventricle!\n');
                                break;
                            end
                            heartgen_arg = [fullfile(CaseDirectory, BinaryName),' -HeartType ',topology,' -MyoLabel ',int2str(MyoLabel),StringArgnE,' -LoD ',LoD,' -bReport ',bGenerateReports];
                            %heartgen2([CaseDirectory BinaryName],'-HeartType',topology,'-MyoLabel',MyoLabel,StringArgnE,'-LoD',LoD,'-bReport',bGenerateReports);
                        end
                    end   
					CaseList{iCase} = fullfile(DataDirectory, directname);                    
					if(bManualInitAlignment)
                        if numel(InitAngles)~=3
                            fprintf('ERRORS! In manual alignment, the initial angles in x,y,z where not 3. Solution: OPTION IGNORED\n');
                            fprintf('  input:'); fprintf('%f, ',InitAngles);
                        else
                            heartgen_arg = [heartgen_arg sprintf(' -InitOption 5 -InitAngles %f %f %f', InitAngles)];
                        end
                    end
                    if exist('bSubApexSlice','var')
                        heartgen_arg = [heartgen_arg sprintf(' -bSubApexSlice %i ', bSubApexSlice)];
                    end
                    if(bSlitShapes)
                        % A flag to indicate if the template should be a
                        % slit or a globular shape:
                        % Recover the case ID from directname:
                        ii = 0; ID = [];
                        while isempty(ID)
                            ii = ii + 1;
                            ID = sscanf(directname(ii:end),'%i');
                            if numel(ID)>1
                                newID = 0;
                                for jj=1:numel(ID)
                                    newID = newID + ID(jj)*(10^(numel(ID)-jj));
                                end
                                ID = newID;
                            end
                        end
                        I = find(SlitShapes(2,:)==ID);
                        if numel(I)>0
                            bSlit = SlitShapes(1,I);
                            if(bSlit)
                                fprintf('Case %i is chosen to be a slit shape!\n',ID);
                                heartgen_arg = [heartgen_arg ' -bSlit 1'];
                            end
                        end
                    end
                    fprintf(filePointer, '%s\n', heartgen_arg);
                    cd(CurrentDirectory);
                    nCases2mesh = nCases2mesh + 1;
                end
            end
        end
    end
    
    fclose(filePointer);
    
    if nCases2mesh == 0
        fprintf('  ERROR! No cases found to personalise!\n');
    else
        fprintf(' Mesh personalization task: %i cases to build\n',nCases2mesh);
    %rootTmpDir = '/home/dn14/.pumpkin/bioeng105-pc-4db5eae3';
        if (numel(pumpkinFolder) > 0)
            atlasEvaluateHeartgen(heartgenCallFile, fullfile(DataDirectory), pumpkinFolder);
        elseif (false)
            atlasEvaluateHeartgen(heartgenCallFile, fullfile(DataDirectory), '', CaseList, options.lobcderfile);
        else
            cd(fullfile(DataDirectory))
            atlasEvaluateHeartgen(heartgenCallFile);
        end
    end
    cd(CurrentDirectory);
end    

if(bStep2_GenerateAtlas)
    ReportFilName = fullfile(OutputDirectory,ReportFilName);
    fidr = fopen(ReportFilName,'w');
    if fidr==-1
        fprintf('ERROR!, not possible to open report file %s\n',ReportFilName);
        fprintf('        ... reverting to report on screen\n');
        fidr = 1;
    end
    fprintf('------------------------------------------------------------\n');
    fprintf(' 2. Make the statistics\n');
    fprintf('    Alignment option: %s\n',options.AtlasAlignmentOption(:));
    fprintf('    Alignment option: %i\n',options.AtlasAlignmentOption(1));
    fprintf('------------------------------------------------------------\n');
    if ~exist(OutputDirectory,'dir')
        mkdir(OutputDirectory);
    end
    bValidCases = zeros(1,nCases);
    bDofSizeDefined = 0;
    if(bSelectedCases)
        nCasesForPCA = numel(Cases2include);
    else
        nCasesForPCA = nCases;
    end
    
    % When a statistical model is to be built, and there is an estimation
    % of the atlas, the average, we might want to make an iterative search
    % of this atlas.
    nAlignmentIterations = 1;

    for iAlignIter = 1:nAlignmentIterations
        if(nAlignmentIterations>1)
            fprintf('\n=========================================================\n');
            fprintf('    Starting alginment iteration #%i\n',iAlignIter);
            fprintf('=========================================================\n\n');
        end
        for iCase = 1:nCasesForPCA

            if(~isempty(CaseDirectories))
                CaseDir = options.CaseDirectories(iCase).name;
            else
                iD = iCase + 2;
                CaseDir = direct(iD).name;
            end        
    %         CaseDir = direct(iD).name;
            CaseDirectory = fullfile(DataDirectory, CaseDir, SubDirectory);
            if bSearchSubDirectoryNameFile
                BinaryName = SearchSubDirectoryNameFile(CaseDir,CaseDirectory,surname);        
            end
            if ~isnan(BinaryName)
                MeshName = [RemovePathAndExtension(BinaryName) '_mesh']; %'_meshLagrange']; %GGG
                switch topology
                    case 'arch'
                        MeshDirectory = fullfile(CaseDirectory, 'Output_VascularGen');
                    otherwise
                        MeshDirectory = fullfile(CaseDirectory, 'Output_heartgen');
                end
                CaseNumber = GetNumberFromName(CaseDir,2);%str2num(direct(iD).name(end-2:end));
                if find(Cases2exclude == CaseNumber)>0
                    fprintf(fidr,'Case %i is excluded\n',CaseNumber);
                else
                    fprintf(fidr,'Case %i is included...\n',CaseNumber);
                    bValid = 0; 
                    if exist(fullfile(MeshDirectory,[ MeshName '.exnode']),'file')
                        bValid = 1;
                    else
                        % Try to recover: find any 'exelemm-exnode pair'
                        MeshName = 'Mesh';
                        fprintf(fidr,'       BUT IS NOT A VALID CASE! - likely data error (no valid mesh found in %s)\n',MeshDirectory);
                        if exist(fullfile(MeshDirectory,[ MeshName '.exnode']),'file')
                            bValid = 1;
                        end
                    end
                    if(bValid)
                        CH = CubicMeshClass(fullfile(MeshDirectory, MeshName));
                        %CH.InterpolationBasis = 2; %GGG (temporarily load only coords (no derivatives)

                        if ~bDofSizeDefined;
                            nDofs = size(CH.GetDofs());
                            MatrixDofs = zeros(nCases,nDofs(1),nDofs(2));
                            DofsInLine = zeros(nCases,prod(nDofs));
                            bDofSizeDefined = 1;
                        end

    %                     bUseDerivativesSubset=0;
    %                     if(bUseDerivativesSubset) %Don't use all derivatives                    
    %                         %derivativesList is the list of derivatives indices in the form of:
    %                         %derivativesList = [duds1 duds2 duds3 duds12 duds13 duds23 duds123]
    %                         derivativesList = [0 0 0 0 0 0 0]; %keep no derivatives
    %                         model = NeglectMeshDerivatives(CH.GetDofs(), derivativesList, CH.nNodes);                    
    %                         CH = CH.SetDofs(model);
    %                     end
                        optionsRigidMotion = options;
                        if isfield(options,'ReferenceMesh'), optionsRigidMotion.ReferenceMesh = options.ReferenceMesh; end
                        if iAlignIter>1
                            optionsRigidMotion.ReferenceMesh = CHmean;
                        end
                        optionsRigidMotion.CaseDirectory = CaseDirectory;
                        CH = SolveRigidBodyMotion(CH,optionsRigidMotion);
                        MatrixDofs(iCase,:,:) = CH.GetDofs();
                        DofsInLine(iCase,:) = reshape(MatrixDofs(iCase,:,:),1,prod(nDofs));
                        bValidCases(iCase) = 1;
                        fprintf(fidr,'       and is a valid case!\n');
                    end
                end
            else
                fprintf(fidr,'Case %i: no binary image found in %s\n',CaseNumber,CaseDirectory);
            end
        end
    
        % Reduce the matrix to the number of valid cases:
        MartrixValidDofs = MatrixDofs(find(bValidCases),:,:);
        ValidDofsInLine  = DofsInLine(find(bValidCases),:);
        nValidCases = numel(find(bValidCases));
        fprintf('Analysis with %i valid cases (out of %i)\n',nValidCases,nCasesForPCA);
        fprintf(fidr,'Analysis with %i valid cases (out of %i)\n',nValidCases,nCasesForPCA);
        fprintf(fidr,'         each case had %i dofs\n',size(MartrixValidDofs,2));
        % Remove the rigid translation:

        % Principal component analysis of the dofs:
        DofsMeanShape = mean(MartrixValidDofs,1);
        DofsMeanShape = squeeze(DofsMeanShape);    
        CHmean = CH.SetDofs(DofsMeanShape);    
        %CHmean = CHmean.SetName(['MeanV' subversion]);
        CHmean = CHmean.SetName(sprintf('MeanIter%i',iAlignIter));
        CHmean.WriteExFiles(OutputDirectory);
    end
    CHmean = CHmean.SetName('Mean');
    CHmean.WriteExFiles(OutputDirectory);

    MeanDofsLn = reshape(DofsMeanShape,1,prod(nDofs));
    MatrixDofsWithoutMean = ValidDofsInLine - repmat(MeanDofsLn,nValidCases,1);
    B = MatrixDofsWithoutMean;
    COV = B'*B/nValidCases;
    fprintf('Eigenanalysis of covariance matrix of size %ix%i\n',size(COV));
    [V,S] = eig(COV);
    ss = diag(S);
    EigenValueMatrix = diag(S);

    filename = fullfile(OutputDirectory, AtlasFileName);
    fprintf(' Saving atlas in %s\n',filename);
    save(filename,'V','ss','CHmean','EigenValueMatrix');
    if fidr>1
        fclose(fidr);
    end
end

if(bDataCompletenessAnalysis)
    cases = iCase0:nCases;
    BinaryMissing = ones(1,numel(cases));
    RVorieMissing = ones(1,numel(cases));
    for iCase = cases
        iD = iCase + 2;
        CaseDirectory = [DataDirectory direct(iD).name SubDirectory];
        % The unzip step is not checked, since there is no much point in that

        % The segmentation from argus should have:
        File = [CaseDirectory SubDirectory 'RVposition.mat'];
        if exist(File,'file')
            RVorieMissing(iCase) = 0;
            Names2plotRV(iCase).name = '';
        else
            Names2plotRV(iCase).name = direct(iD).name;
        end
        % The file with the RV orientation:
        File = [CaseDirectory SubDirectory 'BinaryMask.vtk'];
        if exist(File,'file')
            BinaryMissing(iCase) = 0;
            Names2plot(iCase).name = '';
        else
            Names2plot(iCase).name = direct(iD).name;
        end
        
    end
    figure('color',[1 1 1],'OuterPosition',[-400 600 12000 500]);
    subplot(211)
    imagesc(BinaryMissing);
    set(gca,'XTick',cases);    
    set(gca,'XTickLabel',{Names2plot(cases).name});
    title('Cases with binary mask missing')
    subplot(212)
    imagesc(RVorieMissing);
    set(gca,'XTick',cases);    
    set(gca,'XTickLabel',{Names2plotRV(cases).name});
    title('Cases with RV orientation missing')
end

if(bDeleteImages)
    for iCase = 1:nCases
        iD = iCase + 2;
        CaseDirectory = [DataDirectory direct(iD).name SubDirectory];
%         if exist(CaseDirectory,'dir')
%             %ZipFile = [CaseDirectory '/images.zip'];
%             Files2zip = [CaseDirectory '/*.IMA'];
%             system(sprintf('zip.exe "%s" "%s"',ZipFile,Files2zip));
%             delete(Files2zip);
%         end
        TempMeshingDirectory = fullfile(DataDirectory, direct(iD).name, SubDirectory, '/Output_heartgen/temp');
        if exist(TempMeshingDirectory,'dir')
            fprintf('Removing temporary imags from %s\n',TempMeshingDirectory);
            Files2zip = [TempMeshingDirectory '/*.tiff'];
            delete(Files2zip);
            Files2zip = [TempMeshingDirectory '/*.vtk'];
            delete(Files2zip);
        end
    end
end

function directname = FindDirectWithNuber(direct,ID)
% function to find the folder name with the ID

for iF = 1:numel(direct)
    % try to learn the structure of the name:
    name = direct(iF).name;
    num = GetNumberFromName(name,2);
    if num==ID
        directname = name;
        return;
    end
end
fprintf('ERROR! case with ID=%i not found!\n',ID);
directname = [name(1:i-1) sprintf('%03i',ID)];
fprintf(' ... attemt to guess the name: %s\n',directname);

    



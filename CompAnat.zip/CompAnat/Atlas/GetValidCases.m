function [iValidCases,ClassificationLabels] = GetValidCases(ListCases,Cases2include,ClassDefinition,classes2include)
    % Definition now of the 0 or 1 cathegory of each case, with the local index
    % accordingly to ListCases! Otherwise we are mixing pears to apples...
    % ... the variable coefficients is indexed accordingly to ListCases
    % ... in options.Cases2include we might want to include some more
    % restrictive definition of cases
    
    nCases = numel(ListCases);
    iValidCases = zeros(1,nCases);
    ClassificationLabels = NaN*ones(1,nCases);
    
    for iCase = 1:nCases
        PatID = Cases2include(iCase);
        % Find the valid ID within the ListCases variable:
        ICASE = find(ListCases == PatID);

        if isempty(ICASE)
            fprintf('Error! Contradictory definition of the list of cases.\n');
            fprintf('A case (ID=%i) to include in the analysis was not previously used to get the eigen coordinates\n',PatID);
            break
        else
            % Get the cathegory of this subject
            [ClassificationLabels(ICASE),bValidClassFound,bWrongClass] = GetClassOfCaseID(ClassDefinition,PatID,classes2include);
        end
        if(~bValidClassFound)
            if bWrongClass
                fprintf('ERROR! No class found for caseID = %i\n',PatID);
            end
        else
            % Only when ICASE is found, and has a valid class:
            iValidCases(ICASE) = 1;
        end
    end

    iValidCases = find(iValidCases);
end
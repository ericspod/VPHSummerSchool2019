function [dataout,textout] = LoadUnlinkedClass(excel1,excel2,options)
% Function to deal with the ethical constraint of having unlinked data in a
% single file. Input
% - excel1: spreadsheet with the valid ID, and N shape coefficients
% - excel2: spreadsheet with the same N shape coefficients, and the list of
% clinical variables of interest
%
% By Pablo Lamata. London, 02 Feb 2017

% Number of shape coefficients per case, number of PCA components:
Npca = 10;
% First column with first PCA component in each excel file:
ColPCA1 = 2;
ColPCA2 = 3;
% It is possible that there are still some additional columns with clinical
% variables beyond the end of the last PCA component:
ExtraVariablesInColumns = [];

% The assumption is that the ID is in the first column in excel1:
iColID = 1;
% And a boolean to double the number of PCAs (the exel2 has both the
% diastolic and systolic shape coefficients):
bTwiceCoefs = 1;
% Option to duplicate the clinical output data as many times as needed for
% the creation of different meshes from the same dataset (at different time
% points for example, ED and ES)
nReplicate = 0;
iReplicate = 0;


if nargin>=3
    if isfield(options,'Npca'),     Npca = options.Npca; end
    if isfield(options,'ColPCA1'),  ColPCA1 = options.ColPCA1; end
    if isfield(options,'ColPCA2'),  ColPCA2 = options.ColPCA2; end
    if isfield(options,'nReplicate'),  nReplicate = options.nReplicate; end
    if isfield(options,'iReplicate'),  iReplicate = options.iReplicate; end
    if isfield(options,'bTwiceCoefs'),  bTwiceCoefs = options.bTwiceCoefs; end
    if isfield(options,'ExtraVariablesInColumns'),  ExtraVariablesInColumns = options.ExtraVariablesInColumns; end
    
end

% Check the files are available:
status1 = xlsfinfo(excel1);
status2 = xlsfinfo(excel2);
if isempty(status1)
    error(' File not available: %s\n',excel1);
    return;
end
if isempty(status2)
    error(' File not available: %s\n',excel2);
end

% Now read the data:
fprintf('Reading %s\n',excel1);
[Data1,text1] = xlsread(excel1);
fprintf('Reading %s\n',excel2);
[Data2,text2] = xlsread(excel2);

% We want to find the "clinical information" of each case that is in the
% atlas
Cases = Data1(:,iColID);
% And we want to match the signature of the shape:
Sign1 = Data1(:,ColPCA1:ColPCA1+Npca-1);
Sign2 = Data2(:,ColPCA2:ColPCA2+Npca-1);
n1 = size(Sign1,1);
n2 = size(Sign2,1);
% Fill with NaNs the last "extra case" in excel2, for those cases that
% won't find a match
Data2(end+1,:) = NaN;
iNaN = n2+1;

R       = zeros(1,n1);
iMatch  = zeros(1,n1);
for iC = 1:numel(Cases)
    S1 = Sign1(iC,:);
    % Find the matching signature
    residuals = sum(abs(Sign2 - repmat(S1,n2,1)),2);
    [R(iC),iMatch(iC)] = min(residuals);
    if R(iC)>0.1
        iMatch(iC) = iNaN;
        fprintf('WARNING! No match found for ID: %i\n',Cases(iC));
    end
end

figure; 
subplot(2,1,1), plot(R); title('Residuals (check it is small)') 
subplot(2,1,2), plot(iMatch); title('mapping') 

% Prepare output:
ColumnsOfInterest = [ExtraVariablesInColumns ColPCA2+(1+bTwiceCoefs)*Npca:size(Data2,2)];
ClinicalDataOrdered = squeeze(Data2(iMatch,ColumnsOfInterest));
dataout = [Cases ClinicalDataOrdered];
% Fist row is the description of variables, hence this offset for the ID:
iRowOffset = 1;
% In case there is not enough text, fill with empty space:
if n2>size(text2,1)
    % There is an additional raw for the "not-found subjects":
    text2(end:n2++iRowOffset+1,:)= {' '};
end
heading = [text2(1,1) text2(1,ColumnsOfInterest)];
txtcase = [text2(iMatch+iRowOffset,1) text2(iMatch+iRowOffset,ColumnsOfInterest)];
textout = [heading;txtcase];

if iReplicate > 0
    iRR = iReplicate;
else
    iRR = 1:nReplicate;
end

for iR = iRR
    % Replicate the matrixes, with the ID adding a digit at the end for
    % each replication:
    NewCases = Cases*10 + iR*ones(size(Cases));
    NewData = [NewCases ClinicalDataOrdered];
    dataout = [dataout ; NewData];
    Newtext = txtcase;
    textout = [textout ; Newtext];
end


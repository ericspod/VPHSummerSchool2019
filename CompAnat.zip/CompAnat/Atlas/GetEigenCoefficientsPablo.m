function [coefficientsOut,caseNames,Handles,caseIDs] = GetEigenCoefficients(directory,options)
% INPUT:
% - directory of atlas data
% - The definition of classes (labels) of the cases
%
% OUTPUT:
% - coefficientsOut (coordinates): of all meshes
% - caseNames: with the names of the cases (name of the folder)
% - Handles: to the figures to save the plots afterwards
% - caseIDs: with the number of the valid casis (paired with cases), in
% case some of the input cases were not correct/complete
%
% Version control:
% - 19/01/15: merge with Gerardo's changes
% - 10/11/14: two changes
% 1. generalise to other types of shape representation (data structure). 
% 2. enable the possibility of sub-classes within a case (birth/fu).
% - 09/09/13: class definition is an option

bDebug = 0;

%==========================================================================
% Hard coded definition of directory and files:
DataDirectory = [directory '/AtlasData/'];
OutputDirectory = [directory '/AtlasOutput/'];

% Default options and naming of files:
AtlasSurname    = '';
PersonalizedOutputDirectory = NaN;
bOnlyGenerateAtlasStatisticsFromSource = 0;

% Naming of files:
surname         = '';
BinaryName      = 'BinaryMask.vtk';
SubDirectory    = '/';
MeshSurName     = '_mesh'; % '_meshLagrange';  %GGG
ClassDefinition = '';
bUseMedialAxis = 0;
bUseWallThicknessOnly = 0;
bUseEpiNodes = 0;
bUseEndoNodes = 0;

% A variable to encode if the naming is based on an input image in each
% case, or on an input text file:
KeyFileKind4Mapping = 'image';
% Get all cases in data directory, this can be overwritten later in options
ListCases = GetCasesInDirectory(DataDirectory);
bAllCases = 1;

%nDims = size(V);
bPlot = 0;
iEig2plot = 1:5;
bRecalculateEigenCoords = 1;
iEig = 'all';
eigvectors2output = iEig;
VectorClass = NaN;
H1 = NaN;
H2 = NaN;
colourscheme = 1;
if nargin==2
    if isfield(options,'AtlasSurname'), AtlasSurname = options.AtlasSurname; end
    if isfield(options,'KeyFileKind4Mapping'), KeyFileKind4Mapping = options.KeyFileKind4Mapping; end    
    if isfield(options,'eigvectors2output'), eigvectors2output = options.eigvectors2output; end
    if isfield(options,'iEig'),  iEig = options.iEig; end
    if isfield(options,'iEig2plot'),  iEig2plot = options.iEig2plot; end
    if isfield(options,'bPlot'), bPlot = options.bPlot; end
    if isfield(options,'bRecalculateEigenCoords'), bRecalculateEigenCoords = options.bRecalculateEigenCoords; end    
    if isfield(options,'VectorClass'), VectorClass = options.VectorClass; end
    if isfield(options,'BinaryName'),    BinaryName = options.BinaryName;  end
    if isfield(options,'surname'),       surname  = options.surname;  end
    if isfield(options,'SubDirectory'),  SubDirectory = options.SubDirectory;  end
    if isfield(options,'ClassDefinition'),  ClassDefinition = options.ClassDefinition;  end
    if isfield(options,'ListCases'),    
        bAllCases = 0;      % It may be that we have all cases, but it is not sure
        ListCases = options.ListCases;    end
%     if isfield(options,'ListOfFileNames')   %Accepts list of filenames to search for
%         ListOfFileNames = options.ListOfFileNames;
%         bListOfFileNames = 1;
%     end
%     if isfield(options,'partialFileName'),    partialFileName = options.partialFileName;    end
    if isfield(options,'surnameCases'),     surnameCases = options.surnameCases; end      
    if isfield(options,'surnameID'),        surnameID = options.surnameID; end  
    if isfield(options,'colourscheme'),     colourscheme = options.colourscheme; end  
    if isfield(options,'bUseMedialAxis')   bUseMedialAxis = options.bUseMedialAxis; end  
    if isfield(options,'bUseWallThicknessOnly'),  bUseWallThicknessOnly = options.bUseWallThicknessOnly; end
    
    if isfield(options,'bUseEpiNodes'),  bUseEpiNodes = options.bUseEpiNodes; end
    if isfield(options,'bUseEndoNodes'),  bUseEndoNodes = options.bUseEndoNodes; end
    if isfield(options,'bOnlyGenerateAtlasStatisticsFromSource'),  bOnlyGenerateAtlasStatisticsFromSource = options.bOnlyGenerateAtlasStatisticsFromSource; end
    if isfield(options,'SourceFilesDir'), SourceFilesDir = options.SourceFilesDir; end
    
%     if isfield(options,'PersonalizedOutputDirectory'), PersonalizedOutputDirectory = options.PersonalizedOutputDirectory; end
end

% if(~isnan(PersonalizedOutputDirectory))
%     OutputDirectory = PersonalizedOutputDirectory;
% end
% Check if there is a special condition:
cond = '';
if isfield(options,'iCond') &&      isfield(options,'PostName')
    cond = cell2mat(options.PostName(options.iCond));
end
                        
% File with coordinates:
CoordsMatFileName = fullfile(OutputDirectory ,['/Coordinates' AtlasSurname cond '.mat']);



if(bUseMedialAxis || bUseWallThicknessOnly)
    load([OutputDirectory 'MedialAxisMean.mat']);
end

if(bUseEpiNodes || bUseEndoNodes)
    load([OutputDirectory 'SurfaceNodesMean.mat']);
end

% if(bOnlyGenerateAtlasStatisticsFromSource)
%     load([OutputDirectory 'Atlas.mat']);
% end

if nargin >= 3
    bClassesAvailable = 1;
else
    bClassesAvailable = 0;
end

if strcmp(BinaryName,'SubDirectoryName')
    bSearchSubDirectoryNameFile = 1;
else
    bSearchSubDirectoryNameFile = 0;
end

direct = dir(DataDirectory);
nCases = numel(ListCases);
iValidCase = 0;
AllCasesNames = {};

%==========================================================================
% Load the atlas: 'V','ss' and 'MeanDofs'
load(fullfile(OutputDirectory, ['Atlas' AtlasSurname '.mat']));

if strcmp(iEig, 'all')
    iEig = (1:size(V,1));
end
if strcmp(eigvectors2output, 'all')
    eigvectors2output = (1:size(V,1));
end
nCoords = numel(iEig);
coefficients = NaN * ones(nCoords,nCases);

bCoordsAvailable = 0;
if exist(CoordsMatFileName,'file')
    bCoordsAvailable = 1;
end
if bCoordsAvailable && ~bRecalculateEigenCoords    
    load(CoordsMatFileName);
    % Select the valid ones:
    iValid = [];
    nTotal = numel(AllCasesNames);
    if nTotal == numel(ListCases);
        iValid = 1:nTotal;
    else
        for iAll = 1:nTotal
            if numel(AllCasesNames(iAll).ID)>0
                ID = AllCasesNames(iAll).ID;
                I = find(ListCases == ID);
                if numel(I) > 0
                    iValid = [iValid iAll];
                end
            end
        end
    end
        % Find the 
    AllCasesNames = AllCasesNames(iValid);
    coefficients = coefficients(:,iValid);
    coefficientsOut = coefficients;
    fprintf(' Loaded %i valid coefficients (out of %i) from %s\n',numel(iValid),nTotal,CoordsMatFileName);
else
    % Need to recompute the coefficients:
    for iC = 1:nCases
        iCase = ListCases(iC);       
        % Flag to indicate that iCase is the ID of the case (from folder
        % name):
        options.bCaseID = 1;
        options.SubDirectory = SubDirectory;
        [ KeyFile, output ] = CaseMappingAtlas( DataDirectory, iCase, options );
        CaseFolderName = output.CaseFolderName;
        CaseDirectory = output.CaseDirectory; 
        if isnan(CaseFolderName)
            fprintf('ERROR! No folder corresponding to ID=%i in directory %s\n',iCase,DataDirectory);
        else
%         MeshDirectory = [CaseDirectory 'Output_heartgen/'];
%         if exist(MeshDirectory,'dir')
%             if bSearchSubDirectoryNameFile
%                 %TODO: Check this: What if the list of cases is not sequential?  
%                 %iCase2findIndirect = iCase +2; % a hack to avoid the '.' and '..' from the command dir
%                 iCase2findIndirect = iC +2; % a hack to avoid the '.' and '..' from the command dir
%                 
%                 %Support a user-defined list of cases in the AtlasData
%                 %directory with different surnames than the rest of cases
%                 caseid = str2num(direct(iCase2findIndirect).name(end-2:end));            
%                 FileIndex = find(caseid == surnameCases);
% 
%                 oldSurname = surname;
%                 if(FileIndex > 0)                    
%                     surname = surnameID;
%                 end
%                 
%                 dirname = direct(iCase2findIndirect).name;
%                 BinaryName = SearchSubDirectoryNameFile(dirname,CaseDirectory,surname);        
%                 surname = oldSurname;
%             end
% %             if(bListOfFileNames)                
% %                 BinaryName = [ListOfFileNames{iC} partialFileName];           
% %             end

            
            if(~isnan(KeyFile))
                % Now we look for the degrees of freedom of this case,
                % after finding the KeyFile:
                AllCasesNames(iC).name = CaseFolderName;
                AllCasesNames(iC).ID = output.CaseID;
                bValidCase = 0;
                switch KeyFileKind4Mapping
                    case 'image'
                        MeshName = output.MeshName;
                        MeshDirectory = output.MeshDirectory;
                        MeshFile = fullfile(MeshDirectory,[MeshName '.exnode']);
                        if exist(MeshFile,'file')
                            bValidCase = 1;
                            iValidCase = iValidCase + 1;
                            CH = CubicMeshClass([MeshDirectory MeshName]);
                            CH = SolveRigidBodyMotion(CH,CaseDirectory);
                            Dofs = CH.GetDofs();
                            MeanDofs = CHmean.GetDofs();                            
                        else
                            fprintf('ERROR! No mesh found! Image exists: %s\n',KeyFile);
                            fprintf('       Mesh does not exist: %s\n',MeshFile);
                        end
                    case 'text'
                        % check that we have the ones of the conditons we want:
                        % - Atlassurname encodes the chamber view:
                        ch = options.AtlasSurname;
                        % - The experimental condition is in variable
                        % "cond"
                        % Now the name of the right dof file:
                        % The dofs are in a mat file, like mesh013USfit013birthFrame01dofs
                        DofFileNamePrototype = fullfile(CaseDirectory,['*' cond '*dofs.mat']);
                        DofFiles = ls(DofFileNamePrototype);
                        nF = size(DofFiles,1);
                        if nF>1
                            fprintf('WARNING! Not unique definition of the dof file. Possibilities:\n');
                            for iF = 1:nF
                                fprintf('      %i: %s\n', iF, DofFiles(iF,:));
                            end
                            fprintf(' ... in an attempt to recover, taking the fist one\n');
                            temp = DofFiles(1,:);
                            DofFiles = temp;
                        end                            
                        DofFileWithPath = fullfile(CaseDirectory,DofFiles);
                        if exist(DofFileWithPath,'file')&&nF>0    
                            clear('EndoDofs','EpiDofs','EndoCont2Ch','EpiCont2Ch','EndoCont3Ch','EpiCont3Ch','EndoCont4Ch','EpiCont4Ch')
                            % load the LinearMeshes with the dofs:
                            load(DofFileWithPath);
                            % it may well be that there were dofs, but not the ones of each contour:
                            switch ch
                                case {'2','2ch','2chamber'}
                                    if exist('EndoCont2Ch','var'), EndoDofs = EndoCont2Ch.GetDofs(); end
                                    if exist('EpiCont2Ch','var'), EpiDofs = EpiCont2Ch.GetDofs(); end
                                case {'3','3ch','3chamber'}
                                    if exist('EndoCont3Ch','var'), EndoDofs = EndoCont3Ch.GetDofs(); end
                                    if exist('EpiCont3Ch','var'), EpiDofs = EpiCont3Ch.GetDofs(); end
                                case {'4','4ch','4chamber'}
                                    if exist('EndoCont4Ch','var'), EndoDofs = EndoCont4Ch.GetDofs(); end
                                    if exist('EpiCont4Ch','var'), EpiDofs = EpiCont4Ch.GetDofs(); end
                                otherwise
                                    fprintf('ERROR! chamber view not recognised from the surname of the atlas\n')
                                    fprintf('       surname = %s\n',options.AtlasSurname)
                            end
                            if exist('EndoDofs','var') && exist('EpiDofs','var')
                                bValidCase = 1;                        
                                iValidCase = iValidCase + 1;
                                nDofs = numel(EndoDofs);
                                Dofs = [reshape(EndoDofs,1,nDofs) reshape(EpiDofs,1,nDofs)];
                            end
                        else
                            fprintf('WARNING! No data in caseID %i, condition "%s"\n',output.CaseID,cond);
                        end
                end
                if(bValidCase)
                    OriginalDofs = Dofs;
                    Dofs = OriginalDofs - MeanDofs;
                    for iE = 1:nCoords
                        iEigen = iEig(iE);
                        nDofs = size(Dofs);
                        EigenVector = GetVector(iEigen,V,nDofs);
                        coefficients(iE,iC) = reshape(Dofs,1,prod(nDofs)) * reshape(EigenVector,1,prod(nDofs))';
                    end

                    if(bDebug)
                        subplot(411); imagesc(OriginalDofs); title(sprintf('Dofs case %i',iC));
                        subplot(412), imagesc(Dofs); title('Dofs without mean');
                        subplot(413), imagesc(MeanDofs); title('Mean Dofs');
                        subplot(414), imagesc(GetVector(1,V,nDofs)); title(sprintf('Eigenvector %i',iE));
                        pause();
                    end
                    CasesNames(iValidCase).name = CaseFolderName;
                    AllCasesNames(iC).name = CaseFolderName;
                    AllCasesNames(iC).ID = output.CaseID;
                else
                    fprintf(' Directory without the image! (%s)\n',CaseDirectory);
                end
            else
                fprintf(' Directory without the key file! (%s)\n',CaseDirectory);
            end
                    
        end
    end
    fprintf(' Computed %i valid coefficients (out of %i). Condition: %s. AtlasSubGroup: %s.\n',numel(CasesNames),numel(AllCasesNames),cond,AtlasSurname);
    if(bAllCases)
        fprintf('Saving shape coefficients for all cases to %s\n',CoordsMatFileName);
        save(CoordsMatFileName,'AllCasesNames','coefficients');
    end
end
cases = squeeze(struct2cell(AllCasesNames));
caseNames = cases(1,:);
caseIDs = cell2mat(cases(2,:));
coefficientsOut = coefficients(eigvectors2output,:);
    
if ~isnan(VectorClass)
    bBoxPlot = 1;
else
    bBoxPlot = 0;
end
   
H1 = NaN; H2 = NaN; H3 = NaN;
if(bPlot)
    H1 = figure('color',[1 1 1],'OuterPosition',[0 10 1800 1500]);
    H2 = figure('color',[1 1 1],'OuterPosition',[500 10 800 1200]);
    if(bBoxPlot), H3 = figure('color',[1 1 1],'OuterPosition',[500 10 400 1200]);   end    
end
Handles = [H1 H2 H3];

nCoords2plot = numel(iEig2plot);
    for iC = 1:nCoords
        if(bPlot)&&(iC<=nCoords2plot)
            figure(H1); subplot(nCoords2plot,1,iC); hold on;
            figure(H2); subplot(nCoords2plot,1,iC); hold on;
            if(bBoxPlot), figure(H3); subplot(nCoords2plot,1,iC); hold on; end
        end
        if(bClassesAvailable)
            if isstruct(ClassDefinition)                
                Class = ClassDefinition;
                nClasses = numel(Class);
            else
                % TODO: Create analogous structure:
                [nCasesPerClass nClasses] = size(ClassDefinition);
                IndexesPerClass = zeros(nClasses,nCasesPerClass);
                for iClass=1:nClasses
                    Class(iClass).Indexes = ClassDefinition(:,iClass);
                    Class(iClass).nCases = numel(ClassDefinition(:,iClass));
                end
            end
            ValidFileID = sort(cell2mat({Class(:).FileID}));
            for iClass = 1:nClasses
                IndexesPerClass = GetIndexesPerClass(Class,iClass,ListCases);
                if(bPlot)&&(iC<=nCoords2plot)
                    AllCoefs = coefficients(iC,:);
                    coefs2bar = zeros(size(AllCoefs));
                    coefs2bar(IndexesPerClass) = AllCoefs(IndexesPerClass);
                    coefs2hist = AllCoefs(IndexesPerClass);
                    figure(H1);  bar(coefs2bar,'FaceColor',GetAtlasColor(iClass,colourscheme));
                    figure(H2);  [A,B] = hist(coefs2hist,10); bar(B,A,'FaceColor',GetAtlasColor(iClass,colourscheme)); alpha(0.5)                    
                end
            end
            if(bBoxPlot)&&(bPlot)&&(iC<=nCoords2plot), figure(H3); 
                ValidCoeffs = AllCoefs(ValidFileID);
                boxplot(ValidCoeffs,VectorClass);  end
        else
            if(bPlot)&&(iC<=nCoords2plot)
                 bar(coefficients(iC,:)); end
        end
        if(bPlot)&&(iC<=nCoords2plot)
            figure(H1);  
                set(gca,'XTick',1:nCases)
                set(gca,'XTickLabel',cases)
                title(sprintf('Coordinate %i',iEig(iC)))
            figure(H2);  
                title(sprintf('Coordinate %i',iEig(iC)))
            if(bBoxPlot)
                figure(H3);  
                title(sprintf('Coordinate %i',iEig(iC)))
            end
        end
    end
end

function ID = GetIDfromName(name)
% Function to retrieve the numeric of a name ending in an unknown number of
% digits.
    bFromTheEnd = 1;
    ID = 0; II = 0;
    for In = numel(name):-1:1                    
        if(bFromTheEnd)
            character = name(In);
            if character>='0' && character<='9'
                % This is a digit:
                digits(In) = str2num(character);
                II = II + 1;
                ID = ID + digits(In) * 10^(II-1);
            else
                bFromTheEnd = 0;
            end
        end
    end                
end

function CaseFolderName = FindFolderWithID(direct,iCase)
% Function to find the folder with the name that ends in the digits of the
% iCase:
    CaseFolderName = NaN;
    for iDirect = 1:numel(direct)
        name = direct(iDirect).name;
        ID = GetIDfromName(name);
        if ID == iCase
            CaseFolderName = name;
            return;
        end
    end
end
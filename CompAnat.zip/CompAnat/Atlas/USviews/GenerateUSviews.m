function [v2ch,v3ch,v4ch] = GenerateUSviews(segmentationfile)
% 

% Load the image:
    [mask,hd] = io_ReadMedicalImage(segmentationfile);

% Learn the orientation of the anatomy:
% - assumption: a label with the RV centre
    opts.RVpoolLabel = 2;
    [R S dimensions] = get_shape_orientation(mask,hd,'LV',opts);
    %[dimensions R S] = AnalyseBiVShape(segmentationfile,'LV',CavInitAlingmentOptions);

    a=1;

end


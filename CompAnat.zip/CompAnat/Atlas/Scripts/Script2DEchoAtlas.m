clear; 

ColourChoice = 1;
OutName = 'AtlasOutput';

%==========================================================================
% Data directory and study characteristics
Root = 'C:\Data\Echo2D\';
ClinicalFile = 'FinalCASE-CONTROLS_with_wallfile.xlsx';
AtlasRoot = fullfile(Root,'Atlas');
options.RootName = 'WALL';
options.bRootfirstIDafter = 0;
options.chamberkeyword = '';
options.bTomTecInput = 0;
options.AtlasSurname = '3ch';
options.ApicalCriteria = 'Closest2transductor';
options.iFrames2mesh = 'D';
options.PostName{1} = 'FrameD';
WhichFrame = 'D';
options.iShapeSpace = 'R';
options.RawDataDir = fullfile(Root,'2Dshapesv2');
options.iChamber = 3;
options.bRecalculateEigenCoords = 1;

%% Core functionality
options.KeyFileKind4Mapping = 'text';
% Build the "meshes":
options.bStep1EncodeContours    = 1;
    options.bEncodeContours     = 1;
% Make the PCA:
options.bStep2MakeStatistics    = 0;
% Visualise results:
options.bStep3visualiceResults  = 0;
options.bPlotVariancePerMode    = 0;
options.bMovieModalVariation    = 0;
options.bStep3_ViewEigenSpace   = 0; 
options.bStatisticalAnalysisByExcelFile = 0;
options.bViewAverageShapes      = 0;
bViewBoxPlots                   = 0;
bSaveExcel                      = 0;

%==========================================================================

DataDir = fullfile(AtlasRoot,'AtlasData');
OutputDirectory= fullfile(AtlasRoot,OutName);
if ~exist(OutputDirectory,'dir'), mkdir(OutputDirectory); end
options.OutName = OutName;
options.OutputDirectory = OutputDirectory;


[ClassDefinitionInfo,txt] = xlsread(fullfile(AtlasRoot ,ClinicalFile));
optionsExcel.txt = txt;
[ClassDefinition,VectorClass,CaseMapping] = OrderExcelDataInClassStructure(ClassDefinitionInfo,DataDir,optionsExcel);
options.ClassDefinition = ClassDefinition;
    
AtlasFileName = CalculateUSAtlas(AtlasRoot,options);



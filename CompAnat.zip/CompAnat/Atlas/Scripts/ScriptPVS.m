% Script to analyse the PVS data from Henry

CaseDir = 'F:\Atlas\PVS Harry\TestCase2\';
CaseDir = 'F:\Atlas\PVS Harry\TestCase3\PVS Contours\221 dia + syst only\';
CaseDir = 'F:\Atlas\PVS Harry\TestCase3\PVS Contours\222 dia+syst only\';

CVIfile = ls([CaseDir '*.cvi42wsx' ]);
cvi42file = fullfile(CaseDir,CVIfile);
DICOMdir = CaseDir;

[C] = read_CVI42WSX( cvi42file , DICOMdir , 'verbose' );
LabelImage = CVI42Contour2Image( C , 1);

%%
for iLi = 1:numel(LabelImage)
    % Extract all images per time instant
    nT = LabelImage{iLi}.dim(4);
    for iT = 1:nT
        im = squeeze(LabelImage{iLi}.data(:,:,:,iT));
        hd.origin = LabelImage{iLi}.origin;
        hd.spacing = LabelImage{iLi}.spacing;
        hd.dim = LabelImage{iLi}.dim(1:3);
        hd.TransformMatrix = LabelImage{iLi}.TransformMatrix;
        hd = ParseHeader(hd);
        hd.Extension = '.gipl';
        ImageName = sprintf('SegmentSeries%iInstant%i',iLi,iT);
        File = fullfile(CaseDir,[ImageName '.gipl']);
        hd.File = File;
        io_WriteMedicalImage(File,im,hd);
%       Mv2w: 4x4 matrix (voxel to world coordinate transformation)
%       File: name of the file
%       Extension: to indicate the format
    end
end
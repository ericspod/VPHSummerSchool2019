% Script to prepare the CRT data:
cohort = 3;

switch cohort
    case 1, 
        RootDir = 'G:\CRT\KCL_GC\3DSSFP'; %'D:\GC_CASES_DICOMS_RAW';
        CheckDir = 'F:\Atlas\CRT\CRT_KCL\AtlasData';
        CheckDirSegment = 'F:\Atlas\CRT\Complete50b\AtlasData';
    case 3, RootDir = 'G:\CRT\SD\3DSSFP';
    case 4, RootDir = 'G:\CRT\VP2HF\3DSSFP';
    case 5, RootDir = 'G:\leftatrium\TS';
    case 6, RootDir = 'F:\Atlas\HFLeipzig\DICOM_SSFP';
    case 7, RootDir = 'G:\CRT\SHF\GC images';
end

bExtractStructure  = 0;
bGetSeriesName     = 0;
bExtractTriggerTim = 1;
    bExtractGrayscales = 1;
bCheckData = 0;

items = dir(RootDir);
iValid = 0;
for i=3:numel(items)
    ItemName = items(i).name;
    DirName = fullfile(RootDir,ItemName);
    CaseID = GetIDfromName(ItemName);
    if isdir(DirName)
        iValid = iValid + 1;
        matlabTempFile = fullfile(DirName,'DICOMinfo.mat');        
        if(bExtractStructure)
            fprintf(' Sorting DCM folder: %s\n',DirName);
            S = sortDCMfiles(DirName);
            save(matlabTempFile,'S');
        else
            if exist(matlabTempFile,'file')
                fprintf('Loading DICOM structure from %s\n', matlabTempFile);
                load(matlabTempFile);
                % This loads variable 'S'
            else
                fprintf('No DICOM structure found, extracting DICOM structure from %s\n', DirName);
                S = sortDCMfiles(DirName);
                save(matlabTempFile,'S');
            end    
        end
        
        if(bGetSeriesName)
            sername = S.Patient_01.Study_01.Serie_01.SerieDescription;
            fprintf('Name: %s\n',sername);
        end
        
        if(bExtractTriggerTim)
            OptExtract.InputStructureLevel = 'DicomDir';
            %OptExtract.InputStructureLevel = 'Series';
            OptExtract.Field2extract = 'TriggerTime';
            [T] = ExtractDICOMinfo(S,OptExtract);
            T = unique(cell2mat(T));
            TriggerTime(iValid,1:numel(T)) = T;
            HeartCycle = 0;
            if isfield(S.INFO,'HeartRate')
                if ~isempty(S.INFO.HeartRate)
                    HeartCycle = 1000*60/S.INFO.HeartRate;
                end
            end
            TriggerCyclePoint(iValid,1:numel(T)) = T/HeartCycle;
            CaseIDs{iValid} = sprintf('%i',CaseID);
            opt.iPhase = 1:numel(T);     
            opt.TrigTime = T;
            if(bExtractGrayscales)
                ExtractSSFP(S,opt);            
            end        
        end
        if(bCheckData)
            fprintf('===== Check: case %i =====\n',CaseID);
            % Check that the image resolutions are the same between the
            % data retrieved by Pablo from ArQ, and the original data
            % provided that was segmented by Gerardo
            bError = 0;
            bChecked = 0;
            bQuick = 1;
            if bQuick
                H.Scales(1:2) = S.Patient_01.Study_01.Serie_01.Orientation_01.Position_001.IMAGE_001.PixelsSpacing;
                H.Sizes(1:2) = S.Patient_01.Study_01.Serie_01.Orientation_01.Position_001.IMAGE_001.Size;
            else
                H = dicom_folder_info(DirName);
            end
            nDim = numel(H.Sizes);
            % H.Sizes is the size, the dimension of the image
            % H.Scales is the spacing
            for iCheck = 1:2
                switch iCheck,
                    case 1, Dir2check = CheckDir; keywordimage = '/*grayscale*';
                    case 2, Dir2check = CheckDirSegment; keywordimage = '/*.gipl';
                end
                ImageDir = fullfile(Dir2check,sprintf('KCL%03i',CaseID));
                ImageFile= ls([ImageDir keywordimage]);
                if numel(ImageFile)>0
                    bChecked = bChecked + 1;
                    [im,hd] = io_ReadMedicalImage(fullfile(ImageDir,ImageFile));
                    if hd.dim(1:nDim) ~= H.Sizes(1:nDim)
                        bError = 1;
                        fprintf('-------------- ERROR --------------\n');  
                        fprintf('Case %i has a mismatch in size!\n',CaseID);
                        fprintf('   H.Sizes = '); fprintf('%i, ',H.Sizes); fprintf('\n');
                        fprintf('   hd.dim = '); fprintf('%i, ',hd.dim); fprintf('\n');
                    end
                    epsilon = 1e-6;
                    if sum(abs(hd.spacing(1:nDim) - H.Scales(1:nDim)))>epsilon
                        bError = 1;
                        fprintf('-------------- ERROR --------------\n');  
                        fprintf('Case %i has a mismatch in spacing!\n',CaseID);   
                        fprintf('   H.Scales = '); fprintf('%i, ',H.Scales); fprintf('\n');
                        fprintf('   hd.spacing = '); fprintf('%i, ',hd.spacing); fprintf('\n');                 
                    end
                else
                    fprintf('Warning: no image to check in folder %s\n',ImageDir);
                end
            end
            if(~bError) && bChecked>0
                fprintf('-------------- PASSED! (nTests = %i) --------------\n\n',bChecked);  
            end
            fprintf('\n\n');
        end
    end
    nValid = iValid;
end

figure('color',[1 1 1]);
subplot(211)
plot(TriggerTime); hold on; plot(ones(1,nValid)*500,'r');
ax = gca;
set(ax,'XTick',[1:nValid]);
set(ax,'XTickLabel',CaseIDs);
legend('Trigger 1','Trigger 2');
xlabel('Case ID')
ylabel('Trigger time (ms)');
subplot(212)
plot(TriggerCyclePoint); hold on; plot(ones(1,nValid)*0.5,'r');
ax = gca;
set(ax,'XTick',[1:nValid]);
set(ax,'XTickLabel',CaseIDs);
legend('Trigger 1','Trigger 2');
xlabel('Case ID')
ylabel('Trigger cycle point (%)');

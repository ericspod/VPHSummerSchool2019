for iCon = 11
    for iAlig = 0:4:4
        BatchAtlas(iCon,iAlig);
        close all;
    end
end

bBuildMeshes = 0;
bBuildPCA = 0;
bComputeCoefs = 0;

Cohort = 3;
switch Cohort
    case 1
        AtlasRoot = 'F:\Atlas\AtriaJess\Preliminary\AtlasFreeOrientation';
        Fitting = 1;
    case 2
        AtlasRoot = 'F:\Atlas\AtriaJess\Preliminary\AtlasConstrainedOrientation';
        Fitting = 2;
    case 3
        AtlasRoot = 'F:\Atlas\AtriaJess\Atlas';
        Fitting = 2;
end

% Create the class to perform the analysis:
Atlas = AtlasClass(AtlasRoot);

% Define the template:
optTemplate.topology = 'Sphere';
optTemplate.nE = [12 12 1];
Atlas = Atlas.SetTemplate(optTemplate);


%% Build the meshes:
if(bBuildMeshes)
    RotT = [0 1 0;
            0 0 1;
            1 0 0];

    optBuildMeshes.LoD = 2;                 % Marta, 09/02/2016, Level of detail of fitting
    optBuildMeshes.MyoLabel = 1;            % label of the atrial blood pool
    optBuildMeshes.RVpoolLabel = 2;         % label of the aortic root
    optBuildMeshes.bUseNodalWarping = 1;    % it is a collapsed topology
    %optBuildMeshes.RotT = RotT;            % fix the rotation of template a-priori, since it is a perfect sphere
    optBuildMeshes.RotT = 'FromImage';      % fix the rotation of template to the orientation of the image (scanner coordinate system)
    
    optBuildMeshes.BinaryName = 'Atria.nrrd';
    switch Fitting
        case 1
            optBuildMeshes.Rref = [0 0 1;0 1 0; -1 0 0];
        case 2
            optBuildMeshes.LVdir = [0 0 1];
            optBuildMeshes.DirSecondAxis =[0 1 0];
    end    
    %Atlas = Atlas.BuildMeshes(optBuildMeshes);
    Atlas = Atlas.BuildMeshID(162,optBuildMeshes);
end


%% Build the statistical shape model

if(0)
    CreateExcelClassFile(Atlas.DataDirectory);
end

ShapeSpace = 'rotat';
switch ShapeSpace
    case 'NoAlign'
        options.iShapeSpace = 0;
    case 'centre'
        options.iShapeSpace = 1;
    case 'rotat'
        options.iShapeSpace = 2;
    case 'scale'
        options.iShapeSpace = 3;
    case 'secondaxis'
        options.iShapeSpace = 4;
end

dofs2select = 2;
switch dofs2select
    case 1
        options.bOnlyExtSurf = 0;
        options.KeyName = sprintf('Atria%s',ShapeSpace);        
    case 2
        options.bOnlyExtSurf = 1;
        options.KeyName = sprintf('AtriaExt%s',ShapeSpace);
end
if(bBuildPCA)    
    Atlas = Atlas.BuildPCA(options);
else
    Atlas = Atlas.LoadPCAaxis(options);
end

%% Visualise and analyse the data:

% Compute the coefficients:
if(bComputeCoefs)
    Atlas = Atlas.CalculatePCAcoefs();
else
    Atlas = Atlas.LoadPCAcoefs();
end

% Convert all meshes:
%Atlas.SaveVTKmeshes()
%%

% CreateExcelClassFile(Atlas.DataDirectory,2);

if(0)
    % Visualise the average shape:
    Atlas.ViewMeanMesh();
    Atlas = Atlas.SetClass(fullfile(Atlas.RootDir,'infocases.xls'),3);
    Atlas.ViewEigenSpace();

    Atlas.CompareClassesByPCAaxis();
end

switch ShapeSpace
    case 'rotat'
        RelevantPCAmodes = [1 11 12];
        OptimalPCA = [1 11];
    case 'scale'
        RelevantPCAmodes = [3 9 10 11 13];
        OptimalPCA = [3 9 10 13];
    otherwise
        RelevantPCAmodes = 20;
end

if(0)
    Atlas3 = Atlas.ComprehensiveLDA(RelevantPCAmodes);

    optLDA.bLeave2out = 1;
    optLDA.nLOut = 4;
    Atlas3 = Atlas.StudyLDAcombination(OptimalPCA,optLDA);
% Atlas1 = Atlas.ComprehensiveLDA(20);
% optLDA.CoreModes =  1; 
% Atlas2 = Atlas.ComprehensiveLDA([2:15],optLDA);
% 
% Atlas3 = Atlas.ComprehensiveLDA([2:15]);
end

if(1)
    % Study the predictive power of LV dysfunction
    Atlas = Atlas.SetClass(fullfile(Atlas.RootDir,'infocases.xls'),4);
    Atlas.CompareClassesByPCAaxis();
    Atlas2 = Atlas.ComprehensiveLDA(5);
end

if(0)
    % Correlation with ST2/galetcin 3
    Atlas = Atlas.LinearRegressionModel(10,5,1);
end
if(0)
    % Correlation with pre-atrial size
    Atlas = Atlas.SetClass(fullfile(Atlas.RootDir,'infocases.xls'),6);
    Atlas = Atlas.LinearRegressionModel(11,5,1);
end

    
    
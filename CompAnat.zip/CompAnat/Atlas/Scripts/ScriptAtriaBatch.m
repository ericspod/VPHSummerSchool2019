% Script to process atrial segmentations from Thackshy and Georgia, and
% build a statistical shape model

segm = 'G'; % G for Georgia, T for Thakshy
AtrialLabel = 1; % from the segmentation
AorticRootLabel = 2; % from the segmentation

bCreateDataStructure = 1; % if 1, creates a folder for each case and phase
bBuildMeshes = 1;
    InitialAlignmentOption = 1;
bBuildPCA = 1;
bComputeCoefs = 1;

% directory the data comes from
SegmDir = 'C:\Users\Owner\Documents\Uni\TestAtlas\rawdata'; %'C:\Users\gm16\Dropbox\Georgia\SegmentationsMeshes/';
% directory where the meshes will be
OutRoot = 'C:\Users\Owner\Documents\Uni\TestAtlas/';


switch segm
    case 'T'
        AtlasRoot = fullfile(OutRoot,'\Thakshy');
    case 'G'
        AtlasRoot = fullfile(OutRoot,'\Georgia');
end

% Key naming 
DataDir = fullfile(AtlasRoot,'AtlasData');


%% Generate the data structure:
if ~exist(AtlasRoot,'dir'), mkdir(AtlasRoot); end
if ~exist(DataDir,'dir'), mkdir(DataDir); end

if(bCreateDataStructure)
% 1. Create a folder per each case and phase:
    % list the segmentation files:
    files = dir(SegmDir);
    for iF = 3:numel(files)
        filename = files(iF).name;
        if filename(1) == segm
            [ID,phases,class] = GetIDandPHfromName(filename);
            if ~isempty(ID)
                if isempty(phases)
                    phases = [1 2 3];
                end
                nPhases = numel(phases);
                [im,hd] = io_ReadMedicalImage(fullfile(SegmDir,filename));
                if nPhases > 1
                    nSlices = hd.dim(3)/nPhases;
                    % Prepare the header of the images:
                    hd2 = hd;
                    hd2.dim(3) = nSlices;

                    % Indexing of the image to be splited:
                    z1 = nPhases*nSlices;
                    dz = nPhases;

                    % one file has several phases. Capture the aortic root first:
                    bRootFound = 0;
                    for iP = 1:nPhases
                        z0 = iP;
                        im2 = im(:,:,z0:dz:z1);   
                        if bRootFound == 0
                            % Capture the aortic root label:
                            imRoot = zeros(size(im2));
                            % Check the existence of the aortic root:
                            I = find(im2==AorticRootLabel);
                            if numel(I) > 0
                                bRootFound = 1;
                                imRoot(im2==AorticRootLabel) = AorticRootLabel;
                                fprintf('Aortic root found in %s, phase %i\n',filename,phases(iP));
                            end
                        end
                    end
                    if (~bRootFound)
                        fprintf('ERROR! No aortic root found in %s\n',filename);
                    end
                    for iP = 1:nPhases
                        ph = phases(iP);
                        % Use a consistent naming accross:
                        NewName = sprintf('Case%03i%02i',ID,ph);
                        CaseDir = fullfile(DataDir,NewName);
                        if ~exist(CaseDir,'dir'), mkdir(CaseDir); end
                        % Get the binary mask and save it in the directory:
                        z0 = iP;
                        im2 = im(:,:,z0:dz:z1);   
                        % Add the aortic root, making sure it does not overlap with
                        % the atrial mask:
                        temp = zeros(size(im2));
                        temp( imRoot==AorticRootLabel ) = AorticRootLabel;
                        temp( im2 == AtrialLabel ) = AtrialLabel;
                        im2 = temp;
                        io_WriteMedicalImage(fullfile(CaseDir,[NewName '.gipl']),im2,hd2);
                    end
                else
                    %NewName = sprintf('Case%04i',ID);
                    NewName = RemovePathAndExtension(filename);
                    CaseDir = fullfile(DataDir,NewName);
                    if ~exist(CaseDir,'dir'), mkdir(CaseDir); end
                    io_WriteMedicalImage(fullfile(CaseDir,[NewName '.nii']),im,hd);
                end
            end
        end
    end
end

% Create the class to perform the analysis:
Atlas = AtlasClass(AtlasRoot);

% Define the template:
optTemplate.topology = 'Sphere';
optTemplate.nE = [12 12 1];
Atlas = Atlas.SetTemplate(optTemplate);

%% Build the meshes:
if(bBuildMeshes)
    RotT = [0 1 0;
            0 0 1;
            1 0 0];

    optBuildMeshes.LoD = 1;                 % Marta, 09/02/2016, Level of detail of fitting
    optBuildMeshes.MyoLabel = 1;            % label of the atrial blood pool
    optBuildMeshes.RVpoolLabel = 2;         % label of the aortic root
    optBuildMeshes.bUseNodalWarping = 1;    % it is a collapsed topology
    optBuildMeshes.RotT = RotT;             % fix the rotation of template a-priori, since it is a perfect sphere
    
    switch InitialAlignmentOption
        case 1
            % Perpendicular to plane
            optBuildMeshes.bHorizontalBase = 1;
        case 2
            % Average of the three phases: need to code it!
            
    end
    Atlas = Atlas.BuildMeshes(optBuildMeshes);
end




%% Build the statistical shape model
ShapeSpace = 'rotat';
switch ShapeSpace
    case 'NoAlign'
        options.iShapeSpace = 0;
        outdir = 'AtlasOutputNA';
    case 'centre'
        options.iShapeSpace = 1;
        outdir = 'AtlasOutputC';
    case 'rotat'
        options.iShapeSpace = 2;
        outdir = 'AtlasOutputR';
    case 'scale'
        options.iShapeSpace = 3;
        outdir = 'AtlasOutputS';
    case 'secondaxis'
        options.iShapeSpace = 4;
        outdir = 'AtlasOutputrv';
end

options.KeyName = sprintf('Atria%s%s',ShapeSpace,segm);
if(bBuildPCA)    
    Atlas = Atlas.BuildPCA(options);
else
    Atlas = Atlas.LoadPCAaxis(fullfile(AtlasRoot,outdir));
end

%% Visualise and analyse the data:

% Compute the coefficients:
if(bComputeCoefs)
    Atlas = Atlas.CalculatePCAcoefs();
else
    Atlas = Atlas.LoadPCAcoefs(fullfile(AtlasRoot,outdir,sprintf('Coordinates%s.mat',options.KeyName)));
end

% Convert all meshes:
Atlas.SaveVTKmeshes()

% Visualise the average shape:
Atlas.ViewMeanMesh();

Atlas.ViewEigenSpace();

    
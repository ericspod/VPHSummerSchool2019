% Script to process a mask of a BiV mesh and produce a template oriented of
% the LV, to be used in the analysis of the HCM cohort.

CaseDir = 'C:\Data\data\HCM\GIPLs4Sohini\';
File = 'DTI001.gipl';

opt.labels = [1 2];
opt.Target = 'LV';
LVslices = AnalyseMask(fullfile(CaseDir,File),opt);

options.LVslices = LVslices;
options.nIterationsPunch = 10;
options.nE = [6 12 1];
Template = SynthetiseHeart(options);
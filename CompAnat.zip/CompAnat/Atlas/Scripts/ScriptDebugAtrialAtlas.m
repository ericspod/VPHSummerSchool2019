% Script to debug the atrial shape space...
AtlasRoot = 'F:\Atlas\Atria\Atlas';
AtlasRoot = 'C:\Data\atriatlas';

Atlas = AtlasClass(AtlasRoot);
%Atlas = Atlas.LoadPCAaxis(fullfile(AtlasRoot,'AtlasOutputC'));
%Atlas = Atlas.LoadPCAcoefs(fullfile(AtlasRoot,'AtlasOutputC','CoordinatesAtriacentreT'));

% Define the template:
optTemplate.topology = 'Sphere';
optTemplate.nE = [12 12 1];
Atlas = Atlas.SetTemplate(optTemplate);

if(1)
    options.iShapeSpace = 0;
    options.bOnlyExtSurf = 1;
    options.KeyName = 'AtriaDebExt';
    options.OutputDirectory = 'AtlasOutputDebEx';
else
    options.iShapeSpace = 1;
    options.bOnlyExtSurf = 0;
    options.KeyName = 'AtriaDeb';
    options.OutputDirectory = 'AtlasOutputDeb';
end
if(1)
    Atlas = Atlas.BuildPCA(options);
else
    Atlas = Atlas.LoadPCAaxis(options);
end
if(1)
    Atlas = Atlas.CalculatePCAcoefs();
else
    Atlas = Atlas.LoadPCAcoefs();
end
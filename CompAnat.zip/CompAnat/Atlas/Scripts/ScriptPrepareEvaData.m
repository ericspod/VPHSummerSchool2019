% Script to order the data provided by Eva
bCreateAtlasStructure = 0;
bGenerateBinaries = 0;


%%
% Naming ocnvention: systolic frames have an offset of 100 (first digit
% codifies if diastolic-0, or systolic-1);
SysOffset = 100;

RootFolder = 'F:\Atlas\DCM_Sammut\DTI_DCM_SHAPE\DTI_DCM_SHAPE';
names{1} = 'CONTROLS';
names{2} = 'DCM';

DataDir = 'F:\Atlas\DCM_Sammut\Atlas\AtlasData';

if ~exist(DataDir,'dir'), mkdir(DataDir); end

if (bCreateAtlasStructure)
    iCase = 0;
    for iG = 1:2
        Root = fullfile(RootFolder,(names{iG}));
        listcases = dir(Root);
        for iF = 3:numel(listcases)
            DirName = listcases(iF).name;
            Direct  = fullfile(Root,DirName);
            if isdir(Direct)
                iCase = iCase + 1;
                cvi42file = ls([Direct '/*.cvi42*']);
                initials = cvi42file(1:2);
                AtlasDataDir = fullfile(DataDir,sprintf('%s%02i',initials,iCase));
                if ~exist(AtlasDataDir,'dir'), mkdir(AtlasDataDir); end
                fprintf('Copying file %s into %s\n',cvi42file,AtlasDataDir);
                copyfile(fullfile(Direct,cvi42file),AtlasDataDir);
                % Save the directory path to the original dicoms:
                path2dicom = ls([Direct '/*dicom*']);
                DicomDir = fullfile(Direct,path2dicom);
                path2serie = ls([DicomDir '/*serie*']);
                DicomDir = fullfile(DicomDir,path2serie);
                save(fullfile(AtlasDataDir,'DicomDir.mat'),'DicomDir');
                % Copy also the DicomDir to the systolic frames:
                SysAtlasDataDir = fullfile(DataDir,sprintf('%s%02i',initials,iCase + SysOffset));
                if ~exist(SysAtlasDataDir,'dir'), mkdir(SysAtlasDataDir); end                
                save(fullfile(SysAtlasDataDir,'DicomDir.mat'),'DicomDir');                
            end
        end
    end
end

if(bGenerateBinaries)
    % It is supposed that there are no systolic folders with the cvi42
    % info!
    [ListCases CaseDirectories] = GetCasesInDirectory(DataDir);
    for iCase = 1:numel(ListCases)
        CaseDir = fullfile(DataDir,CaseDirectories(iCase).name);
        CMR42file = ls([CaseDir '/*.cvi42*']);
        load(fullfile(CaseDir,'DicomDir.mat'));        
        fichero_cvi42wsx = fullfile(CaseDir,CMR42file);
        if(0)
            options.DICOMDirectory = DicomDir;
            [im,hd,grayscale] = io_GetSegmentationMaskFromCMR42Output(fichero_cvi42wsx,options);
        else
            % Ernesto's code:
            % Al directorio de DICOMs lo explora recursivamente.
            [C] = read_CVI42WSX( fichero_cvi42wsx , DicomDir , 'verbose' );
            
            LabelImage = CVI42Contour2Image( C );
            nSeries = numel(LabelImage);
            for iS = 1:nSeries
                % Get the image, size [CCC(1).ImageSize , CCC(1).NumberOfSlices , CCC(1).NumberOfTimeInstant]
                Image4D = LabelImage{iS}.data;
                hd.origin = LabelImage{iS}.origin;
                hd.spacing = LabelImage{iS}.spacing;
                hd.TransformMatrix = LabelImage{iS}.TransformMatrix;
                hd.dim = LabelImage{iS}.dim(1:3);
                hd = ParseHeader(hd);
                nTimes = size(Image4D,4);
                for iT = 1:nTimes
                    Image3D = squeeze(Image4D(:,:,:,iT));
                    if numel(find(Image3D))>0
                        % There is some segment information here:
                        if iT>1
                            % this is a systolic frame
                            casename = CaseDirectories(iCase).name;
                            % the two first characters are char, not digits                            
                            CaseID = sscanf(casename(3:end),'%f') + SysOffset;
                            SysName = sprintf('%s%i',casename(1:2),CaseID);
                            CaseDirSys = fullfile(DataDir,SysName);
                            if ~exist(CaseDirSys,'dir'), mkdir(CaseDirSys); end
                            filename = fullfile(CaseDirSys,sprintf('%s.gipl',SysName));
                        else
                            % This is a diastolic frame
                            filename = fullfile(CaseDir,sprintf('%s.gipl',CaseDirectories(iCase).name));
                        end
                        io_WriteMedicalImage(filename,Image3D,hd);
                    end
                end
            end
                
        end
    end

    a=1;
    %imageout = fullfile(DataDir,CaseDirectories(iCase).name,'binary.gipl');
    %io_WriteMedicalImage(imageout,im,hd);
end    


% Los DICOMs corresponden a una �nica serie que tiene como descripci�n "2chCINE".
% La serie es un stack de 16 slices de 288 x 288 pixels 
% (tama�o de pixel 1.5625 x 1.5625) y tiene 30 instantes de tiempo.
% A cada uno de los instantes de tiempo te los convert� en un fichero .NII 
% ("grayscale_01.nii" ... "grayscale_30.nii").


unique( { C.Description } )   %--> 'lineRoiContour'    'saendocardialContour'    'saepicardialContour'    'sarvendocardialContour'

unique( [ C.TimeInstant ] )   %--> [1 10]  lo que significa que solo los instantes 1 y 10 est�n delineados
%%
figure; hold on
for c = find( [C.TimeInstant] == 1 )
  plot3( C(c).Points3D(:,1) , C(c).Points3D(:,2) , C(c).Points3D(:,3) , '.-' , 'color',rand(1,3) );
end; hold off

figure; hold on
for c = find( [C.TimeInstant] == 10 )
  plot3( C(c).Points3D(:,1) , C(c).Points3D(:,2) , C(c).Points3D(:,3) , '.-' , 'color',rand(1,3) );
end; hold off





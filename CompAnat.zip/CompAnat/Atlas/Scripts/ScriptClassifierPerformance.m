% Script to compare the ROCs

if(0)
    close all;
    clear;
end

GroupedModes{1} = [2 5];

iComparison = 1;
iSub = 2;
iShapeSpace = 1;

AtlasVersion = 16;
Sversions = [3 4 11];

    subversion = Sversions(iSub);
    AtlasFileName = 'Atlas.mat';

    options.bRecalculateEigenCoords = 0;
    versionstring = sprintf('%i_%i_%i',AtlasVersion,subversion,iComparison);
    options.versionstring = versionstring;

    StudyParams = GetAtlasStudyParams(AtlasVersion,subversion,iComparison,iShapeSpace);
    fields = fieldnames(StudyParams.options);
    for iField = 1:numel(fields)
        options = setfield(options,fields{iField},getfield(StudyParams.options,fields{iField}));
    end
    options.AtlasVersion = AtlasVersion;
    options.subversion = num2str(subversion);
    classes2include = [1 2 ];
    if isfield(StudyParams,'classes2include'), classes2include = StudyParams.classes2include; end                

    Directory = StudyParams.Directory;
    OutputDirectory = options.OutputDirectory; 
    if ~exist('ClassDefinition','var')
        optionsloadClass = StudyParams.optionsExcel;
        optionsloadClass.DataDirectory = options.DataDirectory;
        optionsloadClass.bOnlyIncludeCasesInExcelFile = 1;
        optionsloadClass.AtlasVersion =  AtlasVersion;
        optionsloadClass.classes2include = classes2include;
        [ClassDefinition,Cases2include] = LoadAtlasClass(Directory, StudyParams.ClinicalFile, optionsloadClass);
    end
    if ~isempty(Cases2include)
        options.Cases2include = Cases2include;
    end 

    if ~exist('coefficients','var')
        % This call updates the ListCases with the set of valid cases after
        % exploring the data directory:
        [coefficients,cases,~,ListCases] = GetEigenCoefficients(Directory,options);
    end
    % need to load the PCA axes:
    PCAfile = fullfile(OutputDirectory,AtlasFileName);
    fprintf('Loading PCA axes from %s\n',PCAfile);
    load(PCAfile);

    % Computation of the p-value
    I1 = GetIndexesPerClass(ClassDefinition,classes2include(1),ListCases);            
    I2 = GetIndexesPerClass(ClassDefinition,classes2include(2),ListCases);  
    GM = cell2mat(GroupedModes);
    [w,p] = fisher( coefficients(GM, I1 ) , coefficients(GM, I2 ) ); 
    
    % COMPUTATION OF THE AUCs:
    optionsLDA = options;   
    optionsLDA.iShapeSpace = iShapeSpace;
    optionsLDA.iMeshing = iSub;
    optionsLDA.bPrintROCs = 0;
    optionsLDA.bPredictive = 0; 
    AUCres = AtlasLinearDiscriminantAnalysis(GroupedModes,coefficients,ClassDefinition,ListCases,V,optionsLDA);
    optionsLDA.bPredictive = 1; 
    AUCcross = AtlasLinearDiscriminantAnalysis(GroupedModes,coefficients,ClassDefinition,ListCases,V,optionsLDA);

    switch iComparison
        case 1, ResponseCriterion = 'EDV';
        case 2, ResponseCriterion = 'ESV';
        case 3, ResponseCriterion = 'cohort';
        otherwise, ResponseCriterion = '';
    end
    switch iShapeSpace, 
        case 0, SpaceString = 'NA';
        case 1, SpaceString = 'C';
        case 2, SpaceString = 'R';
        case 3, SpaceString = 'S';
        case 4, SpaceString = 'rv';
    end
    
fprintf('Classification(%s,%s): p-value,AUCres,AUCcross= %1.5f, %1.5f, %1.5f\n',ResponseCriterion,SpaceString,p,AUCres(1),AUCcross(1));

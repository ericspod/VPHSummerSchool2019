% Script to prepare the MICCAI data

Root = 'F:\Atlas\MICCAI09 Challenge\DataFromToronto\';
OutDir = 'F:\Atlas\MICCAI09 Challenge\AtlasData';

for iBatch = 1:3
    switch iBatch
        case 1
            DICOMroot = [Root 'challenge_online'];
            CONTOroot = [Root 'Sunnybrook Cardiac MR Database ContoursPart1\OnlineDataContours'];
        case 2
            DICOMroot = [Root 'challenge_validation'];            
            CONTOroot = [Root 'Sunnybrook Cardiac MR Database ContoursPart2\ValidationDataContours'];
        case 3
            DICOMroot = [Root 'challenge_training'];
            CONTOroot = [Root 'Sunnybrook Cardiac MR Database ContoursPart3\TrainingDataContours'];
    end
    
    ListDirCont = dir(CONTOroot);
    ListDirDICO = dir(DICOMroot);
    % Get the contour files
    for iC = 3:numel(ListDirCont);
        DirName = ListDirCont(iC).name;
        DirC = fullfile(CONTOroot,DirName,'contours-manual','IRCCI-expert');
        % Get the dicom dir of this subject:
        bFound = 0;
        for iD = 3:numel(ListDirDICO)
            DICn = ListDirDICO(iD).name;
            if strcmp(DirName,DICn)
                bFound = 1;
                DICOMdir = fullfile(DICOMroot,DICn);
            end
        end
        if ~bFound
            fprintf('ERROR! no dicom dir found for %s\n',DirName);
        else        
            CaseDir = fullfile(OutDir, DirName);
            if ~exist(CaseDir,'dir'), mkdir(CaseDir); end
            
            % Get the DICOM information:
            matlabDicomDir = fullfile(CaseDir,'SAstackDICOMDIR.mat');
            if ~exist(matlabDicomDir,'file')
                fprintf(' Sorting DCM folder: %s\n',DICOMdir);
                S = sortDCMfiles(DICOMdir);
                save(matlabDicomDir,'S');
            else
                load(matlabDicomDir);
            end
            
        % Get the names of the matching files:
            ListContFiles = dir(DirC);     
            Icons = [];  % I contours are inner contours
            Ocons = [];  % O contours are outer contours, contours that segment the epicardium
            for icont = 3:numel(ListContFiles)
                % in each contour file, capture the name:
                ConName = ListContFiles(icont).name;
                seriesID = sscanf(ConName(4:7),'%i');
                phase = sscanf(ConName(9:12),'%i'); 
                if numel(phase)>1, 
                    phase = phase(2) + phase(1)*10; 
                end
                phases(icont) = phase;
                Type = ConName(14:17);
                switch Type
                    case 'icon'
                        Icons = [Icons icont];
                    case 'ocon'
                        Ocons = [Ocons icont];
                end
            end
            
        % Now we will try to identify the sequence corresponding to the
        % contours, with two criteriaL
        % - it has enough dicom files
        % - it has enough time points
            nFilesTh = max(phases);
            % Contours are in peak diastole and peak systole:
            nSlicesTh = max(numel(Icons),numel(Ocons))/2;
            
            [nFiles, nSlices, nTimes] = ExtractSliceBasicInfo(S);
            
            % Now find the orientation that has enough files:
            I1 = find( nFiles > nFilesTh );
            % That has enough slices:
            I2 = find( nSlices > nSlicesTh );
            % And that has at least 10 time points:
            I3 = find( nTimes > 10 );
            
            I = intersect(I1,I2);
            I = intersect(I,I3);
            if numel(I) == 1
                fprintf('Dicom stack found! Extracting the frames...\n');
                OR = S.Patient_01.Study_01.Serie_01.(sprintf('Orientation_%02i',I));
                % Get the list of files:
                    iFile = 0;
                    ListPosit = fieldnames (OR);
                    ListPosit = ListPosit( strncmp('Posit',ListPosit,5) );
                    nPosit = numel(ListPosit);
                    for iPo = 1:nPosit
                        % ... the number of images per position (most likely
                        % the number of time frames)
                        ListImages = fieldnames( OR.(sprintf('Position_%03i',iPo)) );
                        ListImages = ListImages( strncmp('IMAGE_', ListImages , 6));
                        nImages = numel(ListImages);      
                        for iIm = 1:nImages;
                            iFile = iFile  + 1;
                            DicomFiles{iFile} = OR.(sprintf('Position_%03i',iPo)).(sprintf('IMAGE_%03i',iIm)).FileName;
                        end
                    end
                    
                % There is a large confusion between names, group them:
                clear 'Group';
                    iGroup = 1;
                    Name = DicomFiles{1};
                    Ir = strfind(Name,'IM-');                    
                    Group{1}.RootName = Name(Ir+3:Ir+6);
                    Group{1}.Files = 1;
                    for iFile = 2:numel(DicomFiles)
                        Name = DicomFiles{iFile};
                        Ir = strfind(Name,'IM-');
                        RootN = Name(Ir+3:Ir+6);
                        % Check if it exists:
                        bExist = 0;
                        for iG = 1:numel(Group)
                            if strcmp(Group{iG}.RootName , RootN)
                                bExist = 1;  
                                iGroup = iG;
                            end
                        end
                        if ~bExist
                            % new group
                            Group{iG+1}.RootName = RootN;
                            Group{iG+1}.Files = iFile;
                        else
                            Group{iGroup}.Files = [Group{iGroup}.Files iFile];
                        end
                    end
                    
                % Now find the group within this orientation that has enough files:
                    for igr = 1:iG
                        nF = numel(Group{igr}.Files);
                        if nF > nFilesTh
                            bValidGroup(igr) = 1;
                        else
                            bValidGroup(igr) = 0;
                        end
                    end
                
                % Get the list of DICOM files:
                for iph = 1:numel(phases)
                    % find the matching file per each txt with contours:
                    phase2find = phases(iph);
                    a=1;
                end
            end
        end
    end
end





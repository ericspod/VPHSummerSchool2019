% Script to re-visit the results of the 144 Barna atrial shapes

AtlasVersion = 1;

bOrganiseAtlasData = 0;
bBuildMeshes = 0;
bCompute = 0;


RecThreshold = 1;
switch RecThreshold
    case 1, excelcolumn = 13;
    case 2, excelcolumn = 19;
end
% Where the atlas will be built
switch AtlasVersion
    case 1, 
        AtlasRoot = 'C:\Data\data\Atria\Bisbal13\AtlasNov16';
        iSP = 0; % Marta had pre-alignemd meshes
        bCorrectWeighting = 0; % Only way to get modes 1,2,8 performing similarly
        bExtSurf = 1; % If no correct weighting, no other chance here
    case 2, 
        AtlasRoot = 'C:\Data\data\Atria\Bisbal13\NewAtlas';
        iSP = 1;
        bCorrectWeighting = 1;
        bExtSurf = 1; % not relevant
end
excelfile2 = fullfile(AtlasRoot,'../Recurrence and morphological indexes v2.xls');

DataDir = fullfile(AtlasRoot,'AtlasData');
if(bOrganiseAtlasData)    
    listcases = dir(DataDir);
    for iF = 3:numel(listcases)
        name = listcases(iF).name;
        casedir= fullfile(DataDir,name);
        outdir = fullfile(casedir,'Output_heartgen');
        if(0)
            mkdir(outdir);
            % Place ex files in right place
            exfile = ls([casedir '\*.exnode']);
            movefile(fullfile(casedir,exfile) ,outdir);  
            exfile = ls([casedir '\*.exelem']);
            movefile(fullfile(casedir,exfile) ,outdir);  
            % Create a mock file for naming purposes:
            fid = fopen(fullfile(casedir,[name '.gipl']),'w');
            fclose(fid);
        end
        if(0)
            % Rename meshes into _mesh:
            exfile = ls([outdir '\*.exnode']);
            movefile(fullfile(outdir,exfile) ,fullfile(outdir,[name '_mesh.exnode']));
            exfile = ls([outdir '\*.exelem']);
            movefile(fullfile(outdir,exfile) ,fullfile(outdir,[name '_mesh.exelem']));
        end
    end
end

Atlas = AtlasClass(AtlasRoot);
obj.bCorrectBasisWeights = bCorrectWeighting;

switch AtlasVersion
    case 1
        % Set the template, take one of the cases:
        Template = CubicMeshClass(fullfile(AtlasRoot,'TemplateDir','Case001'));
        % Enrich the information:
        complete.nE = [6 12 2];
        complete.SecAxLocation = 'MinY';
        complete.topology = 'sphere';
        Atlas = Atlas.SetTemplate(Template,complete);
    case 2
        optTemplate.topology = 'Sphere';
        optTemplate.nE = [12 12 1];
        Atlas = Atlas.SetTemplate(optTemplate);
end

for ExtSurfOnly = bExtSurf
    for SP = iSP
        options.iShapeSpace = SP;

        options.bOnlyExtSurf = ExtSurfOnly;
        if (~bCorrectWeighting)
            options.KeyName = sprintf('AtriaS%iExt%iNoWeight',SP,ExtSurfOnly);
        else
            options.KeyName = sprintf('AtriaS%iExt%i',SP,ExtSurfOnly);
        end
        options.AtlasName = sprintf('Atlas%s.mat',options.KeyName);
        if(bBuildMeshes)
            switch AtlasVersion
                case 2
                    optBuildMeshes.LoD = 1;                 % Marta, 09/02/2016 (changed to 1 from 2), Level of detail of fitting
                    optBuildMeshes.bUseNodalWarping = 1;    % it is a collapsed topology
                    RotT = [ 0 0 1;
                             1 0 0;
                             0 1 0];
                    optBuildMeshes.LVdir = [0 0 1];
                    optBuildMeshes.RotT = RotT;             % fix the rotation of template a-priori, since it is a perfect sphere
                    optBuildMeshes.DirSecondAxis =[0 1 0];

                    Atlas = Atlas.BuildMeshes(optBuildMeshes);
            end
        end
        if(bCompute)
            Atlas = Atlas.BuildPCA(options);
        else
            Atlas = Atlas.LoadPCAaxis(options);
        end
        if(bCompute)
            Atlas = Atlas.CalculatePCAcoefs();
        else
            Atlas = Atlas.LoadPCAcoefs();
        end
        
        Atlas = Atlas.SetClass(excelfile2,excelcolumn);
        
        
        if(bCompute)
            Atlas.CompareClassesByPCAaxis();
            Atlas.SearchPredictiveMetric(15);
        else
            %Atlas.CompareClassesByPCAaxis();
            %Atlas = Atlas.ComprehensiveLDA(15);
            Atlas = Atlas.StudyLDAcombination([1:15]);
            Atlas = Atlas.SearchPredictiveMetric([1 2 3 5 7:11 13:14]);
        end
    end
end

%% Check the excel file correctness
if(0)
    excelcolumn = 19;
    data = xlsread(excelfile2);
    recurr = data(:,excelcolumn);
    I1 = find(recurr==1);
    I2 = find(recurr==2);
    I3 = find(recurr==-1);
    figure; 
    plot(data(I1,5),data(I1,6),'r*')
    hold on;
    plot(data(I2,5),data(I2,6),'b*')
    plot(data(I3,5),data(I3,6),'g*')
    title(sprintf('%i rec, %i non rec, and %i censored',numel(I1),numel(I2),numel(I3)));
end

%% Compute the fitting residual
% Original data with segmentation and meshes
if(0)
    SegAndMeshes = 'C:\Data\data\Atria\Bisbal13\EuropaceMeshes';
    listcases = dir(SegAndMeshes);

    bComputeResidual = 0;

    for iF = 3:numel(listcases)
        direc = listcases(iF).name;
        BinaryImage = fullfile(SegAndMeshes,direc,ls(fullfile(SegAndMeshes,direc,'*.nii')));
        meshfile = ls(fullfile(SegAndMeshes,direc,'Case*.exnode'));
        [DIR, namefile, nameWithoutExtension] = GetPath(meshfile);
        if(bComputeResidual)
            mesh = CubicMeshClass(fullfile(SegAndMeshes,direc,nameWithoutExtension));

            ReportFile = fullfile(fullfile(SegAndMeshes,direc,[nameWithoutExtension '.txt']));
            OutputShapes.QShIRT = NaN;
            options.bQuality = 0;
        % Meshes were saved after correction of centre of mass: so need to
        % bring them back to compute fitting residual
            [im,hd] = io_ReadMedicalImage(BinaryImage);
            pts = getPoints_fromBinary(im,hd.origin,hd.spacing);
            centre = mean(pts,1);
            mesh2 = mesh.translateMesh(centre);

            OutputShapes.Shape3 = mesh2;

            WritePersonalizationReport(OutputShapes,ReportFile,BinaryImage,options);
        end
        casedir= fullfile(DataDir,nameWithoutExtension,'Output_heartgen');
        copyfile( fullfile(SegAndMeshes,direc,[nameWithoutExtension,'.txt']) , fullfile(casedir,['PersonalizationReport' nameWithoutExtension,'.txt']) );
        copyfile( fullfile(SegAndMeshes,direc,['Image*']) , casedir  );

    end
end

%% Aggregate the additional metrics:

if(0)
    switch AtlasVersion
        case 1
            modesOLDA = [1 2 8];
        case 2
            modesOLDA = [1 6 13];
    end    
    % At 12 months:
    Atlas = Atlas.SetClass(excelfile2,13);
    opt.bPredictive = 1;
    Atlas = Atlas.LinearDiscriminantAnalysis({[1:3]},opt);
    BS12 = Atlas.LDAaxis.PredictedScores;
    opt.bPredictive = 0;
    Atlas = Atlas.LinearDiscriminantAnalysis({[1:3]},opt);
    rBS12 = Atlas.CompareClassesByLDAaxis();

    opt.bPredictive = 1;
    Atlas = Atlas.LinearDiscriminantAnalysis({[5 11 14]},opt);
    IS12 = Atlas.LDAaxis.PredictedScores;   
    opt.bPredictive = 0;
    Atlas = Atlas.LinearDiscriminantAnalysis({[5 11 14]},opt);
    rIS12 = Atlas.CompareClassesByLDAaxis();
    
    opt.bPredictive = 1;
    Atlas = Atlas.LinearDiscriminantAnalysis({modesOLDA},opt);
    oL12 = Atlas.LDAaxis.PredictedScores;
    opt.bPredictive = 0;
    Atlas = Atlas.LinearDiscriminantAnalysis({modesOLDA},opt);
    roL12 = Atlas.CompareClassesByLDAaxis();
    
    % At 24 months:
    Atlas = Atlas.SetClass(excelfile2,19);
    opt.bPredictive = 1;
    Atlas = Atlas.LinearDiscriminantAnalysis({[1:3]},opt);
    BS24 = Atlas.LDAaxis.PredictedScores;
    opt.bPredictive = 0;
    Atlas = Atlas.LinearDiscriminantAnalysis({[1:3]},opt);
    rBS24 = Atlas.CompareClassesByLDAaxis();

    % The "intermediate shape" index: 
    opt.bPredictive = 1;
    Atlas = Atlas.LinearDiscriminantAnalysis({[6 10 13]},opt);
    IS24 = Atlas.LDAaxis.PredictedScores;
    opt.bPredictive = 0;
    Atlas = Atlas.LinearDiscriminantAnalysis({[6 10 13]},opt);
    rIS24 = Atlas.CompareClassesByLDAaxis();
    
    % The combined shape index at 24 months:
    opt.bPredictive = 1;
    Atlas = Atlas.LinearDiscriminantAnalysis({modesOLDA},opt);
    oL24 = Atlas.LDAaxis.PredictedScores;
    opt.bPredictive = 0;
    Atlas = Atlas.LinearDiscriminantAnalysis({modesOLDA},opt);
    roL24 = Atlas.CompareClassesByLDAaxis();
end
    


%% Explore the LDA on the original dofs
if(1)
    % At 12 months:
    Atlas = Atlas.SetClass(excelfile2,13);
    opt.LDAmatrixOption = 'linear';
    opt.bAUCs = 1;
    Atlas = Atlas.LoadPCAaxis(options);
    Atlas = Atlas.BuildLDA(opt);
    optv.colourscheme = 10;
    Atlas.ViewLDAextremeShapes(optv);
    Atlas.ViewLDAaxis;
    %rLD12 = Atlas.LDAaxis.ResubCoefs;
    LD12 = Atlas.LDAaxis;
    
    % At 24 months:
    Atlas = Atlas.SetClass(excelfile2,19);  
    Atlas = Atlas.LoadPCAaxis(options);
    Atlas = Atlas.BuildLDA(opt);
    Atlas.ViewLDAextremeShapes(optv);
    Atlas.ViewLDAaxis;
    %rLD24 = Atlas.LDAaxis.ResubCoefs;
    LD24 = Atlas.LDAaxis;
    
    if(0)            
        Atlas = Atlas.LoadPCAaxis(options);
        opt.LDAmatrixOption = 'diagLinear';
        Atlas = Atlas.BuildLDA(opt);
        Atlas.ViewLDAextremeShapes;
        Atlas.ViewLDAaxis;

        Atlas = Atlas.LoadPCAaxis(options);
        opt.LDAmatrixOption = 'pseudoLinear';
        Atlas = Atlas.BuildLDA(opt);
        Atlas.ViewLDAextremeShapes;
        Atlas.ViewLDAaxis;

        
    end
end
        
%% Study the complementarity of the metris:
if(0)
    [data,text] = xlsread(excelfile2);
switch AtlasVersion
    case 1        
        NewM(1,:) = roL12;
        NewM(2,:) = roL24;
        NewM(3,:) = rLD12';
        NewM(4,:) = rLD24';
    case 2
        NewM(1,:) = rBS12;
        NewM(2,:) = rIS12;
        NewM(3,:) = rBS24;
        NewM(4,:) = rIS24;        
end
    NewM(5,:) = data(:,6)';
    NewM(6,:) = data(:,5)';
    NewM(7,:) = data(:,7)';
    NewM(8,:) = data(:,9)';
    NewM(9,:) = oL24;
switch AtlasVersion
    case 1        
        NewMn(1,:) = 'roL12';
        NewMn(2,:) = 'roL24';
        NewMn(3,:) = 'rLD12';
        NewMn(4,:) = 'rLD24';
    case 2
        NewMn(1,:) = 'rBS12';
        NewMn(2,:) = 'rIS24';
        NewMn(3,:) = 'rBS24';
        NewMn(4,:) = 'rIS24';      
end
    NewMn(5,:) = 'VAsy ';
    NewMn(6,:) = 'Sphe ';
    NewMn(7,:) = 'Volu ';
    NewMn(8,:) = 'APrd ';
    NewMn(9,:) = 'oL24 ';

    if(0)
        % Study of correlation between metrics
        i0 = 5; i1=10; ni = i1-i0+1;
        figure('color',[1 1 1]);
        for iNM = 1:4
            M1 = NewM(iNM,:);    
            newmetricname = NewMn(iNM,:); 
            iNotValid1 = find(isnan(M1));
            for iD = i0:i1
                ip = (iNM-1)*ni + iD-i0+1;
                M2 = data(:,iD);
                name2 = text(iD);
                iNotValid2 = find(isnan(M2));

                subplot(4,ni,ip)
                plot(M1,M2,'x'); hold on;
                if iD == i0
                    ylabel(newmetricname);
                end
                % Just to visualise it:
                Atlas.FitOrthoLeastSquaresLine(M1,M2,1,0);
                iNV = unique([iNotValid1 iNotValid2]);
                M1c = M1; M1c(iNV) = []; M2(iNV) = [];
                R = corrcoef(M1c,M2);
                R = R(1,2);
                title( sprintf( '%s: R=%1.3f',cell2mat( name2 ),R));
            end
        end
    end

    if(1)
        % Study of predictive value for each single variable
        Hroc = figure('color',[1 1 1]);
        colors = 'rrbbmgcky';
        styles = '-:-:---:-';
        nP = 9;
        for iNM = 1:nP
            predictor = NewM(iNM,:);    
            newmetricname = NewMn(iNM,:); 
            iNotValid1 = find(isnan(predictor));
            for iD = 1:2
                switch iD
                    case 1, 
                        iColumn = 13;
                        recnam = 'Rec12';
                        iCrossVal = [1 3];                        
                    case 2, 
                        iColumn = 19;
                        recnam = 'Rec24';
                        iCrossVal = [2 4];
                end
%                 GroupedModes{1} = [ 1 2 3];
%                 GroupedModes{2} = [ 1 2];
%                 GroupedModes{3} = [ 5 11 14];
%                 GroupedModes{4} = [ 6 10 13];
                rec = data(:,iColumn);
                iNotValid2 = find(rec==-1);

                iNV = unique([iNotValid1 iNotValid2]);
                M1c = predictor; M1c(iNV) = []; rec(iNV) = [];

                % LDA must be also cross-validation!
%                 if numel(find(iCrossVal == iNM))>0
%                     Atlas = Atlas.SetClass(excelfile2,iColumn);
%                     options.bPredictive = 1;
%                     [AUC,~,~,~,LDAout] = AtlasLinearDiscriminantAnalysis({GroupedModes{iNM}},Atlas.PCAcoefs.coefficients,Atlas.Class,Atlas.PCAcoefs.ListCases,Atlas.PCAaxis.V,options);
%                     xx = LDAout.Xs;
%                     yy = LDAout.Ys;
%                 else
                    [xx,yy,T,AUC] = ComputeROC(rec',M1c,1);
%                 end
                %subplot(2,nP, (iD-1)*nP + iNM )            
                subplot(1,2,iD); hold on;            
                plot(xx,yy,[ colors(iNM) styles(iNM)]);
                if iNM == 1, ylabel( recnam ); end
                %title( sprintf( '%s: AUC=%1.3f (N=%i)',( newmetricname ),AUC,numel(rec)));
                Legendname{iD,iNM} = sprintf( '%s: AUC=%1.3f',( newmetricname ),AUC);
            end
        end
        subplot(1,2,1); legend(Legendname(1,:),'Location','Southeast'); axis equal;
        subplot(1,2,2); legend(Legendname(2,:),'Location','Southeast'); axis equal;
        namefig = sprintf('ROCsummary%s.png',Atlas.PCAaxis.KeyName);
        export_fig(fullfile(Atlas.PCAaxis.OutDir,namefig),'-png','-m2',Hroc);
    end

    if(0)
        % Make all LDA combinations
        coefficients = NewM;
        
        % At 12 months:
        Atlas = Atlas.SetClass(excelfile2,13);
        ClassDefinition = Atlas.Class;
        ListCases = Atlas.PCAaxis.ListCases;
        V = [];
        GroupedModes = BuildGroupedModes([1:8]);     
        options.bPredictive = 1;
        [AUCs12] = AtlasLinearDiscriminantAnalysis(GroupedModes,coefficients,ClassDefinition,ListCases,V,options);
        
        % At 24 months:
        Atlas = Atlas.SetClass(excelfile2,19);  
        ClassDefinition = Atlas.Class;
        [AUCs24] = AtlasLinearDiscriminantAnalysis(GroupedModes,coefficients,ClassDefinition,ListCases,V,options);
        
        H = figure
        subplot(211)
        plot(AUCs12); title('Month 12')
        subplot(212)
        plot(AUCs24); title('Month 24')
    end
end 
% Script to process a list of tomtec files, and build a statistical shape
% model from them. Assumptions:
% - TomTec files are named with this confention:
%         CaseName_sax_#1_#2.txt
%   where #1 is the number of slice, and #2 is the repetition number

% From SA only, or from both SA and LA:
AtlasVersion = 2;

% Number of repetitions of the TomTec analysis per case:
nRep = 3;
% Where the TomTec files are:
TomTecDataDir = 'F:\Atlas\HFLeipzig\TomTec files\';
% Where the original grayscale images are (needed to get the spacing in Z)
GrayscaleDir = 'F:\Atlas\HFLeipzig\DICOM_SSFP';
% Where the atlas will be built:
switch AtlasVersion
    case 1
        AtlasDir = 'F:\Atlas\HFLeipzig\Atlas\';
    case 2
        AtlasDir = 'F:\Atlas\HFLeipzig\Atlas2\';
end

% 1. Reorder the TomTec files into individual folders
bStep1 = 0;
% 2. Extract the origina grayscale image, short axis stack and the 3 long
% axes:
bStep2 = 0;
    bSaveGrayscale = 1;
% Generate the binary images from the TomTec file and headers of images:
bStep3 = 1;



% Post-process atlas results: average
bStep4 = 1;
    ExcelFile = 'ShapeCoefficients.xls';
%% Prepare the data
AtlasDataDir = fullfile(AtlasDir,'AtlasData');
if(bStep1)
    if ~exist(AtlasDir,'dir'), mkdir(AtlasDir); end;
    if ~exist(AtlasDataDir,'dir'), mkdir(AtlasDataDir); end;
    listfiles = dir(TomTecDataDir);
    PreviousCase = '';
    iCase = 0;
    for iFile = 3:numel(listfiles);
        f = listfiles(iFile).name;
        i0= 1;
        I = find(f=='_');
        i1= I(1);
        CaseName = f(i0:i1-1);
        iSlice = sscanf(f(I(2)+1:I(3)-1),'%i');
        iRep = sscanf(f(I(3)+1),'%i');
        if ~strcmpi(PreviousCase,CaseName)
            iCase = iCase+1;
            PreviousCase = CaseName;
            fprintf('New case %i: %s\n',iCase,CaseName);
        end
        CaseDir = fullfile(AtlasDataDir,sprintf('Case%02i%i',iCase,iRep));
        if ~exist(CaseDir,'dir'), mkdir(CaseDir); end
        copyfile(fullfile(TomTecDataDir,f),fullfile(CaseDir,f));
    end
end

if(bStep2)
    % Find the original images, and copy the end diastolic frame:
    ListCases = dir(GrayscaleDir);
    for iC = 22:numel(ListCases)
        casename = ListCases(iC).name;
        CaseDir = fullfile(GrayscaleDir,casename);
        % Make sure that the mapping between cases is the same:
        iCase = GetIDfromName(casename);
        % data structure with all the dicom headers:
        dicominfofile = fullfile(CaseDir,'DICOMinfo.mat');
        if exist(dicominfofile,'file')
            load(dicominfofile);
        else
            S = sortDCMfiles(DirName);
            save(dicominfofile,S);
        end
        for iSeries = 1:4
            switch iSeries,
                case 1, descriptionword = 'short-axis';
                case 2, descriptionword = '2-chamber';
                case 3, descriptionword = 'LVOT'; %'3-chamber';
                case 4, descriptionword = '4-chamber';
            end
            fprintf(' EXTRACTING IMAGE from the %s\n',descriptionword);
            % Find the specific study:
            [Ssa,bFound] = FindDICOMseries(S,descriptionword);
    %         % Find the slice thickness:
    %         OptExtract.InputStructureLevel = 'Series';
    %         OptExtract.Field2extract = 'SliceThickness';
    %         [s] = ExtractDICOMinfo(Ssa,OptExtract);
    %         Thickness = unique(cell2mat(s));
    %         Zspacing(iCase) = Thickness;
            % Extract the end diastolic frame:
            if ~bFound
                error('Not found!!!\n');
            else
                opt.iPhase = 1;
                iRep = 1;
                opt.OutDir = fullfile(AtlasDataDir,sprintf('Case%02i%i',iCase,iRep));
                opt.SeqName = descriptionword;
                Ssa.SSFPdicomDir = CaseDir;
                if(bSaveGrayscale)
                    [~,ImageOut] = ExtractSSFP(Ssa,opt);  
                    [im,hd] = io_ReadMedicalImage(ImageOut{1});
                    Headers{iCase} = hd;
                end
                SAdicomInfoFile = fullfile(opt.OutDir,sprintf('dicomInfo%s.mat',descriptionword));
                save(SAdicomInfoFile,'Ssa');
            end
        end
    end
end


%% Generate the meshes in each case and segmentation repetition
if(bStep3)
    ListCases = dir(AtlasDataDir);
    for iC = 3+3:numel(ListCases)
        casename = ListCases(iC).name;
        CaseDir = fullfile(AtlasDataDir,casename);
        phase = sscanf(casename(end),'%i');
        if phase ~= 1;
            ImageDir = fullfile(AtlasDataDir,[casename(1:end-1) '1']);
        else
            ImageDir = CaseDir;
        end
        
        switch AtlasVersion
            case 1
                % Grayscale from the short axis only:
                GrayscaleImage = ls(fullfile(ImageDir,'*phase1*'));
                SAdicomInfoFile = fullfile(ImageDir,'SAdicomInfo.mat');
                if numel(GrayscaleImage)>0
                    [~,hd] = io_ReadMedicalImage(fullfile(ImageDir,GrayscaleImage));
                    options.hd = hd;
                end
                load(SAdicomInfoFile); % THis loads Ssa
                %opt.Bpm = ExtractBpm(Ssa,hd);
                extopt.InputStructureLevel = 'Series';
                extopt.Field2extract = 'TriggerTime';
                AllTriggerTimes = ExtractDICOMinfo(Ssa,extopt);
                MatrixAllTriggers = [AllTriggerTimes{:}];
                options.TriggerSignature = MatrixAllTriggers;%(end,:);
                [~,RVdirection,~] = io_AssemblyBinaryMaskFromTomTec(CaseDir,AtlasDataDir,options);
                RVdirFile = fullfile(CaseDir, 'RVposition.mat');
                save(RVdirFile,'RVdirection');
            case 2
                % Grayscale from both the SA and LA views. Extract the
                % contours from all TomTec files in the directory:
                epi = []; endo = []; rv = [];
                for iView = 1:4
                    switch iView
                        case 1, TomTecKeyWord = 'sax'; ImKey = 'short-axis'; bStack = 1;
                        case 2, TomTecKeyWord = '2cv'; ImKey = '2-chamber'; bStack = 0;
                        case 3, TomTecKeyWord = '3cv'; ImKey = 'LVOT'; bStack = 0;
                        case 4, TomTecKeyWord = '4cv'; ImKey = '4-chamber'; bStack = 0;
                    end
                    ListTomTecs = dir(fullfile(CaseDir,sprintf('*%s*.txt',TomTecKeyWord)));
                    if isempty(ListTomTecs)
                        fprintf('WARNING! No TomTec files of %s in case %s\n',TomTecKeyWord,CaseDir);
                    else
                        GrayscaleImage = ls(fullfile(ImageDir,['*' ImKey '*phase*.nii']));
                        SAdicomInfoFile = fullfile(ImageDir,sprintf('dicomInfo%s.mat',ImKey));
                        if isempty(GrayscaleImage);
                            fprintf('WARNING! No Grayscale image of %s in case %s\n',ImKey,ImageDir);
                        else
                            [~,hd] = io_ReadMedicalImage(fullfile(ImageDir,GrayscaleImage));
                            if bStack
                                % Re-use the code to build the stack of images:
                                options.hd = hd;
                                options.ListTomTecs = ListTomTecs;
                                options.BinName = sprintf('%sbinary.nii',ImKey);
                                extopt.InputStructureLevel = 'Series';
                                extopt.Field2extract = 'TriggerTime';
                                load(SAdicomInfoFile);
                                AllTriggerTimes = ExtractDICOMinfo(Ssa,extopt);
                                MatrixAllTriggers = [AllTriggerTimes{:}];
                                options.TriggerSignature = MatrixAllTriggers;%(end,:);
                                [~,~,~,contours] = io_AssemblyBinaryMaskFromTomTec(CaseDir,AtlasDataDir,options);
                            else
                                % Assumption one only TomTec file:
                                TomTecFile = fullfile(CaseDir,ListTomTecs.name);
                                contours = io_ReadTomTecContours(TomTecFile,hd);
                            end
                            epi  = [epi contours.epi];
                            endo = [endo contours.endo];
                            if isfield(contours,'rv')
                                rv = [rv contours.rv];
                            end
                        end
                    end
                end  
                % Generate the binary image out of all the contours:
                endo = endo';
                epi  = epi';
                rv   = rv';
                
                if(0)
                    figure; hold on
                    for c = 1:numel(epi)
                      plot3( epi{c}(:,1) , epi{c}(:,2) , epi{c}(:,3) , '-','color',rand(1,3) ,'linewidth',2 );
                    end
                    for c = 1:numel(endo)
                      plot3( endo{c}(:,1) , endo{c}(:,2) , endo{c}(:,3) , '-','color',rand(1,3) ,'linewidth',1);
                    end
                    for c = 1:numel(rv)
                      plot3( rv{c}(:,1) , rv{c}(:,2) , rv{c}(:,3) , '*-','color',rand(1,3) ,'linewidth',3);
                    end
                    hold off; view(3); axis equal
                end                
                if(1)
                    save('contours.matlab','endo','epi','rv');
                    epiV  = Contours2BinaryImage( epi , 'bbox' , [ endo ; epi ; rv ] , 'voxellenght', [1 1 2.5] , 'bottomlid',-60 ,'deform','plot');
                    V = epiV;  %imagen a usar como container
                    endoV = Contours2BinaryImage( endo ,'image', V ,'bottomlid',-10,'upperlid',75,'deform','plot');
                end
        end                               
    end
end
        



%% Analyse results and generate average mesh per case, with shape indexes
if bStep4
    load(fullfile(AtlasDir,'\AtlasOutputrv','Coordinates.mat'));
    nCases  = size(coefficients,2)/nRep;
    for iCase = 1:nCases
        i1 = 1  + (iCase-1)*nRep;
        i2 = i1 + 2;
        ShapeCoefs(iCase,:) = mean(coefficients(:,i1:i2),2);
    end    
end

xlswrite(fullfile(AtlasDir,'\AtlasOutputrv',ExcelFile),ShapeCoefs(1:10,:));
% Script to recover old HLHS atlas

AtlasRoot = 'F:\Atlas\JamesWongAtlas\Version5';
Path2AtlasFile = 'F:\Atlas\JamesWongAtlas\Version5\Results Scanner Coordinate System\AtlasOutputTryReload';
excelfile = 'full dataset HLHS for Pablo.xlsx';     

Atlas = AtlasClass(AtlasRoot);
Atlas = Atlas.LoadPCAaxis(Path2AtlasFile);
% Tell the alignment shape space:
Atlas.PCAaxis(1).iShapeSpace = 1;

% Use the default LV template:
    opt.topology = 'LVL';
    opt.nE = [6 12 1];
    opt.SecAxLocation = 'MaxY';
    Atlas = Atlas.SetTemplate(opt);
    
    Atlas.MeshViewOptions.bVerticalViewIn3D = 1;
    Atlas = Atlas.UpdateTemplateViewOptions();
    
    Atlas.PlotVariancePerMode;
    if(0)
        Atlas.ViewModalVariations(1:6);
        Atlas.iEig2plot = 1:6;
        Atlas.GenerateTexFileAllModes();
        Atlas = Atlas.CalculatePCAcoefs();
    end
    Atlas = Atlas.LoadPCAcoefs();
    
    
    %%
        Atlas.nStd = 2;
        Atlas.iEig2plot = 1:10;
        Atlas = Atlas.SetClass(fullfile(AtlasRoot,excelfile),8);
        opt.significance = 0.05;
        Atlas.CompareClassesByPCAaxis(opt);
        %Atlas.ViewBoxPlots();
        
        Atlas = Atlas.SetClass(fullfile(AtlasRoot,excelfile),6);
        Atlas.CompareClassesByPCAaxis(opt);
        %Atlas.ViewBoxPlots();
        
        Atlas = Atlas.SetClass(fullfile(AtlasRoot,excelfile),7);
        Atlas.CompareClassesByPCAaxis(opt);  
        %Atlas.ViewBoxPlots();      
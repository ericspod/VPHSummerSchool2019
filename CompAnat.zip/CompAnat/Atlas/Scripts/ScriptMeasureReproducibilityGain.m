load('CorrelationTemplateLVLStudy1.mat');
rho1 = rho;
prho1 = prho;

load('CorrelationTemplateLVLStudy2.mat');
rho2 = rho;
prho2 = prho;

figure
for iC = 1:3
    subplot(2,3,iC)
    plot(rho2(iC,:)./rho1(iC,:));
    title('R2/R1')
    hold on
    plot([0 20],[1 1],'r')
    
    ip = 3+iC;
    subplot(2,3,ip)
    plot(prho1(iC,:)./prho2(iC,:));
    title('p1/p2')
    hold on
    plot([0 20],[1 1],'r')
end
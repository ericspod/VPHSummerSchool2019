function [] =  ReorderEpochData(DataRoot)
% Function to rename folder names from EPOCH002FU to EPOCH1002

directorynames = dir(DataRoot);

for iDir = 3:numel(directorynames)
    dirname = directorynames(iDir).name;
    if strcmp(dirname(end-1:end),'FU') || strcmp(dirname(end-1:end),'fu')
        [ID,~,prename] = GetIDfromName(dirname);
        NewName = sprintf('%s%i',prename,ID+1000);
        F1 = fullfile(DataRoot,dirname);
        F2 = fullfile(DataRoot,NewName);
        fprintf('chaning file %s... \n into %s\n',F1,F2);
        movefile(F1,F2);
    end
end
% Script to analyse the data from Patricia

% Where the data of the segmentation images is:
CVIrootfolder = 'C:\Users\Patricia\Desktop\TFG\Data';

% Where we want to build the atlas:
AtlasRoot = 'C:\Users\Patricia\Desktop\TFG\Atlas';

bPrepareData  = 1;
bBuildMeshes  = 1;
bBuildPCA     = 0;
bComputeCoefs = 0;
%%
AtlasData = fullfile(AtlasRoot,'AtlasData');
if(bPrepareData)
    % The code to take the DICOM output from ARGUS, and to generate one
    % folder per mesh in the AtlasData subfolder.
    % WARNING: we need an unique ID per mesh! and naming xxxx123
    RawData = CVIrootfolder;
    ListCases1 = dir(RawData);
    ListCases = ListCases1(3:end)
    listsize = size(ListCases);
    numcases = listsize(1);
    if ~exist(AtlasData,'dir'), mkdir(AtlasData); end
    
    finalmaskFile = 'finalmask.vtk'
    for n = 1:1:numcases
        itemname = ListCases(n).name;
        RawCaseDir = fullfile(RawData,itemname); 
        RawCaseDircomas = sprintf('%s',RawCaseDir);
        resultDir = (fullfile(RawCaseDircomas, 'zmask'));
        meshID = sprintf('%s_%i',itemname,n);
        CaseDir = fullfile(AtlasData,meshID);
        if ~exist(CaseDir), mkdir(CaseDir); end 
        fileIm = fullfile(resultDir, finalmaskFile);
        if exist(fileIm,'file');
            [mask,hd]=read_image_vtk2(fileIm); 
            write_image_vtk2(fullfile(CaseDir, 'finalmask.vtk'),mask,hd,'ascii'); 
        end
    end
    
end
  
    
   
%%
% Instance of the class:
    Atlas = AtlasClass(AtlasRoot);
% Use the default LV template:
    opt.topology = 'LVL';
    opt.nE = [5 12 1];
    Atlas = Atlas.SetTemplate(opt);
% Create the meshes:
    options.SubDirectory = '/';            
    options.LoD = 2;           
    options.RVpoolLabel = 0.5;
    options.MyoLabel = 1;     
    
for iSS = 1:1
    options.iShapeSpace = iSS;           
    options.SeptumLocation = 'MinX';
    
    if(bBuildMeshes)
        Atlas = Atlas.BuildMeshes(options);
    end
    
    if(bBuildPCA)
        %Atlas = Atlas.CalculateAtlas(options);
        Atlas = Atlas.BuildPCA(options);
    else
        Atlas = Atlas.LoadPCAaxis(options);
    end
    
    if(bComputeCoefs)
        Atlas = Atlas.CalculatePCAcoefs(options);
    else
        Atlas = Atlas.LoadPCAcoefs();
    end
    
    % Overview of the statistical shape model:
    Atlas.FullAtlasReport();
    
    %CreateExcelClassFile(Atlas.DataDirectory);    
    iColumn = 6;
    Atlas = Atlas.SetClass(fullfile(AtlasRoot,'infocasesEdited.xls'),6);
    Atlas.ViewEigenSpace();
    Atlas.ViewBoxPlots();
    
    Atlas.colourscheme = 6;
    if(1)
        % Search for differences
        Atlas.CompareClassesByPCAaxis();
        opt.classes2include = [1 3];
        Atlas.SearchPredictiveMetric(6,opt);   
        opt.classes2include = [3 4];
        Atlas.SearchPredictiveMetric(6,opt);
    end    
    % And once they are found, detailed inspection
    GM = {1:3};
    opt.classes2include = [2 4];
    Atlas = Atlas.LinearDiscriminantAnalysis(GM,opt);
    Atlas.PlotLDA();
    Atlas.ViewLDAextremeShapes();
end
% Script to swap the contents of the AtlasData contents


AtlasData = 'F:\Atlas\GenerationR\Segmentations600\Atlas\Data2swap';
AtlasData = 'F:\Atlas\GenerationR\Segmentations600\Atlas\AtlasData';

%IDs = [114370,114406,116012,114441,114460,132386,115850];
%IDs = [115201, 114809, 114461];

for i = 1:numel(IDs)
    ID = IDs(i);

    TempID = '9999';
    NewDirName = sprintf('Case%s',TempID);
    % Move all "systolic" data into the new dir and
    % name:                            
    OldSysID = sprintf('%i_1',ID);
    OldDiaID = sprintf('%i_2',ID);
    CaseSys = sprintf('Case%s',OldSysID);
    CaseDia = sprintf('Case%s',OldDiaID);
    ReplaceDir(AtlasData,CaseSys,NewDirName,OldSysID,TempID);
    ReplaceDir(AtlasData,CaseDia,CaseSys,OldDiaID,OldSysID);
    ReplaceDir(AtlasData,NewDirName,CaseDia,TempID,OldDiaID);
end
% Script to analyse the CRT atlas

% With the average of the two observations:
RootAtlas = 'F:\Atlas\CRT\Ave50bPCA50';

Atlas = AtlasClass(RootAtlas);

% Use the default LV template:
    opt.topology = 'LV';
    opt.nE = [6 12 1];
    Atlas = Atlas.SetTemplate(opt);
% Create the meshes:
    options.SubDirectory = '/';            
    options.LoD = 3;           
    options.RVpoolLabel = 2;
    options.MyoLabel = 1;         
    
    
    options.iShapeSpace = 4;
    options.KeyName = 'CRT_rvspace';
    options.SeptumLocation = 'MinX';

    
    if(0)
        %Atlas = Atlas.CalculateAtlas(options);
        Atlas = Atlas.BuildPCA(options);
    else
        Atlas = Atlas.LoadPCAaxis(fullfile(RootAtlas,'AtlasOutputrv'));
    end

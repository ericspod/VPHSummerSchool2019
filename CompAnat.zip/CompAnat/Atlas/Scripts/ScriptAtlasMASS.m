% Build a statistical shape model from a set of MASS files

AtlasRoot  = 'C:\Data\Madrid\Atlas';
ConMassDir = fullfile(AtlasRoot , 'RawData');

bExtractBinaries = 0;
bBuildMeshes     = 0;


Atlas = AtlasClass(AtlasRoot);

% Set the topology:
opt.topology = 'LVL';
opt.nE = [5 12 1];
Atlas = Atlas.SetTemplate(opt);

if(bExtractBinaries)
    nCases = Atlas.ExtractBinaries(ConMassDir);
end

options.iShapeSpace = 2;
options.KeyName = 'ResTime';    
options.LoD = 2;
options.RVpoolLabel = 2; %4;
options.MyoLabel = 1;          
options.bRVdirFromSA = 0;
if(bBuildMeshes)
    Atlas.BuildMeshes(options);    
end

Atlas = Atlas.BuildPCA(options);
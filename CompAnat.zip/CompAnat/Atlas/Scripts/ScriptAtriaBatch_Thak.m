% Script to process atrial segmentations from Thackshy and Georgia, and
% build a statistical shape model

% Definition of the temp dir, for some reason Thakshy's session was
% crashing becuase of an access failure into:
% Cannot CD to C:\Users\tm16\AppData\Local\Temp;C:\Users\tm16\Documents\SourceTree\external (Directory
% access failure).
%TempDir = 'C:\Users\tm16';
%setenv('TEMP',TempDir)

% Where I want to work in my local machine (not dropbox folder)
RootDir = 'C:\Data\AtriaAtlas';
% directory the data comes from
SegmDir = 'C:\Users\pl10\DropboxPL\Dropbox\AtrialShapeAnalysis\data\Reproducibility study';

bCheckUser = 0;
    user = 'T'; % G for Georgia, T for Thakshy
AtrialLabel = 1; % from the segmentation
AorticRootLabel = 2; % from the segmentation

bCreateDataStructure = 1; % if 1, creates a folder for each case and phase
    IDresegmented = 9;
bBuildMeshes = 0; % make the meshes for each case (only needed once per case)
     InitialAlignmentOption = 2; 
     % 1 was the only available option (finding the orientation in each case
     % 2 is the new option, prescribing orientation according to SA
bBuildPCA       = 0; % do PC analysis from scratch
bComputeCoefs   = 0; % compute PCA coefficients

switch InitialAlignmentOption
    case 1
        % Running the PCA on the shapes
        AtlasRoot = 'C:\Users\tm16\Documents\MATLAB\Atlas/';
    case 2
        % Asuming vertical orientation from the perpendicular to slice
        %AtlasRoot = 'C:\Users\tm16\Documents\MATLAB\AtlasLocalCoordinateSystem';
        %AtlasRoot = 'C:\Users\tm16\Documents\MATLAB\BringingCasesBack';
        
        % Some cases are corrected by the flip:
        %AtlasRoot = 'C:\Users\tm16\Documents\MATLAB\AtlasLocCoorANDCorrectFlip';   
        
        % The code is improved to correctly weight each dof of a mesh:
        AtlasRoot = 'C:\Users\tm16\Documents\MATLAB\AtlasLocCoCorFlipRightWeight';
        AtlasRoot = RootDir;
end

% Key naming
DataDir = fullfile(AtlasRoot,'AtlasData');


%% Generate the data structure:
if ~exist(AtlasRoot,'dir'), mkdir(AtlasRoot); end
if ~exist(DataDir,'dir'), mkdir(DataDir); end

if(bCreateDataStructure)
% 1. Create a folder per each case and phase:
     % list the segmentation files:
     files = dir(SegmDir); % find all the files in directory
     for iF = 3:numel(files) % for files 3 to number of found files
         % (files 1 and 2 are dummies)
         filename = files(iF).name; % get filename
         bGood = 1;
         switch filename(1)
             case 'T', userID = 1;
             case 'G', userID = 2;
         end
         if bCheckUser
            if filename(1) ~= user
                bGood = 0;
            end
         end             
         if (bGood)
             [ID,phases,class,IDoriginal] = GetIDandPHfromName(filename);
             if ~isempty(ID) %&& IDoriginal == IDresegmented
                 if isempty(phases) || phases(1) == 0
                     phases = [1 2 3];
                 end
                 nPhases = numel(phases);
                 [im,hd] = io_ReadMedicalImage(fullfile(SegmDir,filename));
                 if nPhases > 1
                     nSlices = hd.dim(3)/nPhases;
                     % Prepare the header of the images:
                     hd2 = hd;
                     hd2.dim(3) = nSlices;

                     % Indexing of the image to be splited:
                     z1 = nPhases*nSlices;
                     dz = nPhases;

                     % one file has several phases. Capture the aortic root first:
                     bRootFound = 0;
                     for iP = 1:nPhases
                         z0 = iP;
                         im2 = im(:,:,z0:dz:z1);
                         if bRootFound == 0
                             % Capture the aortic root label:
                             imRoot = zeros(size(im2));
                             % Check the existence of the aortic root:
                             I = find(im2==AorticRootLabel);
                             if numel(I) > 0
                                 bRootFound = 1;
                                 imRoot(im2==AorticRootLabel) = AorticRootLabel;
                                 fprintf('Aortic root found in %s, phase%i\n',filename,phases(iP));
                             end
                         end
                     end
                     if (~bRootFound)
                         fprintf('ERROR! No aortic root found in%s\n',filename);
                     end
                     for iP = 1:nPhases
                         ph = phases(iP);
                         % Use a consistent naming accross:
                         NewName = sprintf('Case%04i%01i%01i',ID,ph,userID);
                         CaseDir = fullfile(DataDir,NewName);
                         if ~exist(CaseDir,'dir'), mkdir(CaseDir); end
                         % Get the binary mask and save it in the directory:
                         z0 = iP;
                         im2 = im(:,:,z0:dz:z1);
                         % Add the aortic root, making sure it does not overlap with
                         % the atrial mask:
                         temp = zeros(size(im2));
                         temp( imRoot==AorticRootLabel ) = AorticRootLabel;
                         temp( im2 == AtrialLabel ) = AtrialLabel;
                         im2 = temp;
                         imagename = fullfile(CaseDir,[NewName '.gipl']);
                         fprintf('Writting %s\n',imagename);
                         io_WriteMedicalImage(imagename,im2,hd2);
                     end
                 else
                     %NewName = sprintf('Case%04i',ID);
                     NewName = RemovePathAndExtension(filename);
                     CaseDir = fullfile(DataDir,NewName);
                     if ~exist(CaseDir,'dir'), mkdir(CaseDir); end
                     io_WriteMedicalImage(fullfile(CaseDir,[NewName '.nii']),im,hd);
                 end
             end
         end
     end
end

%% Create the class to perform the analysis:
Atlas = AtlasClass(AtlasRoot);

% Define the template:
optTemplate.topology = 'Sphere';
optTemplate.nE = [12 12 1];
Atlas = Atlas.SetTemplate(optTemplate);

%% Build the meshes:
if(bBuildMeshes)

     % optiions for building meshes
     optBuildMeshes.LoD = 1;                 % Marta, 09/02/2016 (changed to 1 from 2), Level of detail of fitting
     optBuildMeshes.MyoLabel = 1;            % label of the atrial blood pool
     optBuildMeshes.RVpoolLabel = 2;         % label of the aortic root
     optBuildMeshes.bUseNodalWarping = 1;    % it is a collapsed topology
     

     switch InitialAlignmentOption
         case 1
             RotT = [0 1 0;
                     0 0 1;
                     1 0 0];
            % Perpendicular to plane
             optBuildMeshes.bHorizontalBase = 1;
             optBuildMeshes.RotT = RotT;             % fix the rotation of template a-priori, since it is a perfect sphere
         case 2
             RotT = [0 0 1;
                     1 0 0;
                     0 1 0];
             % Fixing the orientation of the LV to the image coordinate
             % space. NOTE: images are aligned with respect to the basal
             % plane orientation (SA with rotation matrix the identity).
            optBuildMeshes.LVdir = [0 0 1];
            optBuildMeshes.RotT = RotT;             % fix the rotation of template a-priori, since it is a perfect sphere
            %optBuildMeshes.DirSecondAxis =[0 1 0];
         case 3
             % Average of the three phases: need to code it!

     end

     Atlas = Atlas.BuildMeshes(optBuildMeshes);
%      for iPhase = 1:3
%          meshID = IDresegmented*10000 + 100 + iPhase;
%          Atlas = Atlas.BuildMeshID(meshID,optBuildMeshes);
%      end
end




%% Build the statistical shape model
ExtSurfOnly = 1;    % values of 1 or 0

options.OutputDirectory = 'PabloRun';
for SP = 0:4
    % 0= No alignment (NA)
    % 1= Centre (C)
    % 2= Rotation(R)
    % 3= Scale(S)
    % 4= Rotation relying on an external landmark (in our case, the aortic
    % root);
    options.iShapeSpace = SP;

    options.bOnlyExtSurf = ExtSurfOnly;
    options.KeyName = sprintf('AtriaS%iExt%i',SP,ExtSurfOnly);
    options.AtlasName = sprintf('Atlas%s.mat',options.KeyName);
    if(bBuildPCA)
         Atlas = Atlas.BuildPCA(options);
    else
         Atlas = Atlas.LoadPCAaxis(options);
    end

    %% Visualise and analyse the data:

    % Compute the coefficients:
    if(bComputeCoefs)
         Atlas = Atlas.CalculatePCAcoefs();
    else
         Atlas = Atlas.LoadPCAcoefs();
    end

    % Load the excel file with the classed defiend:
    excelfile = [AtlasRoot '\infocases3.xls'];
    %columnofinterest = 5;
    %Atlas = Atlas.SetClass(excelfile,columnofinterest);
    % Visualise the PCA shape space:
    %Atlas.ViewEigenSpace();
    %%
    if(0)
        % Visualise the average shape:
        Atlas.ViewMeanMesh();
        
        % Visualise the variance encoded in each mode:
        Atlas.PlotVariancePerMode();
        % View a specific mesh
        Atlas.ViewMeshID(100103);

        % Visualise the extrem shapes in each PCA mode:

        for iMode=1:2
            Atlas.ViewModalVariations(iMode);
        end
    end

    if(1)
        % Call the statistical analysis
        % Step 1: search differences in each axis:
%         Atlas = Atlas.SetClass(excelfile,5);
%         Atlas.CompareClassesByPCAaxis();

        % Step 2: search for the best grouping of the information of axes through the LDA:   
        options.classes2include = [1 2];
        for iCol = 5:8
            Atlas = Atlas.SetClass(excelfile,iCol);
            Atlas.CompareClassesByPCAaxis();
            Atlas.SearchPredictiveMetric(10,options); 
            opt.bEpiOnly = 1;
            Atlas.ViewAverageShapes(opt);
            Atlas.ViewComparisonAverageGroups();
        end
    end
    %%
    if(0)
        Atlas.colourscheme = 6;
        Atlas = Atlas.SetClass(excelfile,3);
        Atlas.ViewComparisonAverageGroups();
    end
    if(1)
        Atlas.colourscheme = 1;
        Atlas = Atlas.SetClass(excelfile,5);
        Atlas.ViewComparisonAverageGroups();
    end
    if(1)
        % Step 3: once the optimal combination is found, visualise it. In this
        % case, the optimal is up to mode 16:
        
        Atlas = Atlas.SetClass(excelfile,6);
        GroupedModes = {[5,6,9,10]};
        options.bPredictive = 0;
            % 2.1: find the LDA axis:
            Atlas = Atlas.LinearDiscriminantAnalysis(GroupedModes,options);
            % 2.2: test differences between subgroups in this LDA axis:
            Atlas.CompareClassesByLDAaxis();
            % 2.3: visualise the distribution of the classes in the LDA axis:
            Atlas.ViewLDAaxis();
            Atlas.PlotLDA();
            Atlas.ViewLDAextremeShapes();
    end
end


bExtSurf = 0;

bABS = 0;

bBuildPCA = 0;
bComputeCoefs = 0;
bPaperFigures = 0;
    bStudyTriggerTime = 0;

bStudyQRSduration = 0;
    
% Script CRT data
Root = 'F:\Atlas\CRT\';
Root = 'C:\Data\data\CRT\';
AtlasRoot = fullfile(Root,'Ave50bPCA50');


Atlas = AtlasClass(AtlasRoot);

if(bBuildPCA)
    % Define the template:
    TemplateOptions.nE = [6 12 1];
    TemplateOptions.topology = 'LV';
    Atlas = Atlas.SetTemplate(TemplateOptions);
end

for iResponse = 2:2
%iResponse = 1;
    switch iResponse
        case 1, iColumn = 2; opt.bFlipMode = 1;
        case 2, iColumn = 6;
    end
    Atlas = Atlas.SetClass(fullfile(Root,'ResponseDefinition\CRTcohort.xlsx'),iColumn);


    %%
    for ShapeSpace = 1:1
        if(bExtSurf)
%             PCAoptions.OutputDirectory = 'AtlasOutputExt';
%             PCAoptions.bOnlyExtSurf = 1;
%             PCAoptions.KeyName = sprintf('CRTs%i',ShapeSpace);
            PCAoptions.OutputDirectory = 'AtlasOutputEqualExt';
            PCAoptions.bOnlyExtSurf = 1;
            PCAoptions.KeyName = sprintf('CRTeqS%i_2017',ShapeSpace);
        else
            % Old run before equalization of dofs:
%             PCAoptions.OutputDirectory = 'AtlasOutput2';
%             PCAoptions.bOnlyExtSurf = 0;
%             PCAoptions.KeyName = 'CRT';
            % New run after equalization of dofs:
            PCAoptions.OutputDirectory = 'AtlasOutputEqualized';
            PCAoptions.bOnlyExtSurf = 0;
            PCAoptions.KeyName = 'CRTeq_2017';
            
            % Final run for the paper, removing case KCL008 and getting to
            % the intial 50:
            if(bABS)
                PCAoptions.OutputDirectory = 'AtlasOutputPaperABS';
            else
                PCAoptions.OutputDirectory = 'AtlasOutputPaper';
                bBuildPCA = 0;
                bComputeCoefs = 0;
            end
            PCAoptions.bOnlyExtSurf = 0;
            PCAoptions.KeyName = 'CRTeq_Paper';
        end
        PCAoptions.iShapeSpace = ShapeSpace;
        PCAoptions.SeptumLocation = 'MinX';

        if(bBuildPCA)    
            Atlas = Atlas.BuildPCA(PCAoptions);
        else
            Atlas = Atlas.LoadPCAaxis(PCAoptions);
        end
        if(bComputeCoefs)
            Atlas = Atlas.CalculatePCAcoefs();
        else
            Atlas = Atlas.LoadPCAcoefs();
        end
        
        % Set the correct visualization
        %Atlas.SeptumLocation = 'MinX';
        Atlas.MeshViewOptions.bVerticalViewIn3D = 1;
        Atlas.MeshViewOptions.ZoomFactor = 2.4;
        Atlas = Atlas.UpdateTemplateViewOptions();

        if(bStudyQRSduration)
            [ListCases] = GetCasesInDirectory(Atlas.MeshDirectory);
            iColumnVariable = 8;
            [QRS,VarNameQRS] = Atlas.ReadClinicalVariable(iColumnVariable,ListCases);
            [ResponseESV,VarName2] = Atlas.ReadClinicalVariable(6,ListCases);
            [StudyID,VarNameID] = Atlas.ReadClinicalVariable(1,ListCases);
            [~,VarName3,Sex] = Atlas.ReadClinicalVariable(48,ListCases);
            [EFpre,VarName4] = Atlas.ReadClinicalVariable(49,ListCases);
            [EFpost,VarName5] = Atlas.ReadClinicalVariable(50,ListCases);
            optionsGeoMetrics.SlicePlane = 'X';
            [Metrics , MetNames, CaseNames] = Atlas.GeometricalAnalysisAllCases( optionsGeoMetrics );
            
            ExcelFile = fullfile(AtlasRoot , 'GeoMetricsWithQRSandEF.xls');
            sheet = 'Metrics';
            xlswrite(ExcelFile,{VarNameID},sheet,'A1');
            xlswrite(ExcelFile,StudyID',sheet,'A2');
            xlswrite(ExcelFile,{VarNameQRS},sheet,'B1');
            xlswrite(ExcelFile,QRS',sheet,'B2');
            xlswrite(ExcelFile,{VarName2},sheet,'C1');
            xlswrite(ExcelFile,ResponseESV',sheet,'C2');
            xlswrite(ExcelFile,{VarName3},sheet,'D1');
            xlswrite(ExcelFile,Sex',sheet,'D2');
            xlswrite(ExcelFile,{VarName4},sheet,'E1');
            xlswrite(ExcelFile,EFpre',sheet,'E2');
            xlswrite(ExcelFile,{VarName5},sheet,'F1');
            xlswrite(ExcelFile,EFpost',sheet,'F2');
            for iMN = 1:numel(MetNames)
                name2writ = MetNames{iMN};
                xlswrite(ExcelFile,{name2writ},sheet,sprintf('%s','F'+iMN));
            end
            xlswrite(ExcelFile,Metrics',sheet,'G2');
        end
        
        if (bPaperFigures)
                        
            opt.Significance = 0.05;
            opt.nCoefsMax2IncludeT = 20;
            opt.Legend = {'Resp','NonR'};
            Atlas.CompareClassesByPCAaxis(opt);
            
            % Study all possible combinations with certain p-value
            switch ShapeSpace
                case 1
                    Atlas = Atlas.ComprehensiveLDA([7 8 10 15 17 19],opt);
                    opt2.CoreModes = [7 8 10];
                    Atlas = Atlas.ComprehensiveLDA([1:6 9],opt2);
                case 2
                    if bABS
                        opt2.CoreModes = [5 8];
                        Atlas = Atlas.ComprehensiveLDA([4 9],opt2);
                    else
                        Atlas = Atlas.ComprehensiveLDA([1 2 3 4 6 7 8 9 13 17],opt);
                        Atlas = Atlas.ComprehensiveLDA([3 6 9 7 13 17],opt);
                        opt2 = opt;
                        opt2.CoreModes = [3 6];
                        Atlas = Atlas.ComprehensiveLDA([1 2 4 7 8 9],opt2);
                    end
            end
            % The optimal combination:
            optLDA.bLeave2out = 1;
            optLDA.nLOut = 4;
            switch ShapeSpace
                case 1
                    Atlas = Atlas.StudyLDAcombination([7 8 10 15],optLDA);
                case 2
                    Atlas = Atlas.StudyLDAcombination([6 7 8 13],optLDA);
            end
            opt.bViewThickness = 1;
            opt.b3Dmeshes = 0;
            Atlas.ViewLDAextremeShapes(opt);
            Atlas.SaveLDAcoefs();
            
            if (bStudyTriggerTime)
                % Trigger time is the third column. We make regression to the
                % PCA modes:
                Atlas.ShapeCoefficientsRegression(3);
                % And to the LDA mode:
                Atlas.ShapeCoefficientsRegression(3,1);
                
                % Consider it a binary variable, systolic or diastolic:
                AtlasTrigger = Atlas.SetClass(fullfile(Root,'ResponseDefinition\CRTcohort.xlsx'),9);
                opt.Significance = 0.05;
                opt.nCoefsMax2IncludeT = 20;
                opt.Legend = {'Syst','Diast'};
                AtlasTrigger.CompareClassesByPCAaxis(opt);
                AtlasTrigger.CompareClassesByLDAaxis(opt);
                
            end
                           
            Atlas.ExtraDataDir = fullfile(AtlasRoot,'ExtraData');
            Atlas = Atlas.CheckLDAreproducibility();
        end
        
        
        
        if(0)
            optViewModes.bOverlayExtremes = 1;
            optViewModes.bAutomaticExit = 1;
            Atlas.ViewModalVariations(1:6,optViewModes);
        end
        if(0)
            % Search for differences
            %Atlas.CompareClassesByPCAaxis();
            %opt.bExaustiveAUC = 1;
            opt.bPredictive = 1;
            Atlas = Atlas.ComprehensiveLDA(20,opt);            
        end    
        if(0)
            % Only the reproducible modes
            Atlas = Atlas.ComprehensiveLDA([1:7 9 13 14],opt); 
        end
            
        %% Compute the reproducibility:
        
        if(0)
            % And once they are found, detailed inspection
            switch iColumn
                case 2, GM = [2 5 13];            
                case 6, GM = [7 8 10 15];
            end
            opt.bLeave2out = 1;
            opt.nLOut = 4;
            opt.bViewThickness = 1;
            Atlas = Atlas.StudyLDAcombination(GM,opt);            
            Atlas.SaveLDAcoefs();
        end
        
        if(0)
            % Reproducibility of LDA coefs:                        
            Atlas.ExtraDataDir = fullfile(AtlasRoot,'ExtraData');
            Atlas = Atlas.CheckLDAreproducibility();
            Atlas = Atlas.CheckPCAreproducibility();
        end
    end
end

%if(bMeshTopology)
    % Find the VTK mesh nodes of epi, endo and base
%    Atlas.SaveVTKmeshes
    
%end
% Script to generate the VTK image to be segmented from the RAW images from
% VEVO.

RootDir = 'F:\Atlas\Mouse\Cohort';
GrayscaleDir = 'F:\Atlas\Mouse\Cohort\Grayscales';
listcases = dir(RootDir);

if ~exist(GrayscaleDir,'dir'), mkdir(GrayscaleDir); end;
for iC=3:numel(listcases)
    nam = listcases(iC).name;
    CaseDir = fullfile(RootDir,nam);
    rawfile = ls(fullfile(CaseDir,'*raw.3d.bmode'));
    I = loadI3D(fullfile(CaseDir,rawfile));
    OutDir = fullfile(GrayscaleDir,nam);
    if ~exist(OutDir,'dir'), mkdir(OutDir); end;
    write_NII( I , fullfile(OutDir, sprintf('Grayscale%s.nii',nam)) );
end
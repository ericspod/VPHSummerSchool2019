% Script to convert the DICOM export from Barna

DirFile = 'F:\Atlas\Barna\Patricia\US';
FileName = 'G53AQ980';
FileOut  = 'G53AQ980.nii';

% Read the data:
File = fullfile(DirFile,FileName);
[im] = dicomread(File);
[hd] = dicominfo(File);

% Get the image box
MinX = hd.SequenceOfUltrasoundRegions.Item_1.RegionLocationMinX0;
MaxX = hd.SequenceOfUltrasoundRegions.Item_1.RegionLocationMaxX1;
MinY = hd.SequenceOfUltrasoundRegions.Item_1.RegionLocationMinY0;
MaxY = hd.SequenceOfUltrasoundRegions.Item_1.RegionLocationMaxY1;
im2 = im(MinY:MaxY,MinX:MaxX);

% Parse the header: get the spacing, dimensions, etc
hd2 = ParseHeader(hd);

% Write the medical image:
io_WriteMedicalImage(fullfile(DirFile,FileOut),im2,hd2);

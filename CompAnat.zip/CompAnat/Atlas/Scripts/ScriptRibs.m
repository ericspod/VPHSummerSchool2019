close all;
% Control flags of the three time consuming tasks:
bBuildMeshes = 0;
bBuildPCA = 1;
bComputeCoefs = 1;


AtlasRoot = 'Z:\Segmenting\Atlas';
AtlasRoot = 'C:\Data\ribs';
% Pre-processing step to store the data in the right way (all in AtlasData,
% and one sub-folder per case

% First instance of the class:
Atlas = AtlasClass(AtlasRoot);

TemplateOptions.topology = 'Rib';
Atlas = Atlas.SetTemplate(TemplateOptions);

opt.LoD = 1; %set a value to this - see what happens;
opt.OutMeshingDir = sprintf('MeshingHG%i',opt.LoD);
Atlas.bTailoredTemplate = 0;
if(bBuildMeshes)
    Atlas = Atlas.BuildMeshes(opt);
    % Move to the 'AtlasMeshData' folder:
    Atlas = Atlas.SaveMeshes_sortedbymeshID();
end

if(bBuildPCA)
    % Define the template, will be stored in the PCAaxis member variable at the 
    % end of the PCA construction
    
    TemplateOptions.nE = [12 8 1];
    TemplateOptions.topology = 'Rib';
    Atlas = Atlas.SetTemplate(TemplateOptions);
end

PCAoptions.iShapeSpace = 2;
PCAoptions.KeyName = 'RibModel';
PCAoptions.OutMeshingDir = opt.OutMeshingDir;

if(bBuildPCA)
    Atlas = Atlas.BuildPCA(PCAoptions);
else
    Atlas = Atlas.LoadPCAaxis(PCAoptions);
end

if(bComputeCoefs)
    Atlas = Atlas.CalculatePCAcoefs();
else
    Atlas = Atlas.LoadPCAcoefs();
end

Atlas.FullAtlasReport

Atlas.ViewMeshID(141,142)


% Script to build the statistical shape model from the PVS data from Henry

% Directory with the results of the new 43 meshes:
%RootAtlas = 'F:\Atlas\PVSHarry\Atlas';

% Directory with the complete set of cases:
RootAtlas = 'F:\Atlas\JRfemalecohort\Atlasv5.0';
%RootAtlas = 'C:\Data\PVS';
AtlasData = fullfile(RootAtlas,'AtlasData');

bPrepareData = 0;

%%
if(bPrepareData)
    RawData = 'F:\Atlas\PVS Harry\RawData';
    ListCases = dir(RawData);
    if ~exist(AtlasData,'dir'), mkdir(AtlasData); end

    for iC = 3:numel(ListCases)
        itemname = ListCases(iC).name;
        if exist(fullfile(RawData,itemname),'dir')
            RawCaseDir = fullfile(RawData,itemname);
            % This is a case:
            ID = sscanf(itemname,'%i',1);
            casename = sprintf('PVS%03i',ID);
            CaseDir = fullfile(AtlasData,casename);
            if ~exist(CaseDir), mkdir(CaseDir); end       

            CVIfile = ls([RawCaseDir '\*.cvi42wsx' ]);
            cvi42file = fullfile(RawCaseDir,CVIfile);
            DICOMdir = RawCaseDir;

            [C] = read_CVI42WSX( cvi42file , DICOMdir , 'verbose' );
            LabelImage = CVI42Contour2Image( C , 1);

            % Only one LabelImage expected, but just in case:
            for iLi = 1:numel(LabelImage)
                % Extract all images per time instant (only two expected,
                % diastole and systole), take only the first:
                nT = LabelImage{iLi}.dim(4);
                for iT = 1:1
                    im = squeeze(LabelImage{iLi}.data(:,:,:,iT));
                    hd.origin = LabelImage{iLi}.origin;
                    hd.spacing = LabelImage{iLi}.spacing;
                    hd.dim = LabelImage{iLi}.dim(1:3);
                    hd.TransformMatrix = LabelImage{iLi}.TransformMatrix;
                    hd = ParseHeader(hd);
                    hd.Extension = '.gipl';
                    %ImageName = sprintf('Mask%iTime%i',iLi,iT);
                    ImageName = sprintf('Mask%03i',ID);
                    File = fullfile(CaseDir,[ImageName '.gipl']);
                    hd.File = File;
                    io_WriteMedicalImage(File,im,hd);
            %       Mv2w: 4x4 matrix (voxel to world coordinate transformation)
            %       File: name of the file
            %       Extension: to indicate the format
                end
            end
        end
    end
end
%%

% Instance of the class:
    Atlas = AtlasClass(RootAtlas);
% Use the default LV template:
    opt.topology = 'LVL';
    opt.nE = [5 12 1];
    Atlas = Atlas.SetTemplate(opt);
% Create the meshes:
    options.SubDirectory = '/';            
    options.LoD = 1;           
    options.RVpoolLabel = 2;
    options.MyoLabel = 1;          
    options.bRVdirFromSA = 0;
    options.iShapeSpace = 4;
    ExtSurf = 0;
    switch ExtSurf
        case 1
            options.KeyName = 'PVSn43_rvspaceExtSurf';
            options.bOnlyExtSurf = 1;
            options.OutputDirectory = 'AtlasOutputExtSurf';
        otherwise
            options.KeyName = 'PVSn43_rvspace';
            options.bOnlyExtSurf = 0;
            options.OutputDirectory = 'AtlasOutput';            
    end
    options.SeptumLocation = 'MinX';
    if(0)
        %Atlas = Atlas.CalculateAtlas(options);
        Atlas = Atlas.BuildPCA(options);
    else
        Atlas = Atlas.LoadPCAaxis(fullfile(RootAtlas,[options.OutputDirectory 'rv']));
    end
    %%
    if(0)
        Atlas = Atlas.CalculatePCAcoefs(options);
    else
        Atlas = Atlas.LoadPCAcoefs(fullfile(RootAtlas,[options.OutputDirectory 'rv'],sprintf('Coordinates%s.mat',options.KeyName)));
    end
    Atlas.Template.SecAxLocation = 'MinX';
    Atlas = Atlas.UpdateTemplateViewOptions();
    
    %%
    % Learn to differentiate betewen the normo and hypertensive, the third
    % column of the excel file:
    Atlas = Atlas.SetClass('F:\Atlas\JRfemalecohort\Atlasv5.0\codebreaker FINAL corrected.xlsx',3);
    optionsLDA.bPredictive = 0;
    %Atlas.SearchPredictiveMetric(10);
    
    Atlas = Atlas.LinearDiscriminantAnalysis({[1:4]},optionsLDA);    
    Atlas.ViewLDAextremeShapes();
    Atlas.PlotLDA();
    
    % And now test the significances in the five classes, second column:
    Atlas = Atlas.SetClass('F:\Atlas\JRfemalecohort\Atlasv5.0\codebreaker FINAL corrected.xlsx',2);
    Atlas.ViewLDAaxis();
    %Atlas.CompareClassesByLDAaxis();
    
    Atlas = Atlas.SetClass('F:\Atlas\JRfemalecohort\Atlasv5.0\codebreaker FINAL corrected.xlsx',3);
    optionsLDA.bPredictive = 1;
    Atlas = Atlas.LinearDiscriminantAnalysis({[1:5]},optionsLDA);    
    
    %% View the space of the two modes
    Atlas = Atlas.SetClass('F:\Atlas\JRfemalecohort\Atlasv5.0\codebreaker FINAL corrected.xlsx',3);
    optionsLDA.bPredictive = 0;
    Atlas = Atlas.LinearDiscriminantAnalysis({[2:4]},optionsLDA);    
    CoefLDA = Atlas.LDAaxis.wC;
    [~,coefs] = Atlas.GetCurrentCoefficients();
    Coef6 = coefs(6,:);
    %%
    figure('color',[1 1 1]); hold on;    
    colorscheme = 1;
    for iC = 1:numel(Atlas.Class)
        I = Atlas.Class(iC).FileID;
        color = GetAtlasColor(iC,colorscheme);
        plot(Coef6(I),CoefLDA(I),'*','color',color);
        plot(mean(Coef6(I)),mean(CoefLDA(I)),'o','color',color,'MarkerSize',15,'LineWidth',3);
    end
    xlabel('Mode 6')
    ylabel('LDA mode 1-5');
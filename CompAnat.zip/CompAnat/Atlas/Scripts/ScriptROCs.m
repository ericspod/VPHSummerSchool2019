% Script to compare the ROCs

close all;
clear;

bCheckReproducible = 1;

SearchCriteria = 1;

AtlasVersion = 16;
Sversions = [3 4 11];
WindowsSize = [100 100 1100 600];

switch SearchCriteria
    case 1
        bPredictive = 1;
        exstr = 'Exhaustive';
        bPrintROCs = 0;
        nMaxMod = 8;
        for iCombination = 1:nMaxMod
            GroupedModes{iCombination} = iCombination;
        end
        key2 = iCombination + 1;
        for iM = 1:nMaxMod
            for iM2 = iM+1:nMaxMod
                iCombination = iCombination + 1;
                GroupedModes{iCombination} = [iM iM2];
            end
        end
        key3 = iCombination + 1;
        for iM = 1:nMaxMod
            for iM2 = iM+1:nMaxMod
                for iM3 = iM2+1:nMaxMod
                    iCombination = iCombination + 1;
                    GroupedModes{iCombination} = [iM iM2 iM3];
                end
            end
            if(iM<nMaxMod-3)
                key3 =[key3 iCombination + 1];
            end
        end    
    case 2
        % This test should converge in results of case 3, there is nothing
        % learned in each iteration, so the cross-validation error should
        % be the assymptote. 
        bPredictive = 1;
        exstr = 'Unimodal';
        bPrintROCs = 1;
        nMaxMod = 10;
        for iCombination = 1:nMaxMod
            GroupedModes{iCombination} = iCombination;
        end
        key2 = 2:nMaxMod;
        key3 = [];
    case 3
        bPredictive = 0;
        exstr = 'Resubstitution';
        WindowsSize = [100 100 600 600];
        bPrintROCs = 1;
        nMaxMod = 10;
        for iCombination = 1:nMaxMod
            GroupedModes{iCombination} = iCombination;
        end
        key2 = 2:nMaxMod;
        key3 = [];
    case 4
        bPredictive = 0;
        exstr = 'Bimodal';
        bPrintROCs = 1;
        nMaxMod = 9;
        iCombination = 0; key2 = [];
        for iM = 1:nMaxMod
            for iM2 = iM+1:nMaxMod
                iCombination = iCombination + 1;
                GroupedModes{iCombination} = [iM iM2];
            end
            key2 = [key2 iCombination];
        end
            
        key3 = [];
    case 5
        bPredictive = 1;
        exstr = 'Trimodal';
        bPrintROCs = 1;
        nMaxMod = 9;
        iCombination = 0; 
        key2 = []; key3 = [];
        for iM = 1:nMaxMod
            for iM2 = iM+1:nMaxMod
                for iM3 = iM2+1:nMaxMod
                    iCombination = iCombination + 1;
                    GroupedModes{iCombination} = [iM iM2 iM3];
                end
            end
            if(iM<nMaxMod-3)
                key3 =[key3 iCombination + 1];
            end
        end  
    case 6
        bPredictive = 0;
        exstr = 'Quadmodal';
        bPrintROCs = 1;
        nMaxMod = 9;
        iCombination = 0; 
        WindowsSize = [100 100 1500 600];
        key2 = []; key3 = [];
        for iM = 1:nMaxMod
            for iM2 = iM+1:nMaxMod
                for iM3 = iM2+1:nMaxMod
                    for iM4 = iM3+1:nMaxMod
                        iCombination = iCombination + 1;
                        GroupedModes{iCombination} = [iM iM2 iM3 iM4];
                    end
                end
            end
            if(iM<nMaxMod-3)
                key3 =[key3 iCombination + 1];
            end
        end  
end
nCombinations = numel(GroupedModes);



%for bPredictive = 1
    if(bPredictive)
        predstr = 'Pred';
    else
        predstr = 'Expl';
    end
    if bCheckReproducible
        repstr = 'Reprod';
    else
        repstr = 'Reprod';
    end
    for iComparison = 1:2
        if exist('ClassDefinition','var'), clear('ClassDefinition'); end
        for iSub = 1:3
            close all;
            subversion = Sversions(iSub);
            AtlasFileName = ['Atlas.mat'];
            colors = 'rgbkc';

            Haucs = figure('color',[1 1 1],'OuterPosition',WindowsSize);

            options.bRecalculateEigenCoords = 0;
            versionstring = sprintf('%i_%i_%i',AtlasVersion,subversion,iComparison);
            options.versionstring = versionstring;

            for iShapeSpace = 0:4    
                StudyParams = GetAtlasStudyParams(AtlasVersion,subversion,iComparison,iShapeSpace);
                fields = fieldnames(StudyParams.options);
                % fill the options fields with the new ones coming from the atlas study
                % parameters:
                for iField = 1:numel(fields)
                    options = setfield(options,fields{iField},getfield(StudyParams.options,fields{iField}));
                end
                options.AtlasVersion = AtlasVersion;
                options.subversion = num2str(subversion);
                classes2include = [1 2 ];
                if isfield(StudyParams,'classes2include'), classes2include = StudyParams.classes2include; end                

                Directory = StudyParams.Directory;
                OutputDirectory = options.OutputDirectory; 
                if ~exist('ClassDefinition','var')
                    optionsloadClass = StudyParams.optionsExcel;
                    optionsloadClass.DataDirectory = options.DataDirectory;
                    optionsloadClass.bOnlyIncludeCasesInExcelFile = 1;
                    optionsloadClass.AtlasVersion =  AtlasVersion;
                    optionsloadClass.classes2include = classes2include;
                    [ClassDefinition,Cases2include] = LoadAtlasClass(Directory, StudyParams.ClinicalFile, optionsloadClass);
                end
                if ~isempty(Cases2include)
                    options.Cases2include = Cases2include;
                end 
                

                % This call updates the ListCases with the set of valid cases after
                % exploring the data directory:
                [coefficients,cases,~,ListCases] = GetEigenCoefficients(Directory,options);
                % need to load the PCA axes:
                PCAfile = fullfile(OutputDirectory,AtlasFileName);
                fprintf('Loading PCA axes from %s\n',PCAfile);
                load(PCAfile);

                optionsLDA = options;
                optionsLDA.bPredictive = bPredictive;    
                optionsLDA.FigureHandle = Haucs;
                optionsLDA.plotcolor = colors(iShapeSpace+1);
                optionsLDA.bPrintROCs = bPrintROCs;
                optionsLDA.bCheckReproducible = bCheckReproducible;
                optionsLDA.iShapeSpace = iShapeSpace;
                optionsLDA.iMeshing = iSub;
                AtlasLinearDiscriminantAnalysis(GroupedModes,coefficients,ClassDefinition,ListCases,V,optionsLDA);
            end
            switch iComparison
                case 1, ResponseCriterion = 'EDV';
                case 2, ResponseCriterion = 'ESV';
                case 3, ResponseCriterion = 'cohort';
                otherwise, ResponseCriterion = '';
            end
            axis([0.5 nCombinations+0.5 0.5 0.85]);
            legend('NA','C','R','S','rv');
            title(['Classification by ' ResponseCriterion '. ' predstr])
            xlabel('Choice of combinations of shape modes')
            ylabel('AUC of ROC')
            keycombinations = unique([1 key2 key3]);
            for iCombination = 1:numel(keycombinations)
                xString(iCombination).name = sprintf('%i,',GroupedModes{keycombinations(iCombination)});
            end
            set(gca,'XTick',keycombinations);    
            set(gca,'XTickLabel',{xString(:).name});
            filename = [exstr 'AUCs' sprintf('%sStudy%sG%i%s',predstr,versionstring,nCombinations,repstr)];
            export_fig(fullfile(Directory,[filename '.png']),'-png',Haucs);%,'-m3','-painters',H);
            savefig(Haucs,fullfile(Directory,[filename '.fig']))
        end
    end
%end

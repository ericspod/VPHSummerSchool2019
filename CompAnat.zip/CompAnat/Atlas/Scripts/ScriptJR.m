% Script to review the JR data, and generate the VTK meshes of the
% collection of cases:
% - With the "RV" pre-orientation solved
% - With AtlasClass for code consisntency, hopefully reproducing what the
% ScriptAtlas.m old code generated
%
% P.Lamata

ShapeSpace = 4;
AtlasRoot = 'F:\JRpreterm\Atlas_v6';


bBuildPCA = 0;
bComputeCoefs = 0;

Atlas = AtlasClass(AtlasRoot);

if(bBuildPCA)
    % Define the template:
    TemplateOptions.nE = [6 12 1];
    TemplateOptions.topology = 'LV';
    Atlas = Atlas.SetTemplate(TemplateOptions);
end

    PCAoptions.OutputDirectory = 'AtlasOutput18';
    PCAoptions.KeyName = sprintf('JReqS%i_18',ShapeSpace);
    PCAoptions.SubDirectory = '/zmask/'; 
    PCAoptions.iShapeSpace = ShapeSpace;
    PCAoptions.SeptumLocation = 'Ymax';
    if(bBuildPCA)    
        Atlas = Atlas.BuildPCA(PCAoptions);
        Atlas = Atlas.SaveMeshes_sortedbymeshID(PCAoptions);  
    else
        Atlas = Atlas.LoadPCAaxis(PCAoptions);
    end
    if(bComputeCoefs)
        Atlas = Atlas.CalculatePCAcoefs();
    else
        Atlas = Atlas.LoadPCAcoefs();
    end

NodeLabels = Atlas.SaveVTKmeshes;
fid = fopen(fullfile(Atlas.DataDirectory,'NodeLabels.txt'),'w');
fprintf(fid,'%i\n',NodeLabels);
fclose(fid)
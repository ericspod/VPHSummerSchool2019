% Script to correct case 185:

direct = 'F:\Atlas\JR\Atlas_v5.0\AtlasData\EVS185\zmask';


in = 'RawBinary';
%in = 'EDframe';
%in = 'BinaryMask';

iSlices2Remove = [9 11];
[im,hd] = io_ReadMedicalImage(fullfile(direct,[in '0.vtk']));

iS = 0;
for iSlice = 1:hd.dim(3)
    I = find(iSlices2Remove == iSlice);
    if numel(I) == 0
        iS = iS + 1;
        im2(:,:,iS) = im(:,:,iSlice);
    end
end

hd2 = hd;
hd2.dim = size(im2);
hd2 = ParseHeader(hd2);
io_WriteMedicalImage(fullfile(direct,[in '.vtk']),im2,hd2);

% Script to analyse the data from Tarique

%CVIrootfolder = 'C:\Data\data\Tarique\PILOT_DATA\PILOT DATA';
%AtlasRoot = 'C:\Data\data\Tarique\Atlas';
CVIrootfolder = 'E:\Peter\Dallas\Projects\OncoAtlas\Atlas\AtlasData';
AtlasRoot = 'E:\Peter\Dallas\Projects\OncoAtlas\Atlas';
bPrepareData  = 0;
bBuildMeshes  = 1;
bBuildPCA     = 1;
bComputeCoefs = 1;
%%
AtlasData = fullfile(AtlasRoot,'AtlasData');
if(bPrepareData)
    RawData = CVIrootfolder;
    ListCases = dir(RawData);
    if ~exist(AtlasData,'dir'), mkdir(AtlasData); end

    for iC = 4:numel(ListCases)
        itemname = ListCases(iC).name;
        if exist(fullfile(RawData,itemname),'dir')
            RawCaseDir = fullfile(RawData,itemname);
            % This is a case:
            % ... check if it is a control or a case:
            if exist('bDiseased','var'), clear('bDiseased'); end
            switch itemname(2:4)
                case 'ase', bDiseased = 1;
                case 'ont', bDiseased = 0;
                otherwise
                    fprintf('Error! naming not expected\n');
            end
            ID = sscanf(itemname(end-1:end),'%i',1);
            
            % Dicom information:
            % ... where I save the info once extracted:
            dicominfofile = fullfile(RawCaseDir,'dicomdirinfo.mat');           
            % ... where the list of files is:
            % ... Identify the directory with the DICOMs: only directory in
            % the current folder
            listitems = dir(RawCaseDir);
            if exist('DICOMdir','var'), clear('DICOMdir'); end
            for iFF = 3:numel(listitems)
                CanDICOMdir = fullfile(RawCaseDir,listitems(iFF).name);
                if isdir(CanDICOMdir)
                    DICOMdir = CanDICOMdir;
                end
            end
            if ~exist('DICOMdir','var'), fprintf('DICOMdir not found in %s\n',RawCaseDir); end
            if exist(dicominfofile,'file')
                load(dicominfofile);
            else
                fprintf('sorting directory: %s\n', DICOMdir);
                S = sortDCMfiles(DICOMdir);
                save(dicominfofile,'S');
            end
            
            % Look for the contour files:
            Contours{1} = 'ED';
            Contours{2} = 'ES';
            CVIfile = ls([RawCaseDir '\*.cvi42wsx' ]);
            for iCF = 1:2
                meshID = sprintf('%02i_%i_%i',ID,bDiseased,iCF);
                casename = sprintf('PILOT%s',meshID);
                CaseDir = fullfile(AtlasData,casename);
                if ~exist(CaseDir), mkdir(CaseDir); end 
                % Identfy the CVI file with the keyname 'ED' or 'ES'
                CVIfile = ls([RawCaseDir '\*' Contours{iCF} '.cvi42wsx' ]);
                if isempty(CVIfile)
                    fprintf('Error! no %s file found in %s\n',Contours{iCF},RawCaseDir);
                else
                    cvi42file = fullfile(RawCaseDir,CVIfile);
                    %[C] = read_CVI42WSX( cvi42file , S , 'verbose' );
                    [C] = read_CVI42WSX( cvi42file , DICOMdir , 'verbose' );
                    LabelImage = CVI42Contour2Image( C , 1);

                    % Only one LabelImage expected, but just in case:
                    for iLi = 1:numel(LabelImage)
                        % Extract all images per time instant (only two expected,
                        % diastole and systole), take only the first:
                        nT = LabelImage{iLi}.dim(4);
                        for iT = 1:nT
                            im = squeeze(LabelImage{iLi}.data(:,:,:,iT));
                            if max(im(:))<=0
                                fprintf(' WARNING! label image in time %i was empty\n',iT);
                            else
                                hd.origin = LabelImage{iLi}.origin;
                                hd.spacing = LabelImage{iLi}.spacing;
                                hd.dim = LabelImage{iLi}.dim(1:3);
                                hd.TransformMatrix = LabelImage{iLi}.TransformMatrix;
                                hd = ParseHeader(hd);
                                hd.Extension = '.gipl';
                                %ImageName = sprintf('Mask%iTime%i',iLi,iT);
                                ImageName = sprintf('Mask%03i_T%i',ID,iT);
                                File = fullfile(CaseDir,[ImageName '.gipl']);
                                hd.File = File;
                                io_WriteMedicalImage(File,im,hd);

                                opt.OutDir = CaseDir;
                                opt.iPhase = iT;
                                opt.imageformat = 'vtk';
                                ExtractSSFP(S,opt);

                        %       Mv2w: 4x4 matrix (voxel to world coordinate transformation)
                        %       File: name of the file
                        %       Extension: to indicate the format
                            end
                        end
                    end
                end
            end
        end
    end
end
%%

% Instance of the class:
    Atlas = AtlasClass(AtlasRoot);
    %Atlas.RemoveOutputFolders();
% Use the default LV template:
    opt.topology = 'LVL';
    opt.nE = [5 12 1];
    Atlas = Atlas.SetTemplate(opt);
% Create the meshes:
    options.SubDirectory = '/';            
    options.LoD = 2;           
    options.RVpoolLabel = 2;
    options.MyoLabel = 1;     
    
ExtSurf = 0;
switch ExtSurf
    case 1
        options.KeyName = 'OncoExtSurf';
        options.bOnlyExtSurf = 1;
        options.OutputDirectory = 'AtlasOutputExtSurf';
    otherwise
        options.KeyName = 'Onco';
        options.bOnlyExtSurf = 0;
        options.OutputDirectory = 'AtlasOutput';            
end
options.SeptumLocation = 'MaxY';

if(bBuildMeshes)
    Atlas = Atlas.BuildMeshes(options);
end
    
for iSS = 3:4
    % iShapeSpace will determine the aglignment for different meshes:
    % 0, NA
    % 1, C (center of mass)
    % 2, R (center of mass and rotation)
    % 3, S (center, rotate, scale)
    % 4, rv (alignment using the position of the right ventricle)
    options.iShapeSpace = iSS;
    if(bBuildPCA)
        %Atlas = Atlas.CalculateAtlas(options);
        Atlas = Atlas.BuildPCA(options);
    else
        Atlas = Atlas.LoadPCAaxis(options);
    end
    
    if(bComputeCoefs)
        Atlas = Atlas.CalculatePCAcoefs(options);
    else
        Atlas = Atlas.LoadPCAcoefs();
    end
    
    Atlas.colourscheme = 6;
    iColumn = 6;
    Atlas = Atlas.SetClass(fullfile(AtlasRoot,'infocasesEdited.xls'),iColumn);
    if(1)
        Atlas.FullAtlasReport();
        %CreateExcelClassFile(Atlas.DataDirectory);
        Atlas.ViewEigenSpace();
        Atlas.ViewBoxPlots();
    end    
    if(1)
        % Search for differences
        Atlas.CompareClassesByPCAaxis();
        opt.bExaustiveAUC = 1;
        opt.classes2include = [1 3];
        Atlas.SearchPredictiveMetric(10,opt);   
        opt.classes2include = [2 4];
        Atlas.SearchPredictiveMetric(10,opt);
    end    
    if(0)
        % And once they are found, detailed inspection
        % GM contains index of PCA coefficients for with PCA as highest covariance
        % e.g. GM = {1:3} -> only first three coeffs
        GM = {1:3};
        opt.classes2include = [2 4];
        opt.classes2include = [1 3];
        Atlas = Atlas.LinearDiscriminantAnalysis(GM,opt);
        Atlas.PlotLDA();
        %Atlas.ViewLDAextremeShapes();
    end
end
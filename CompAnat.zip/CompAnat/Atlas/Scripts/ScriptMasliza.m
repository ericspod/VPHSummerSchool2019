% Script to analyse the data from Masliza

cohort = 6;
PairedNamingCriteria = 'classinfirstdigit';

organ = 'RV'; %'BiV'; %'RV'; % 'LV',
IDoffset =0;
% Where the case ID is within the name:
i0 = 5; i1 = 'end';
namingoptions = [];
bMeshingList = 0;
switch cohort
    case 1
        RawDataDir = 'C:\Data\MaslizaAorticStenosis\Shape+in+aortic+stenosis\Shape in aortic stenosis';
        i0 = 3;
    case 2
        AtlasRoot = 'F:\Atlas\MaslizaAorticStenosis\Atlas';
        Root = 'C:\Data\data\MaslizaAorticStenosis';
        RawDataDir = 'C:\Data\data\MaslizaAorticStenosis\NewRawData';
        RawDataDir = 'C:\Data\data\MaslizaAorticStenosis\RawData';        
        AtlasRoot = fullfile(Root,'Atlas');
        %RawDataDir = fullfile(Root,'Test');
    case 3
        % Make the RV atlas
        organ = 'RV';
        Root = 'C:\Data\data\MaslizaAorticStenosis';
        RawDataDir = fullfile(Root,'RawData');        
        AtlasRoot = fullfile(Root,'RVAtlasv2');
    case 4
        Root = 'C:\Data\data\MaslizaAorticStenosis\HypertesiveCases';
        AtlasRoot = fullfile(Root,'Atlas2');               
        RawDataDir = fullfile(Root,'HTN');
        IDoffset = 500;
    case 5
        % Merge of cohorts 2 and 4
        AtlasRoot = 'C:\Data\data\MaslizaAorticStenosis\AtlasAll';
        AtlasRoot = 'C:\Data\MaslizaAorticStenosis\AtlasAll';
    case 6
        % Build meshes of 4 new cases
        RawDataDir = 'C:\Data\data\MaslizaAorticStenosis\NewFourCases';
        i0 = 4; i1 = 6;
        % And add them to the AtlasAll collection:
        AtlasRoot = 'C:\Data\MaslizaAorticStenosis\AtlasAll';
        bMeshingList = 1; List = [53 60 61 73];
    case 7
        % Build meshes of 4 new cases
        RawDataDir = 'C:\Data\MaslizaAorticStenosis\AMICAdata';
        AtlasRoot = 'C:\Data\MaslizaAorticStenosis\AtlasAll';
        % And add them to the AtlasAll collection:
        AtlasRoot = 'C:\Data\MaslizaAorticStenosis\AtlasAll';
        IDoffset = 600;
        bMeshingList = 1; List = [619, 625, 644, 667];
        namingoptions.bNotEnd = 1;
        namingoptions.bAllDigits = 0;
end

bDebug = 1;

bPrepareData = 0;
    
bBuildAtlas = 1;
    bBuildMeshes = 0;
        bForceTemplateCreation = 0;
    bBuildPCA = 1;
    bComputeCoefs = 1;

AtlasDataRoot = fullfile(AtlasRoot,'AtlasData');




if(bPrepareData)
    if ~exist(AtlasDataRoot,'dir'), mkdir(AtlasDataRoot); end        
     listdirs = dir(RawDataDir);
     for iF = 3:numel(listdirs)
         namefile = listdirs(iF).name;
         DirName = fullfile(RawDataDir,namefile);         
         if isdir(DirName)
            % For some reason, sscanf does not always work!
            %ID = sscanf(namefile(i0:end),'%i',1);
            if strcmp(i1,'end'), ID = GetIDfromName(namefile(i0:end),namingoptions);
            else, ID = GetIDfromName(namefile(i0:i1)); end
%             if ID==0
%                 % hack to solve the scan of 008!
%                 ID = sscanf(namefile(i0+1:end),'%i',1);
%             end
            ID = ID + IDoffset;
            CaseDirName = sprintf('Case%03i',ID);
            CaseDir = fullfile(AtlasDataRoot,CaseDirName);
            if ~exist(CaseDir,'dir'), mkdir(CaseDir); end 
             
            % get the structure of all the dicoms
             DICOMdir = DirName;
             CVIfile = ls(fullfile(DirName, '*.cvi42wsx' ));
             if isempty(CVIfile)
                 fprintf('ERROR! no CVI file found in %s\n',DirName);
             end
             ContourMatFile = fullfile(DirName,sprintf('Contours%03i.mat',ID));
             cvi42file = fullfile(DirName,CVIfile);
             if strcmp(namefile,'Case1042')                 
                 load('C:\Data\MaslizaAorticStenosis\AtlasData\Case1042\contours\Case1042.mat');
             else
                 if exist(ContourMatFile,'file')
                     fprintf('loading contours from %s\n',ContourMatFile);
                     load(ContourMatFile);
                     fprintf('Done! (contours loaded)\n');
                 else
                     fprintf('Reading %s\n',cvi42file);
                     [C] = read_CVI42WSX( cvi42file , DICOMdir , 'verbose' );
                     fprintf(' finished!\n');
                     % keep only contours with associated dicom
                     if isfield(C,'parentDICOMfound')
                        C( ~[ C.parentDICOMfound ] ) = [];
                     end
                     if isfield(C,'parentFilename')
                        bParent = ones(1,numel(C));
                        for iC = 1:numel(C)
                            pp = C(iC).parentFilename;
                            if strcmp( char(pp) , 'NotVal')
                                bParent(iC) = 0;
                            end
                        end  
                        C( ~bParent ) = [];
                     end                        
                     % and keep only contours with more than 3 points
                     C( [ C.NPoints ] < 3 ) = [];
                     save(ContourMatFile,'C');
                 end
                 %[C] = read_CVI42WSX_full( cvi42file , DICOMdir , 'verbose' );                 
             end
             
             
             switch organ
                 case 'LV'
                     % me quedo con los tres contornos que quiero:
                     C2 = C( strcmp( { C.Description } , 'saendocardialContour' ) );
                     C3 = C( strcmp( { C.Description } , 'saepicardialContour' ) );
                     C4 = C( strcmp( { C.Description } , 'sarvendocardialContour' ) );
                     C = [C2; C3; C4];
                     OrganLabel= '';
                 case 'RV'
                     C = C( strcmp( { C.Description } , 'sarvendocardialContour' ) );                     
                     OrganLabel = 'RV';                     
             end
             
             % Select only the ones of the first time instant:
             Times = sort(unique([C(:).TimeInstant]),'ascend');
             if Times(1)<3
                 EDtime = Times(1);
             else
                 EDtime = Times(end);
             end
             C = C([C(:).TimeInstant] == EDtime);
             
             % Group contours
             C2 = groupCVI42Contours(C);
             
             % lo que queda es:
                figure; 
                subplot(121); hold on;
                for c = 1:numel( C )
                  plot3( C(c).Points3D(:,1) , C(c).Points3D(:,2) , C(c).Points3D(:,3) , 'Color',rand(1,3) );
                end
                hold off; axis equal; view(3);
                subplot(122); hold on;
                for c = 1:numel( C2 )
                  plot3( C2(c).Points3D(:,1) , C2(c).Points3D(:,2) , C2(c).Points3D(:,3) , 'Color',rand(1,3) );
                end
                hold off; axis equal; view(3);
             
             LabelImage = CVI42Contour2Image( C2 );
             
             if numel(LabelImage) == 1
                 im = LabelImage.data;
                 ImageName = sprintf('Mask%s%03i',OrganLabel,ID);
                 File = fullfile(CaseDir,[ImageName '.gipl']);
                 [hd] = io_WriteImageFromLabelImage(File,im,LabelImage);
                 if(bDebug)
                     H = figure('color',[1 1 1]);
                     subplot(131)
                     PlotContours(C);
                     subplot(132)
                     PlotContours(C2);
                     subplot(133)
                     show_segment_surface(im,hd.Mv2w);
                     title(sprintf('Case %i',ID));
                     export_fig(fullfile(CaseDir, sprintf('Contouring%s.png',OrganLabel)),'-m2','-png',H);%,'-painters',H);
                     %pause();
                 end
             else
                 for iLi = 1:numel(LabelImage)
                    % Extract all images per time instant (only two expected,
                    % diastole and systole), take only the first:
                    nT = LabelImage{iLi}.dim(4);
                    for iT = 1:nT
                        im = squeeze(LabelImage{iLi}.data(:,:,:,iT));
                        if numel(im(im>0))>0
                            iLabelImage = LabelImage{iLi};
                            ImageName = sprintf('Mask%03iLabelIm%02iTime%02i',ID,iLi,iT);
                            File = fullfile(CaseDir,[ImageName '.gipl']);
                            io_WriteImageFromLabelImage(File,im,iLabelImage);
                        end
                    end
                 end
            end
         end 
     end
end
    
if(bBuildAtlas)
    Atlas = AtlasClass(AtlasRoot);
    
    % Set template
    switch organ
        case 'RV'
            Atlas.MeshViewOptions.HeartVisualizationStyle = 'RV';
            options.iShapeSpace = 4;
            options.topology = 'RVbp';
            options.CustomiseTemplate = 'RVbp';
            options.bForceTemplateCreation = bForceTemplateCreation;
            % Try only with one case:
            %options.iCase1 = 4;            
            options.bOnlyExtSurf = 1;
            options.nE = [4 4 1];
            % Label for the RV blood pool in the segmentation:
            options.Label = 4;
            options.LoD = 5;     
            % Specific output of the meshing and the atlas:
            options.OutMeshingDir = ['Output_Gen' organ];
            options.KeyName = 'rvAS';
            options.OutputDirectory = ['Atlas' organ 'Output'];
        case 'BiV'
            % Meshes are built previously, simply merge them
            bBuildMeshes = 0;
            options.OutMeshingDir{1} = {'Output_GenRV'};
            options.OutMeshingDir{2} = {'Output_heartgen'};
            options.OutputDirectory = ['Atlas' organ 'Output'];
            options.KeyName = 'BiV';    
            options.bMerge = 1;
            options.iShapeSpace = 4;
            options.iNodeSecondAxis = 20;
            options.iNodeSecondAxis = 151;
            % options.SecAxLocation = 'MaxX';
        otherwise
            opt.topology = 'LVL';
            opt.nE = [5 12 1];
            Atlas = Atlas.SetTemplate(opt);
            options.RVpoolLabel = 4;
            options.MyoLabel = [1 2 6];          
            options.bRVdirFromSA = 0;
            options.iShapeSpace = 4;
            options.KeyName = 'AS';    
            options.LoD = 1;
    end
    
    % Build the atlas
    options.SubDirectory = '/';     
    
     

    if(bBuildMeshes)
        if(~bMeshingList)
            Atlas.BuildMeshes(options);
        else        
            for iL=1:numel(List)
                Atlas.BuildMeshID(List(iL),options);
            end
        end
    end
    
    if(bBuildPCA)
        Atlas = Atlas.BuildPCA(options);
    else
        Atlas = Atlas.LoadPCAaxis(options);
    end    
    if(bComputeCoefs)
        Atlas = Atlas.CalculatePCAcoefs();
    else
        Atlas = Atlas.LoadPCAcoefs();
    end    
end

Atlas.MeshViewOptions.ZoomFactor = 2.5;
% Set the RV pointed to the left (in bottom right view):
Atlas.MeshViewOptions.orthoFRONT = 'Y';

% CreateExcelClassFile(Atlas.DataDirectory);
Atlas = Atlas.SetClass(fullfile(Atlas.RootDir,'infocases.xls'),4);
Atlas.colourscheme = 11;

if(0)    
    Atlas.PlotFittingAccuracy();
    Atlas.GenerateTexFileAllMeshes();
    Atlas.iEig2plot = 1:9;
    Atlas.GenerateTexFileAllModes();
    Atlas.ViewAverageShapes();   

    Atlas.ViewComparisonAverageGroups();
    Atlas.ViewEigenSpace();
    Atlas.ViewBoxPlots();
    Atlas.CompareClassesByPCAaxis();
    Atlas.SearchPredictiveMetric(10);
end
if(0)       
    % Impact of surgery in paired analysis:
    opt.PairedNamingCriteria = PairedNamingCriteria;
    Atlas.PlotLongitudinalClasses(1:9,opt);
end

if(0)
    optViewEig.classes2pair = [1 2];
    optViewEig.PairedNamingCriteria = PairedNamingCriteria;
    Atlas.ViewEigenSpace(optViewEig);
end
    
if(0)
    % Combine modes 1 and 2, differences from G1 to control:
    optionsLDA.classes2include = [1 3];
    Atlas.SearchPredictiveMetric(10,optionsLDA);
    Atlas = Atlas.LinearDiscriminantAnalysis({1:2},optionsLDA);
    Atlas.PlotLDA;
    Atlas.ViewLDAaxis;
    Atlas.ViewLDAextremeShapes;
    Atlas.CompareClassesByLDAaxis();
end    

if(0)
    % Combine modes 1 and 2, differences from G1 to G2:
    optionsLDA.classes2include = [1 2];
    Atlas = Atlas.LinearDiscriminantAnalysis({1:2},optionsLDA);
    Atlas.PlotLDA;
    Atlas.ViewLDAaxis;
    Atlas.ViewLDAextremeShapes;
    Atlas.CompareClassesByLDAaxis();
end 
    
if(0)
    % Combine modes 3 and 4, differences from G1 to control:
    optionsLDA.classes2include = [4 3];
    Atlas = Atlas.LinearDiscriminantAnalysis({3:4},optionsLDA);
    Atlas.PlotLDA;
    Atlas.ViewLDAaxis;
    Atlas.ViewLDAextremeShapes;
    Atlas.CompareClassesByLDAaxis();
end

if(0)
    % Combine modes 7 and 8, differences from G1 to after surgery (G2):
    optionsLDA.classes2include = [1 2];
    Atlas = Atlas.LinearDiscriminantAnalysis({7:8},optionsLDA);
    Atlas.PlotLDA;
    Atlas.ViewLDAaxis;
    Atlas.ViewLDAextremeShapes;
    Atlas.CompareClassesByLDAaxis();
end

if(0)
    % Optimal single modes to diff G1 to G2
    OptimalModes = {[1 6 7 8]};
    optionsLDA.classes2include = [1 2];
    optionsLDA.bPredictive = 1;
    Atlas = Atlas.LinearDiscriminantAnalysis(OptimalModes,optionsLDA);
    fprintf('AUC = %1.3f\n',Atlas.LDAaxis.AUCs);
    optionsLDA.bPredictive = 0;
    Atlas = Atlas.LinearDiscriminantAnalysis(OptimalModes,optionsLDA);
    Atlas.ViewLDAextremeShapes;
    % View the paired cases:
    Atlas.PlotLongitudinalClasses(0,opt);
end

if(0)
    % Optimal single modes to diff G1 to G3
    OptimalModes = [1:4];
    optionsLDA.classes2include = [1 3];
    optionsLDA.bPredictive = 1;
    Atlas = Atlas.StudyLDAcombination(OptimalModes,optionsLDA);
    fprintf('AUC = %1.3f\n',Atlas.LDAaxis.AUCs);
    optionsLDA.bPredictive = 0;
    Atlas = Atlas.LinearDiscriminantAnalysis(OptimalModes,optionsLDA);
    Atlas.ViewLDAextremeShapes;
end

if(0)
    % Search differences between the two hypertensive groups
    opthyp.classes2include = [1 4];
    % RV optimal ones
    Modes2search = [8 2 4 11 12 13];
    Atlas = Atlas.ComprehensiveLDA(Modes2search,opthyp);

    OptimalModes = [2 4 8 12 13];
    Atlas = Atlas.StudyLDAcombination(OptimalModes)
end

if(0)
    % RV, G1 vs G2
    opthyp.classes2include = [1 2];
    % RV optimal ones
    Modes2search = [2 3 4 7 8 10 11 12 13];
    Atlas = Atlas.ComprehensiveLDA(Modes2search,opthyp);
    
    % RV, G1 vs G3
    optAS.classes2include = [1 3];
    Modes2search = [1 2 3  9 11 13];
    Atlas = Atlas.ComprehensiveLDA(Modes2search,optAS);

    % RV, G1 vs G3
    optHYP.classes2include = [3 4];
    Modes2search = [1 2 3 6 7 8];
    Modes2search = [7 8 10 12 13 14];
    Atlas = Atlas.ComprehensiveLDA(Modes2search,optHYP);

end

if(0)
    % Explore the LDA on the original dofs
    opt.LDAmatrixOption = 'linear';
    opt.classes2include = [1 2];
    opt.bAUCs = 1;
    Atlas = Atlas.LoadPCAaxis(options);
    Atlas = Atlas.BuildLDA(opt);
    optv.colourscheme = 10;
    Atlas.ViewLDAextremeShapes(optv);
    Atlas.ViewLDAaxis;
    %rLD12 = Atlas.LDAaxis.ResubCoefs;
    LD12 = Atlas.LDAaxis;
end

if(0)
    % Age matched HYP vs AS, smaller sample size and age matched:
    Atlas = Atlas.SetClass(fullfile(Atlas.RootDir,'infocases.xls'),6);
    % Explore differences in PCA axes:
    Atlas.CompareClassesByPCAaxis
    % Search differences between the two hypertensive groups
    opthyp.classes2include = [1 4];
    switch organ
        case 'BiV'
            HYP_Modes2search = [8 4 2 1 5 12];
            HYP_OptimalModes = [8 2 1 5 12];
        case 'RV'
            HYP_Modes2search = [4 5 9 12 13];
    end
    %opthyp.CoreModes = [4 1 3 6];
    %Atlas = Atlas.ComprehensiveLDA(Modes2search,opthyp);

    %OptimalModes = [2 4 8 12 13];
    OptimalModes = [2 4 7 8 12 13];
    %Atlas = Atlas.StudyLDAcombination(HYP_OptimalModes,opthyp);
    % Atlas.MakeLDAModeMovie
end

if(0)
    % Ken analysing the correlation between Systemic pressure with the
    % anatomy of the cohort
    
    % Where is the data of the systemic pressure:
    iColumn = 8;
    Atlas.LinearRegressionModel(iColumn,10);
    
end

if(1)
    
end
    
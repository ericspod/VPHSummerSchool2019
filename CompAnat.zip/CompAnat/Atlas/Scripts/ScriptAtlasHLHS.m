% Where we want to build the atlas:
AtlasRoot = 'F:\Atlas\JamesWongAtlas\Version5';
excelfile = 'full dataset HLHS for Pablo.xlsx';                    
iColumn = 2;

bAtlasStagesI_II = 1;
    iColumnStaI_II = 8;
bAtlasBasalSliceCoordinateSystem = 0;
    
bBuildPCA     = 0;
bComputeCoefs = 0;
SecAxLocation = 'MaxY';

% Instance of the class:
    Atlas = AtlasClass(AtlasRoot);
% Use the default LV template:
    opt.topology = 'LVL';
    opt.nE = [6 12 1];
    opt.SecAxLocation = SecAxLocation;
    Atlas = Atlas.SetTemplate(opt);
 
    
    iSS = 1;
    options.iShapeSpace = iSS;           
    options.SeptumLocation = SecAxLocation;
    optkeyname = ''; 
    if bAtlasStagesI_II, 
        optkeyname = '_S12only'; 
        Atlas = Atlas.SetClass(fullfile(AtlasRoot,excelfile),iColumnStaI_II);
        options.bBuildPCAwithOnlyCasesWithClassData = 1;
    end
    % First atlas results in "Basal slice coordinate system":
    if(bAtlasBasalSliceCoordinateSystem)
        options.BinaryName = 'Mesh';
    end
    options.KeyName = sprintf('HLHS_%s%s',SecAxLocation,optkeyname);
    
    if(bBuildPCA)
        Atlas = Atlas.BuildPCA(options);
    else
        Atlas = Atlas.LoadPCAaxis(options);
    end
    
    if(bComputeCoefs)
        Atlas = Atlas.CalculatePCAcoefs(options);
    else
        Atlas = Atlas.LoadPCAcoefs();
    end
    
    % Overview of the statistical shape model:
    % Atlas.FullAtlasReport();
    
    Atlas.MeshViewOptions.bVerticalViewIn3D = 1;
    Atlas.MeshViewOptions.ZoomFactor = 2.4;
    Atlas = Atlas.UpdateTemplateViewOptions();
    
    if(0)        
        Atlas = Atlas.SetClass(fullfile(AtlasRoot,excelfile),6);
        Atlas.ViewBoxPlots
        Atlas = Atlas.SetClass(fullfile(AtlasRoot,excelfile),7);
        Atlas.ViewBoxPlots
        Atlas = Atlas.SetClass(fullfile(AtlasRoot,excelfile),8);
        Atlas.ViewBoxPlots
    end
    if(0)
        Atlas.ViewModalVariations(1:6);    
        Atlas.iEig2plot = 1:6;
        Atlas.GenerateTexFileAllModes()
        Atlas.PlotVariancePerMode;
    end    
    if(0)
        % Search for differences: between stages I, II and III
        Atlas.colourscheme = 4;
        Atlas = Atlas.SetClass(fullfile(AtlasRoot,excelfile),4);
        Atlas.CompareClassesByPCAaxis(opt);
        Atlas.ViewComparisonAverageGroups();
        Atlas.iEig2plot = 1:6;
        Atlas.ViewBoxPlots();    

        % Search for differences: all stages, between surgical shunts
        Atlas.colourscheme = 1;
        Atlas = Atlas.SetClass(fullfile(AtlasRoot,excelfile),2);
        Atlas.CompareClassesByPCAaxis();
        Atlas.ViewComparisonAverageGroups();
    end
        
        
        opt.significance = 0.05;
        opt.bBonferroniCorrection = 1;
        Atlas = Atlas.SetClass(fullfile(AtlasRoot,excelfile),6);
        Atlas.CompareClassesByPCAaxis(opt);
        Atlas = Atlas.SetClass(fullfile(AtlasRoot,excelfile),7);
        Atlas.CompareClassesByPCAaxis(opt);
        Atlas = Atlas.SetClass(fullfile(AtlasRoot,excelfile),8);
        Atlas.CompareClassesByPCAaxis(opt);
        
    if(0)
        % Search for differences: at stage I, between surgical shunts    
        Atlas = Atlas.SetClass(fullfile(AtlasRoot,excelfile),6);
        Atlas.CompareClassesByPCAaxis();
        Atlas.ViewComparisonAverageGroups();

        % Search for differences: at stage II, between surgical shunts
        Atlas = Atlas.SetClass(fullfile(AtlasRoot,excelfile),7);
        Atlas.CompareClassesByPCAaxis();
        Atlas.ViewComparisonAverageGroups();
    end
    if(0)
        opt.classes2include = [1 3];
        Atlas.SearchPredictiveMetric(6,opt);   
        opt.classes2include = [3 4];
        Atlas.SearchPredictiveMetric(6,opt);
       
        % And once they are found, detailed inspection
        GM = {1:3};
        opt.classes2include = [2 4];
        Atlas = Atlas.LinearDiscriminantAnalysis(GM,opt);
        Atlas.PlotLDA();
        Atlas.ViewLDAextremeShapes();
    end
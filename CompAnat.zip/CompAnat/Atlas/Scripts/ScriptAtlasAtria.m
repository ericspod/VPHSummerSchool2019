% Revision of the DCM atlas results in June 2016. Example of a script where
% a correlation between shape scores and a continuous output clinical
% variable is performed.

if ispc
    prefix='C:\Users\mv12\Dropbox\ResearchFiles';
elseif ismac
    prefix='/Users/mustafa/Dropbox/ResearchFiles'; 
end

atlasname='Tsegs'; 
datadir =fullfile(prefix,'Scripts/Tsegs');
currdir=datadir;

AtlasRoot = fullfile(prefix,'/CINE_MRI/fromPablo/');

AtlasRoot ='C:\Data\data\Atria\Marta';
AtlasRoot ='C:\Data\atria\Marta';

excelfile = 'infocases.xls';                    
iColumn = 3;

bBuildMeshes = 1;
    AlignmentOption = 'A';
bBuildPCA = 0;
bComputeCoefs = 0;


% Instance of the class:
    Atlas = AtlasClass(AtlasRoot);
% Use the default LV template:
    opt.topology = 'Sphere';
    opt.nE = [12 12 1];
    opt.LoD = 1; % change later
    opt.Template=fullfile(AtlasRoot,'TemplateDir/ellipsoidAproxGT2_nE12121');
    opt.bReport =1;
    opt.Label = 1;
    opt.RVpoolLabel=2;
    switch AlignmentOption
        case 'A', opt.bHorizontalBase=1;
        case 'B', opt.bHorizontalBase=0;
    end
    Atlas.OutMeshingDir = sprintf('Meshing%s',AlignmentOption);
    opt.bUseNodalWarping=1;
    opt.RotT = [0.00000 0.00000 1.00000; 1.00000 0.00000 0.00000; 0.00000 1.00000 0.00000];
    Atlas = Atlas.SetTemplate(opt);
    
%     heartgen2(binary,'-Template',bpname,'-LoD',1,'-InitOption',1,...
%             '-SenseRot',2,'-HeartType','Sphere','-bReport',1,...
%             '-RVpoolLabel',2,'-MyoLabel',1);
% Shape space choice:
    options.iShapeSpace = 4;   
    options.KeyName = sprintf('rv%s',AlignmentOption);
    
%     if(bPrepareData)
%         RawData = 'C:\Users\mv12\Dropbox\ResearchFiles\Scripts\Tsegs';
%         files = dir(RawData);
%         for iFile = 3:numel(files)
%             filename = files(iFile).name;
%             if strcmp(filename(end-3:end),'.nii')
%                 [
                
    
    if(bBuildMeshes)
        % To compute the residual right:
        opt.FittingResidualCodeOption = 'matlab';
        Atlas = Atlas.BuildMeshes(opt);
        % Move to the 'AtlasMeshData' folder:
        Atlas = Atlas.SaveMeshes_sortedbymeshID(opt);
    end
    
    if(bBuildPCA)
        Atlas = Atlas.BuildPCA(options);
    else
        Atlas = Atlas.LoadPCAaxis(options);
    end
    
    if(bComputeCoefs)
        Atlas = Atlas.CalculatePCAcoefs(options);
    else
        Atlas = Atlas.LoadPCAcoefs();
    end

% Analyse results:

    if(1)
        Atlas.iEig2plot = 1:6;
        Atlas.FullAtlasReport();
    end

     Atlas = Atlas.SetClass(fullfile(AtlasRoot,excelfile),iColumn);
% Script to resamble the Generation R data


ResolutionWanted = 1.0938;
ResString = '109';

RootDir = 'F:\Atlas\GenerationR\Segmentations600\AtlasData';
OutDir = ['F:\Atlas\GenerationR\Segmentations600\' sprintf('AtlasDataRes%s',ResString)];
if ~exist(OutDir,'dir'), mkdir(OutDir); end

listcases = dir(RootDir);

for iC = 3:189%numel(listcases)
    casedir = listcases(iC).name;
    casedirwithpath = fullfile(RootDir,casedir);
    if isdir(casedirwithpath)
        listim = ls([casedirwithpath '/*.nii']);
        OutCaseDir = fullfile(OutDir,casedir);
        if ~exist(OutCaseDir,'dir'), mkdir(OutCaseDir); end
        nIm = size(listim,1);
        for iIm = 1:nIm
            imname = deblank2(listim(iIm,:));
            Image = fullfile(casedirwithpath,imname);
            [im,hdG] = ResizeImage(Image,ResolutionWanted);
            [imrootname ext] = RemoveExtensionFromImageName(imname);
            newname = [imrootname sprintf('RES%s',ResString) ext];
            io_WriteMedicalImage(fullfile(OutCaseDir,newname),im,hdG);
        end        
    end
end


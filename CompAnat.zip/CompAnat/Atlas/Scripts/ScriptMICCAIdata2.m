% Script to prepare the MICCAI data
%
% First attempt assuming that dicom headers were going to be enough to sort
% the data.
%
% Second attempt with pre-sorting dicom files in different folders
% accordingly to the series name


bCreateTempData = 1;

Root = 'F:\Atlas\MICCAI09 Challenge\DataFromToronto\';
OutDir = 'F:\Atlas\MICCAI09 Challenge\AtlasData';
TempDir = 'F:\Atlas\MICCAI09 Challenge\SortedDicoms';

if ~exist(TempDir,'dir'), mkdir(TempDir); end

for iBatch = 1:2
    switch iBatch
        case 1
            DICOMroot = [Root 'challenge_online'];
            CONTOroot = [Root 'Sunnybrook Cardiac MR Database ContoursPart1\OnlineDataContours'];
        case 2
            DICOMroot = [Root 'challenge_validation'];            
            CONTOroot = [Root 'Sunnybrook Cardiac MR Database ContoursPart2\ValidationDataContours'];
        case 3
            DICOMroot = [Root 'challenge_training'];
            CONTOroot = [Root 'Sunnybrook Cardiac MR Database ContoursPart3\TrainingDataContours'];
    end
    
    ListDirCont = dir(CONTOroot);
    ListDirDICO = dir(DICOMroot);
    % Get the contour files
    for iC = 3:numel(ListDirCont);
        DirName = ListDirCont(iC).name;
        DirC = fullfile(CONTOroot,DirName,'contours-manual','IRCCI-expert');
        % Get the dicom dir of this subject:
        bFound = 0;
        for iD = 3:numel(ListDirDICO)
            DICn = ListDirDICO(iD).name;
            if strcmp(DirName,DICn)
                bFound = 1;
                DICOMdir = fullfile(DICOMroot,DICn);
            end
        end
        if ~bFound
            fprintf('ERROR! no dicom dir found for %s\n',DirName);
        else        
            CaseDir = fullfile(OutDir, DirName);
            if ~exist(CaseDir,'dir'), mkdir(CaseDir); end
            
            if(0)
                % Get the DICOM information:
                matlabDicomDir = fullfile(CaseDir,'SAstackDICOMDIR.mat');
                if ~exist(matlabDicomDir,'file')
                    fprintf(' Sorting DCM folder: %s\n',DICOMdir);
                    S = sortDCMfiles(DICOMdir);
                    save(matlabDicomDir,'S');
                else
                    load(matlabDicomDir);
                end
            else
                clear 'Group';
                % get the list of files, and create sub-folders
                ListFiles = dir(DICOMdir);
                iGroup = 1;
                Name = ListFiles(3).name;
                Ir = strfind(Name,'IM-');                    
                Group{1}.RootName = Name(Ir+3:Ir+6);
                Group{1}.Files = 3;
                for iFile = 4:numel(ListFiles)
                    Name = ListFiles(iFile).name;
                    Ir = strfind(Name,'IM-');
                    RootN = Name(Ir+3:Ir+6);
                    % Check if it exists:
                    bExist = 0;
                    for iG = 1:numel(Group)
                        if strcmp(Group{iG}.RootName , RootN)
                            bExist = 1;  
                            iGroup = iG;
                        end
                    end
                    if ~bExist
                        % new group
                        Group{iG+1}.RootName = RootN;
                        Group{iG+1}.Files = iFile;
                    else
                        Group{iGroup}.Files = [Group{iGroup}.Files iFile];
                    end
                end
                for iG = 1:numel(Group)
                    SeriesName = Group{iG}.RootName;
                    SeriesDir = fullfile(TempDir,DirName,SeriesName);
                    if ~exist(SeriesDir,'dir'), mkdir(SeriesDir); end;
                    nF = numel(Group{iG}.Files);
                    Group{iG}.Directory = SeriesDir;
                    if (bCreateTempData)
                        fprintf('Copying %i files into %s\n',nF,SeriesDir);
                        for iF = 1:nF
                            iF2copy = Group{iG}.Files(iF);
                            file2copy = ListFiles(iF2copy).name;  
                            if ~exist(fullfile(SeriesDir,file2copy),'file')
                                copyfile(fullfile(DICOMdir,file2copy),fullfile(SeriesDir,file2copy));
                            end
                        end
                    end
                end
            end
                    % 
        % Get the names of the matching files:
            ListContFiles = dir(DirC);     
            Icons = [];  % I contours are inner contours
            Ocons = [];  % O contours are outer contours, contours that segment the epicardium
            for icont = 3:numel(ListContFiles)
                % in each contour file, capture the name:
                ConName = ListContFiles(icont).name;
                seriesID = sscanf(ConName(4:7),'%i');
                phase = sscanf(ConName(9:12),'%f'); 
                if numel(phase)>1, 
                    phase = phase(2) + phase(1)*10; 
                end
                phases{icont} = ConName(9:12);
                NumPha(icont) = phase;
                Type = ConName(14:17);
                switch Type
                    case 'icon'
                        Icons = [Icons icont];
                    case 'ocon'
                        Ocons = [Ocons icont];
                end
            end
            
        % Now we will try to identify the sequence corresponding to the
        % contours, with two criteriaL
        % - it has enough dicom files
        % - it has enough time points
            nFilesTh = max(NumPha);
            % Contours are in peak diastole and peak systole:
            nSlicesTh = max(numel(Icons),numel(Ocons))/2;
            
            % Now find the group within this orientation that has enough files:
            bValidGroup = zeros(1,numel(Group));
            for igr = 1:iG
                nF = numel(Group{igr}.Files);
                if nF >= nFilesTh
                    bValidGroup(igr) = 1;
                else
                    bValidGroup(igr) = 0;
                end
            end
            
            iValid = find(bValidGroup);
            if numel(iValid) == 0
                fprintf('=================================================\n');
                fprintf('  no series found with enough files (need %i)\n',nFilesTh);
                fprintf('=================================================\n');
                fprintf('%s\n',ListContFiles.name);
            else
                %% 
                if numel(iValid)>1
                    bValid2 = zeros(1,numel(iValid));
                    % Sort the dicom folders:                
                    for ig = 1:numel(iValid)
                        iGroup = iValid(ig);
                        DICOMdir = Group{iGroup}.Directory;
                        matlabDicomDir = fullfile(CaseDir,sprintf('DICOMDIR-Group%02i.mat',iGroup));
                        if ~exist(matlabDicomDir,'file')
                            fprintf(' Sorting DCM folder: %s\n',DICOMdir);
                            S = sortDCMfiles(DICOMdir);
                            save(matlabDicomDir,'S');
                        else
                            load(matlabDicomDir);
                        end
                        [nFiles, nSlices, nTimes] = ExtractSliceBasicInfo(S);
                        % Now find the orientation that has enough files:
                        I1 = find( nFiles >= nFilesTh );
                        % That has enough slices:
                        I2 = find( nSlices >= nSlicesTh );
                        % And that has at least 10 time points:
                        I3 = find( nTimes > 10 );

                        I = intersect(I1,I2);
                        I = intersect(I,I3);
                        if numel(I)>0
                            % THere is a valid orientation within this
                            % structure
                            bValid2(ig) = 1;
                        else
                            bValid2(ig) = 0;
                        end
                    end

                    % Define the valid series:
                    iValid = iValid(find(bValid2));

                    %%
                    if numel(iValid) > 1
                        % Get the name of the series:
                        bValid3 = zeros(1,numel(iValid));
                        for ig = 1:numel(iValid)
                            iGroup = iValid(ig);
                            DICOMdir = Group{iGroup}.Directory;
                            matlabDicomDir = fullfile(CaseDir,sprintf('DICOMDIR-Group%02i.mat',iGroup));
                            if ~exist(matlabDicomDir,'file')
                                fprintf(' Sorting DCM folder: %s\n',DICOMdir);
                                S = sortDCMfiles(DICOMdir);
                                save(matlabDicomDir,'S');
                            else
                                load(matlabDicomDir);
                            end
                            SD = S.Patient_01.Study_01.Serie_01.INFO.ScanningSequence;
                            if strcmp(SD,'RM')
                                bValid3(ig) = 1;
                            else
                                bValid3(ig) = 0;
                            end

                        end
                        %%
                        if numel(find(bValid3))>0
                            % Define the valid series:
                            iValid = iValid(find(bValid3));
                        else
                            % Another criteria, search the SA, not LA:
                            bValid4 = zeros(1,numel(iValid));
                            for ig = 1:numel(iValid)
                                iGroup = iValid(ig);
                                DICOMdir = Group{iGroup}.Directory;
                                matlabDicomDir = fullfile(CaseDir,sprintf('DICOMDIR-Group%02i.mat',iGroup));
                                if ~exist(matlabDicomDir,'file')
                                    fprintf(' Sorting DCM folder: %s\n',DICOMdir);
                                    S = sortDCMfiles(DICOMdir);
                                    save(matlabDicomDir,'S');
                                else
                                    load(matlabDicomDir);
                                end
                                V = S.Patient_01.Study_01.Serie_01.Orientation_01.INFO.ImageOrientationPatient;
                                v1 = V(1:3);
                                v2 = V(4:6);
                                if abs(dot(v1,[1 0 0]))<0.5
                                    bValid4(ig) = 1;
                                else
                                    bValid4(ig) = 0;
                                end
                            end
                            if numel(find(bValid4))>0
                                iValid = iValid(find(bValid4));
                            else
                                fprintf('ERROR! no criteria found to identify the correct sequence!\n')
                            end
                        end
                    end
                end
                
                % hard coded solution for conflictive cases:
                switch DirName
                    case 'SC-HYP-01', iValid = 6;
                    case 'SC-HYP-03', iValid = 5;
                    case 'SC-HYP-08', iValid = 12;
                    case 'SC-HYP-09', iValid = 3;
                    case 'SC-HYP-11', iValid = 3;
                    case 'SC-HYP-37', iValid = 6;
                    case 'SC-HYP-38', iValid = 7;
                    case 'SC-HYP-40', iValid = 7;
                    case 'SC-N-07', iValid = 6;
                    case 'SC-N-09', iValid = 5;
                    case 'SC-N-10', iValid = 12;
                    case 'SC-HF-I-02', iValid = 3;
                    % After Rudra's feedback:
                    case 'SC-HF-I-10', iValid = 4;
                    case 'SC-HF-NI-04', % SC-HF-NI-4: 0501 better than 0506 
                        iValid = 3;
                    case 'SC-N-02', % SC-N-2: 0898 has more clear slices than 0902� agree!
                         iValid = 10;
                    case 'SC-HF-I-11', % SC-HF-I-11 : 0043 looks better than 0047
                        iValid = 3;
                    case 'SC-HYP-10', % SC-HYP-10  : 0579 image is darker but better than 0592� agree!
                        iValid = 3;
                    case 'SC-N-11', % SC-N-11: 0878 both are bad but slightly better contrast than 0882
                        iValid = 8;
                    case 'SC-HF-I-07', % SC-HF-I-7   : 0209 slightly better than 0217�
                        iValid = 4;
                end

                if numel(iValid)==1
                    % This is the valid series:
                    DICOMdir = Group{iValid}.Directory;
                    iFiles = Group{iValid}.Files;
                    ListDicomFiles = {ListFiles(iFiles).name};

                    % Get the list of DICOM files:
                    RootName = ListDicomFiles{1};
                    RootName = RootName(1:8);
                    UniquePhases = unique(NumPha);
                    fprintf('Phases to copy: '); fprintf('%i, ',UniquePhases); fprintf('\n');
                    for iph = 2:numel(UniquePhases) % First two phases are 0
                        % find the matching file per each txt with contours:
                        phase2find = UniquePhases(iph);
                        string2find = sprintf('%04i',phase2find);
                        File = cell2mat(ListDicomFiles( strncmp([RootName string2find], ListDicomFiles , 12)));
                        % Even and odd frames in different folders:
                        if rem(iph,2)==0
                            DestinyDir = fullfile(CaseDir,'DICOMdataPhase1');
                        else
                            DestinyDir = fullfile(CaseDir,'DICOMdataPhase2');
                        end
                        if ~exist(DestinyDir), mkdir(DestinyDir); end
                        % Delete the previous files
                        if iph==2 || iph == 3
                            delete(fullfile(DestinyDir,'*'));
                        end
                        fprintf('Copying %s\n   into %s\n',File,DestinyDir);
                        if ~exist(fullfile(DestinyDir,File),'file')
                            copyfile(fullfile(DICOMdir,File),DestinyDir);  
                        end
                    end
                else
                    fprintf('*******************************************\n')
                    fprintf('Not a unique choice of a valid sequence:\n')
                    for iV = 1:numel(iValid)
                        fprintf(' Opt%i: %s\n',iV,Group{iValid(iV)}.Directory);
                    end
                    fprintf('*******************************************\n')
                end
            end
            clear 'S' 'Group' 'phases' 'NumPha';
        end
    end
end





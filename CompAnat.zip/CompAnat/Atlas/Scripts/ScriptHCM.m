%% Script to evaluate the pICP improvements over heartgen

% In each folder we will have
% 1. GIPL with the binary segmentation from the SA after alignment
% 2. MeshingXXX, a collection of folders containing each of them a computational mesh fitted to (1), 
%each with different Meshing options

clear

%% Parameters for experiment's protocol set-up 
%Parameters start with the letter b. They are all initialised here, and
%some of them are overwriten by the specific study protocol (studyID)

%Set bBuildMeshes=1 if the there are no meshes and they need to be
%computed. Otherwise the script will load them.
bBuildMeshes = 0;
%If bPermutation=0 then no perturbation is introduced in the meshes.
bPermutation = 1;
%If bMakePCA=0 it means that the PCA coefficients have already been
%computed and the script needs to load them.
bMakePCA = 0;
%Set bSelectOrigMesh=0 to include all the permuted meshes in the build up of the atlas
%Set  bSelectOrigMesh=1, if you want the atlas to be buil only using the
%original meshes
bSelectOrigMesh = 0; 
%Computing the PCA coefficients for each of the meshes.
bComputeCoeffs = 0; %This was 0 as set by Pablo


%% Permutation-specific parameters
%Two parameters are required. The first, MaxGradientDist, allows to
%discriminate between reliable and un-reliable pixels. Only the latter will
% be affected by the perturbation.
%The second parameter, PertMagnitude, defines by how many pixels an
%unreliable pixel is moved in a perturbation of the mesh

%MaxGradientDist = [0.5 2];
%PertMagnitude = [0.1, 0.2, 0.3]; % First parameters run by SHan

%% Machine and study protocol details
%Below you need to tell the script on which machine the experiment is being
%run (this will change some basic settings) and which study protocol
machine = 'VavaDesktop'; 
studyID = 3;
switch machine    
    case 'PabloDesktop'
        RootDir = 'C:\Data\data\HCM\';
    case 'Bioeng073'
        RootDir = 'C:\Data\HCM\';
    case 'ShanDesktop'
        RootDir = 'C:\Users\shg17\postdoc\Data\HCM\PermutedMeshes';
        RootDir = 'C:\Users\shg17\postdoc\Data\HCM\ErnestoAlignedImageContour\';
        % RootDir = 'C:\Users\shg17\postdoc\tryHCMDataAnalysis\ForTesting\Data\HCM';
        % RootDir = 'C:\Users\shg17\postdoc\Data\HCM\';  
    case 'VavaDesktop'
        %This is the same machine as Shan 'bioen050-pc', this is just to
        %mark the start of Valentina's efforts
        
        addpath(genpath('C:\Users\vc18\KCL_material\CardiacAtlasCode\computationalcardiacanatomy'));
        %Uncomment the following to run protocol on a small sample. At the
        %moment only 5 cases
        %RootDir = 'C:\Users\vc18\KCL_material\Data\HCM\SmallSample\';
        %Uncomment the following to run protocol on the full dataset from
        %Rina. TODO, add reference to dataset details
        %RootDir = 'C:\Users\vc18\KCL_material\Data\HCM\ErnestoAlignedImageContour_study3 - Copy\';
end



switch studyID
    case 1
        LoDchosen = 1;
        DirAtlas = fullfile(RootDir,'AtlasHCM');
        excelfile = [DirAtlas '\info_orig103cases.xls'];
    case 2
        RootDir = 'C:\Users\shg17\postdoc\Data\HCM\JointAtlasHCM';
        LoDchosen = 6;  % PL: this does not exist?!
        DirAtlas= fullfile(RootDir);
        excelfile = [DirAtlas '\infocases_groupByLoD.xls'];
    case 3
        % where Valentina kicks off
        LoDchosen = 1;
        %LoDchosen= [1:5];
        MaxGradientDist = [0.5 0.8];
        PertMagnitude = [10, 50];
        %RootDir = 'C:\Users\vc18\KCL_material\Data\HCM\Study3_Copy\';
        %RootDir = 'C:\Users\vc18\KCL_material\Data\HCM\SmallSample\';
        %DirAtlas = fullfile(RootDir,'AtlasHCM');
        
        %in the case of VerySmallsample use the following
        RootDir = 'C:\Users\vc18\KCL_material\Data\HCM\VerySmallSample\';
        DirAtlas=RootDir; %this is for VerySmallSample
        %excelfile = [DirAtlas '\info_orig103cases.xls'];
        % Time estimation: 100 cases x 5 LoDs x 6 permuations per case x 6
        % min = 12 days!
end

% Directory with the raw GIPL data, full path to the data depends on the
% machine and study details
DirBins = fullfile(RootDir,'Data','GIPLs');
DirDataAtlas = fullfile(DirAtlas,'AtlasData');

%% Core of the experiment
%- Build folder tree if not in place already
%- Instantiate the AtlasClass (core class of experiment)
%- Build Meshes (if bBuildMshes=1)
%- MakePCA (if bMakePCA=1)
%- Compute PCA coefficients (if bComputeCoeffs=1)



if(0)
    fprintf('\n\n*** Build folder tree AtlasData and AtlasMeshData ***\n\n');
    % Build the structure of folders in DirDataAtlas, one per image in
    % DirBins:
    listfiles = dir(DirBins);
    for iF = 3:numel(listfiles)
        file = listfiles(iF).name;
        [nameHeart formatHeartFile bImage] = RemoveExtensionFromImageName(file);
        if bImage
            % Check directory does not exist yet:
            CaseDir = fullfile(DirDataAtlas,nameHeart);
            if ~exist(CaseDir,'dir')
                mkdir(CaseDir);
            end
            copyfile(fullfile(DirBins,file),fullfile(CaseDir,file));
        end
    end
end

fprintf('\n\n*** Instantiate the AtlasClass (core class of experiment) ***\n\n');
Atlas = AtlasClass(DirAtlas);

% Build a standard heartgen mesh out of each case (baseline)
opt.MyoLabel = 1;
opt.RVpoolLabel = 2;
opt.nE = [8 12 1];
opt.topology = 'LVL';
opt.LVdir = [ 0 0 1 ]; %use only when the mesh is up-side-down
for LoD = LoDchosen
    disp(LoD)
    opt.LoD = LoD;
    opt.OutMeshingDir = sprintf('MeshingHG%i',opt.LoD);

    if(bBuildMeshes)
        if(bPermutation)
            opt2 = opt;
            opt2.PertDirec = [1, 2]; % 1(inwards) or 2(outwards),determine the reference convexhull
            opt2.MaxGradientDist = MaxGradientDist;   % mm of distance from contour to point of max gradient
            opt2.PertMagnitude = PertMagnitude;   % Percentate of the distance to the convex hull
            Atlas = Atlas.BuildMeshes(opt2);
        else
            Atlas = Atlas.BuildMeshes(opt);
        end

        % save the mesh to 'AtlasMeshData' for PCA calculation, they are sorted by MeshID
        opt3.DirAtlas = DirAtlas;
        opt3.LoD = LoD;
        %TODO: FIX MESH SAVING method. this is where the meshes are saved. The code takes into
        %account the permuted meshes. 
        Atlas = Atlas.SaveMeshes_sortedbymeshID(opt3);
    end

    SP = 4;     % Shape space
    opt.iShapeSpace = SP;
    opt.KeyName = sprintf('HG%is%i',opt.LoD,SP);
    opt.OutputDirectory = sprintf('AtlasOutputHG%i',opt.LoD);
    opt.AtlasName = sprintf('Atlas%s.mat',opt.KeyName);

    if(bMakePCA)     
        opt.bSelectOrigMesh = bSelectOrigMesh;
        Atlas = Atlas.BuildPCA(opt);
    else
        Atlas = Atlas.LoadPCAaxis(opt);
    end
    if(bComputeCoeffs)
        tic
        optcoefs.bSelectOrigMesh = bSelectOrigMesh;
        %CALLING HelperCodeToIssue2
        %Temporary fix, to be removed asap
        run('C:\Users\vc18\KCL_material\CodingStuff\MatlabScripts\HelperCodeToIssue2.m')
        Atlas = Atlas.CalculatePCAcoefs(optcoefs);
        toc
    else
%Valentina           
% I tried this with bComputeCoeffs=0, but of course it cannot find the coeffs
%if I never compute them
%             try
%                 Atlas = Atlas.LoadPCAcoefs();
%             catch
%                 tmp='C:\Users\vc18\KCL_material\Data\HCM\SmallSample\AtlasHCM\AtlasOutputHG1rv\AtlasHG1s4.mat';
%                 Atlas= Atlas.LoadPCAcoefs(tmp);
%             end
%%%%%%%%%%%%%%%%%%%%%%%%%
%Pablo: the commented code needs to be replaced by better feedback to screen to the use in the
%LoadPCAcoefs function when folder or file is not found or incorrect.
        Atlas = Atlas.LoadPCAcoefs();


    end
end



%% Set class label for all the patients
fprintf('\n\n*** Labelling of classes in the dataset using excelfile ***\n\n')
%Old code, previously it was required to create a new excelfile from the
%original one, containing the heath/disease labels for all of the permuted
%meshes
CreateExcelClassFile(Atlas.DataDirectory);
% excelfile = [DirAtlas '\infocases.xls'];

%Same as before, excelfile contains health/disease labels for all the
%orginal meshs
excelfile = [DirAtlas '\info_orig103cases.xls'];

%Assign parameters defined at the beginning of the script
optionsloadClass.bSelectOrigMesh = bSelectOrigMesh;
optionsloadClass.bPermutation =  bPermutation;
Atlas =  Atlas.SetClass(excelfile,4,optionsloadClass);

%% view Box Plot
%this section works
%What am I looking at here?



% Atlas.ViewAllMeshes
Atlas.ViewBoxPlots
% Atlas.ViewMeshID(3649100)


%Output is:
% A total of 98 cases were identified (ID from end of name) from C:\Users\vc18\KCL_material\Data\HCM\Study3_Copy\AtlasHCM\AtlasData
% Loading PCA coordinates from C:\Users\vc18\KCL_material\Data\HCM\Study3_Copy\AtlasHCM\AtlasOutputHG1rv\Coordinates.mat
%  There are 4410 valid coefficients (out of 4410 possible cases)
% Distribution of eigenvalue 1 had 4410 valid samples: (-9.040 +/- 128.376) - Variance = 54.910
% Distribution of eigenvalue 2 had 4410 valid samples: (6.504 +/- 36.614) - Variance = 32.919
% Distribution of eigenvalue 3 had 4410 valid samples: (-7.580 +/- 34.492) - Variance = 28.693
% Printing figure to C:\Users\vc18\KCL_material\Data\HCM\Study3_Copy\AtlasHCM\AtlasOutputHG1rv\ModalBoxPlots_HG1s4_s4_c4_M123.png

%% Calculate Mahalanobis distance
% generate features
PCAcoef = struct(Atlas.PCAcoefs);
features = PCAcoef.coefficients;

if(bSelectOrigMesh)
    [IdxOrigCases , ~] = Atlas.GetIdxNoPermutations();
    features = features(:,IdxOrigCases');
end

features = features';
NrCases = size(features,1);
NrFeatures = size(features,2);

% feature name list
featureNames = cell(NrFeatures,1);
for i_feat = 1:NrFeatures
    featureNames{i_feat} = ['PCA coefficient ' num2str(i_feat)];
end

% generate class label list
% % ------------------------ 2 classes ---------------------%
classlabels = zeros(NrCases,1);
for i_class = 1:2
    tmp = struct(Atlas.Class(i_class));
    classlabels(tmp.Indexes) = i_class;
end

lablist = char('Control','HCM');
classLabelsText = lablist(classlabels,:);

% --------------------- 3 classes -------------------------%
% classlabels = zeros(NrCases,1);
% for i_class = 1:3
%     tmp = struct(Atlas.Class(i_class));
%     classlabels(tmp.Indexes) = i_class;
% end
% 
% lablist = char('Control','HCMnegative','HCMpositive');
% classLabelsText = lablist(classlabels,:);
% ---------------------------------------------------------%

% generate PRTools dataset
% cd 'C:\Users\shg17\ShanGao\PRTools New\prtools'
ds = dataset(features,classLabelsText,'FEATLAB',char(featureNames));

% extract Index for original meshes(without permutation)
ListMeshes = dir(DirDataAtlas);
ListMeshes(1:2) = [];
IdxOrigMesh = [];
for iMesh = 1:size(ListMeshes,1)
    MeshID = ListMeshes(iMesh).name;
    [PatID, LoDID, PermID] = MeshIDExplanation(MeshID);
    if strcmp(PermID ,'00')
        IdxOrigMesh = [IdxOrigMesh; iMesh]; %#ok<AGROW>
    end
end

% select features
for iC = 2:50  %50 or 100
    ds_featSelected = ds(:,[1:iC]);  % all meshes (include permuted ones)
%     ds_featSelected = ds(IdxOrigMesh,[1:iC]);    % only original meshes (no permutation)
    
    % calculate inter-class Mahalanobis distance
    Metrics = distmaha(ds_featSelected);
    ControlvsHCMpostive(iC) = Metrics(1,3);
end
colourchoice = 'rgbcm';
figure,plot(ControlvsHCMpostive,colourchoice(LoD));
% hold on;

title('Use All Meshes based on contour permutations (ErnestoNewData,LoD=1)')
% title('Use Only Meshes based on Original manual contour (ErnestoNewData,LoD=1)')
xlabel('PCA mode');
ylabel('Mahalanobis distance');
ylim([0 45]);


%Average wall thickness for each mesh(?)
%Old code, Pablo did not compute all thickness values when testing the
%code, why?
% CreateExcelClassFile(Atlas.DataDirectory);
% excelfile = [DirAtlas '\infocases.xls'];
% Atlas =  Atlas.SetClass(excelfile,4,optionsloadClass);

Atlas.ComputeThicknesses(opt)

%% calculate Mahalanobis distance
% classlabels = zeros(NrCases,1);
% for i_class = 1:2
%     tmp = struct(Atlas.Class(i_class));
%     classlabels(tmp.Indexes) = i_class;
% end
%
% lablist = char('Control','HCM');
% classLabelsText = lablist(classlabels,:);
% --------------------- 3 classes -------------------------%
classlabels = zeros(NrCases,1);
for i_class = 1:3
    tmp = struct(Atlas.Class(i_class));
    classlabels(tmp.Indexes) = i_class;
end

lablist = char('Control','HCMnegative','HCMpositive');
classLabelsText = lablist(classlabels,:);
% ---------------------------------------------------------%

% generate PRTools dataset
% cd 'C:\Users\shg17\ShanGao\PRTools New\prtools'
ds = dataset(features,classLabelsText,'FEATLAB',char(featureNames));
% extract Index for original meshes(without permutation)
ListMeshes = dir(DirDataAtlas);
ListMeshes(1:2) = [];
IdxOrigMesh = [];
for iMesh = 1:size(ListMeshes,1)
    MeshID = ListMeshes(iMesh).name;
    [PatID, LoDID, PermID] = MeshIDExplanation(MeshID);
    display(PatID);display(LoDID); display(PermID);
    if strcmp(PermID ,'00')
        IdxOrigMesh = [IdxOrigMesh; iMesh]; %#ok<AGROW>
    end
end

% select features
for iC = 2:50  %50 or 100
    ds_featSelected = ds(:,[1:iC]);  % all meshes (include permuted ones)
%     ds_featSelected = ds(IdxOrigMesh,[1:iC]);    % only original meshes (no permutation)
    
    % calculate inter-class Mahalanobis distance
    Metrics = distmaha(ds_featSelected);
    ControlvsHCMpostive(iC) = Metrics(1,3);
end
colourchoice = 'rgbcm';
figure,plot(ControlvsHCMpostive,colourchoice(LoD));
% hold on;

title('Use All Meshes based on contour permutations (ErnestoNewData,LoD=1)')
% title('Use Only Meshes based on Original manual contour (ErnestoNewData,LoD=1)')
xlabel('PCA mode');
ylabel('Mahalanobis distance');
ylim([0 45]);

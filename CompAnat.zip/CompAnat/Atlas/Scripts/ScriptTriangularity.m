% Script to  process all Bisbal cases:

% File with the mesh topology:
meshname = 'F:\Atlas\Atria\Bisbal13\BisbalMeshes\Mean24mo';
template = CubicMeshClass(meshname);

% File with the dofs of the 144 meshes: load the variable 'DofsInLine'
load('F:\Atlas\Atria\Bisbal13\BisbalMeshes\dofs.mat');
dofsin = DofsInLine;

nMeshs = size(dofsin,1);
scores = NaN * ones(1,nMeshs);

%% Compute the metric for extrem cases:
SC(1) = ComputeTriangularity(CHmean12);
SC(2)  = ComputeTriangularity(CHRec12);
SC(3)  = ComputeTriangularity(CHNonRec12);

%%
for iM = 1:nMeshs
    % Update the dofs of the template accordingly to this case
    template = template.SetDofs(dofsin(iM,:));
    scores(iM) = ComputeTriangularity(template);
end

%% Visualise histogram
figure('color',[1 1 1]); 
hist(scores,50); 
title('Histogram of triangularity in 144 cases');

hold on;
colors = 'rgc';
for iSC = 1:numel(SC)
    plot(SC(iSC),0,[colors(iSC) 's'],'MarkerFaceColor',colors(iSC));
end

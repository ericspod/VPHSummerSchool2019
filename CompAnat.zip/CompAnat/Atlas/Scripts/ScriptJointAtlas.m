% Script to build the joing atlas between two segmentations

bOneCaseOnly = 1;

AtlasRoot1 = 'F:\Atlas\CRT\Complete50b';
AtlasRoot2 = 'F:\Atlas\CRT\Lamata50b';

% Aggregate the 100 case from the two segmentations:
bAggregated = 0;
JointAtlas = 'F:\Atlas\CRT\LamGon50b';
DataDirJ = fullfile(JointAtlas,'AtlasData');
if ~exist(DataDirJ,'dir'), mkdir(DataDirJ); end

% Bring the 50 average shapes from 2 observers
bAveraged = 1;
    bCopyImage = 0;
AverageShapesAtlas = 'F:\Atlas\CRT\Ave50bPCA50';
DataDirA = fullfile(AverageShapesAtlas,'AtlasData');
if ~exist(DataDirJ,'dir'), mkdir(DataDirA); end

% Visualise the meshes:
bVisualiseAveragedAndInstances = 1;

%%
iMesh = 0;
for iSeg = 1:2
    switch iSeg
        case 1, DD = fullfile(AtlasRoot1,'AtlasData');
        case 2, DD = fullfile(AtlasRoot2,'AtlasData');
    end
    cases = dir(DD);
    %for iC = 3:numel(cases)
    for iC = 30:30 %3:numel(cases)
        CaseDir = fullfile(DD,cases(iC).name);
        CaseName = cases(iC).name;
        % Get ID from name:
        CaseNumber = sscanf(CaseName,'%i');
        if isempty(CaseNumber)
            % Hack for names "KCL###"
            CaseNumber = sscanf(CaseName(4:end),'%d');
            if numel(CaseNumber)>1
                switch numel(CaseNumber)
                    case 2, CaseNumber = 10*CaseNumber(1) + CaseNumber(2);
                    case 3, CaseNumber = 100*CaseNumber(1) + 10*CaseNumber(2) + CaseNumber(3);
                end
            end
        end
        
        % The original binary (use for naming purposes):
        bin = ls([CaseDir '\*.gipl']);
        if(bAggregated)
            NewFolderName = sprintf('%i%03i',iSeg,CaseNumber);
            DestDir = fullfile(DataDirJ,NewFolderName);
            if ~exist(DestDir,'dir'), mkdir(DestDir); end
            fprintf('Coping data to %s\n',DestDir);
            copyfile(fullfile(CaseDir,bin),DestDir);
        end
        if(bAveraged)
            if(bCopyImage)
                NewFolderName = sprintf('Ave%03i',CaseNumber);
                DestDir = fullfile(DataDirA,NewFolderName);
                if ~exist(DestDir,'dir'), mkdir(DestDir); end
                [name,extension] = RemoveExtensionFromImageName(bin);
                fprintf('Coping data to %s\n',DestDir);
                delete(fullfile(DestDir,bin))
                copyfile(fullfile(CaseDir,bin),fullfile(DestDir,sprintf('%s.%s',NewFolderName,extension)));
            end
        end
        
        % Now the meshes:
        MeshRoot = fullfile(CaseDir,'Output_heartgen');
        EXnode = ls([MeshRoot '\*_mesh.exnode']);
        EXelem = ls([MeshRoot '\*_mesh.exelem']);
        if(bAggregated)
            MeshDest = fullfile(DestDir,'Output_heartgen');
            if ~exist(MeshDest,'dir'), mkdir(MeshDest); end
            copyfile(fullfile(MeshRoot,EXnode),MeshDest);
            copyfile(fullfile(MeshRoot,EXelem),MeshDest);
        end
        if(bAveraged)
            iMesh = iMesh + 1;
            % Load the dofs:
            CHmesh = CubicMeshClass(fullfile(MeshRoot,EXnode),fullfile(MeshRoot,EXelem));
            data(iMesh).dofs = CHmesh.GetDofs(); 
            data(iMesh).CaseNumber = CaseNumber;             
        end
    end
end

%% 
if(bAveraged)
    if (bOneCaseOnly)
        cases2 = [data(2).CaseNumber];
        nCases = 1;
    else
        cases2 = [data(51:100).CaseNumber];
        nCases = 50;
    end
    loopcases = 1:nCases;
    for iCase = loopcases
        dofs1 = data(iCase).dofs;
        CaseID = data(iCase).CaseNumber;
        i2 = find(cases2 == CaseID);
        dofs2 = data(nCases+i2).dofs;
        meandofs = (dofs1 + dofs2)/2;
        CHmesh = CHmesh.SetDofs(meandofs);
        CHmesh = CHmesh.SetName(sprintf('Ave%03i_mesh',CaseID));
        NewFolderName = sprintf('Ave%03i',CaseID);
        DestDir = fullfile(DataDirA,NewFolderName);
        if ~exist(DestDir,'dir'), mkdir(DestDir); end
        MeshDest = fullfile(DestDir,'Output_heartgen');
        if ~exist(MeshDest,'dir'), mkdir(MeshDest); end
        CHmesh.WriteExFiles(MeshDest);        
    end
end

%%

viewoptioni = 1;
if(bVisualiseAveragedAndInstances)
    % List the cases of the average atlas:    
    cases = dir(DataDirA);
    for iC = 42:42 %:numel(cases)
        [ID] = GetIDfromName(cases(iC).name);
        Mesh0 = GetMeshFromID(DataDirA,ID);

        % Get the first mesh:
        DD = fullfile(AtlasRoot1,'AtlasData');
        Mesh1 = GetMeshFromID(DD,ID);
            
        % Get the second mesh:
        DD = fullfile(AtlasRoot2,'AtlasData');
        Mesh2 = GetMeshFromID(DD,ID);
            
        switch viewoptioni
            case 1
                opt.CH2 = Mesh2;
                opt.bOrthographic = 1;
                opt.bAutomaticExit = 0;
                opt.CaptionName = sprintf('OverlayOnlyInstances%03i',ID);
                cmGuiViewMesh(Mesh1,[],opt);
            case 2
                opt.CH2 = Mesh1;
                opt.CH3 = Mesh2;
                opt.bOrthographic = 1;
                opt.bAutomaticExit = 1;
                opt.CaptionName = sprintf('OverlayInstances%i',ID);
                cmGuiViewMesh(Mesh0,[],opt);
        end
    end
end
            
        
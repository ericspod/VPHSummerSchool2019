% Script to visualise the modes from Marta Varela

% load the mat:
bLoadMatFile = 0;

% There will be some informations saved in disk: choose a temp diretory
% here:
WorkDir = 'F:\Atlas\Atria\Visualization Modes Marta\';

% The data provided by Marta
matfile = 'F:\Atlas\Atria\Visualization Modes Marta\wsav.mat';
if bLoadMatFile, load(matfile); end

% Choice of the visualization to use:
iVisualization = 1;
switch iVisualization
    case 1
        mesh1 = CHmean;
        mesh2 = CHmean12;
        
end

% Need to save the meshes of interst in the local drive, in order to tell
% cmGui where the data is:
mesh1.WriteExFiles(WorkDir);
mesh2.WriteExFiles(WorkDir);

% Specify the second mesh:
viewoptions.CH2 = mesh2.name;

% call the visualization:
cmGuiViewMesh(WorkDir,mesh1,viewoptions);
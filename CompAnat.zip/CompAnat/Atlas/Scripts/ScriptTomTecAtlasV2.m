% Script to try to build meshes out of 3 SA and 2 LA contours.

RootDir = 'F:\Atlas\Infarct Schuster\10_cases\';

ListCases = dir(RootDir);
for iC = 3:numel(ListCases);
    CaseDir = fullfile(RootDir,ListCases(iC).name);
    % Read the TomTecData
    Contours = io_ReadTomTecContours(CaseDir);
    
    % Create a binary image
    
    % Build a mesh
    
end
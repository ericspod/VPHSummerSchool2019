clear; 

ColourChoice = 1;
OutName = 'AtlasOutput';

%==========================================================================
Version = 3;
Root = 'F:\HCM\Madrid echo';
Root = 'C:\Data\Echo2D';
switch Version
    case 1
        AtlasRoot = fullfile(Root,'Data');
        % Naming conventions:
        options.RootName = 'WALL';
        options.bRootfirstIDafter = 0;
        options.chamberkeyword = '';
        options.bTomTecInput = 0;
        options.AtlasSurname = '3ch';
        
        options.ApicalCriteria = 'Closest2transductor';
        
        iStudy = 2;
        switch iStudy
            case 1
                options.iFrames2mesh = 'D';
                options.PostName{1} = 'FrameD';
                StudyString = 'D';
            case 2
                options.iFrames2mesh = 'S';
                options.PostName{2} = 'FrameS';
                StudyString = 'S';
        end
        % needed to correctly index the dof file to read!
        options.iCond = iStudy;
        options.iShapeSpace = 'R';
                
%        options.PostName = {'fu', 'birth'}; 
        options.RawDataDir = fullfile(Root,'2D shapes');
        ClinicalFile = 'clinicalfile.xlsx';
%        options.iCondition2analyse = 2;
        options.bSspace = 0;
        options.iChamber = 3;
%        options.bSimpleInputName = 1;
%        bReorderDirectory = 0;
%        options.bDebugDofSearch = 0;
        options.bRecalculateEigenCoords = 1;
        iComparison = 1; 
%        OutName = 'AtlasOutputSS';
%        options.bSkeleton = 1;
%        options.bRatioSkeleton = 1;
%        options.bScaleWithAllDofs = 1;
    case 2
        % 
        AtlasRoot = fullfile(Root,'Atlasv2');
        options.RootName = 'WALL';
        options.bRootfirstIDafter = 0;
        options.chamberkeyword = '';
        options.bTomTecInput = 0;
        options.AtlasSurname = '3ch';
        
        options.ApicalCriteria = 'Closest2transductor';
        
        iStudy = 1;
        switch iStudy
            case 1
                options.iFrames2mesh = 'D';
                options.PostName{1} = 'FrameD';
                WhichFrame = 'D';
            case 2
                options.iFrames2mesh = 'S';
                options.PostName{2} = 'FrameS';
                WhichFrame = 'S';
        end
        options.iCond = iStudy;
        options.iShapeSpace = 'R';
        
        comparisons = 1;
        StudyString = [ WhichFrame 'HCMvsCON' ];
        switch comparisons
            case 1 % in general, all controls vs. all HCMs
                optionsExcel.iColumnClass = 3;
            case 2 % Each HCM phenotype separately
                optionsExcel.iColumnClass = 2;
        end
                
        options.RawDataDir = fullfile(Root,'2Dshapesv2');
        % File with 
        % - Column 2: (1) HCM septal; (2) HCM apical; (3) Volunteer
        ClinicalFile = 'FinalCASE-CONTROLS_with_wallfile.xlsx';
        options.bSspace = 0;
        options.iChamber = 3;
        options.bRecalculateEigenCoords = 1;
        iComparison = 1; 
    case 3
        AtlasRoot = fullfile(Root,'Atlasv3');
        options.RootName = 'WALL';
        options.bRootfirstIDafter = 0;
        options.chamberkeyword = '';
        options.bTomTecInput = 0;
        options.AtlasSurname = '3ch';
        
        options.ApicalCriteria = 'Closest2transductor';
        
        iStudy = 2;
        switch iStudy
            case 1
                options.iFrames2mesh = 'D';
                options.PostName{1} = 'FrameD';
                WhichFrame = 'D';
            case 2
                options.iFrames2mesh = 'S';
                options.PostName{2} = 'FrameS';
                WhichFrame = 'S';
        end
        options.iCond = iStudy;
        options.iShapeSpace = 'R';
        
        comparisons = 1;
        StudyString = [ WhichFrame 'HCMvsCON' ];
        switch comparisons
            case 1 % in general, all controls vs. all HCMs
                optionsExcel.iColumnClass = 3;
                comparison2make = 0;
            case 2 % Each HCM phenotype separately
                optionsExcel.iColumnClass = 2;
                comparison2make = 1:3;
        end
                
        options.RawDataDir = fullfile(Root,'2019_2D Shapes');
        % File with 
        % - Column 2: (1) HCM septal; (2) HCM apical; (3) Volunteer
        ClinicalFile = '2019-Cases-Controls_PL.xlsx';
        options.bSspace = 0;
        options.iChamber = 3;
        options.bRecalculateEigenCoords = 1;
        iComparison = 1; 
        
end

options.KeyFileKind4Mapping = 'text';

% Build the "meshes":
options.bStep1EncodeContours    = 0;
    options.bEncodeContours     = 0;
% Make the PCA:
options.bStep2MakeStatistics    = 0;
% Visualise results:
options.bStep3visualiceResults  = 0;
options.bPlotVariancePerMode    = 0;
options.bMovieModalVariation    = 0;
options.bStep3_ViewEigenSpace   = 0; 
options.bStatisticalAnalysisByExcelFile = 0;
options.bViewAverageShapes      = 0;
%options.iCases                  = 1:10;
%    options.iCondition2analyse  = 2; % or 2 (birth)
bViewBoxPlots                   = 0;
bLDAs                           = 1;
bSaveExcel                      = 1;

%==========================================================================

DataDir = fullfile(AtlasRoot,'AtlasData');
OutputDirectory= fullfile(AtlasRoot,OutName);
if ~exist(OutputDirectory,'dir'), mkdir(OutputDirectory); end
options.OutName = OutName;
options.OutputDirectory = OutputDirectory;


if(options.bSspace)
    StudyString = [ StudyString 'SS'];
end
options.StudyString = StudyString;

if (~isempty(ClinicalFile)) && ~options.bStep1EncodeContours   
    [ClassDefinitionInfo,txt] = xlsread(fullfile(AtlasRoot ,ClinicalFile));
    %[ClassDefinitionInfo,txt] = xlsread('C:\Data\Pablo excel new.xlsx');     optionsExcel.iColumnClass = 9;
    optionsExcel.txt = txt;
    optionsExcel.bForceGetText = 1;    
    %optionsExcel.Study = AtlasVersion;
    [ClassDefinition,VectorClass,CaseMapping] = OrderExcelDataInClassStructure(ClassDefinitionInfo,DataDir,optionsExcel);
    % Make the classification based on the class provided, not by the
    % naming of files (fu vs. birth)
    % bPostNameAnalysis = 0;
    options.ClassDefinition = ClassDefinition;
end
    
AtlasFileName = CalculateUSAtlas(AtlasRoot,options);



    options.AtlasFileName = AtlasFileName;    
    [coefs,cases,~,ListCases] = GetEigenCoefficients(AtlasRoot,options);
    load(fullfile(AtlasRoot,OutName,options.AtlasFileName));
    options.OutputDirectory = fullfile(AtlasRoot,OutName);
    options.bPredictive = 1;
    options.classes2include = [1 2];
    
%%
if (bLDAs)
%     if(1)
%         options.bPredictive = 0;
%         options.classes2include = [1 3];
%          for iGM = 1:9
%              GM{iGM} = 2:iGM+2;
%          end
%          [AUCs,iSignifDif,Sensitivities,Specificities,LDAout,OptPoint] = AtlasLinearDiscriminantAnalysis(GM,coefs,ClassDefinition,ListCases,V,options);
%      end
    if(1)
        % to Find the LDA direction from HCM apical (1) to controls (3)        
        pThreshold = 0.01;
        options.bPredictive = 1;
        options.bPrintAllROCs = 0;
        options.bPrintROCs = 0;
        
        study = 'inclusive';
        
        for icomparison = comparison2make
            switch icomparison
                case 0, options.classes2include = [1 2]; compared = 'all HCM vs. control';%, comparisons = 1;
                case 1, options.classes2include = [1 3]; compared = 'basal HCM vs. control';
                case 2, options.classes2include = [2 3]; compared = 'apical HCM vs. control';
                case 3, options.classes2include = [1 2]; compared = 'basal vs. apical HCM'; % comparisons = 2;
            end
            clear GM;
            switch study
                case 'optimisedv1'
                    switch iStudy
                        case 1 % ED
                            switch icomparison
                                case 0, CoreMode = []; ModeRanking = [4 3 6 2 7];
                                case 1, CoreMode = []; ModeRanking = [3 4 2 6 9 10];%[3, 4, 9, 11];
                                case 2, CoreMode = []; ModeRanking = [4 5 7 8 6];
                                case 3, CoreMode = []; ModeRanking = [5 4 7 8 9 10 2 3] ; %1:10;%
                            end                    
                        case 2 % ES
                            switch icomparison
                                case 0, CoreMode = []; ModeRanking = [4 2 7 1 10 3];
                                case 1, CoreMode = []; ModeRanking = [2 4 10 3 5 1];%[3, 4, 9, 11];
                                case 2, CoreMode = []; ModeRanking = [4 7 1 8 3 5 6 9 10]; %1:10;% [4 7 1 8];
                                case 3, CoreMode = [ ]; ModeRanking = [4 7 2 5 9 1 10 8 6] ; %1:10;%
                            end    
                    end
                    
                    aggregation = 'gradual';
                    switch aggregation
                        case 'onestep'
                            for iGM = 1:numel(ModeRanking)
                                GM{iGM} = [CoreMode ModeRanking(iGM)];
                            end
                        case 'gradual'
                            for iGM = 1:numel(ModeRanking)
                                GM{iGM} = [CoreMode ModeRanking(1:iGM)];
                            end
                    end
                case 'optimisedv2'
                    switch iStudy
                        case 1 % ED
                            switch icomparison
                                case 0, CoreMode = []; ModeRanking = []; 
                                case 1, CoreMode = []; ModeRanking = []; 
                                case 2, CoreMode = []; ModeRanking = []; 
                                case 3, CoreMode = []; ModeRanking = [2 4 5];
                            end                    
                        case 2 % ES
                            switch icomparison
                                case 0, CoreMode = []; ModeRanking = [3 2]; 
                                case 1, CoreMode = []; ModeRanking = []; 
                                case 2, CoreMode = []; ModeRanking = [];                            
                                case 3, CoreMode = []; ModeRanking = [2 4 5];
                            end    
                    end
                    
                    aggregation = 'gradual';
                    switch aggregation
                        case 'onestep'
                            for iGM = 1:numel(ModeRanking)
                                GM{iGM} = [CoreMode ModeRanking(iGM)];
                            end
                        case 'gradual'
                            for iGM = 1:numel(ModeRanking)
                                GM{iGM} = [CoreMode ModeRanking(1:iGM)];
                            end
                    end
                case 'inclusive'
                    for iGM = 1:4
                        ioff = 0;
                        GM{iGM} = 1+ioff:iGM+ioff;
                    end
            end                
                
            options.bPredictive = 1;
            [crossAUCs,iSignifDif,Sensitivities,Specificities,LDAout,OptPoint] = AtlasLinearDiscriminantAnalysis(GM,coefs,ClassDefinition,ListCases,V,options);
            %options.nLeaveOut = 2;
            %[AUCsN2] = AtlasLinearDiscriminantAnalysis(GM,coefs,ClassDefinition,ListCases,V,options);
            options.bPredictive = 0;
            [resubAUCs,~,~,~] = AtlasLinearDiscriminantAnalysis(GM,coefs,ClassDefinition,ListCases,V,options);

                HsummaryPred = figure('color',[1 1 1]);
                nG = numel(GM);
                [hp,ha1,ha2] = plotyy(1:nG,resubAUCs,1:nG,log10(LDAout.Significances));
                set(ha1,'LineStyle','-.')
                hold on;
                %plot(1:nG,AUCsN2,'r');
                plot(1:nG,crossAUCs,'k');

                % plot limits of goodness:
                Lim1=ones(1,nG)*0.7;
                Lim2=log10(ones(1,nG)*pThreshold);
                [hpl,hl1,hl2] = plotyy(1:nG,Lim1,1:nG,Lim2);
                set(hl1,'LineStyle',':')
                set(hl2,'LineStyle',':')

                set(hp(1),'ylim',[0.5 1])
                set(hpl(1),'ylim',[0.5 1])
                set(hp(2),'ylim',[-10 0])
                set(hpl(2),'ylim',[-10 0])
                xlabel('LDA combining PCA modes from 1 to x'); 
                xlabel('Number of PCA modes used in the LDA'); 
                %ylabel('AUC: resub.(k), leave-1(b), leave-2(r)');
                %ylabel('AUC: resubstitution(k), cross-validation(b)');
                ylabel('AUC'); legend('resubstitution','cross-validation','location','NorthWest');               
                ylabel(hp(2),'log(p)');

                c1 = options.classes2include(1);
                c2 = options.classes2include(2);
                title(sprintf('AUC performance G%i vs G%i',c1,c2));
                FigName = fullfile(OutputDirectory,sprintf('PredictiveSummary_%ivs%i.png',c1,c2));
                export_fig(FigName,'-png','-m2',HsummaryPred);

            % visualise the result:
            iMax = find(crossAUCs == max(crossAUCs));
            GMopt = GM{iMax};
            options.bPredictive = 0;
            [AUCs,iSignifDif,Sensitivities,Specificities,optLDAout,OptPoint] = AtlasLinearDiscriminantAnalysis({GMopt},coefs,ClassDefinition,ListCases,V,options);
            optLDAout.MeanDofs = MeanDofs;
            options.bPlotSeparate = 0;
            % Add the AUC to be rendered
            optLDAout.AUC = crossAUCs(iMax);
            Hlda = PlotLDAspace(optLDAout,coefs,AtlasRoot,GMopt,options);
            FigName = fullfile(OutputDirectory,sprintf('LDA_%ivs%i.png',c1,c2));
            export_fig(FigName,'-png','-m2',Hlda);
            
            % Export the LDA coefficients
            LDAcoefs = optLDAout.w.'*coefs(GMopt,:);
            options.bPredictive = 1;
            [AUCs,iSignifDif,Sensitivities,Specificities,optLDAout,OptPoint] = AtlasLinearDiscriminantAnalysis({GMopt},coefs,ClassDefinition,ListCases,V,options);
            LDAcoefsLeave1 = optLDAout.PredictedScores;
            if (bSaveExcel)
                ExcelFile = fullfile(OutputDirectory, sprintf('LDA %s at E%s.xls',compared,WhichFrame));
                modescombined= sprintf('%i ',optLDAout.GM);
                LDAtitle = sprintf('LDAscore between %s at E%s, combining modes %s', compared, WhichFrame, modescombined);
                xlswrite(ExcelFile,{LDAtitle},1,'A1');
                xlswrite(ExcelFile,{'Case ID','Resubstitution','Leave-1'},1,'A2');
                xlswrite(ExcelFile,ListCases',1,'A3');
                xlswrite(ExcelFile,LDAcoefs',1,'B3');
                xlswrite(ExcelFile,LDAcoefsLeave1',1,'C3');
            end
        end
    end
    if(0)
        options.bPredictive = 0;
        if(0)
            options.classes2include = [1 2];
            GM = 1;
        else
            options.classes2include = [3 4];
            GM = 1:9;
        end
        [AUCs,iSignifDif,Sensitivities,Specificities,LDAout,OptPoint] = AtlasLinearDiscriminantAnalysis({GM},coefs,ClassDefinition,ListCases,V,options);
        LDAout.MeanDofs = MeanDofs;
        options.bPlotSeparate = 1;
        PlotLDAspace(LDAout,coefs,AtlasRoot,GM,options)
        % Measure differences:
        coefs = LDAout.PredictedScores;
        [~,Pbirth,CI,STATS] = ttest2(coefs(ClassDefinition(1).FileID),coefs(ClassDefinition(2).FileID));
        [~,Pfu,CI,STATS] = ttest2(coefs(ClassDefinition(3).FileID),coefs(ClassDefinition(4).FileID));
        fprintf('Significance at birth and fu: %1.5f & %1.5f\n',Pbirth,Pfu);
        pvalues = [Pbirth Pfu];
        
        %% Now plot the boxplots of the LDA:
    %function [] = PlotBoxPlots(LDAout,ClassDefinition)        
        orientation = 'horizontal';
        bGaussians = 0;
        switch orientation
            case 'horizontal'
                if bGaussians
                    Hbp = figure('color',[1 1 1],'OuterPosition',[50 50 250 500]); hold on
                else
                    Hbp = figure('color',[1 1 1],'OuterPosition',[50 50 500 250]); hold on
                end
            case 'vertical'
                Hbp = figure('color',[1 1 1],'OuterPosition',[50 50 500 500]); hold on
        end
        MkSize = 10;
        LnWidth= 1.5;
        % Plot the (-2std +2std) interval:
        NumberSTDS = 3;
        S1 = NumberSTDS*LDAout.Std;
        ColourChoice = 1;
        for iS = 1:2                     
            switch orientation
                case 'horizontal'
                    subplot(2,1,iS); hold on
                    plot([-S1,S1],[0 0],'LineWidth',LnWidth,'Color',[.2 .2 .2]);
                    plot(0,0,'+','MarkerEdgeColor',GetAtlasColor(1,2),'MarkerSize',MkSize,'LineWidth',LnWidth);
                    plot(S1,0,'+','MarkerEdgeColor',GetAtlasColor(2,2),'MarkerSize',MkSize,'LineWidth',LnWidth);
                    plot(-S1,0,'+','MarkerEdgeColor',GetAtlasColor(3,2),'MarkerSize',MkSize,'LineWidth',LnWidth);            
                case 'vertical'
                    subplot(1,2,iS); hold on
                    plot([0 0],[-S1,S1],'LineWidth',LnWidth,'Color',[.2 .2 .2]);
                    plot(0,0,'+','MarkerEdgeColor',GetAtlasColor(1,2),'MarkerSize',MkSize,'LineWidth',LnWidth);
                    plot(0,S1,'+','MarkerEdgeColor',GetAtlasColor(2,2),'MarkerSize',MkSize,'LineWidth',LnWidth);
                    plot(0,-S1,'+','MarkerEdgeColor',GetAtlasColor(3,2),'MarkerSize',MkSize,'LineWidth',LnWidth);            
            end
            for iC = 1:2
                iClass(iC) = iC + 2*(iS-1);
                Offset = 0.2*iC;
                data = coefs(ClassDefinition(iClass(iC)).FileID);
                media(iC) = mean(data);
                color = GetAtlasColor(iC,ColourChoice);
                if bGaussians
                    if(1)
                        h = estimate_pdf( data , 50 ); 
                        plot( h(:,1) , h(:,2) , 'color',color , 'LineWidth', 2);
                    else
                        plot(media(iC),0,'color',color,'Marker','*','MarkerSize',10,'LineWidth',1.5)
                    end
                else
                    boxplot(data,'colors',color,'Position',Offset,'Orientation',orientation,'plotstyle','compact');%,'notch','on')
                end
            end
            switch orientation
                case 'horizontal',  axis([-S1*1.1 S1*1.1 -0.2 0.6]);
                case 'vertical',    axis([-0.2 0.6 -S1*1.1 S1*1.1]);
            end
            %title(sprintf('Class %i vs %i (p=%1.5f) %1.2f vs %1.2f',iClass,pvalues(iS),media))
            title(sprintf('Class %i vs %i (p=%1.5f)',iClass,pvalues(iS)))
            axis off;
        end        
        FigName = fullfile(OutputDirectory,sprintf('BoxPlotsLDA_%ivs%i.png',LDAout.ClassesCompared(1),LDAout.ClassesCompared(2)));
        export_fig(FigName,'-png','-m2',Hbp);
    end
end

if(bViewBoxPlots)
    iEig2plot =1:6;
%     iView = 4;
%     options.AtlasFileName = sprintf('Atlas%ich.mat',iView);
%    options.AtlasSurname = '4ch';
    options.PlotType = 'BoxPlot';
    options.orientation = 'horizontal'; %'vertical';
    options.colourscheme = ColourChoice;
    options.BoxOutliers = 1;
    options.bTextMode = 1;
    H = PlotEigenDistribution(AtlasRoot,iEig2plot,options);
    export_fig(fullfile(OutputDirectory, sprintf('ModalBoxPlots%s.png',StudyString)),'-m2','-png',H);%,'-painters',H);
end

% if(bSaveExcel)
%     options.AtlasFileName = 'Atlas4ch.mat';
%     options.AtlasSurname = '4';
%     [coeff,cases,~,ListCases] = GetEigenCoefficients(AtlasRoot,options);
%     xlswrite(fullfile(OutputDirectory,sprintf('ShapeCoefficients%s.xls',StudyString)),[ListCases' coeff']);
% end
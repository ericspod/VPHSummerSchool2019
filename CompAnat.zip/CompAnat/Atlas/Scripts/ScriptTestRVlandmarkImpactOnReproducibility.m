% Script to prepare the generation of meshes in the CRT study where the RV
% landmark is taken from GG's and exported to PL's and DW's
clear;

RVlabel = 2;

criterion = 'EDV';
template = 'LV';
switch template
    case 'LVL', 
        AtlasFilePCAaxes = 'F:\Atlas\CRT\Complete50\AtlasOutput\Atlas.mat';
        MeshSeg(1).Dir =  'F:\Atlas\CRT\Complete50';
        MeshSeg(2).Dir =  'F:\Atlas\CRT\Lamata19';
        MeshSeg(3).Dir =  'F:\Atlas\CRT\Warriner19';
    case 'LV'
        AtlasFilePCAaxes = 'F:\Atlas\CRT\Complete50b\AtlasOutput\Atlas.mat';
        MeshSeg(1).Dir =  'F:\Atlas\CRT\Complete50b';
        MeshSeg(2).Dir =  'F:\Atlas\CRT\Lamata19';
        MeshSeg(3).Dir =  'F:\Atlas\CRT\Warriner19';
end
MeshSeg(1).Label =  'GG';
MeshSeg(2).Label =  'PL';
MeshSeg(3).Label =  'DW';

ClassFile = 'F:\Atlas\CRT\Complete50\CaseIdentities10pc_AllCorrect_19cases.xlsx';

% Load class definition:
ClassDefinitionInfo = xlsread(ClassFile);
DataDirectory = fullfile(MeshSeg(1).Dir,'AtlasData');
switch criterion
    case 'EDV', optClassDef.iColumnClass = 2;
    case 'ESV', optClassDef.iColumnClass = 6;
end
[ClassDefinition,VectorClass,CaseMapping] = OrderExcelDataInClassStructure(ClassDefinitionInfo,DataDirectory,optClassDef);
% List of cases to study:
classes2include = 1:2;
Cases2include = [ClassDefinition(classes2include).PatID];

% Create the data:
RefDataDir = fullfile(MeshSeg(1).Dir,'AtlasData');
for iSeg = 2:3
    NewAtlasDir = [MeshSeg(iSeg).Dir 'RVGG'];%
    NewAltasDataDir = fullfile(NewAtlasDir,'AtlasData');
    OldDataDir = fullfile(MeshSeg(iSeg).Dir,'AtlasData');
    if ~exist(NewAtlasDir,'dir')
        mkdir(NewAtlasDir);
        mkdir(NewAltasDataDir);
    end
    for iC = 1:numel(Cases2include)
        iCase  = Cases2include(iC);
        % Get this segmentation:        
        optMap.bCaseID = 1;
        [ KeyFile, output ] = CaseMappingAtlas( OldDataDir , iCase , optMap );
        [im,hd] = io_ReadMedicalImage(fullfile(output.CaseDirectory,KeyFile));
        % Get the reference segmentation to get the RV label:
        [ KeyFile2, output ] = CaseMappingAtlas( RefDataDir , iCase , optMap );
        [imR,hd] = io_ReadMedicalImage(fullfile(output.CaseDirectory,KeyFile2));
        % Remove the RV label in im:
        im(im==RVlabel) = 0;
        % Add the RV label as in imR:
        im(imR==RVlabel)= RVlabel;
        % Save the image
        CaseDir = fullfile(NewAltasDataDir,output.CaseFolderName);
        if ~exist(CaseDir,'dir')
            mkdir(CaseDir);
        end
        namefile = fullfile(CaseDir,KeyFile);
        io_WriteMedicalImage(namefile,im,hd);
    end
end
    
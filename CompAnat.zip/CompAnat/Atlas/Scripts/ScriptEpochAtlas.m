clear; 

ColourChoice = 1;
OutName = 'AtlasOutput';

%==========================================================================
Version = 4;
Root = 'F:\EPOCH'; % Root = 'F:\Atlas\EPOCH';
switch Version
    case 1
        AtlasRoot = fullfile(Root,'Data');
        options.RootName = 'epoch';
        options.PostName = {'fu', 'birth'}; 
        options.RawDataDir = fullfile(Root,'Data\RawData\');
        ClinicalFile = 'EPOCH Data_Pablo batch3.xlsx';
        options.iCondition2analyse = 2;
        options.bSspace = 0;
    case 2
        AtlasRoot = fullfile(Root,'EPOCHatlasv2.0\');
        options.RootName = 'EPOCH';
        ClinicalFile = 'EPOCH Data.xlsx';
        options.iChamber = 4;
        options.SimpleInputName = '1';
        bReorderDirectory = 0;
        options.bDebugDofSearch = 0;
        options.bRecalculateEigenCoords = 0;
        options.bSspace = 0;
    case 3
        AtlasRoot = fullfile(Root,'EPOCHatlasv3.0\');
        options.RootName = 'EPOCH';
        ClinicalFile = 'Pablo excel.xlsx';
        options.iChamber = 4;
        options.SimpleInputName = '1';
        bReorderDirectory = 0;
        options.bDebugDofSearch = 0;
        options.bRecalculateEigenCoords = 0;
        iComparison =  5;  % the 6 subgroups as in Feb2018
        options.bSspace = 0;
    case 4
        AtlasRoot = fullfile(Root,'EPOCHatlasRVv1.0\');
        options.RootName = 'EPOCH';
        ClinicalFile = 'Pablo excel.xlsx';
        options.iChamber = 4;
        options.SimpleInputName = '1';
        bReorderDirectory = 0;
        options.bDebugDofSearch = 0;
        options.bRecalculateEigenCoords = 0;
        %iComparison = 4; 
        iComparison =  5;  % the 6 subgroups as in Feb2018
        options.bSspace = 0;
    case 5
        AtlasRoot = fullfile(Root,'EPOCHatlasv3.0\');
        options.RootName = 'EPOCH';
        ClinicalFile = 'Pablo excel.xlsx';
        options.iChamber = 4;
        options.SimpleInputName = '1';
        bReorderDirectory = 0;
        options.bDebugDofSearch = 0;
        options.bRecalculateEigenCoords = 0;
        iComparison =  1;  % 1: premature birth, 2; hypertension mother
        options.bSspace = 1;
        OutName = 'AtlasOutputSS';
    case 6
        AtlasRoot = fullfile(Root,'EPOCHatlasv3.0\');
        options.RootName = 'EPOCH';
        ClinicalFile = 'Pablo excel.xlsx';
        options.iChamber = 4;
        options.SimpleInputName = '1';
        bReorderDirectory = 0;
        options.bDebugDofSearch = 0;
        options.bRecalculateEigenCoords = 0;
        iComparison =  1;  % 1: premature birth, 2; hypertension mother
        options.bSspace = 0;
        OutName = 'AtlasSkelOutputSS';
        options.bSkeleton = 1;
        options.bScaleWithAllDofs = 0;
    case 7
        AtlasRoot = fullfile(Root,'EPOCHatlasv3.0\');
        options.RootName = 'EPOCH';
        ClinicalFile = 'Pablo excel.xlsx';
        options.iChamber = 4;
        options.SimpleInputName = '1';
        bReorderDirectory = 0;
        options.bDebugDofSearch = 0;
        options.bRecalculateEigenCoords = 0;
        iComparison =  1;  % 1: premature birth, 2; hypertension mother
        options.bSspace = 1;
        OutName = 'AtlasRatioOutputSS';
        options.bRatioSkeleton = 1;
        options.bScaleWithAllDofs = 1;
end


options.KeyFileKind4Mapping = 'text';

% Build the "meshes":
options.bStep1EncodeContours    = 0;
    options.bEncodeContours     = 1;
% Make the PCA:
options.bStep2MakeStatistics    = 0;
% Visualise results:
options.bStep3visualiceResults  = 0;
options.bMovieModalVariation    = 0;
options.bStep3_ViewEigenSpace   = 0; 
options.bStatistical_Analysis   = 1;
options.bViewAverageShapes      = 1;
%    options.iCondition2analyse  = 2; % or 2 (birth)
bViewBoxPlots                   = 1;
bSaveExcel                      = 0;

%==========================================================================

DataDir = fullfile(AtlasRoot,'AtlasData');
OutputDirectory= fullfile(AtlasRoot,OutName);
if ~exist(OutputDirectory,'dir'), mkdir(OutputDirectory); end
options.OutName = OutName;
options.OutputDirectory = OutputDirectory;
if(bReorderDirectory)
    ReorderEpochData(DataDir);
end

switch iComparison
    case 1,  
        optionsExcel.iColumnClass = 2;
        StudyString = 'PreFacr';
    case 2,  
        optionsExcel.iColumnClass = 3;
        StudyString = 'HypFac';
    case 3,
        optionsExcel.iColumnClass = 4;
        StudyString = 'SGA';
    case 4, 
        optionsExcel.iColumnClass = 4;
        StudyString = 'G3';
    case 5,
        % six subgroups as Feb2018
        optionsExcel.iColumnClass = 4;
        StudyString = 'G6';
end
if(options.bSspace)
    StudyString = [ StudyString 'SS'];
end
options.StudyString = StudyString;

if(~isempty(ClinicalFile))    
    [ClassDefinitionInfo,txt] = xlsread([AtlasRoot ClinicalFile]);
    %[ClassDefinitionInfo,txt] = xlsread('C:\Data\Pablo excel new.xlsx');     optionsExcel.iColumnClass = 9;
    optionsExcel.txt = txt;
    optionsExcel.bForceGetText = 1;
    %optionsExcel.Study = AtlasVersion;
    [ClassDefinition,VectorClass,CaseMapping] = OrderExcelDataInClassStructure(ClassDefinitionInfo,DataDir,optionsExcel);
    % Make the classification based on the class provided, not by the
    % naming of files (fu vs. birth)
    % bPostNameAnalysis = 0;
    options.ClassDefinition = ClassDefinition;
end
    
AtlasFileName = CalculateUSAtlas(AtlasRoot,options);



    options.AtlasFileName = AtlasFileName;
    options.AtlasSurname = '4ch';
    [coefs,cases,~,ListCases] = GetEigenCoefficients(AtlasRoot,options);
    load(fullfile(AtlasRoot,OutName,options.AtlasFileName));
    options.OutputDirectory = fullfile(AtlasRoot,OutName);
    options.bPredictive = 1;
    options.classes2include = [1 2];
if (0)
    % Exploratory on the predictive ROC
%     if(0)
%         for iGM = 1:9
%             GM{iGM} = 2:iGM+2;
%         end
%         [AUCs,iSignifDif,Sensitivities,Specificities,LDAout,OptPoint] = AtlasLinearDiscriminantAnalysis(GM,coefs,ClassDefinition,ListCases,V,options);
%     end
    
    
    if(0)
        %%
        pThreshold = 0.01;
        options.bPredictive = 1;
        for iGM = 1:10
            ioff = 0;
            GM{iGM} = 1+ioff:iGM+ioff;
        end
        options.bPrintAllROCs = 1;
        options.bPrintROCs = 1;
        
        for icomparison = 3:4
            switch icomparison
                case 1, options.classes2include = [1 2];
                case 2, options.classes2include = [4 5];
                %case 2, options.classes2include = [3 4];
                case 3, options.classes2include = [2 3];
                case 4, options.classes2include = [5 6];
            end
            options.bPredictive = 1;
            [AUCs,iSignifDif,Sensitivities,Specificities,LDAout,OptPoint] = AtlasLinearDiscriminantAnalysis(GM,coefs,ClassDefinition,ListCases,V,options);
            %options.nLeaveOut = 2;
            %[AUCsN2] = AtlasLinearDiscriminantAnalysis(GM,coefs,ClassDefinition,ListCases,V,options);
            options.bPredictive = 0;
            [resubAUCs] = AtlasLinearDiscriminantAnalysis(GM,coefs,ClassDefinition,ListCases,V,options);
            
                HsummaryPred = figure('color',[1 1 1]);
                nG = numel(GM);
                [hp,ha1,ha2] = plotyy(1:nG,resubAUCs,1:nG,log10(LDAout.Significances));
                set(ha1,'LineStyle','-.')
                hold on;
                %plot(1:nG,AUCsN2,'r');
                plot(1:nG,AUCs,'k');
                
                % plot limits of goodness:
                Lim1=ones(1,nG)*0.7;
                Lim2=log10(ones(1,nG)*pThreshold);
                [hpl,hl1,hl2] = plotyy(1:nG,Lim1,1:nG,Lim2);
                set(hl1,'LineStyle',':')
                set(hl2,'LineStyle',':')

                set(hp(1),'ylim',[0.5 1])
                set(hpl(1),'ylim',[0.5 1])
                set(hp(2),'ylim',[-10 0])
                set(hpl(2),'ylim',[-10 0])
                xlabel('LDA combining PCA modes from 1 to x'); 
                xlabel('Number of PCA modes used in the LDA'); 
                %ylabel('AUC: resub.(k), leave-1(b), leave-2(r)');
                %ylabel('AUC: resubstitution(k), cross-validation(b)');
                ylabel('AUC'); legend('resubstitution','cross-validation','location','NorthWest');               
                ylabel(hp(2),'log(p)');
                
                c1 = options.classes2include(1);
                c2 = options.classes2include(2);
                title(sprintf('AUC performance G%i vs G%i',c1,c2));
                FigName = fullfile(OutputDirectory,sprintf('PredictiveSummary_%ivs%i.png',c1,c2));
                export_fig(FigName,'-png','-m2',HsummaryPred);
        end
    end
    %%
        options.bPredictive = 0;
        if(1)
            options.classes2include = [1 2];
            GM = 1;
        else
            options.classes2include = [3 4];
            GM = 1:9;
        end
        [AUCs,iSignifDif,Sensitivities,Specificities,LDAout,OptPoint] = AtlasLinearDiscriminantAnalysis({GM},coefs,ClassDefinition,ListCases,V,options);
        LDAout.MeanDofs = MeanDofs;
        options.bPlotSeparate = 1;
        PlotLDAspace(LDAout,coefs,AtlasRoot,GM,options)
        % Measure differences:
        coefs = LDAout.PredictedScores;
        [~,Pbirth,CI,STATS] = ttest2(coefs(ClassDefinition(1).FileID),coefs(ClassDefinition(2).FileID));
        [~,Pfu,CI,STATS] = ttest2(coefs(ClassDefinition(3).FileID),coefs(ClassDefinition(4).FileID));
        fprintf('Significance at birth and fu: %1.5f & %1.5f\n',Pbirth,Pfu);
        pvalues = [Pbirth Pfu];
        
        %% Now plot the boxplots of the LDA:
    %function [] = PlotBoxPlots(LDAout,ClassDefinition)        
        orientation = 'horizontal';
        bGaussians = 0;
        switch orientation
            case 'horizontal'
                if bGaussians
                    Hbp = figure('color',[1 1 1],'OuterPosition',[50 50 250 500]); hold on
                else
                    Hbp = figure('color',[1 1 1],'OuterPosition',[50 50 500 250]); hold on
                end
            case 'vertical'
                Hbp = figure('color',[1 1 1],'OuterPosition',[50 50 500 500]); hold on
        end
        MkSize = 10;
        LnWidth= 1.5;
        % Plot the (-2std +2std) interval:
        NumberSTDS = 3;
        S1 = NumberSTDS*LDAout.Std;
        ColourChoice = 1;
        for iS = 1:2                     
            switch orientation
                case 'horizontal'
                    subplot(2,1,iS); hold on
                    plot([-S1,S1],[0 0],'LineWidth',LnWidth,'Color',[.2 .2 .2]);
                    plot(0,0,'+','MarkerEdgeColor',GetAtlasColor(1,2),'MarkerSize',MkSize,'LineWidth',LnWidth);
                    plot(S1,0,'+','MarkerEdgeColor',GetAtlasColor(2,2),'MarkerSize',MkSize,'LineWidth',LnWidth);
                    plot(-S1,0,'+','MarkerEdgeColor',GetAtlasColor(3,2),'MarkerSize',MkSize,'LineWidth',LnWidth);            
                case 'vertical'
                    subplot(1,2,iS); hold on
                    plot([0 0],[-S1,S1],'LineWidth',LnWidth,'Color',[.2 .2 .2]);
                    plot(0,0,'+','MarkerEdgeColor',GetAtlasColor(1,2),'MarkerSize',MkSize,'LineWidth',LnWidth);
                    plot(0,S1,'+','MarkerEdgeColor',GetAtlasColor(2,2),'MarkerSize',MkSize,'LineWidth',LnWidth);
                    plot(0,-S1,'+','MarkerEdgeColor',GetAtlasColor(3,2),'MarkerSize',MkSize,'LineWidth',LnWidth);            
            end
            for iC = 1:2
                iClass(iC) = iC + 2*(iS-1);
                Offset = 0.2*iC;
                data = coefs(ClassDefinition(iClass(iC)).FileID);
                media(iC) = mean(data);
                color = GetAtlasColor(iC,ColourChoice);
                if bGaussians
                    if(1)
                        h = estimate_pdf( data , 50 ); 
                        plot( h(:,1) , h(:,2) , 'color',color , 'LineWidth', 2);
                    else
                        plot(media(iC),0,'color',color,'Marker','*','MarkerSize',10,'LineWidth',1.5)
                    end
                else
                    boxplot(data,'colors',color,'Position',Offset,'Orientation',orientation,'plotstyle','compact');%,'notch','on')
                end
            end
            switch orientation
                case 'horizontal',  axis([-S1*1.1 S1*1.1 -0.2 0.6]);
                case 'vertical',    axis([-0.2 0.6 -S1*1.1 S1*1.1]);
            end
            %title(sprintf('Class %i vs %i (p=%1.5f) %1.2f vs %1.2f',iClass,pvalues(iS),media))
            title(sprintf('Class %i vs %i (p=%1.5f)',iClass,pvalues(iS)))
            axis off;
        end        
        FigName = fullfile(OutputDirectory,sprintf('BoxPlotsLDA_%ivs%i.png',LDAout.ClassesCompared(1),LDAout.ClassesCompared(2)));
        export_fig(FigName,'-png','-m2',Hbp);
    %end
end

if(bViewBoxPlots)
    iEig2plot =1:6;
    iView = 4;
    options.PlotType = 'BoxPlot';
    options.AtlasFileName = sprintf('Atlas%ich.mat',iView);
    options.AtlasSurname = '4ch';
    options.orientation = 'horizontal'; %'vertical';
    options.colourscheme = ColourChoice;
    options.BoxOutliers = 0;
    options.bTextMode = 1;
    H = PlotEigenDistribution(AtlasRoot,iEig2plot,options);
    export_fig(fullfile(OutputDirectory, sprintf('ModalBoxPlots%s.png',StudyString)),'-m2','-png',H);%,'-painters',H);
end

if(bSaveExcel)
    options.AtlasFileName = 'Atlas4ch.mat';
    options.AtlasSurname = '4';
    [coeff,cases,~,ListCases] = GetEigenCoefficients(AtlasRoot,options);
    xlswrite(fullfile(OutputDirectory,sprintf('ShapeCoefficients%s.xls',StudyString)),[ListCases' coeff']);
end
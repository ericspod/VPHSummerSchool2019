function plotPrediction(Y,yfit)
    plot(Y,'o')
    hold on
    plot(yfit,'x','LineWidth',2);
    iValid = find(~isnan(yfit));
    nSamples = numel(iValid);
    
    % Binarise response and estimate success ratecl
    ybin = zeros(size(Y));
    ybin(yfit>=0.5) = 1;
    aa = logical(Y(iValid));
    bb = logical(ybin(iValid));
    SuccRate = 100* (1 - sum( abs( aa-bb ) ) / nSamples);
    fprintf(' Response in %i cases, %1.2f%% of success\n',nSamples,SuccRate);
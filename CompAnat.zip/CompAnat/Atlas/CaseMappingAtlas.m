function [ KeyFile, output ] = CaseMappingAtlas( DataDirName, iCase, options )
% Function to find the key files of each of the cases in an atlas study. 
%
% INPUT:
% - DataDirName: directory where all cases are stored, one case per folder
% - iCase: ID of the case 
% 
% OUTPUT:
% - 
%
% Version control
% 29-04-2015: allow the possibilitly of a DirPostName when identifying the
% correct case. This requires the corresponding choice of iCond
% 10/11/2014: make it versatile to different shape encodings/files

%==========================================================================
% Key option for the different encodings:
KeyFileKind4Mapping = 'image';

bWarnings = 0;
%==========================================================================
SubDirectory    = '';
OutMeshingDir   = 'Output_heartgen';
surname         = '';
% flag to indicate that iCase is a case ID (a number in the folder name):
bCaseID         = 0;
% flag to indicate if a specific name of the binary is provided
bBinaryProvided = 0;
MeshSurName     = '_mesh'; % '_meshLagrange';  %GGG
KeyFileSurname  = '';
topology = 'LV';
% The mapping of cases can also be driven by a "keyword", an ending of the
% case ID to indicate an experimental condition. This will be introduced in
% the options.DirPostName
bCaseNamingEndingCondition = 0;

if nargin>=3
    if isfield(options,'OutMeshingDir'), OutMeshingDir = options.OutMeshingDir; end
    if isfield(options,'KeyFileKind4Mapping'), KeyFileKind4Mapping = options.KeyFileKind4Mapping; end
    %if isfield(options,'ShapeEncoding'), ShapeEncoding = options.ShapeEncoding; end
    if isfield(options,'KeyFileSurname'), KeyFileSurname = options.KeyFileSurname; end
    if isfield(options,'SubDirectory'), SubDirectory = options.SubDirectory;   end;
    if isfield(options,'bCaseID'),      bCaseID = options.bCaseID;   end;
    if isfield(options,'MeshSurName'),  MeshSurName = options.MeshSurName;   end;
    if isfield(options,'surname'),      surname = options.surname;   end; %BinImageSurname
    if isfield(options,'topology'),     topology = options.topology;   end; %BinImageSurname
    if isfield(options,'BinaryName'),   
        BinaryName = options.BinaryName; 
        if ~strcmp(BinaryName,'SubDirectoryName')
            bBinaryProvided = 1;
        end
    end
    if isfield(options,'DirPostName'),  
        DirPostName = options.DirPostName;
        bCaseNamingEndingCondition = 1;
    end
end

%==========================================================================
% Defalt output:
KeyFile = '';
MeshName = '';
MeshDirectory = '';
CaseID = NaN;
iCaseFolder = NaN;
CaseDirectory = '';
CaseFolderName = '';

% =========================================================================
% Functionality:
    direct = dir(DataDirName);
    if(bCaseID)
        if bCaseNamingEndingCondition && isfield(options,'iCond')
            nameending = options.DirPostName{options.iCond};
            [CaseFolderName, iCaseFolder] = FindFolderWithID(direct,iCase,nameending);
        else            
            [CaseFolderName, iCaseFolder] = FindFolderWithID(direct,iCase);
        end
        CaseID = iCase;
    else
        iCaseFolder = iCase + 2;
        if numel(direct) < iCaseFolder
            fprintf('WARNING! index of folder greater than number of folders in %s\n',DataDirName);
        else
            CaseFolderName = direct(iCaseFolder).name;
            CaseID = GetIDfromName(CaseFolderName);
        end
    end
    if ~isnan(CaseFolderName)
        CaseDirectory = fullfile(DataDirName, CaseFolderName , SubDirectory);
        switch KeyFileKind4Mapping
            % Depending of the study, there is a key file to find in the
            % directory to rely upon
            case {'image','contourimage'}
                switch KeyFileKind4Mapping
                    case 'image',          ShapeEncoding = 'mesh';
                    case 'contourimage',   ShapeEncoding = 'contour';
                end
                % This is used for atlas built from binary masks. The name of
                % the mesh is based on it. 
                if(~bBinaryProvided) 
                    ImageFormats = {'.gipl','.vtk','.nii','.GIPL','.VTK','.NII','.mha','.nrrd'};
                    nF = numel(ImageFormats); bFound = 0; iF = 0;
                    while ~bFound && iF<nF
                        iF = iF+1;
                        BinImageSurname = ImageFormats{iF};
                        [KeyFile,bFound] = SearchSubDirectoryNameFile(CaseFolderName,CaseDirectory,BinImageSurname);  
                    end
                    if bFound
                        fprintf(' FOUND: %s\n',KeyFile);
                    else
                        fprintf(' WARNING! No KeyFile (binary image) found in case folder %s\n',CaseFolderName);
                    end
                else
                    KeyFile = BinaryName;
                end
            case 'text'
                % In case of 2D US contours, it is a text file what encodes the
                % segmentation. It also encodes which 2D view is representing.
                KeyFile = ls(fullfile(CaseDirectory,[KeyFileSurname '*.txt']));  
                if isempty(KeyFile)
                    if isfield(options,'RootName')
                        KeyFile = ls(fullfile(CaseDirectory, [options.RootName '*'] ));
                    end
                end
                ShapeEncoding = 'contour'; 
        end

        switch ShapeEncoding
            case 'mesh'
                switch topology
                    case 'arch'
                        MeshDirectory = fullfile(CaseDirectory,'Output_VascularGen');
                    otherwise
                        MeshDirectory = fullfile(CaseDirectory,OutMeshingDir);
                end
                if iscell(MeshDirectory)
                    % A variety of meshing directories, chosen for example
                    % when creating an atlas with permutations. Assumption
                    % is that there is only one valid directory (i.e. the
                    % MeshData folder populated with only right
                    % combinations)
                    nDirs = numel(MeshDirectory);
                else
                    nDirs = 1;
                    MD = MeshDirectory; clear 'MeshDirectory';
                    MeshDirectory{1} = MD;
                end
                for iD = 1:nDirs
                    MeshDirName = MeshDirectory{iD};
                    if exist(MeshDirName,'dir')
                        if(~isnan(KeyFile))
                            MeshName = [RemovePathAndExtension(KeyFile) MeshSurName];
                        else
                            % Try to find at least the output mesh (in case
                            % this is a post-processing directory)
                            ending = ['.exnode'];
                            Meshcandidate = ls( fullfile(CaseDirectory,OutMeshingDir,[KeyFileSurname '*' MeshSurName ending ]) );
                            if numel(Meshcandidate) > 0
                                nCC= numel(ending);
                                MeshName = Meshcandidate(1:end-nCC);
                                fprintf(' Directory with mesh: %s \n',MeshName);                            
                            else
                                fprintf(' Directory without the image and without mesh! (%s)\n',CaseDirectory);
                            end
                        end
                    else
                        if bWarnings, fprintf(' WARNING: Mesh directry does not exist: %s\n',MeshDirectory); end
                    end
                end                

    %        if bSearchSubDirectoryNameFile
    %             %Support a user-defined list of cases in the AtlasData
    %             %directory with different surnames than the rest of cases
    %             caseid = str2num(direct(iCase2findIndirect).name(end-2:end));            
    %             FileIndex = find(caseid == surnameCases);
    %             oldSurname = surname;
    %             if(FileIndex > 0)                    
    %                 surname = surnameID;
    %             end
    %            BinaryName = SearchSubDirectoryNameFile(dirname,CaseDirectory,surname);        
    %            surname = oldSurname;
    %        end
    %             if(bListOfFileNames)                
    %                 BinaryName = [ListOfFileNames{iC} partialFileName];           
    %             end
            case 'contour'
                % DO NOTHING
        end
    end
    
output.CaseID = CaseID;
output.iCaseFolder = iCaseFolder;
output.CaseDirectory = CaseDirectory;
output.CaseFolderName = CaseFolderName;
output.KeyFile = KeyFile;
output.MeshName = MeshName;
output.MeshDirectory = MeshDirectory;
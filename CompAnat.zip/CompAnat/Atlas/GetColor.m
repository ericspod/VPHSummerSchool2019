function [color] = GetColor(iColor,options)

colorstype = 'CirculationPaper';
nColors = 5;
if nargin >= 2
    if isfield(options,'nColors'), nColors = options.nColors; end
    if isfield(options,'colorstype'), colorstype = options.colorstype; end
end

switch colorstype
    case 'CirculationPaper'
        switch iColor
            case 1, color = [ 72 145 220]/220;
            case 2, color = [105 180  59]/255;
            case 3, color = [180 36   52]/255;
            case 4, color = [  0  33  71]/220;
            case 5, color = [153  51 255]/255; %color = [235 168 203]/255;
            case 6, color = [207 122  48]/255;
            otherwise
                fprintf('Not more than 6 different colors so far in GetColor.m!\n');
        end
    case 'Rainbow'
        colors = jet(nColors);
        color = colors(iColor,:);
    case 'Cool'
        colors = cool(nColors);
        color = colors(iColor,:);
end
        
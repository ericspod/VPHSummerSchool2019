function [] = CreateExcelClassFile(DataDir,EncodingOption)
% Function to create an excel file with the information of the class for
% the analysis of the atlas subjects

if nargin<2
    EncodingOption = 0;
end

    iID = 1;
    iPhase = 11;
    iClass = 9;
listfiles = dir(DataDir);
data = NaN*ones(4,numel(listfiles));
iValid = 0;
for iF=3:numel(listfiles)
    if listfiles(iF).isdir
        iValid = iValid + 1;
        nam = listfiles(iF).name;
        switch EncodingOption
            case 0
                ID = RobustSscanf(nam);
                phase = NaN;
                class = NaN;
                MeshID = ID;
            case 1
                % In Thakshy's and Georgia's study
                [ID,phase,class] = GetIDandPHfromName(nam,0);
                MeshID = ID*10000 + class*100 + phase;
            case 2
                % Generation R data:
                MeshID = RobustSscanf(nam);
                phase = RobustSscanf(nam(end-1:end));
                ID = floor(MeshID/10);
                %MeshID = phase + + ID*10;
                class = 0;
            case 3
                % Case#xxx, where # is class, and #xxx is mesh ID
                ID = RobustSscanf(nam(5:end));
                class = RobustSscanf(nam(5))+1;
                MeshID= ID;
                phase = 0;
            case 4
                % Mouse cohort
                MeshID = GetNumberFromName(nam,2);
                ID = MeshID;
                firstdig = sscanf(nam,'%i',1);
                switch firstdig
                    case 2, class = 1;
                    case 22, class = 2;
                end
                lastdig = sscanf(nam(end-1:end),'%i',1);
                switch lastdig
                    case 10, phase = 1;
                    case 11, phase = 2;
                end
            case 6
                % First digit is class, rest is case ID:
                phase = RobustSscanf(nam(5));
                ID = RobustSscanf(nam(6:end));
                MeshID = RobustSscanf(nam(5:end));
                class = 0;
            case 7
                % madrid data, first digit is class, last digit is phase
                class = RobustSscanf(nam(5));
                ID = RobustSscanf(nam(5:7));
                phase = RobustSscanf(nam(8));
                MeshID = RobustSscanf(nam(5:end));
            otherwise
                ID = RobustSscanf(nam(iID:end));
                phase = RobustSscanf(nam(iPhase:end));
                class = RobustSscanf(nam(iClass:end));
                MeshID = phase + class*10 + ID*100;
        end
        data(1,iValid) = MeshID;
        data(2,iValid) = ID;
        data(3,iValid) = phase;
        data(4,iValid) = class;
    end
end
excelout = fullfile(DataDir,'../','infocases.xls');
xlswrite(excelout,{'Mesh ID','Case ID','phase','class'})
%xlswrite(excelout,names',1,'A2')
xlswrite(excelout,data',1,'A2')

function ID = RobustSscanf(nam)
tmp = regexp(nam,'\d*','Match');
if size(tmp,2) < 2
    ID = sscanf(nam,'%d');
    if numel(ID)>1
        % do not know why, sometimes '08' gets into two digits...
        ID = ID(1)*10 + ID(2);
    end
    if isempty(ID)
        % Search in the next characters:
        if numel(nam)>1
            ID = RobustSscanf(nam(2:end));
        end
    end
else
    % if the name is special, e.g. DIT142_14
    ID = strcat(num2str(tmp{1}),num2str(tmp{2}) );
    ID = str2double(ID);
end

    
function [BinaryName,bFound] = SearchSubDirectoryNameFile(RootName,CaseDirectory,surname)
    
    bDebug = 0;
    
    bSurname = 1;
    
    if nargin<3
        surname = '';
        bSurname = 0;
    end
    bFound = 0;
    BinaryName = NaN;
    Name2Find = [RootName surname];
    files = dir(CaseDirectory);
    for iF=3:numel(files)
        filename = files(iF).name;
        RootName = RemovePathAndExtension(filename);
        if strcmp(RootName,Name2Find)
            BinaryName = filename;
            bFound = 1;
            return;
        end
    end
    if(~bFound)&&bSurname
        % New attempt to find the image, now with just the surname:
        for iF=3:numel(files)
            filename = java.lang.String(files(iF).name)    ;
            if filename.contains(java.lang.String(surname))
                BinaryName = filename.toCharArray()';
                [foo foo bImage] = RemoveExtensionFromImageName(BinaryName,0);
                if bImage
                    bFound = 1;
                    return;
                else
                    BinaryName = NaN;
                end
            end
        end
    end
    if(~bFound)
        % New attempt to find the image, now with just the name of the
        % directory and a valid ending format:
        for iF=3:numel(files)
            filename = java.lang.String(files(iF).name)    ;
            if filename.contains(java.lang.String(Name2Find))
                BinaryName = filename.toCharArray()';
                [foo foo bImage] = RemoveExtensionFromImageName(BinaryName);
                if bImage
                    bFound = 1;
                    return;
                else
                    BinaryName = NaN;
                end
            end
        end
    end
    if(~bFound)&&(bDebug)
        fprintf('ERROR! File named like %s not found in %s\n',Name2Find,CaseDirectory);
    end
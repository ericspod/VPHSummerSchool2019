function DisplayStatistics(VarNames,b,st)
    VarNames(2:numel(VarNames)+1) = VarNames;
    VarNames(1) = {'(Intercept)'};
    predstring = sprintf('%s - ',VarNames{:});
    fprintf(' Recurrence ~ %s\n',predstring);
    Estimate = b;
    SE = st.se;
    tStat = st.t;
    pValue = st.p;
    T = table(Estimate,SE,tStat,pValue,'RowNames',VarNames)

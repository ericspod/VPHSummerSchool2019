function [IndexesPerClass] = GetIndexesPerClass(Classes,iClass,ListCases,bWarning)
% Retrieve the relative index of the cases corresponding to the class iClass. This
% index is not the "name" of the folder (absolute), but it is the position of the case
% in the data folder.
% INPUT:
% - Classes: table which contains all cases and sorts them into our (four)
% different classes: *01, *02, *11, *12
% - iClass: index of for loop that calls this function
% - ListCases: list of IDs of the folder name

if nargin<4
    bWarning = 1;
end
% get number of cases that belong to class with index "iClass" from
% table "Classes"
nCasesPerClass = Classes(iClass).nCases;
IndexesPerClass = {};
% save all patients belonging to one class ind this variable

% ========================================================================
% Indexing: there is a big change from AtlasData indexing to MeshData
% indexing, and this was an attempt to be compatible backwards. Still, much
% more is needed, so it is left as it is with the default option of the
% indexing by mesh (what is needed in the new convention):
IndexingChoice = 0; % Default is to index by PatID, for compatibility reasons with previous results
% if isfield(Classes,'IndexingChoice')
%     IndexingChoice = Classes(1).IndexingChoice;
% end
if IndexingChoice
    % Index by the patient ID, because the PCA axis was build with this
    % indexing (old way)
    CasesPerClass = cell2mat({Classes(iClass).PatID(:)});
else
    % Index by the mesh ID< because the PCA axis was build with several
    % instances of each patient ID, and therefore the are many more meshes
    % than cases (but each mesh has a set of coefficients we want to index
    % here):
    CasesPerClass = cell2mat({Classes(iClass).MeshID(:)});
end
% ========================================================================

% check whether each patient has more than 1 mesh
if nCasesPerClass > numel(CasesPerClass)
    % We want the patient ID to be checked, not the mesh ID
    ListCases = RemoveInfo_LoD_Perm(ListCases);
end

for iCase  = 1:numel(CasesPerClass)
    iCa = find(ListCases == CasesPerClass(iCase));
    if numel(iCa)>0
        %             if numel(iCa) > 1
        %                 fprintf('WARNING! More than one case had ID=%i in the list of cases provided\n',CasesPerClass(iCase));
        %             end
        IndexesPerClass{iCase} = iCa;
    else
        if (bWarning)
            fprintf('WARNING! case with ID %03i not available (class %i)\n',CasesPerClass(iCase),iClass);
        end
    end
end
IndexesPerClass = cell2mat(IndexesPerClass);
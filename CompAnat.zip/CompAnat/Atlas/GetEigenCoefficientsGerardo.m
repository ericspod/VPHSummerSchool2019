function [coefficientsOut,caseNames,Handles,caseIDs] = GetEigenCoefficientsGerardo(directory,options)
% INPUT:
% - directory of atlas data
% - The definition of classes (labels) of the cases
%
% OUTPUT:
% - coefficients (coordinates): of all meshes
% - cases: with the names of the cases (name of the folder)
% - Handles: to the figures to save the plots afterwards
% - caseIDs: with the number of the valid casis (paired with cases), in
% case some of the input cases were not correct/complete
%
% Version control:
% - 09/09/13: class definition is an option


DataDirectory = [directory '/AtlasData/'];
OutputDirectory = [directory '/AtlasOutput/'];
CoordsMatFileName = [OutputDirectory '/Coordinates.mat'];

PersonalizedOutputDirectory = NaN;
bOnlyGenerateAtlasStatisticsFromSource = 0;

% Naming of files:
surname         = '';
BinaryName      = 'BinaryMask.vtk';
SubDirectory    = '/';
MeshSurName     = '_mesh'; % '_meshLagrange';  %GGG
ClassDefinition = '';
bUseMedialAxis = 0;
bUseWallThicknessOnly = 0;
bUseEpiNodes = 0;
bUseEndoNodes = 0;

ListCases = GetCasesInDirectory(DataDirectory);

load([OutputDirectory 'Atlas.mat']);

nDims = size(V);

bPlot = 0;
iEig2plot = 1:5;
bRecalculateEigenCoords = 0;
iEig = 1:nDims;
eigvectors2output = iEig;
VectorClass = NaN;
H1 = NaN;
H2 = NaN;
colourscheme = 1;
bCLagrange4CornersOnly = 0; %get only 4 nodes in each face of cLagrange, instead of default 16 nodes
buserDefinedPCAAxes = 0; %whether the user has provided their eigenvectors V variable
bAvoidMeanSubstrationInPCA = 0; %%Do not substract mean to make PCA (for test purposes)

if nargin==2
    if isfield(options,'eigvectors2output'), eigvectors2output = options.eigvectors2output; end
    if isfield(options,'iEig'),  iEig = options.iEig; end
    if isfield(options,'iEig2plot'),  iEig2plot = options.iEig2plot; end
    if isfield(options,'bPlot'), bPlot = options.bPlot; end
    if isfield(options,'bRecalculateEigenCoords'), bRecalculateEigenCoords = options.bRecalculateEigenCoords; end    
    if isfield(options,'VectorClass'), VectorClass = options.VectorClass; end
    if isfield(options,'BinaryName'),    BinaryName = options.BinaryName;  end
    if isfield(options,'surname'),       surname  = options.surname;  end
    if isfield(options,'SubDirectory'),  SubDirectory = options.SubDirectory;  end
    if isfield(options,'ClassDefinition'),  ClassDefinition = options.ClassDefinition;  end
    if isfield(options,'ListCases'),    ListCases = options.ListCases;    end
%     if isfield(options,'ListOfFileNames')   %Accepts list of filenames to search for
%         ListOfFileNames = options.ListOfFileNames;
%         bListOfFileNames = 1;
%     end
%     if isfield(options,'partialFileName'),    partialFileName = options.partialFileName;    end
%     if isfield(options,'ListCases'),    ListCases = options.ListCases;    end
    if isfield(options,'surnameCases'),     surnameCases = options.surnameCases; end      
    if isfield(options,'surnameID'),        surnameID = options.surnameID; end  
    if isfield(options,'colourscheme'),     colourscheme = options.colourscheme; end  
    
    if isfield(options,'bUseMedialAxis')   bUseMedialAxis = options.bUseMedialAxis; end  
    if isfield(options,'bUseWallThicknessOnly'),  bUseWallThicknessOnly = options.bUseWallThicknessOnly; end
    
    if isfield(options,'bUseEpiNodes'),  bUseEpiNodes = options.bUseEpiNodes; end
    if isfield(options,'bUseEndoNodes'),  bUseEndoNodes = options.bUseEndoNodes; end
    if isfield(options,'bOnlyGenerateAtlasStatisticsFromSource'),  bOnlyGenerateAtlasStatisticsFromSource = options.bOnlyGenerateAtlasStatisticsFromSource; end
    if isfield(options,'SourceFilesDir'), SourceFilesDir = options.SourceFilesDir; end
    if isfield(options,'bCLagrange4CornersOnly'), bCLagrange4CornersOnly = options.bCLagrange4CornersOnly; end    
%     if isfield(options,'PersonalizedOutputDirectory'), PersonalizedOutputDirectory = options.PersonalizedOutputDirectory; end
    if isfield(options,'bAvoidMeanSubstrationInPCA'), bAvoidMeanSubstrationInPCA = options.bAvoidMeanSubstrationInPCA; end    
    
    if isfield(options,'V')
        V = options.V; 
        buserDefinedPCAAxes = 1;
        bRecalculateEigenCoords = 1;
    end    

end

% if(~isnan(PersonalizedOutputDirectory))
%     OutputDirectory = PersonalizedOutputDirectory;
% end



if(bUseMedialAxis || bUseWallThicknessOnly)
    load([OutputDirectory 'MedialAxisMean.mat']);
end

if(bUseEpiNodes || bUseEndoNodes)
    load([OutputDirectory 'SurfaceNodesMean.mat']);
end

% if(bOnlyGenerateAtlasStatisticsFromSource)
%     load([OutputDirectory 'Atlas.mat']);
% end

if nargin >= 3
    bClassesAvailable = 1;
else
    bClassesAvailable = 0;
end

if strcmp(BinaryName,'SubDirectoryName')
    bSearchSubDirectoryNameFile = 1;
else
    bSearchSubDirectoryNameFile = 0;
end

direct = dir(DataDirectory);
nCases = numel(ListCases);
nCoords = numel(iEig);
coefficients = zeros(nCoords,nCases);
iValidCase = 0;
AllCasesNames = {};
bCoordsAvailable = 0;
if exist(CoordsMatFileName,'file')
    bCoordsAvailable = 1;
end
if bCoordsAvailable && ~bRecalculateEigenCoords
    load(CoordsMatFileName);
    % Select the valid ones:
    iValid = [];
    nTotal = numel(AllCasesNames);
    if nTotal == numel(ListCases);
        iValid = 1:nTotal;
    else
        for iAll = 1:nTotal
            if numel(AllCasesNames(iAll).ID)>0
                ID = AllCasesNames(iAll).ID;
                I = find(ListCases == ID);
                if numel(I) > 0
                    iValid = [iValid iAll];
                end
            end
        end
    end
        % Find the 
    AllCasesNames = AllCasesNames(iValid);
    coefficients = coefficients(:,iValid);
    fprintf(' Loaded %i valid coefficients (previously computed)\n',numel(iValid));
else
        for iC = 1:nCases
            iCase = ListCases(iC);       
            % Flag to indicate that iCase is the ID of the case (from folder
            % name):
            options.bCaseID = 1;
            options.SubDirectory = SubDirectory;
            [ BinaryName, output ] = CaseMappingAtlas( DataDirectory, iCase, options );
            CaseFolderName = output.CaseFolderName;
            CaseDirectory = output.CaseDirectory; 
            if isnan(CaseFolderName)
                fprintf('ERROR! No folder corresponding to ID=%i in directory %s\n',iCase,DataDirectory);
            else
                if(~isnan(BinaryName))
                    MeshName = output.MeshName;
                    MeshDirectory = output.MeshDirectory;
                    if exist([MeshDirectory MeshName '.exnode'],'file')
                        iValidCase = iValidCase + 1;
                        CH = CubicMeshClass([MeshDirectory MeshName]);
                        CH = SolveRigidBodyMotion(CH,CaseDirectory);
                        if(bUseMedialAxis) %Use calculated medial axes instead of the entire CH mesh
                            [medialAxisInfo CHMedialAxis] = MedialAxis(CH);
                            medialAxisNodes = medialAxisInfo(:,1:4); %get only x,y,z coords (and wall thickness)
                            Dofs = medialAxisNodes - MedialAxisMean;        
        %                     CHMeanMR = SetMedialAxisMesh( CH, MedialAxisMean );
        %                     Dofs = CHMedialAxis.GetDofs() - CHMeanMR.GetDofs();
                        elseif(bUseWallThicknessOnly)
                            [medialAxisInfo, ~] = MedialAxis(CH);
                            medialAxisNodes = medialAxisInfo(:,4:4); %get only x,y,z coords
                            Dofs = medialAxisNodes' - MedialAxisMean;        
                        elseif(bUseEpiNodes || bUseEndoNodes) %surface nodes

                                surfaceNodePos    = [];
                                if(bUseEpiNodes)
                                    chdofs = CH.GetDofs();
                                    epiNodesIdx = CH.FindEpiNodes(bCLagrange4CornersOnly);
                                    EpiNodePos  = chdofs(epiNodesIdx,:);
                                    surfaceNodePos = [surfaceNodePos; EpiNodePos];
                                end                   
                                if(bUseEndoNodes)
                                    chdofs = CH.GetDofs();
                                    endoNodesIdx = CH.FindEndoNodes(bCLagrange4CornersOnly);
                                    EndoNodePos  = chdofs(endoNodesIdx,:);
                                    surfaceNodePos = [surfaceNodePos; EndoNodePos];
                                end
                                Dofs = surfaceNodePos - SurfaceNodesMean;
                        else                            
                            Dofs = CH.GetDofs() - CHmean.GetDofs();
                            if(bAvoidMeanSubstrationInPCA)
                                Dofs = CH.GetDofs();
                            end
                        end

                        nDofs = size(Dofs);

                        for iE = 1:nCoords
                            iEigen = iEig(iE);
                            EigenVector = GetVector(iEigen,V,nDofs);
                            coefficients(iE,iC) = reshape(Dofs,1,prod(nDofs)) * reshape(EigenVector,1,prod(nDofs))';
                        end

                        CasesNames(iValidCase).name = CaseFolderName;
                    end
                    AllCasesNames(iC).name = CaseFolderName;
                    AllCasesNames(iC).ID = output.CaseID;
                else
                    fprintf(' Directory without the image! (%s)\n',CaseDirectory);
                end
            end
         end
    
    if(~buserDefinedPCAAxes)
        save(CoordsMatFileName,'AllCasesNames','coefficients');
        fprintf(' Computed %i valid coefficients\n',numel(AllCasesNames));
    end
end
nValidCases = iValidCase;
cases = squeeze(struct2cell(AllCasesNames));
caseNames = cases(1,:);
caseIDs = cell2mat(cases(2,:));
coefficientsOut = coefficients(eigvectors2output,:);

if ~isnan(VectorClass)
    bBoxPlot = 1;
else
    bBoxPlot = 0;
end
   
H1 = NaN; H2 = NaN; H3 = NaN;
if(bPlot)
    H1 = figure('color',[1 1 1],'OuterPosition',[0 10 1800 1500]);
    H2 = figure('color',[1 1 1],'OuterPosition',[500 10 800 1200]);
    if(bBoxPlot), H3 = figure('color',[1 1 1],'OuterPosition',[500 10 400 1200]);   end    
end
Handles = [H1 H2 H3];

nCoords2plot = numel(iEig2plot);
    for iC = 1:nCoords
        if(bPlot)&&(iC<=nCoords2plot)
            figure(H1); subplot(nCoords2plot,1,iC); hold on;
            figure(H2); subplot(nCoords2plot,1,iC); hold on;
            if(bBoxPlot), figure(H3); subplot(nCoords2plot,1,iC); hold on; end
        end
        if(bClassesAvailable)
            if isstruct(ClassDefinition)                
                Class = ClassDefinition;
                nClasses = numel(Class);
            else
                % TODO: Create analogous structure:
                [nCasesPerClass nClasses] = size(ClassDefinition);
                IndexesPerClass = zeros(nClasses,nCasesPerClass);
                for iClass=1:nClasses
                    Class(iClass).Indexes = ClassDefinition(:,iClass);
                    Class(iClass).nCases = numel(ClassDefinition(:,iClass));
                end
            end
            ValidFileID = sort(cell2mat({Class(:).FileID}));
            for iClass = 1:nClasses
                IndexesPerClass = GetIndexesPerClass(Class,iClass,ListCases);
                if(bPlot)&&(iC<=nCoords2plot)
                    AllCoefs = coefficients(iC,:);
                    coefs2bar = zeros(size(AllCoefs));
                    coefs2bar(IndexesPerClass) = AllCoefs(IndexesPerClass);
                    coefs2hist = AllCoefs(IndexesPerClass);
                    figure(H1);  bar(coefs2bar,'FaceColor',GetAtlasColor(iClass,colourscheme));
                    figure(H2);  [A,B] = hist(coefs2hist,10); bar(B,A,'FaceColor',GetAtlasColor(iClass,colourscheme)); alpha(0.5)                    
                end
            end
            if(bBoxPlot)&&(bPlot)&&(iC<=nCoords2plot), figure(H3); 
                ValidCoeffs = AllCoefs(ValidFileID);
                boxplot(ValidCoeffs,VectorClass);  end
        else
            if(bPlot)&&(iC<=nCoords2plot)
                 bar(coefficients(iC,:)); end
        end
        if(bPlot)&&(iC<=nCoords2plot)
            figure(H1);  
                set(gca,'XTick',1:nCases)
                set(gca,'XTickLabel',cases)
                title(sprintf('Coordinate %i',iEig(iC)))
            figure(H2);  
                title(sprintf('Coordinate %i',iEig(iC)))
            if(bBoxPlot)
                figure(H3);  
                title(sprintf('Coordinate %i',iEig(iC)))
            end
        end
    end
end

function ID = GetIDfromName(name)
% Function to retrieve the numeric of a name ending in an unknown number of
% digits.
    bFromTheEnd = 1;
    ID = 0; II = 0;
    for In = numel(name):-1:1                    
        if(bFromTheEnd)
            character = name(In);
            if character>='0' && character<='9'
                % This is a digit:
                digits(In) = str2num(character);
                II = II + 1;
                ID = ID + digits(In) * 10^(II-1);
            else
                bFromTheEnd = 0;
            end
        end
    end                
end

function CaseFolderName = FindFolderWithID(direct,iCase)
% Function to find the folder with the name that ends in the digits of the
% iCase:
    CaseFolderName = NaN;
    for iDirect = 1:numel(direct)
        name = direct(iDirect).name;
        ID = GetIDfromName(name);
        if ID == iCase
            CaseFolderName = name;
            return;
        end
    end
end
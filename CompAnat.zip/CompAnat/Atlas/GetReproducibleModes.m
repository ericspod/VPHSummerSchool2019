function [modes] = GetReproducibleModes(iMeshing,iShapeSpace)
% Function to encapsulate the reproducible modes depending on the accuracy
% of the meshing, and the shape space. This is a hard-coded result after
% running the ScriptCompareSegmentations.m

switch iMeshing
    case {1,'LVL-LoD3'}
        switch iShapeSpace
            case {0,'NA'},  modes = [1:7,14];                 
            case {1,'C'},  modes = [1:4]; 
            case {2,'R'},  modes = [1:3]; 
            case {3,'S'},  modes = [1:2]; 
            case {4,'rv'},  modes = [1:5 8];                 
        end
    case {2,'LV-LoD3'}
        switch iShapeSpace
            case {0,'NA'},  modes = [1:7];                 
            case {1,'C'},  modes = [1:5]; 
            case {2,'R'},  modes = [1:2]; 
            case {3,'S'},  modes = [1]; 
            case {4,'rv'},  modes = [1:5];                 
        end
    case {3,'LV-LoD2'}
        switch iShapeSpace
            % So far, only a copy-paste from the previous (at least these
            % should be reproducible!)
            case {0,'NA'},  modes = [1:7];                 
            case {1,'C'},  modes = [1:5]; 
            case {2,'R'},  modes = [1:2]; 
            case {3,'S'},  modes = [1]; 
            case {4,'rv'},  modes = [1:5];                
        end
end
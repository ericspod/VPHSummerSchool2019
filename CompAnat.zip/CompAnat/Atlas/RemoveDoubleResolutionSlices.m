function [NewDistance,NewIm,NewIed] = RemoveDoubleResolutionSlices(Distance,im,Ied)
% Function to remove extra slices at double resolution from the list of slices (oritinated from a
% duplicate existance of files, exported twice in Argus).

[nX nY nSlicesIn] = size(im);

[DistancesOrdered,I2] = sort(Distance,'ascend');
Increment = DistancesOrdered(2:end) - DistancesOrdered(1:end-1);
% Analyse the sequence of "Distance", and get the "median"
GoodSpacing = median(Increment);
% Evaluate two guesses of good distances, from first and second:
epsilon = 0.01;
for iEval = 1:2
    First = DistancesOrdered(iEval);
    NewDis = First + [0:1:nSlicesIn]*GoodSpacing;
    iDf = 0;
    % Find the number of distances present:
    for iD = 1:nSlicesIn
        Dist = Distance(iD);
        if numel(find(abs(NewDis - Dist) < epsilon)) == 1
            iDf =  iDf + 1;
            NewI(iEval,iDf) = Ied(iD);
            NewIloc(iEval,iDf) = iD;
        end
    end
    Metric(iEval) = iDf;
end
% Get the one with highest metric:
I = find(Metric==max(Metric));
NewIed = NewI(I(1),1:max(Metric));
NewIlocal = NewIloc(I(1),1:max(Metric));
NewDistance = Distance(NewIlocal);
NewIm = im(:,:,NewIlocal);


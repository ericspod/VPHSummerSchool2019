function [] = CalculateAltas(directory)
% Function to calculate an atlas of all shapes contained in a given
% directory.

% Naming conventions:
    ExnodeName = 'BinaryMask_mesh.exnode';
    BinaryName = 'BinaryMask.vtk';

DataDirectory = [directory '/data/'];
CurrentDirectory = pwd;

direct = dir(DataDirectory);
nCases = numel(direct) - 2;
for iCase = 1:nCases
    iD = iCase + 2;
    CaseDirectory = [DataDirectory direct(iD).name '/zmask/'];
    MeshDirectory = [CaseDirectory 'Output_heartgen/'];
    if ~exist([MeshDirectory ExnodeName])
        % Create the mesh:
        cd(CaseDirectory);
        heartgen2([CaseDirectory BinaryName],'-HeartType',LV,'-nE',[6 12 1]);
        cd(CurrentDirectory);
    end
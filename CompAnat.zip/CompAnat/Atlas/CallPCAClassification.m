function [ output_args ] = CallPCAClassification( OutputDirectory )
%Function to call PCA Classification of pre-term cohort of 224 cases

    outdirectory = OutputDirectory;
    nTrials = 1;

    %prefixName = 'A-prioriPCs';
    prefixName = '50OriginalPCs';
        
    classifyOptions = [];
    classifyOptions.ResultsDir = 'U:\ResultsTraditionalModels\224cases\';   
    classifyOptions.OutputPath = 'Classification\OriginalPCs\50PCs\OriginalcLagrangeFixed_16nodes\';
    
    classifyOptions.bOriginal3PCs = 0;
    classifyOptions.bOriginalALLPCs = 1;
        classifyOptions.numOriginalCoordsP = 50;
        
    for iTr=1:nTrials    
        classifyOptions.numberTrial = iTr;
        
        %Case1vs3
        classifyOptions.bCase1vs3 = 1;    
        classifyOptions.bCase3vs4 = 0;   
        classifyOptions.bCase1vs4 = 0;
        [clapLinear1vs3,clapQuad1vs3,clapSVM1vs3,clapSVM3vs4,clapSVM1vs4 ] = PCAClassification(outdirectory, classifyOptions);
        Linear1vs3(iTr) = clapLinear1vs3;
        Quad1vs3(iTr) = clapQuad1vs3;
        SVM1vs3(iTr) = clapSVM1vs3;
        
        %Case3vs4 
        classifyOptions.bCase1vs3 = 0;    
        classifyOptions.bCase3vs4 = 1;   
        classifyOptions.bCase1vs4 = 0;
        [clapLinear3vs4,clapQuad3vs4,clapSVM1vs3,clapSVM3vs4,clapSVM1vs4 ] = PCAClassification(outdirectory, classifyOptions);
        Linear3vs4(iTr) = clapLinear3vs4;
        Quad3vs4(iTr) = clapQuad3vs4;
        SVM3vs4(iTr) = clapSVM3vs4;
        
        %Case1vs4 
        classifyOptions.bCase1vs3 = 0;    
        classifyOptions.bCase3vs4 = 0;   
        classifyOptions.bCase1vs4 = 1;
        [clapLinear1vs4,clapQuad1vs4,clapSVM1vs3,clapSVM3vs4,clapSVM1vs4 ] = PCAClassification(outdirectory, classifyOptions);
        Linear1vs4(iTr) = clapLinear1vs4;
        Quad1vs4(iTr) = clapQuad1vs4;
        SVM1vs4(iTr) = clapSVM1vs4;

    end

    %Mean sensitivity/specificity values among the trials
    sensLin1vs3 = 0;    sensLin3vs4 = 0;    sensLin1vs4 = 0;
    specLin1vs3 = 0;    specLin3vs4 = 0;    specLin1vs4 = 0;
    sensQuad1vs3 = 0;    sensQuad3vs4 = 0;    sensQuad1vs4 = 0;
    specQuad1vs3 = 0;    specQuad3vs4 = 0;    specQuad1vs4 = 0;    
    sensSVM1vs3 = 0;    sensSVM3vs4 = 0;    sensSVM1vs4 = 0;
    specSVM1vs3 = 0;    specSVM3vs4 = 0;    specSVM1vs4 = 0;
    
    for iTr=1:nTrials  
        %Linear 
        sensLin1vs3 = sensLin1vs3 + Linear1vs3(iTr).sensitivity;
        specLin1vs3 = specLin1vs3 + Linear1vs3(iTr).specificity;
        
        sensLin3vs4 = sensLin3vs4 + Linear3vs4(iTr).sensitivity;
        specLin3vs4 = specLin3vs4 + Linear3vs4(iTr).specificity;
        
        sensLin1vs4 = sensLin1vs4 + Linear1vs4(iTr).sensitivity;
        specLin1vs4 = specLin1vs4 + Linear1vs4(iTr).specificity;
        
        %Quadratic
        sensQuad1vs3 = sensQuad1vs3 + Quad1vs3(iTr).sensitivity;
        specQuad1vs3 = specQuad1vs3 + Quad1vs3(iTr).specificity;
        
        sensQuad3vs4 = sensQuad3vs4 + Quad3vs4(iTr).sensitivity;
        specQuad3vs4 = specQuad3vs4 + Quad3vs4(iTr).specificity;
        
        sensQuad1vs4 = sensQuad1vs4 + Quad1vs4(iTr).sensitivity;
        specQuad1vs4 = specQuad1vs4 + Quad1vs4(iTr).specificity;
        
        %SVM
        sensSVM1vs3 = sensSVM1vs3 + SVM1vs3(iTr).sensitivity;
        specSVM1vs3 = specSVM1vs3 + SVM1vs3(iTr).specificity;
        
        sensSVM3vs4 = sensSVM3vs4 + SVM3vs4(iTr).sensitivity;
        specSVM3vs4 = specSVM3vs4 + SVM3vs4(iTr).specificity;
        
        sensSVM1vs4 = sensSVM1vs4 + SVM1vs4(iTr).sensitivity;
        specSVM1vs4 = specSVM1vs4 + SVM1vs4(iTr).specificity;
    end
    sensLin1vs3 = sensLin1vs3 / nTrials;    specLin1vs3 = specLin1vs3 / nTrials;    sensLin3vs4 = sensLin3vs4 / nTrials;
    specLin3vs4 = specLin3vs4 / nTrials;    sensLin1vs4 = sensLin1vs4 / nTrials;    specLin1vs4 = specLin1vs4 / nTrials;
    sensQuad1vs3 = sensQuad1vs3 / nTrials;  specQuad1vs3 = specQuad1vs3 / nTrials;  sensQuad3vs4 = sensQuad3vs4 / nTrials;
    specQuad3vs4 = specQuad3vs4 / nTrials;  sensQuad1vs4 = sensQuad1vs4 / nTrials;  specQuad1vs4 = specQuad1vs4 / nTrials;
    sensSVM1vs3 = sensSVM1vs3 / nTrials;    specSVM1vs3 = specSVM1vs3 / nTrials;    sensSVM3vs4 = sensSVM3vs4 / nTrials;
    specSVM3vs4 = specSVM3vs4 / nTrials;    sensSVM1vs4 = sensSVM1vs4 / nTrials;    specSVM1vs4 = specSVM1vs4 / nTrials;
    
    
    C = {'Linear', '' '';...
        'Types', prefixName 'Case1vs3'; 'Specificity' specLin1vs3 ''; 'Sensitivity' sensLin1vs3 ''; '' '' '';...
        '', prefixName 'Case3vs4'; 'Specificity' specLin3vs4 ''; 'Sensitivity' sensLin3vs4 ''; '' '' '';...
        '', prefixName 'Case1vs4'; 'Specificity' specLin1vs4 ''; 'Sensitivity' sensLin1vs4 ''; '' '' '';...        
        %'' '' ''; ...
        'Quadratic', '' '';...
        'Types', prefixName 'Case1vs3'; 'Specificity' specQuad1vs3 ''; 'Sensitivity' sensQuad1vs3 ''; '' '' '';...
        '', prefixName 'Case3vs4'; 'Specificity' specQuad3vs4 ''; 'Sensitivity' sensQuad3vs4 ''; '' '' '';...
        '', prefixName 'Case1vs4' ; 'Specificity' specQuad1vs4 ''; 'Sensitivity' sensQuad1vs4 ''; '' '' '';...
        %'' '' ''; ...
        'SVM', '' '';...
        'Types', prefixName 'Case1vs3'; 'Specificity' specSVM1vs3 ''; 'Sensitivity' sensSVM1vs3 ''; '' '' '';...
        '', prefixName 'Case3vs4'; 'Specificity' specSVM3vs4 ''; 'Sensitivity' sensSVM3vs4 ''; '' '' '';...
        '', prefixName 'Case1vs4'; 'Specificity' specSVM1vs4 ''; 'Sensitivity' sensSVM1vs4 ''; '' '' '';...        
        };

     name = 'classificationOutputcLagrangeSurface';
%    name= 'classificationOutputcHermiteALLDerivs';
    
    filename = [name prefixName num2str(nTrials) 'Trials' '.xlsx'];
    directory = [classifyOptions.ResultsDir classifyOptions.OutputPath];
    xlswrite([directory filename],C,'Case1vs3vs4');
    
%     %Matthews correlation coefficient: measure of the quality of binary 
%     %(two-class) classifications.
%     %http://en.wikipedia.org/wiki/Matthews_correlation_coefficient

%     confusionMat = Linear1vs3(1).DiagnosticTable';
% %     confusionMat = Quad1vs3(1).DiagnosticTable';
% %     confusionMat = SVM1vs3(1).DiagnosticTable';
%     TP = confusionMat(1,1); FP = confusionMat(1,2);
%     FN = confusionMat(2,1); TN = confusionMat(2,2);    
%     MCC = ( (TP*TN)-(FP*FN) ) / sqrt( (TP+FP)*(TP+FN)*(TN+FP)*(TN+FN) ) ;
    
    
end


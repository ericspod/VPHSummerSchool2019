function [HF2] = PlotLDAspace(LDAout,coefPCA,Directory,GM,options)
% Function to plot the parametric LDA space defined by:
% - LDAout: structure with:
%   - w: weight of each PCA mode (result of the LDA)
%   - wC: coefPCA of each case in LDA space
%   - Std: The standard deviation of the samples, w, in the LDA axis
%   - I1,I2: indexes of the cases of class 1 and class 2 respectively
%   - p: p-value of the Fisher test (significance of differences)
%   - ClassesCompared: indexes of the clases compared
% - coefPCA: coefPCA in PCA space 
% - GM: PCA modes that are grouped
% - options:
     

bPlotSeparate = 1;
bOnlyLDAprojections = 0;
% For the representation of the points of extreme shapes:
nStd = 3;

if isfield(options,'bPlotSeparate'), bPlotSeparate = options.bPlotSeparate; end
if isfield(options,'bOnlyLDAprojections'), bOnlyLDAprojections = options.bOnlyLDAprojections; end

if isfield(options,'nStd'), nStd = options.nStd; end

wC = LDAout.wC;
w  = LDAout.w;

if isfield(LDAout,'VarC')
    VarC = LDAout.VarC;
else
    VarC = NaN;
end
if isfield(LDAout,'MeanDofs')
    % Quick hack to enable this visualization:
    bPlotEcho = 1;
    MeanDofs = reshape(LDAout.MeanDofs,size(LDAout.Mode,1),size(LDAout.Mode,2));
else
    bPlotEcho = 0;
end

I1 = LDAout.I1;
I2 = LDAout.I2;
p  = LDAout.p;
cc = LDAout.ClassesCompared;
bAUC =0;
if isfield(LDAout,'AUC')
    AUC = LDAout.AUC;
    bAUC = 1;
end

colourscheme = 1;
if nargin>=5
    if isfield(options,'colourscheme')
        colourscheme = options.colourscheme;
    end
    optionsEigenSpace = options;
end
    HF2 = figure('color',[ 1 1 1]);   
    if~(bOnlyLDAprojections)
        subplot(223)    
    end
    if (bPlotEcho)
        LineWidth = 3;
        % The third panel is the mode:
        if (bPlotSeparate)
            Hf = figure('color',[ 1 1 1],'OuterPosition',[10 10 1000 300]);
            subplot(131)
        else
            subplot(223); 
        end
        hold on;
        % plot the extremes:        
        PlotEchoContours(MeanDofs + nStd*LDAout.Std * LDAout.Mode, GetAtlasColor(2,2), LineWidth);
        if (bPlotSeparate)
            %axis off;
            subplot(132); hold on;
        end
        PlotEchoContours(MeanDofs,GetAtlasColor(1,2), LineWidth);
        %PlotEchoContours(MeanDofs,GetAtlasColor(1,2), LineWidth);
        
        if (bPlotSeparate)
            %axis off;
            subplot(133)
            hold on;
        else
            PlotEchoContours(MeanDofs,GetAtlasColor(1,2), LineWidth);
        end
        PlotEchoContours(MeanDofs - nStd*LDAout.Std * LDAout.Mode, GetAtlasColor(3,2), LineWidth);
        title(sprintf('LDA mode (+/- %istd)',nStd));
        if (bPlotSeparate)
            %axis off;
            figure(HF2);
        end
    else
        if(bOnlyLDAprojections)
            % Group paris of GM's
            b = nchoosek(numel(GM),2);
            II = nchoosek([1:numel(GM)],2);
            C = nchoosek(GM,2);
            figure('color',[1 1 1]); nC = ceil(sqrt(b));
            for i=1:b
                iGM = C(i,:)';
                subplot(nC,nC,i);
                ViewParametricSpace(LDAout,coefPCA,Directory,iGM,optionsEigenSpace,nStd,w(II(i,:)));
            end
        else
            ViewParametricSpace(LDAout,coefPCA,Directory,GM,optionsEigenSpace,nStd,w);
        end            
    end    

    if~(bOnlyLDAprojections)

        subplot(221), hold on;
        nHistCounts = round(numel(wC)/10);
        if numel(wC)==1
            fprintf('WARNING! It all looks that the LDA was computed in predictive leave-1 out mode, so no samples of the complete cohort are available\n');
        end
        SemiTransparentHistogram(wC( I1 ),nHistCounts,GetAtlasColor(cc(1),colourscheme));
        SemiTransparentHistogram(wC( I2 ),nHistCounts,GetAtlasColor(cc(2),colourscheme));
        if isfield(LDAout,'Deviance')
            a = LDAout.Deviance.pValue(2);
            title(sprintf('Deviance = %f (p=%f)',LDAout.Deviance.Deviance(2),a));
        end


        subplot(222)
        h = estimate_pdf( wC( I1 ) , 50 ); 
        plot( h(:,1) , h(:,2) , 'b' );
        hold on
        h = estimate_pdf( wC( I2 ) , 50 ); 
        plot( h(:,1) , h(:,2) , 'g' );
        titlestring = sprintf('p value = %1.5f',p);
        if(bAUC)
            titlestring = sprintf('%s AUC=%1.4f',titlestring,AUC);
        end
        title(titlestring);
        hold off


        subplot(224)
        bar(w); set(gca,'XTickLabel',GM);
        title('Weight of each PCA component')
    end    
    
end

function [] = ViewParametricSpace(LDAout,coefPCA,Directory,GM,optionsEigenSpace,nStd,w)    
    STD = LDAout.Std;
    % View the cloud of points (if dimensionality allows it):
    optionsEigenSpace.bNewFig = 0;
    if isfield(LDAout,'PCAweights')
        coefPCA = coefPCA ./ repmat(LDAout.PCAweights,1,size(coefPCA,2));
    end
    optionsEigenSpace.coefPCA = coefPCA;
    optionsEigenSpace.ListCases = LDAout.ListCases;            
    GetEigenSpace(Directory,GM,optionsEigenSpace);
    % Visualise the Fisher's line:
    xMin = min(coefPCA(GM(1),:));
    xMax = max(coefPCA(GM(1),:));

    switch numel(GM)
        case 2
            t = xMin:1:xMax;
            fl= t * w(2)/w(1);
            plot(t,fl,'r')
            axis equal;
            % Add the location of the extreme shapes synthetised
            Ex1 = [0 0] + nStd*STD*reshape(w,1,2);
            Ex2 = [0 0] - nStd*STD*reshape(w,1,2);
            plot(Ex1(1),Ex1(2),'r*');
            plot(Ex2(1),Ex2(2),'r*');
        case 3
            zMin = min(coefPCA(GM(3),:));
            zMax = max(coefPCA(GM(3),:));
            %Decide on a suitable showing range
            xLim = [xMin xMax];
            zLim = [zMin zMax];
            [X,Z] = meshgrid(xLim,zLim);
            %Find all coefPCA of plane equation    
            A = w(1); B = w(2); C = w(3);
            D = 0;
            Y = (A * X + C * Z + D)/ (-B);
            reOrder = [1 2  4 3];
            hold on
            patch(X(reOrder),Y(reOrder),Z(reOrder),'r');
            grid on; alpha(0.3);
            axis equal;
        otherwise
            % plot the weighted set of coefficients:
            title('no variance of PCA modes available');
            if exist('VarC','var')
                if ~isnan(VarC)
                    WeigsTimesVar = w.*VarC;
                    bar(abs(WeigsTimesVar)); set(gca,'XTickLabel',GM);
                    title('(Weight * Variance) of each PCA mode')
                end                
            end
    end
end
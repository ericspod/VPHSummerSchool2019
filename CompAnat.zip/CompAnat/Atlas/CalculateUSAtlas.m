function [AtlasFileName] = CalculateUSAtlas(RootDir,options)
% Function to compute the statistical distribution of the shape captured by
% 2D US of the heart, specifically the endo and epi contours of the
% longitudinal standard views: 2 chamber, 3 chamber and 4 chamber.
%
% INPUT:
% - RootDir: where data is provided, and where results will be located. It
% needs an AtlasData folder with a subfolder per each case, with a naming that
% has the patient ID at the end of the folder name. If we have different
% repetitions of a single subject, need to use different digits to encode
% each aspect (patient ID, acquisition number, segmentation number, etc...)
%   AtlasData/CAB00101
%   AtlasData/CAB00102
%   AtlasData/CAB00103
% - options: a set of choices that will be carried forward to the other
% sub-functions.
% 
% By Pablo Lamata. November 2014

% Correction of scale: S space
bSspace = 0;
    bScaleWithAllDofs = 1;

% Hard coded directory naming:
DataDir = [RootDir '/AtlasData/'];
OutName = 'AtlasOutput';

% A naming convention: a string added to the root name of all files, so
% that it indicates a different condition. By default this is simply:
PostName = {''};
% A second naming convention that came in the 250 4ch:
DirPostName = {''};
% A file with the definition of classes:
ClinicalFile = '';
% chamber views to be analysed
iChamber = 2:4;
StudyString = '';

bSkeleton = 0;
bRatioSkeleton =0 ;

ColourChoice = 1;

bStep1EncodeContours    = 1;
    
bStep2MakeStatistics    = 1;
bStep3visualiceResults  = 1;
    iEig                = 1:5;
    Scale               = 2;
bMovieModalVariation    = 1;
bPlotVariancePerMode    = 0;
bStep3_ViewEigenSpace   = 1;
    bRecalculateEigenCoords= 1;
    bConditionsIndependent = 0;  % The default is to analyse the fu vs. birth, the subclasses by the naming of files
    iCondition2analyse  = 2;     % but if there is a ClinicalFile, the classes there are loaded, and then a choice is needed for the condition to analyse
bViewAverageShapes      = 1;
    optionAverages      = 1;
bViewCase               = 0;
    iCases              = [];
    
bStatisticalAnalysisByExcelFile = 0;    
bStatistical_Analysis   = 0;
    bPostNameAnalysis   = 0;
    bPairedAnalysis     = 0;
    bLDAremodelling     = 0;
    
% The default method of encoding the contours, by setting them in vertical,
% is conceptually R (correction for centre of mass and rotation):
DefaultShapeSpace = 'R';
    
if nargin>=2
    if isfield(options,'bStep1EncodeContours'),     bStep1EncodeContours = options.bStep1EncodeContours; end
    if isfield(options,'bStep2MakeStatistics'),     bStep2MakeStatistics = options.bStep2MakeStatistics; end
    if isfield(options,'bStep3visualiceResults'),   bStep3visualiceResults = options.bStep3visualiceResults; end
    if isfield(options,'bPlotVariancePerMode'),     bPlotVariancePerMode = options.bPlotVariancePerMode; end
    if isfield(options,'bStep3_ViewEigenSpace'),    bStep3_ViewEigenSpace = options.bStep3_ViewEigenSpace; end
    if isfield(options,'bMovieModalVariation'),     bMovieModalVariation = options.bMovieModalVariation; end    
    if isfield(options,'bStatisticalAnalysisByExcelFile'),     bStatisticalAnalysisByExcelFile = options.bStatisticalAnalysisByExcelFile; end    
    
    if isfield(options,'bStatistical_Analysis'),    bStatistical_Analysis = options.bStatistical_Analysis; end
    if isfield(options,'bViewAverageShapes'),       bViewAverageShapes = options.bViewAverageShapes; end
    if isfield(options,'iCases'),                   iCases = options.iCases; bViewCase = 1; end
    
    if isfield(options,'PostName'),                 PostName = options.PostName; end
    if isfield(options,'DirPostName'),              DirPostName = options.DirPostName; end
    if isfield(options,'iCondition2analyse'),       iCondition2analyse = options.iCondition2analyse; end
    if isfield(options,'iChamber'),                 iChamber = options.iChamber; end
    if isfield(options,'ClassDefinition'),          ClassDefinition = options.ClassDefinition; end
    
    if isfield(options,'StudyString'),          StudyString = options.StudyString; end
    
    if isfield(options,'bSspace'),          bSspace = options.bSspace; end
    if isfield(options,'bScaleWithAllDofs'),          bScaleWithAllDofs = options.bScaleWithAllDofs; end
    
    if isfield(options,'bSkeleton'),        bSkeleton = options.bSkeleton; end
    if isfield(options,'bRatioSkeleton'),        bRatioSkeleton = options.bRatioSkeleton; end    
    if isfield(options,'OutName'),        OutName = options.OutName; end

end

if ~isfield(options,'iShapeSpace')
    options.iShapeSpace = DefaultShapeSpace;
end
if bSspace
    options.iShapeSpace = 3;
end
if options.iShapeSpace == 3 || options.iShapeSpace == 'S'
    bSspace = 1;
end

% Naming:
OutDir = fullfile(RootDir, OutName);
if ~exist(OutDir,'dir'), mkdir(OutDir); end
options.OutputDirectory = OutDir;

EncodingOutFile     = fullfile(OutDir, ['DofMatrices' ,StudyString,  '.mat']);

% The conditions can be encoded in either PostName or DirPostName
if isfield(options,'PostName') 
    Conditions = options.PostName; 
    if isfield(options,'DirPostName') 
        disp('ERROR! the two encoding options are not compatible\n');
    end
end
if isfield(options,'DirPostName') 
    Conditions = options.DirPostName; 
    if isfield(options,'PostName')
        disp('ERROR! the two encoding options are not compatible\n');
    end
end

if(bStep1EncodeContours)
    DofMatrices = USmeshing(RootDir,options);
    save(EncodingOutFile,'DofMatrices');
else
    if exist(EncodingOutFile,'file')
        fprintf('Loading matrix of dofs previously computed from %s\n',EncodingOutFile);
        load(EncodingOutFile,'DofMatrices');
    else
        fprintf('ERROR! No matrix with all degrees of freedom available (%s). Need to run shape encoding step\n',EncodingOutFile);
        return;
    end
end

% July 2018: control of naming output:
AtlasVersion = sprintf('Atlas%s\',StudyString');

% Hack to extract the name of the atlas out:
iView = iChamber;
AtlasFileName = sprintf('%s%ich.mat',AtlasVersion,iView);
if bSkeleton
    % Change the representation to an skeleton and thicnkess
    options.Encoding = 'skeleton';
    AtlasFileName = sprintf('%sSkel%ich.mat',AtlasVersion,iView);
end
if(bRatioSkeleton)
    options.Encoding = 'RatioSkeleton';
    AtlasFileName = sprintf('%sRatSkel%ich.mat',AtlasVersion,iView);
end
options.AtlasFileName = AtlasFileName;

if(bStep2MakeStatistics)
    % How many experimental conditions:
    nPos = size(DofMatrices.EndoCont2chMatrix,1);
    
    % Each view independently first:
    for iView = iChamber

        TotalDofs = Convert2DechoMatrices2Vectors(DofMatrices,iView,options);
        nCases = size(TotalDofs,1);
        iValid = 0;
        for iCase = 1:nCases
            if ~isnan(TotalDofs(iCase,:))
                iValid = iValid + 1;
                ValidDofs(iValid,:) = TotalDofs(iCase,:);
            else
                %fprintf('Not valid case: %i (%ich view)\n',iCase,iView);
            end
        end
        nValid = iValid; 
        fprintf('Analysis with %i valid cases (out of %i) in %ich view\n',nValid,nCases,iView);
        MeanDofs = mean(ValidDofs,1);
        if (bSspace)
            nDofs = numel(MeanDofs);  
            % Work with only the values, not the derivatives:
            MeanCoordDofs = MeanDofs(1:2:end);
            for iV = 1:size(ValidDofs,1)
                % Get only the coordinates, not the derivatives:
                CaseCoordDofs = ValidDofs(iV,1:2:end);                
                % Get the scale
                nDofsScale = nDofs/2;
                if (bScaleWithAllDofs)
                    scale(iV) = sqrt(sum( CaseCoordDofs.^2 ) ) / sqrt(sum(MeanCoordDofs.^2)) ;
                else
                    % Only with the first half of the dofs:
                    scale(iV) = sqrt(sum( CaseCoordDofs(1:nDofsScale).^2 ) ) / sqrt(sum(MeanCoordDofs(1:nDofsScale).^2)) ;
                end
                ValidDofs(iV,:) = ValidDofs(iV,:) / scale(iV);
            end
            % Check that the scale is correct
            MeanScale = mean(scale);
            figure; plot(scale); title(sprintf('Mean scale = %1.3f',MeanScale));
        end
                
                
        MatrixDofsWithoutMean = ValidDofs - repmat(MeanDofs,nValid,1);
        B = MatrixDofsWithoutMean;
        COV = B'*B/nValid;
        fprintf('Eigenanalysis of covariance matrix of size %ix%i\n',size(COV));
        [V,S] = eig(COV);
        ss = diag(S);

        AtlasFile = fullfile( OutDir, AtlasFileName);
        fprintf('Saving atlas %s\n',AtlasFile);
        save(AtlasFile,'V','ss','MeanDofs');
    end
end


% =========================================================================

% Any search for the dofs of each case:, for the retrieval of coordinates:
% options.KeyFileKind4Mapping = 'text';

% Visualization functions:
if(bStep3visualiceResults)
    %for iView = iChamber
    %    AtlasFileName = sprintf('Atlas%ich.mat',iView);
        options.AtlasFileName = AtlasFileName;
        H = ViewUSModalVariation(OutDir,iEig,Scale,options);
        %set(gcf,'units','normalized','outerposition',[0 0 1 1])
        pause(0.00001);
        frame_h = get(handle(gcf),'JavaFrame');
        set(frame_h,'Maximized',1);
        pause(0.1);
        export_fig(fullfile(OutDir, sprintf('Modes%s%ich.png',StudyString,iView)),'-png',H);
    %end    
end

if(bPlotVariancePerMode)
    for iView = iChamber
        load(fullfile(OutDir,sprintf('%s%ich.mat',AtlasVersion,iView)));
        variancePerEigenvalue = ss;
        RelativeEigenvalue = variancePerEigenvalue(end:-1:1)/sum(variancePerEigenvalue);

        Hvar = figure('color',[1 1 1]);
        Fsize = 12;
        colorVar = 'k';
        iEig2plot = 1:15;
        nModes2plotVar = 10;
        for iMode = iEig2plot
            CumulativeRelativeEigenvalue(iMode) = sum(RelativeEigenvalue(1:iMode));
        end
        subplot(1,2,1,'FontSize',Fsize); hold on;
        data = 100*RelativeEigenvalue(iEig2plot);
        hold on;
        plot(data(iEig2plot),[colorVar '*-'])    
        plot(data,colorVar)
        for id = 1:5, 
            iE = iEig2plot(id); 
            text(iE+2,data(iE)-0.2,sprintf('%1.2f%%',data(iE)),'FontSize',Fsize); 
        end
        xlabel('Mode of variation')
        ylabel('Relative explained variance (%)')
        subplot(1,2,2,'FontSize',Fsize); hold on;
        data = 100*CumulativeRelativeEigenvalue;
        plot(data(iEig2plot),[colorVar '*-'])    
        plot(data,colorVar)
        for id = 1:nModes2plotVar
            iE = iEig2plot(id)  ;
            text(iE+2,data(iE)-0.2,sprintf('%1.2f%%',data(iE)),'FontSize',Fsize);
        end
        xlabel('Mode of variation')
        ylabel('Cummulative explained variance (%)')
        %set(findall(Hvar,'type','text'),'FontName',Font)
    end
end


if(bMovieModalVariation)
%    for iView = iChamber
        options.iView = iView;
%        options.AtlasFileName = sprintf('Atlas%ich.mat',iView);
        MakeMovieUSModalVariation(OutDir,iEig,options);
%    end
end

if (bStep3_ViewEigenSpace)
    for iView = iChamber
        % There are independent coefficients in terms of the view:
        options.AtlasSurname = sprintf('%ich',iView);
        %options.AtlasFileName = sprintf('Atlas%ich.mat',iView);
        options.bRecalculateEigenCoords = bRecalculateEigenCoords;
        if(bConditionsIndependent)
            for iCond = 1:numel(Conditions)
                % And also coefficients in terms of the "condition" (birth or
                % follow-up 'fu' in the epoch cohort)
                options.iCond = iCond;
                H = GetEigenSpace(RootDir,[1 2],options);
                FigName = sprintf('Distribution%ich%s%s.png',iView,cell2mat(Conditions(iCond)),StudyString);
                export_fig([OutDir FigName],'-png','-m2',H);
            end
        else
            if exist('Conditions','var')
                options.iCond = 1:numel(Conditions);
            end            
            H = PlotEigenDistribution(RootDir,1:5,options);            
            FigName = sprintf('Distribution%ich%s_A.png',iView,StudyString);
            export_fig(fullfile(OutDir, FigName),'-png','-m2',H);
            H2 = PlotEigenDistribution(RootDir,6:10,options);            
            FigName = sprintf('Distribution%ich%s_B.png',iView,StudyString);
            export_fig(fullfile(OutDir, FigName),'-png','-m2',H2);
        end
    end
end

% =========================================================================
% Statistical functions:
% Too many warnings in the duplication of the FU cohort as another set
% of subjects:
optionsStats = options;

if(bStatisticalAnalysisByExcelFile)
    for iC1 = 1:numel(ClassDefinition)-1
        for iC2 = iC1+1:numel(ClassDefinition)
            for iView = iChamber   
                [coefficients,cases,~,ListCases] = GetEigenCoefficients(RootDir,optionsStats);
                iClass1 = GetIndexesPerClass(ClassDefinition,iC1,ListCases);
                iClass2 = GetIndexesPerClass(ClassDefinition,iC2,ListCases);

                coef4stats{1} = coefficients(:,iClass1);
                coef4stats{2} = coefficients(:,iClass2);
                % Global patient ID to save:
                optionsPaired = optionsStats;
                optionsPaired.cmpC = [1 2];
                [Hstat] = StatisticalComparisonBetweenClasses(coef4stats,optionsPaired);
            end
        end
    end
end

if(bStatistical_Analysis)
    for iView = iChamber        
        optionsStats.AtlasSurname = sprintf('%ich',iView);
        if(bPostNameAnalysis)
            for iC = 1:numel(Conditions)
                % The number of the condition is introduced, and this will capture
                % only the cases with the naming options.NamePost(iC), see inside
                % GetEigenCoefficients.m
                optionsStats.iCond = iC;
                if isfield(options,'PostName')||isfield(options,'DirPostName')
                    [coeff,cases,~,ListCases] = GetEigenCoefficients(RootDir,optionsStats);
                    iValid = ~isnan(coeff(1,:));
                    coefficients{iC} = coeff(:,find(iValid));
                    if(bPairedAnalysis)
                        ValidConditions{iC} = iValid;
                        AllCoefs{iC} = coeff;
                    end
                else
                    fprintf('ERROR! Need to provide a naming characteristic to differentiate classes\n');
                end
            end
            ConditionString = sprintf('%s_vs_%s',Conditions{1},Conditions{2});
        else
            optionsStats.iCond = iCondition2analyse;
            %optionsStats.AtlasFileName = sprintf('Atlas%ich.mat',iView);
            [coefficients,cases,~,ListCases] = GetEigenCoefficients(RootDir,optionsStats);
            optionsStats.ListCases = ListCases;
            if exist('Conditions','var')
                ConditionString = sprintf('%s',Conditions{iCondition2analyse});
            else
                ConditionString = '';
            end
        end
        StringStudy = sprintf('Study%s%ich%s',StudyString,iView,ConditionString);
        optionsStats.StringStudy = StringStudy;
        optionsStats.nCoefsMax2IncludeT = 10;
        [Hstat] = StatisticalComparisonBetweenClasses(coefficients,optionsStats);
        export_fig(fullfile(OutDir,[ 'P_values' StringStudy '.png']),'-png',Hstat);
        if(bPairedAnalysis)
            % List of paired cases:
            if exist('ValidConditions','var')
                iV = and(ValidConditions{1},ValidConditions{2});
                for iC=1:2
                    coeff = AllCoefs{iC};
                    coefficients{iC} = coeff(:,find(iV));
                    % Now generate a list with all cases, and NaN all that are
                    % not valid:
                    values = NaN*ones(size(coeff));
                    values(:,find(iV)) = coeff(:,find(iV));
                    coefficientsALL{iC} = values; 
                end
                remodelling = coefficientsALL{1} - coefficientsALL{1};
                [Hstat] = StatisticalComparisonBetweenClasses(coefficients,optionsStats);
                export_fig(fullfile(OutDir,[ 'P_values' sprintf('Study%sPAIRED%ich%s',StudyString, iView,ConditionString) '.png']),'-png',Hstat);
            else   
                coeff = coefficients;
                coeffremod = NaN*ones(size(coefficients));
                Cases2include = [];
                for iBirth = 1:2
                    switch iBirth
                        case 1, iC1 = 1; iC2 = 3; ConditionString = 'pre-term';
                        case 2, iC1 = 2; iC2 = 4; ConditionString = 'term';
                    end
                    % The codification: FU has an ID+1000:
                    [IDClass1] = [ClassDefinition(iC1).PatID]; 
                    [IDClass2] = [ClassDefinition(iC2).PatID]; 
                    iV = intersect(IDClass1,IDClass2-1000);
                    % Now get the relative index:
                    % ... all the cases in each class:
                    iClass1 = GetIndexesPerClass(ClassDefinition,iC1,ListCases);
                    iClass2 = GetIndexesPerClass(ClassDefinition,iC2,ListCases);
                    % iClass1 has the same elements as IDClass1, the first
                    % is the local index, the second is the global index.
                    for ii = 1:numel(iV)
                        ID = iV(ii);
                        I1(ii) = find(IDClass1 == ID);
                        I2(ii) = find(IDClass2-1000 == ID);
                    end
                    coef4stats{1} = coeff(:,iClass1(I1));
                    coef4stats{2} = coeff(:,iClass2(I2));
                    remodelling{iBirth} = coef4stats{2} - coef4stats{1};
                    coeffremod(:,iClass1(I1)) = coef4stats{2} - coef4stats{1};
                    % Global patient ID to save:
                    Cases2include = [Cases2include , IDClass1(I1)];
                    optionsPaired = optionsStats;
                    optionsPaired.cmpC = [1 2];
                    [Hstat] = StatisticalComparisonBetweenClasses(coef4stats,optionsPaired);
                    filename  = [ 'P_values' sprintf('Study%sPAIRED%ich%s',StudyString, iView,ConditionString) '.png'];
                    export_fig(fullfile(OutDir,filename),'-png',Hstat);
                end                
            end            
            
            % Extract the "remodelling" per case:            
            %AtlasFileName = sprintf('Atlas%ich.mat',iView);
            load(fullfile( OutDir, AtlasFileName));
            optionsStats.cmpC = [1 2];
%             Growth = remodelling + repmat(MeanDofs',1,size(remodelling,2));
%             Growth{1} = remodelling{1} + repmat(MeanDofs',1,size(remodelling{1},2));
%             Growth{2} = remodelling{2} + repmat(MeanDofs',1,size(remodelling{2},2));
            [Hstat] = StatisticalComparisonBetweenClasses(remodelling,optionsStats);
            export_fig(fullfile(OutDir,[ 'P_values' sprintf('Study%sREMODELLING%ich%s',StudyString, iView,ConditionString) '.png']),'-png',Hstat);            
            if(bLDAremodelling)
                optionsLDA.Cases2include = Cases2include;
                optionsLDA.OutputDirectory = OutDir;
                if(0)
                    for iGM = 1:10
                        GM{iGM} = 1:iGM;
                    end
                    optionsLDA = options;           
                    optionsLDA.bPredictive = 1;
                    [AUCs,iSignifDif,Sensitivities,Specificities,LDAout,OptPoint] = AtlasLinearDiscriminantAnalysis(GM,coeffremod,ClassDefinition,ListCases,V,optionsLDA);                
                    %options.nLeaveOut = 2;
                    %[AUCsN2] = AtlasLinearDiscriminantAnalysis(GM,coefs,ClassDefinition,ListCases,V,options);
                    optionsLDA.bPredictive = 0;
                    [resubAUCs] = AtlasLinearDiscriminantAnalysis(GM,coeffremod,ClassDefinition,ListCases,V,optionsLDA);    

                    HsummaryPred = figure('color',[1 1 1]);
                    pThreshold = 0.01;
                    nG = numel(GM);
                    [hp,ha1,ha2] = plotyy(1:nG,resubAUCs,1:nG,log10(LDAout.Significances));
                    set(ha1,'LineStyle','-.')
                    hold on;
                    %plot(1:nG,AUCsN2,'r');
                    plot(1:nG,AUCs,'k');                
                    % plot limits of goodness:
                    Lim1=ones(1,nG)*0.7;
                    Lim2=log10(ones(1,nG)*pThreshold);
                    [hpl,hl1,hl2] = plotyy(1:nG,Lim1,1:nG,Lim2);
                    set(hl1,'LineStyle',':')
                    set(hl2,'LineStyle',':')
                    set(hp(1),'ylim',[0.5 1])
                    set(hpl(1),'ylim',[0.5 1])
                    set(hp(2),'ylim',[-10 0])
                    set(hpl(2),'ylim',[-10 0])
                    xlabel('LDA combining PCA modes from 1 to x'); 
                    %ylabel('AUC: resub.(k), leave-1(b), leave-2(r)');
                    %ylabel('AUC: resubstitution(k), cross-validation(b)');
                    ylabel('AUC'); legend('resubstitution','cross-validation','location','NorthWest');               
                    ylabel(hp(2),'log(p)');           
                    FigName = fullfile(OutDir,sprintf('PredictiveSummary_Growth.png'));
                    export_fig(FigName,'-png','-m2',HsummaryPred);
                end                
                
                
                
                % Best combination:
                GM = 1:10;
                optionsLDA.bPredictive = 0;
                [AUCs,iSignifDif,Sensitivities,Specificities,LDAout,OptPoint] = AtlasLinearDiscriminantAnalysis({GM},coeffremod,ClassDefinition,ListCases,V,optionsLDA);
                LDAout.MeanDofs = MeanDofs;
                options.bPlotSeparate = 0;
                PlotLDAspace(LDAout,coeffremod,RootDir,GM,options)
                
                coefs = LDAout.wC;
                bGaussians = 0;
                Hbp = figure('color',[1 1 1],'OuterPosition',[50 50 500 250]); hold on
                MkSize = 10;
                LnWidth= 1.5;
                % Plot the (-2std +2std) interval:
                NumberSTDS = 3;
                S1 = NumberSTDS*LDAout.Std;
                ColourChoice = 1;

                plot([-S1,S1],[0 0],'LineWidth',LnWidth,'Color',[.2 .2 .2]);
                plot(0,0,'+','MarkerEdgeColor',GetAtlasColor(1,2),'MarkerSize',MkSize,'LineWidth',LnWidth);
                plot(S1,0,'+','MarkerEdgeColor',GetAtlasColor(2,2),'MarkerSize',MkSize,'LineWidth',LnWidth);
                plot(-S1,0,'+','MarkerEdgeColor',GetAtlasColor(3,2),'MarkerSize',MkSize,'LineWidth',LnWidth);            
                for iC = 1:2
                    iClass(iC) = iC;
                    Offset = 0.2*iC;
                    switch iC,
                        case 1, data = coefs(LDAout.I1);
                        case 2, data = coefs(LDAout.I2);
                    end
                    media(iC) = mean(data);
                    color = GetAtlasColor(iC,ColourChoice);
                    boxplot(data,'colors',color,'Position',Offset,'Orientation','horizontal','plotstyle','compact');%,'notch','on')
                end
                axis([-S1*1.1 S1*1.1 -0.2 0.6]);                
                title(sprintf('Preterm (n=%i) vs term (n=%i), p=%1.5f',numel(LDAout.I1),numel(LDAout.I2),LDAout.Significances(1)))
                axis off;
                 
                FigName = fullfile(OutDir,sprintf('BoxPlotsLDA_Growth.png'));
                export_fig(FigName,'-png','-m2',Hbp);

                
            end
        end
        clear('optionsStats');
    end
end

% =========================================================================
% Helping the interpreation of results
if(bViewAverageShapes)||bViewCase
    % How many experimental conditions:
    nPos = size(DofMatrices.EndoCont2chMatrix,1);    
    % Each view independently first:
    Hmean = figure('color',[1 1 1],'OuterPosition',[50 200 1600 1000]);
    HmeanTh = figure('color',[1 1 1],'OuterPosition',[50 200 1600 1000]);
   
    for iView = iChamber        
        optionsStats = options;
        optionsStats.bDebugDofSearch = 0;
        optionsStats.AtlasSurname = sprintf('%ich',iView);
        %optionsStats.AtlasFileName = sprintf('Atlas%ich.mat',iView);
        if(0)
            % old analysis based on condition:
            for iC=1:2
                options.iCon = iC;
                DofVectors = Convert2DechoMatrices2Vectors(DofMatrices,iView,options)';
                optionsStats.iCond = iC;
                if ~isfield(options,'PostName')&&~isfield(options,'DirPostName')
                    fprintf('ERROR! Need to provide a naming characteristic to differentiate classes\n');
                else
                    % Get all coefficients corresponding to experimental condition iC 
                    [coeff,cases,~,ListCases] = GetEigenCoefficients(RootDir,optionsStats);
                    bValid = ~isnan(coeff(1,:));                
                    % Get the indexes of each class (pre-term vs. term):            
                    [iClass1] = GetIndexesPerClass(ClassDefinition,1,ListCases);
                    [iClass2] = GetIndexesPerClass(ClassDefinition,2,ListCases);
                    % Select the valid cases:
                    Dofs1 = DofVectors(:,intersect(find(bValid),iClass1));
                    Dofs2 = DofVectors(:,intersect(find(bValid),iClass2));
                    % Get the average coeffs:
                    Mean1 = mean(Dofs1,2); n1 = size(Dofs1,2);
                    Mean2 = mean(Dofs2,2); n2 = size(Dofs2,2);
                    % Overlay the two average contours:
                    iPlot = (iView-1) + 3*(iC-1);
                    subplot(2,3,iPlot)
                    hold on;
                    PlotEchoContours(Mean1,GetAtlasColor(1,ColourChoice));
                    PlotEchoContours(Mean2,GetAtlasColor(2,ColourChoice));
                    title(sprintf('Average %ich at %s. (n=%i) vs (n=%i)',iView,Conditions{iC},n1,n2));
                end
            end
        else
            bPoints = 1;
            LnWidth =1.5;
            for bPlotThickness = 0:1
                if(bPlotThickness)
                    figure(HmeanTh);
                    bEpiOnly = 1;
                else
                    figure(Hmean);
                    bEpiOnly = 0;
                end
                % New analysis based on 4 classes:
                [coeff,cases,~,ListCases] = GetEigenCoefficients(RootDir,optionsStats);
                bValid = ~isnan(coeff(1,:));  
                DofVectors = Convert2DechoMatrices2Vectors(DofMatrices,iView,options)';
                if bViewCase
                    Dofs = DofVectors(:,iCases);
                    for iC = 1:numel(iCases)
                        PlotEchoContours(Dofs(:,iC),GetAtlasColor(iC,1),LnWidth,bPoints);
                    end
                else
                    MeanDofs = mean(DofVectors,2);
                    MeanCoordDofs = MeanDofs(1:2:end);
                    switch optionAverages
                        case 1
                            % Compare in pairs
                            nPlots = length(combnk(1:numel(ClassDefinition),2));
                            f = factor(nPlots); iPlot = 0;
                            for iC1 = 1:numel(ClassDefinition)-1
                                for iC2 = iC1+1:numel(ClassDefinition)
                                    % Get the indexes of each class (pre-term vs. term):            
                                    [iClass1] = GetIndexesPerClass(ClassDefinition,iC1,ListCases);
                                    [iClass2] = GetIndexesPerClass(ClassDefinition,iC2,ListCases);
                                    % Select the valid cases:
                                    Dofs1 = DofVectors(:,intersect(find(bValid),iClass1));
                                    Dofs2 = DofVectors(:,intersect(find(bValid),iClass2));
                                    % Get the average coeffs:
                                    Mean1 = mean(Dofs1,2); n1 = size(Dofs1,2);
                                    Mean2 = mean(Dofs2,2); n2 = size(Dofs2,2);
                                    % Overlay the two average contours:
                                    iPlot = iPlot+1;
                                    %if iC2 == 4 && iC1 == 3, iPlot = 4; end
                                    if(nPlots)>3
                                        subplot(f(1),f(2),iPlot)
                                    else
                                        subplot(1,nPlots,iPlot)
                                    end
                                    hold on;
                                    PlotEchoContours(Mean1,GetAtlasColor(iC1,ColourChoice),LnWidth,bPoints);
                                    PlotEchoContours(Mean2,GetAtlasColor(iC2,ColourChoice),LnWidth,bPoints);
                                    title(sprintf('Average %ich. %i(n=%i) vs %i(n=%i)',iView,iC1,n1,iC2,n2));
                                end
                            end
                        case 2
                            % Compare all together:      

                            for iC1 = 1:numel(ClassDefinition)
                                [iClass1] = GetIndexesPerClass(ClassDefinition,iC1,ListCases);
                                Dofs1 = DofVectors(:,intersect(find(bValid),iClass1));
                                if bSspace
                                    for icase = 1:size(Dofs1,2)
                                        CaseCoordDofs = Dofs1(:,icase);
                                        if (bScaleWithAllDofs)
                                            scale(icase) = sqrt(sum( CaseCoordDofs.^2 ) ) / sqrt(sum(MeanCoordDofs.^2)) ;
                                        else
                                            % Only with the first half of the dofs:
                                            scale(icase) = sqrt(sum( CaseCoordDofs(1:nDofsScale).^2 ) ) / sqrt(sum(MeanCoordDofs(1:nDofsScale).^2)) ;
                                        end
                                        Dofs1(:,icase) = Dofs1(:,icase) / scale(icase);
                                    end
                                end
                                Mean1 = mean(Dofs1,2); 
                                Std1 = std(Dofs1,0,2); 
                                n1 = size(Dofs1,2);
                                hold on;
                                if(bPlotThickness)
                                    PlotEchoThickness(Mean1,GetAtlasColor(iC1,ColourChoice),LnWidth,bPoints);
                                    if(0)
                                        dofs2 = zeros(size(Mean1));
                                        dofs2(1:2:end) = Mean1(1:2:end) + Std1(1:2:end);
                                        PlotEchoThickness(dofs2,GetAtlasColor(iC1,ColourChoice),LnWidth/2,bPoints);
                                        dofs2(1:2:end) = Mean1(1:2:end) - Std1(1:2:end);
                                        PlotEchoThickness(dofs2,GetAtlasColor(iC1,ColourChoice),LnWidth/2,bPoints);
                                    end
                                else
                                    PlotEchoContours(Mean1,GetAtlasColor(iC1,ColourChoice),LnWidth,bPoints,bEpiOnly);
                                end
                            end
                            if(~bPlotThickness)
                                plot(0,0,'ok');
                                x=0:-1/100:-pi; plot(2*sin(x),2*cos(x),':k');
                                x=0:-1/100:-pi; plot(2.5*sin(x),2.5*cos(x),':k');
            %                     x=0:-1/100:-pi; plot(3*sin(x),3*cos(x),':k');
            %                     x=0:-1/100:-pi; plot(3.5*sin(x),3.5*cos(x),':k');
            %                     x=0:-1/100:-pi; plot(4*sin(x),4*cos(x),':k');
                            else
                                ylabel('Thickness (mm)')
                                xlabel('anatomical point')
                                set(gca,'XTick',[0 6 12]);
                                set(gca,'XTickLabel',{'Base(septum)','apex','Base(free wall)'})
                            end
                            grid minor
                            title(sprintf('Comparison of averages'));
                        case 3
                            % All individually
                            for iC1 = 1:4
                                subplot(2,2,iC1)
                                [iClass1] = GetIndexesPerClass(ClassDefinition,iC1,ListCases);
                                Dofs1 = DofVectors(:,intersect(find(bValid),iClass1));
                                Mean1 = mean(Dofs1,2); n1 = size(Dofs1,2);
                                hold on;
                                PlotEchoContours(Mean1,GetAtlasColor(iC1,ColourChoice),LnWidth,bPoints);
                            end
                    end
                end
                if(bPlotThickness)
                    export_fig(fullfile(OutDir, sprintf('AverageThickness%s_v%i.png',StudyString,optionAverages)),'-png',HmeanTh);            
                else
                    export_fig(fullfile(OutDir, sprintf('Averages%s_v%i.png',StudyString,optionAverages)),'-png',Hmean);            
                end
            end
        end
    end    
end